"""Offline v9.2 validation entry point; no board/serial access."""
from pathlib import Path
import argparse,hashlib,io,json,sys,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick',action='store_true')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    from clean_capture import enable_dpi_awareness
    enable_dpi_awareness()
    names=['test_v92_fixes','test_v92_strokes','test_v92_semantics']
    if not args.quick:
        names=['test_protocol','test_wave_monitor','test_autoswing_monitor',
               'test_position_monitor','test_unified_monitor','test_unified_runtime',
               'test_centered_profiles','test_amfm_monitor','test_derivative_filter_status',
               'test_clean_semantics','test_clean_monitor','test_clean_performance',
               'test_v91_fixes']+names
    # Agent-owned specialized modules are optional until integrated.
    names=[n for n in names if (ROOT/'tests'/f'{n}.py').exists() or (ROOT/'monitor'/f'{n}.py').exists()]
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
    stream=io.StringIO();result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    from test_v92_fixes import REAL_PATH,envelope_report
    data={'version':'v9.2','success':result.wasSuccessful(),'tests':result.testsRun,
          'skipped':[(str(t),r) for t,r in result.skipped],
          'failures':[(str(t),trace) for t,trace in result.failures],
          'errors':[(str(t),trace) for t,trace in result.errors],
          'real_record':str(REAL_PATH),'real_firmware_CF':'CB045654',
          'envelope_coverage':envelope_report(),
          'reference_style':'#C44E52 muted red rounded arc-length dashes',
          'actual_style':'#4C72B0 solid','envelope_style':'#C59A3D solid',
          'serial_port_opened':False,'FPGA_modified':False}
    if args.output:
        data['source_sha256']={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for folder in ('monitor','config','tests') for p in (ROOT/folder).glob('*')
            if p.suffix in ('.py','.json','.cmd') and not p.name.endswith('_result.json')}
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in data.items() if k!='source_sha256'},ensure_ascii=False,indent=2))
    if not result.wasSuccessful():print(stream.getvalue(),file=sys.stderr)
    return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())

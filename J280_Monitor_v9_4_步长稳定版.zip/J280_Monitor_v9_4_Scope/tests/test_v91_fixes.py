"""v9.1 regression checks for the user's four requested presentation fixes.

Everything is offline. Synthetic immutable X frames and at most one matching
row from an existing recording exercise the real parser; no COM port is opened.
"""
from pathlib import Path
import csv, io, math, sys, tempfile, tkinter as tk, unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
sys.path.insert(0,str(ROOT/'tests'))
from clean_monitor import CleanMonitor, REFERENCE, ACTUAL, ENVELOPE
from clean_widgets import CleanPlot
from clean_semantics import mode_status
from unified_protocol import decode_unified, UnifiedHistory
from test_clean_monitor import frame
import amfm_semantics as semantics

KNOWN=0xC1020D3F
LEGACY_NAMES=('梯形','七段','正弦')
REAL_RECORDS=ROOT/'monitor'/'records'
REAL_SAMPLE=None

def rgb(value):
    return tuple(int(value[i:i+2],16) for i in (1,3,5))

def missing_config():
    return patch.object(semantics,'SEMANTICS_PATH',ROOT/'tests'/'__intentionally_missing_config__.json')

def first_real_modulated_frame():
    """Read only until one qualifying frame, never materialize the CSV."""
    global REAL_SAMPLE
    if REAL_SAMPLE is not None:return REAL_SAMPLE
    if not REAL_RECORDS.is_dir():return None
    for path in sorted(REAL_RECORDS.glob('*_unified.csv'),reverse=True):
        with path.open(encoding='utf-8-sig',newline='') as stream:
            for row_number,row in enumerate(csv.DictReader(stream),2):
                # Bound the optional local fixture scan to a small prefix.
                if row_number>2000:break
                raw=row.get('raw_line','')
                if 'CF=C1020D3F' not in raw:continue
                f=decode_unified(raw)
                if f.active_trajectory_profile in (1,2,3) and f.trajectory_phase==2 and f.flag(5):
                    REAL_SAMPLE=(f,path.name,row_number)
                    return REAL_SAMPLE
    return None

class V91SemanticTests(unittest.TestCase):
    def test_known_tag_without_external_config_has_correct_labels(self):
        with missing_config():
            for dip,word in ((1,'AM'),(2,'FM'),(3,'心形')):
                f=frame(D=dip,J=dip)
                m=mode_status(f)
                self.assertIn(word,m['selected'])
                self.assertIn(word,m['actual'])
                self.assertFalse(any(old in m['selected'] for old in LEGACY_NAMES))

    def test_am_envelope_is_bipolar_maximum_and_one_third(self):
        with missing_config():
            for elapsed,half in ((0,30.),(15750,10.),(31500,30.)):
                f=frame(D=1,J=1,CL=31500,TA=300,EL=elapsed)
                self.assertAlmostEqual(semantics.upper_envelope_degrees(f),half,places=5)
                self.assertAlmostEqual(semantics.lower_envelope_degrees(f),-half,places=5)

    def test_fm_envelope_and_labels_use_active_profile_not_dip(self):
        with missing_config():
            f=frame(D=3,J=2,CL=30000,TA=900,TE=560)
            self.assertEqual(semantics.upper_envelope_degrees(f),90.)
            self.assertEqual(semantics.lower_envelope_degrees(f),-90.)
            m=mode_status(f)
            self.assertIn('心形',m['selected']);self.assertIn('FM',m['actual'])
            self.assertTrue(m['pending'])

    def test_heart_56_and_59_seconds_use_board_cycle(self):
        with missing_config():
            for cycle,gap in ((56000,0),(59000,3)):
                f=frame(J=3,D=3,CL=cycle,EL=28000,TA=300)
                d=semantics.heart_data(f)
                self.assertIsNotNone(d);self.assertEqual(d['repeat_period_s'],cycle/1000)
                self.assertEqual(d['gap_s'],gap)
                self.assertGreater(semantics.upper_envelope_degrees(f),0)
                self.assertLess(semantics.lower_envelope_degrees(f),-29)
            h=frame(J=3,D=3,CL=59000,EL=57500,TA=300)
            self.assertEqual(semantics.upper_envelope_degrees(h),0.)
            self.assertEqual(semantics.lower_envelope_degrees(h),0.)

    def test_unknown_tag_never_invents_legacy_names_or_envelopes(self):
        with missing_config():
            for j in (1,2,3):
                f=frame(CF=0xDEADBEEF,J=j,D=j)
                m=mode_status(f)
                self.assertFalse(any(old in m['selected']+' '+m['actual'] for old in LEGACY_NAMES),m)
                self.assertIsNone(semantics.upper_envelope_degrees(f))
                self.assertIsNone(semantics.lower_envelope_degrees(f))

    def test_real_user_c1020d3f_row_without_external_config(self):
        sample=first_real_modulated_frame()
        if sample is None:
            self.skipTest('Optional older C1020D3F recording unavailable; bundled CB045654 is tested separately')
        f,name,row_number=sample
        with missing_config():
            label=mode_status(f)['actual']
            expected={1:'AM',2:'FM',3:'心形'}[f.active_trajectory_profile]
            self.assertIn(expected,label)
            self.assertIsNotNone(semantics.upper_envelope_degrees(f))
            self.assertIsNotNone(semantics.lower_envelope_degrees(f))

class V91GuiTests(unittest.TestCase):
    def setUp(self):
        self.guard=patch('serial.Serial',side_effect=AssertionError('Offline verification must never open COM'))
        self.guard.start();self.addCleanup(self.guard.stop)
        self.root=tk.Tk()
        self.app=CleanMonitor(self.root,mode='replay',create_worker=False)
        self.root.geometry('1280x720')
        self.root.update()

    def tearDown(self):
        if not self.app.closing:self.app.close()

    def put(self,f):
        self.app.process_frame(f,1.,record=False)
        self.app.refresh_status();self.root.update_idletasks()
        self.app.mark_dirty();self.app.redraw()
        return self.app

    def test_all_dip_choices_always_visible_top_and_in_task_details(self):
        with missing_config():
            for dip,word in ((0,'定位'),(1,'AM'),(2,'FM'),(3,'心形')):
                a=self.put(frame(D=dip,J=2,CL=30000,TA=900,TE=450,E=123))
                top=a.mode_summary_var.get();details=a.task_compact_var.get()
                self.assertIn('拨码',top);self.assertIn(format(dip,'02b'),top)
                self.assertIn(word,top);self.assertIn('FM',top)
                self.assertIn(format(dip,'02b'),details.splitlines()[0])
                self.assertIn(word,details.splitlines()[0])
                self.assertIn('+12.3°' if dip==0 else '+45.0°',details.splitlines()[0])
                self.assertIn('FM',details.splitlines()[1]);self.assertIn('+90.0°',details.splitlines()[1])

    def test_idle_and_recovery_never_claim_running_positioning(self):
        for f in (frame(R=0,J=0,N=1,D=2),frame(M=6,J=0,D=1)):
            a=self.put(f);top=a.mode_summary_var.get();details=a.task_compact_var.get()
            self.assertIn('拨码',top);self.assertNotIn('执行 定位',top)
            self.assertNotIn('实际执行：定位',details)

    def test_curves_default_visibility_colours_and_styles(self):
        a=self.app
        self.assertEqual((REFERENCE,ACTUAL,ENVELOPE),('#C44E52','#4C72B0','#C59A3D'))
        pos={name:colour for name,colour,getter in a.primary_plot.series}
        speed={name:colour for name,colour,getter in a.speed_plot.series}
        self.assertEqual(pos['参考'],REFERENCE);self.assertEqual(pos['实际'],ACTUAL)
        self.assertEqual(pos['上包络'],ENVELOPE);self.assertEqual(pos['下包络'],ENVELOPE)
        self.assertEqual(speed['规划'],REFERENCE);self.assertEqual(speed['估算'],ACTUAL)
        for name in ('参考','实际','上包络','下包络'):self.assertNotIn(name,a.primary_plot.hidden)
        self.assertTrue(CleanPlot.is_dashed('参考'));self.assertTrue(CleanPlot.is_dashed('规划'))
        for name in ('实际','估算','上包络','下包络'):self.assertFalse(CleanPlot.is_dashed(name))

    def test_actual_raster_shows_two_yellow_envelopes_blue_dashes_and_red_solid(self):
        a=self.app;p=a.primary_plot
        # Fixed FM bounds +/-30; measured/reference traces are separated so no
        # curve occlusion can masquerade as a missing colour.
        h=UnifiedHistory()
        with missing_config():
            for i in range(61):
                f=frame(J=2,D=2,CL=30000,TA=300,H=0,P=11,RF=4,EP=0,
                        EL=i*100,Q=i,T=1000+i*100)
                h.append(f,i*.1,0)
            p.draw(h.window(6,6),6,6)
        self.root.update_idletasks()
        im=p.last_raster
        self.assertIsNotNone(im,'Pillow raster renderer required for visibility regression')
        w,hh=im.size
        pixel=[im.getpixel((x,y)) for y in range(hh) for x in range(w)];yellow=rgb(ENVELOPE);green=rgb(REFERENCE);red=rgb(ACTUAL)
        top=sum(px==yellow for px in pixel[:w*(hh//2)])
        bottom=sum(px==yellow for px in pixel[w*(hh//2):])
        self.assertGreater(top,w);self.assertGreater(bottom,w)
        columns=lambda c:sum(any((all(abs(a-b)<=45 for a,b in zip(im.getpixel((x,y)),c)) if c==green else im.getpixel((x,y))==c) for y in range(hh)) for x in range(w))  # antialiasing blends the2.5px reference into white
        gc,rc=columns(green),columns(red)
        self.assertGreater(gc,w*.45);self.assertLess(gc,w*.92)  # rounded dash caps occupy part of each gap
        self.assertGreater(rc,w*.90)

    def test_1280_window_retains_core_controls_and_metrics(self):
        a=self.put(frame())
        for item in (a.connect_button,a.port_box,a.pause_button,a.footer,*a.card_labels.values()):
            self.assertTrue(item.winfo_ismapped())
            x=item.winfo_rootx()-self.root.winfo_rootx();y=item.winfo_rooty()-self.root.winfo_rooty()
            self.assertGreaterEqual(x,0);self.assertGreaterEqual(y,0)
            self.assertLessEqual(x+item.winfo_width(),self.root.winfo_width()+1)
            self.assertLessEqual(y+item.winfo_height(),self.root.winfo_height()+1)
        self.assertIsNone(a.worker)

if __name__=='__main__':unittest.main(verbosity=2)

"""Independent compact-monitor semantics; no GUI, serial worker, or hardware."""
from pathlib import Path
from types import MappingProxyType
import sys,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
import amfm_semantics as a
import clean_semantics as c
from unified_protocol import FIELDS,UnifiedFrame
HEART=0xC1020D3F
GAP_HEART=0x9D59A150
BASE_FLAGS=(1<<3)|(1<<4)|(1<<5)|(1<<8)|(1<<9)|(1<<13)
def frame(version=0x8002,**kw):
 v={name:0 for _,_,name,_ in FIELDS}
 v.update(trajectory_config_tag=HEART,selected_dip_mode=3,reference_owner=1,
 active_trajectory_profile=3,balance_mode=5,system_active=1,calibrated=1,flags=BASE_FLAGS,
 trajectory_time_stretch=1,trajectory_cycle_ms=56000,trajectory_elapsed_ms=28000,
 trajectory_phase=2,accepted_trajectory_deci=560,selected_trajectory_edit_deci=560,
 sine_edit_deci=560,angle_adc=2965,center_adc=2955,actual_position_units=236,
 planner_reference_units=168,active_base_units=100,command_pct=35,actual_velocity_q8=256)
 v.update(kw);return UnifiedFrame(MappingProxyType(v),'offline synthetic',version)

class Cards(unittest.TestCase):
 def test_six_unconnected(self):
  d=c.dashboard_values(None)
  self.assertEqual(set(d),{'pole','pwm','direction','speed','position','reference'})
  self.assertTrue(all(v['value']=='—' for v in d.values()))
 def test_pole_adc_not_degrees(self):
  d=c.dashboard_values(frame())['pole']
  self.assertEqual(d['value'],'+10');self.assertIn('ADC',d['detail'])
  self.assertNotIn('°',d['value']+d['detail'])
  self.assertEqual(c.dashboard_values(frame(calibrated=0))['pole']['value'],'—')
 def test_command_sign_and_not_measured_direction(self):
  for u,name in [(35,'正向命令'),(-35,'反向命令'),(0,'停止命令')]:
   d=c.dashboard_values(frame(command_pct=u))
   self.assertEqual(d['pwm']['value'],f'{abs(u)}%');self.assertIn('给定',d['pwm']['detail'])
   self.assertEqual(d['direction']['value'],name);self.assertIn('非实测',d['direction']['detail'])
 def test_disabled_retains_given_value(self):
  d=c.dashboard_values(frame(flags=BASE_FLAGS & ~(1<<4),command_pct=-35))
  self.assertEqual(d['direction']['value'],'未使能')
  self.assertEqual(d['pwm']['value'],'35%');self.assertIn('未使能',d['pwm']['detail'])
 def test_speed_estimate(self):
  d=c.dashboard_values(frame(actual_velocity_q8=-256))['speed']
  self.assertAlmostEqual(float(d['value']),-360/408,places=2)
  self.assertIn('估算',d['detail']);self.assertIn('°/s',d['detail'])
 def test_position_error_sign(self):
  f=frame();d=c.dashboard_values(f)
  self.assertEqual(d['position']['value'],'+120.00°')
  self.assertEqual(d['reference']['value'],'+60.00°')
  self.assertEqual(c.tracking_error(f),60);self.assertIn('误差 +60.00°',d['reference']['detail'])
 def test_hold_and_position_no_FL5_required(self):
  for owner,j in [(0,0),(1,3)]:
   f=frame(reference_owner=owner,active_trajectory_profile=j,flags=BASE_FLAGS & ~(1<<5))
   self.assertTrue(c.tracking_available(f));self.assertEqual(c.tracking_error(f),60)
 def test_tracking_inapplicable(self):
  for kw in [dict(system_active=0),dict(balance_mode=2),dict(balance_mode=3),
  dict(balance_mode=4),dict(balance_mode=6),dict(fault=2),dict(flags=BASE_FLAGS & ~(1<<3))]:
   f=frame(**kw)
   self.assertFalse(c.tracking_available(f),kw);self.assertIsNone(c.tracking_error(f))
   self.assertNotIn('误差 +',c.dashboard_values(f)['reference']['detail'])
 def test_invalid_base(self):
  d=c.dashboard_values(frame(flags=BASE_FLAGS & ~(1<<3)))
  self.assertEqual(d['position']['value'],'—');self.assertEqual(d['reference']['value'],'—')
 def test_actual_mode_not_selected(self):
  d=c.mode_status(frame(selected_dip_mode=2,active_trajectory_profile=3))
  self.assertIn('心形',d['actual']);self.assertIn('FM',d['selected']);self.assertTrue(d['pending'])
 def test_wait_real_takeover(self):
  f=frame(reference_owner=0,active_trajectory_profile=0,selected_dip_mode=3)
  self.assertTrue(c.mode_status(f)['pending']);self.assertNotIn('心形',c.mode_status(f)['actual'])
  self.assertFalse(c.mode_status(frame(balance_mode=3))['pending'])
  self.assertIn('自动起摆',c.mode_status(frame(balance_mode=3))['actual'])
 def test_stopped_and_fault(self):
  self.assertEqual(c.mode_status(frame(system_active=0))['status'],'已停止')
  self.assertIn('角度超范围',c.mode_status(frame(fault=2))['status'])

class HeartTiming(unittest.TestCase):
 def test_registered56(self):
  h=a.heart_data(frame())
  self.assertEqual(h['period_s'],56);self.assertEqual(h['repeat_period_s'],56)
  self.assertEqual(h['gap_s'],0);self.assertAlmostEqual(h['lower_degrees'],-56)
 def test_v_only59_reported_cycle(self):
  h=a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=57500))
  self.assertEqual(h['period_s'],56);self.assertEqual(h['repeat_period_s'],59)
  self.assertEqual(h['gap_s'],3);self.assertTrue(h['holding'])
  self.assertEqual((h['upper_degrees'],h['lower_degrees']),(0.,0.))
  self.assertIn('56s心形＋3s保持',a.heart_summary(h))
 def test_explicit_gap_tag(self):
  self.assertIsNotNone(a.heart_config(GAP_HEART))
  h=a.heart_data(frame(trajectory_config_tag=GAP_HEART,trajectory_cycle_ms=59000,trajectory_elapsed_ms=58000))
  self.assertEqual(h['gap_s'],3);self.assertEqual((h['upper_degrees'],h['lower_degrees']),(0.,0.))
 def test_300_hold_samples(self):
  for t in range(56000,59000,10):
   h=a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=t))
   self.assertEqual((h['upper_degrees'],h['lower_degrees']),(0.,0.))
 def test_original_shape_and59s_phase(self):
  for t in range(0,56000,10):
   h0=a.heart_data(frame(trajectory_elapsed_ms=t))
   h1=a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=t))
   h2=a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=t+59000))
   pair=lambda h:(h['upper_degrees'],h['lower_degrees'])
   self.assertEqual(pair(h0),pair(h1));self.assertEqual(pair(h1),pair(h2))
 def test_mirror_pending_edit_independent(self):
  for t in (0,10,1500,10000,28000,55990,56000,59000,60000):
   pos=a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=t))
   neg=a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=t,
     accepted_trajectory_deci=-560,selected_trajectory_edit_deci=900,sine_edit_deci=900))
   self.assertEqual(pos['upper_degrees'],-neg['lower_degrees'])
   self.assertEqual(pos['lower_degrees'],-neg['upper_degrees'])
   self.assertEqual(neg['maximum_absolute_degrees'],56)
 def test_elapsed_not_uptime(self):
  self.assertEqual(a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=57000,uptime_ms=57000)),
   a.heart_data(frame(trajectory_cycle_ms=59000,trajectory_elapsed_ms=57000,uptime_ms=900000)))
 def test_unknown_and_legacy_not_guessed(self):
  for tag in (0xDEADBEEF,0xB5FBC6B6):
   self.assertIsNone(a.heart_config(tag));self.assertIsNone(a.heart_data(frame(trajectory_config_tag=tag)))
   self.assertNotIn('心形',a.profile_label(3,tag,'普通正弦'))
 def test_invalid_timing_old_protocol_rejected(self):
  for kw in [dict(trajectory_cycle_ms=55000),dict(trajectory_cycle_ms=59001),
   dict(trajectory_cycle_ms=700000),dict(trajectory_time_stretch=2),dict(trajectory_cycle_ms=True),
   dict(reference_owner=0),dict(flags=BASE_FLAGS & ~(1<<5))]:
   self.assertIsNone(a.heart_data(frame(**kw)),kw)
  self.assertIsNone(a.heart_data(frame(version=0x8001)))
 def test_exit_envelopes_hidden(self):
  f=frame(trajectory_cycle_ms=59000,trajectory_phase=3,trajectory_elapsed_ms=20000)
  self.assertIsNone(a.upper_envelope_degrees(f));self.assertIsNone(a.lower_envelope_degrees(f))
 def test_direct_metadata_gap(self):
  h=dict(a.heart_config(HEART),gap_ms=3000)
  self.assertEqual(a.heart_bounds_at(57500,560,h),(0.,0.))
  self.assertEqual(a.heart_bounds_at(1000,560,h),a.heart_bounds_at(60000,560,h))
 def test_invalid_metadata_gap_rejected(self):
  original=a.config_for_tag;h=a.heart_config(HEART)
  try:
   for bad in (-1,1,True,3.0,float('nan')):
    a.config_for_tag=lambda tag,bad=bad:dict(heart=dict(h,gap_ms=bad))
    self.assertIsNone(a.heart_config(HEART),bad)
  finally:a.config_for_tag=original

if __name__=='__main__':unittest.main(verbosity=2)

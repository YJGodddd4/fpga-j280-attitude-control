"""Offline screenshots of AM, FM and heart monitoring, no serial port."""
from pathlib import Path
import math,sys,tkinter as tk
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness,capture_window
from clean_monitor import CleanMonitor
from unified_monitor import mod_stop_meaning,sw4_meaning
from test_clean_monitor import frame
from amfm_semantics import heart_config,heart_bounds_at

def reference(profile,t):
    if t<0:return 0.
    if profile==1:
        amp=30*(2+math.cos(2*math.pi*t/31.5))/3
        return amp*math.sin(2*math.pi*t/3.5)
    if profile==2:
        phase=2*math.pi*(.3*t-.2*30/(2*math.pi)*math.sin(2*math.pi*t/30))
        return 30*math.sin(phase)
    cfg=heart_config(0xC1020D3F).copy();cfg['gap_ms']=3000
    up,low=heart_bounds_at(round(t*1000),560,cfg)
    local=t%59
    return (up+low)/2-(up-low)/2*math.cos(2*math.pi*local/4) if local<56 else 0.

def main():
    enable_dpi_awareness()
    destination=ROOT/'previews';destination.mkdir(exist_ok=True)
    results=[]
    with patch('serial.Serial',side_effect=AssertionError('Screenshot fixture must never open a COM port')):
        root=tk.Tk();app=CleanMonitor(root,mode='demo',create_worker=False)
        root.geometry('1366x768');root.update()
        app.toggle_task_details()
        app.span_var.set('60')
        for profile,name,cycle,accepted,end in ((1,'AM',31500,300,63.),
                                               (2,'FM',30000,300,60.),
                                               (3,'Heart',59000,560,59.)):
            app.history.clear();app.last_frame=None;app._loading_replay=True
            for i in range(round(end/.05)+1):
                t=i*.05;q=reference(profile,t)
                v=(reference(profile,t+.005)-reference(profile,max(0,t-.005)))/(.01 if t else .005)
                actual=reference(profile,max(0,t-.04))+2.*math.sin(1.7*t)
                w=(reference(profile,max(0,t-.020))-reference(profile,max(0,t-.030)))/(.01 if t>=.03 else .03)
                unit=408/360
                f=frame(D=profile,J=profile,CL=cycle,TA=accepted,TE=accepted,
                        EA=300,EB=300,EC=560,H=0,EP=0,P=round(actual*unit),RF=round(q*unit),
                        Y=round(q*unit),V=round(v*unit*256),W=round(w*unit*256),
                        A=2955+round(3*math.sin(1.7*t)),C=2955,U=round(12*math.sin(2*math.pi*t/4)),
                        EL=round(t*1000),Q=i,T=1000+round(t*1000),PH=2,FL=0x623f,
                        CY=int(t//(cycle/1000)))
                app.history.append(f,t,app.connection_segment);app.last_frame=f;app.valid+=1
            app.sw4_var.set(mod_stop_meaning(f) or sw4_meaning(f))
            app._loading_replay=False;app._setup_replay();app._sync_frame();app.refresh_status()
            app.connect_button.configure(state='disabled')
            root.update();app.mark_dirty();app.redraw();root.update()
            assert app.worker is None and app.recorder is None
            assert app.task_frame.winfo_ismapped() and app.task_details.get()
            assert '拨码' in app.mode_summary_var.get()
            path=destination/f'v91_{name}_1366x768.png'
            capture_window(root,path)
            results.append(str(path))
            if profile==2:
                app.open_zoom(app.primary_plot)
                win,plot,original=app._zoom_windows[-1]
                win.geometry('1366x768');root.update()
                app.mark_dirty();app.redraw();root.update()
                zoom=destination/'v91_FM_zoom_1366x768.png'
                capture_window(win,zoom);results.append(str(zoom))
                win.withdraw()
        app.close()
    print('\n'.join(results))
    return 0

if __name__=='__main__':raise SystemExit(main())

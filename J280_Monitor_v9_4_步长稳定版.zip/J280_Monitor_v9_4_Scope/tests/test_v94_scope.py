"""Offline oscilloscope interaction regressions; serial access is forbidden."""
from pathlib import Path
import math
import sys
import tkinter as tk
import types
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'monitor'))
sys.path.insert(0, str(ROOT / 'tests'))
from clean_capture import enable_dpi_awareness
from clean_monitor import CleanMonitor
from clean_widgets import CleanPlot
from scope_controls import TIME_DIVS, scope_window_seconds, step_time_div
from test_clean_monitor import frame

enable_dpi_awareness()


def sample(t, reference, actual=None):
    return types.SimpleNamespace(t=t, segment=0, epoch=0,
        frame=types.SimpleNamespace(q=reference, p=reference if actual is None else actual))


class ScopeTimebaseTests(unittest.TestCase):
    def test_timebase_accepts_subsecond_windows_and_bounds_invalid_input(self):
        self.assertEqual(scope_window_seconds('.5'), .5)
        self.assertEqual(scope_window_seconds('2.5'), 2.5)
        self.assertEqual(scope_window_seconds('-1'), .5)
        self.assertEqual(scope_window_seconds('99999'), 1800.)
        for value in ('nan', 'inf', '-inf', 'invalid', None):
            with self.subTest(value=value):
                self.assertEqual(scope_window_seconds(value), 30.)

    def test_timebase_steps_follow_four_grid_divisions_and_saturate(self):
        spans = [float(value) * 4 for value in TIME_DIVS]
        self.assertEqual(spans, sorted(set(spans)))
        self.assertEqual((spans[0], spans[-1]), (.5, 1800.))
        for index, span in enumerate(spans):
            with self.subTest(span=span):
                self.assertEqual(step_time_div(span, 1), spans[max(0, index - 1)])
                self.assertEqual(step_time_div(span, -1), spans[min(len(spans) - 1, index + 1)])
        self.assertLess(step_time_div(30, 1), 30)
        self.assertGreater(step_time_div(30, -1), 30)


class ScopePlotTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.geometry('860x420')
        self.plot = CleanPlot(self.root, 'Position', 'degree', [
            ('参考', '#C44E52', lambda f: f.q),
            ('实际', '#4C72B0', lambda f: f.p)])
        self.plot.pack(fill='both', expand=True)
        self.root.update_idletasks()

    def tearDown(self):
        self.root.update_idletasks()
        self.root.destroy()

    def test_manual_scale_stays_fixed_as_data_and_legend_change(self):
        p = self.plot
        p.set_y_scale(5., center=10.)
        p.draw([sample(0, -100), sample(.1, 200)], .5, .5)
        self.assertEqual(p._cached_range, (0., 20.))
        p.toggle_series('参考')
        self.assertEqual(p._cached_range, (0., 20.))
        p.draw([sample(0, -1000), sample(.1, 2000)], .5, .5)
        self.assertEqual(p._cached_range, (0., 20.))
        self.assertEqual(p.y_per_div, 5.)
        self.assertEqual(p.y_center, 10.)

    def test_reset_restores_autoscale_and_new_units_do_not_reuse_old_scale(self):
        p = self.plot
        points = [sample(0, 100), sample(.1, 200)]
        p.set_y_scale(1., center=0.)
        p.draw(points, .5, .5)
        p.reset_y_scale()
        p.draw(points, .5, .5)
        self.assertIsNone(p.y_per_div)
        self.assertLessEqual(p._cached_range[0], 100.)
        self.assertGreaterEqual(p._cached_range[1], 200.)
        p.set_y_scale(1., center=12.)
        p.set_series('ADC', 'ADC counts', [('实际', '#4C72B0', lambda f: f.p)])
        self.assertIsNone(p.y_per_div)

    def test_scale_steps_are_monotonic_bounded_and_keep_center(self):
        p = self.plot
        p.set_y_scale(10., center=7.)
        p.step_y_scale(1)
        self.assertLess(p.y_per_div, 10.)
        self.assertEqual(p.y_center, 7.)
        p.step_y_scale(-1)
        self.assertEqual(p.y_per_div, 10.)
        for _ in range(100):
            p.step_y_scale(1)
        self.assertGreaterEqual(p.y_per_div, 1e-6)
        for _ in range(100):
            p.step_y_scale(-1)
        self.assertLessEqual(p.y_per_div, 1e9)
        self.assertTrue(math.isfinite(p.y_per_div))

    def test_zoom_changes_display_without_changing_sample_values(self):
        p = self.plot
        points = [sample(i * .1, math.sin(i), 2 * math.cos(i)) for i in range(6)]
        original = [(point.t, point.frame.q, point.frame.p) for point in points]
        p.draw(points, .5, .5)
        for scale in (10., 1., .01, 100.):
            p.set_y_scale(scale, center=1.)
            p.draw(points, .5, .5)
        self.assertEqual(original, [(point.t, point.frame.q, point.frame.p) for point in points])
        self.assertEqual(len(points), 6)

    def test_subsecond_axis_has_distinct_readable_tick_labels(self):
        p = self.plot
        p.draw([sample(0, 0), sample(.5, 1)], .5, .5)
        labels = [p.canvas.itemcget(item, 'text') for item in p._xl]
        self.assertEqual(len(labels), 5)
        self.assertEqual(len(set(labels)), 5, labels)
        self.assertTrue(any('.' in label or 'ms' in label for label in labels), labels)

    def test_canvas_fallback_clips_extreme_values_at_plot_border(self):
        p = self.plot
        p.set_y_scale(.01, center=0.)
        points = [sample(0, -1e12, 1e12), sample(.1, 1e12, -1e12), sample(.2, 1e12, 1e12)]
        with patch('clean_widgets.Image', None):
            p.draw(points, .5, .5)
        visible = []
        for pool in p._curves.values():
            for line, dot in pool:
                for item in (line, dot):
                    if p.canvas.itemcget(item, 'state') == 'hidden':
                        continue
                    coords = p.canvas.coords(item)
                    self.assertTrue(all(math.isfinite(value) for value in coords))
                    for x, y in zip(coords[::2], coords[1::2]):
                        self.assertGreaterEqual(x, p._x0 - 1.1)
                        self.assertLessEqual(x, p._x1 + 1.1)
                        self.assertGreaterEqual(y, p._y0 - 1.1)
                        self.assertLessEqual(y, p._y1 + 1.1)
                    visible.append(item)
        self.assertTrue(visible, 'Crossing the visible band must still draw the crossing')

    def test_hidden_offscreen_series_does_not_appear_on_canvas_border(self):
        p = self.plot
        p.set_y_scale(1., center=0.)
        with patch('clean_widgets.Image', None):
            p.draw([sample(0, 1e12), sample(.1, 1e12)], .5, .5)
        for pool in p._curves.values():
            for line, dot in pool:
                self.assertEqual(p.canvas.itemcget(line, 'state'), 'hidden')
                self.assertEqual(p.canvas.itemcget(dot, 'state'), 'hidden')


class ScopeMonitorTests(unittest.TestCase):
    def setUp(self):
        self.guard = patch('serial.Serial', side_effect=AssertionError('Scope tests never open COM'))
        self.guard.start()
        self.addCleanup(self.guard.stop)
        self.root = tk.Tk()
        self.app = CleanMonitor(self.root, mode='replay', create_worker=False)
        self.root.geometry('1280x720')
        self.root.update_idletasks()

    def tearDown(self):
        if not self.app.closing:
            self.app.close()

    @staticmethod
    def wheel(delta=120, state=0, num=None):
        return types.SimpleNamespace(delta=delta, state=state, num=num)

    def test_wheel_changes_shared_timebase_and_ctrl_wheel_changes_only_target_amplitude(self):
        a = self.app
        a.span_var.set('40')
        p = a.primary_plot
        a._scope_wheel(self.wheel(), p)
        self.assertEqual(scope_window_seconds(a.span_var.get()), 20.)
        before = a.span_var.get()
        a._scope_wheel(self.wheel(state=4), p)
        self.assertEqual(a.span_var.get(), before)
        self.assertIsNotNone(p.y_per_div)
        self.assertIsNone(a.speed_plot.y_per_div)
        self.assertIsNone(a.pole_plot.y_per_div)
        self.assertIsNone(a.worker)
        self.assertIsNone(a.recorder)

    def test_high_resolution_wheel_accumulates_small_delta(self):
        a = self.app
        a.span_var.set('40')
        a._scope_wheel(self.wheel(delta=60), a.primary_plot)
        self.assertEqual(scope_window_seconds(a.span_var.get()), 40.)
        a._scope_wheel(self.wheel(delta=60), a.primary_plot)
        self.assertEqual(scope_window_seconds(a.span_var.get()), 20.)

    def test_linux_wheel_buttons_and_reset_scope(self):
        a = self.app
        a.span_var.set('40')
        a._scope_wheel(self.wheel(delta=0, num=4), a.primary_plot)
        self.assertEqual(scope_window_seconds(a.span_var.get()), 20.)
        a._scope_wheel(self.wheel(delta=0, num=5), a.primary_plot)
        self.assertEqual(scope_window_seconds(a.span_var.get()), 40.)
        for p in a.main_plots + a.advanced_plots:
            p.set_y_scale(2., center=10.)
        a.reset_scope()
        self.assertEqual(scope_window_seconds(a.span_var.get()), 30.)
        self.assertTrue(all(p.y_per_div is None for p in a.main_plots + a.advanced_plots))

    def test_zoom_window_starts_with_source_amplitude_and_has_two_dials(self):
        a = self.app
        a.process_frame(frame(), 1., record=False)
        a.primary_plot.set_y_scale(5., center=20.)
        before = [(point.t, point.frame.raw) for point in a.history.samples]
        a.open_zoom(a.primary_plot)
        win, plot, source = a._zoom_windows[-1]
        self.root.update()
        self.assertIs(source, a.primary_plot)
        self.assertEqual(plot.y_per_div, 5.)
        self.assertEqual(plot.y_center, 20.)
        dials = (plot.time_dial, plot.amplitude_dial)
        self.assertEqual(len(dials), 2)
        self.assertTrue(all(dial.winfo_ismapped() for dial in dials))
        a.step_timebase(1)
        a._scope_wheel(self.wheel(state=4), plot)
        self.assertEqual(before, [(point.t, point.frame.raw) for point in a.history.samples])
        self.assertIsNone(a.worker)
        self.assertIsNone(a.recorder)


if __name__ == '__main__':
    unittest.main(verbosity=2)



"""Performance behavior and layout checks; no serial connection."""
from pathlib import Path
import sys,types,time,tkinter as tk,unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))
from clean_monitor import CleanMonitor
from clean_widgets import CleanPlot
from test_clean_monitor import frame
class PerformanceTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.app=CleanMonitor(self.root,mode='replay',create_worker=False)
    def tearDown(self):self.app.close()
    def test_cadence_and_window_controls_fit(self):
        a=self.app
        self.assertEqual(a.redraw_interval_ms,33);self.assertEqual(a.event_poll_ms,15)
        a.process_frame(frame(),1,record=False);a.refresh_status()
        for size in ('1000x640','1280x720','1366x768'):
            self.root.geometry(size);self.root.update();a.mark_dirty();a.redraw()
            widgets=[a.connect_button,a.port_box,a.settings_button,a.replay_button,a.demo_button,a.advanced_button,a.help_button,a.pause_button,a.footer,*a.card_labels.values()]
            for w in widgets:
                self.assertTrue(w.winfo_ismapped(),(size,str(w)))
                x=w.winfo_rootx()-self.root.winfo_rootx();y=w.winfo_rooty()-self.root.winfo_rooty()
                self.assertGreaterEqual(x,0);self.assertGreaterEqual(y,0)
                self.assertLessEqual(x+w.winfo_width(),self.root.winfo_width()+1,(size,str(w),'right'))
                self.assertLessEqual(y+w.winfo_height(),self.root.winfo_height()+1,(size,str(w),'bottom'))
            for w in [a.settings_button,a.replay_button,a.demo_button,a.advanced_button,a.help_button]:
                self.assertGreaterEqual(w.winfo_width(),w.winfo_reqwidth(),(size,str(w),'text cropped'))
    def test_cached_values_and_canvas_items_reused(self):
        calls=[]
        plot=CleanPlot(self.root,'cache','units',[('q','blue',lambda f:(calls.append(f.x) or f.x))])
        plot.pack();self.root.update()
        pts=[types.SimpleNamespace(t=i/10,segment=0,epoch=0,frame=types.SimpleNamespace(x=i)) for i in range(50)]
        plot.draw(pts,5,5);n=len(plot.canvas.find_all());first=len(calls)
        plot.draw(pts,5.03,5)
        self.assertEqual(first,50);self.assertEqual(len(calls),50)
        self.assertEqual(len(plot.canvas.find_all()),n)
        plot.toggle_series('q');self.assertEqual(len(calls),50)
    def test_decimation_preserves_both_extreme_spikes(self):
        pts=[(i/20,0.) for i in range(1000)];pts[125]=(pts[125][0],100.);pts[126]=(pts[126][0],-100.)
        result=CleanPlot._decimate(pts)
        self.assertIn(pts[125],result);self.assertIn(pts[126],result)
        self.assertEqual(result[0],pts[0]);self.assertEqual(result[-1],pts[-1])
        self.assertLess(len(result),len(pts)//2)
    def test_zoom_tracks_same_samples_and_hides_without_stopping(self):
        a=self.app;a.process_frame(frame(),1,record=False);self.root.update()
        a.open_zoom(a.primary_plot);self.root.update();a.mark_dirty();a.redraw()
        self.assertEqual(len(a._zoom_windows),1);win,plot,_=a._zoom_windows[0]
        self.assertEqual(len(plot.last_draw[0]),len(a.primary_plot.last_draw[0]))
        win.withdraw();n=len(a.history.samples)
        a.process_frame(frame(Q=11,T=1100),1.1,record=False)
        self.assertEqual(len(a.history.samples),n+1)
    def test_record_error_visible_in_demo_view(self):
        a=self.app;a.process_frame(frame(),1,record=False)
        a.record_var.set('记录异常，显示继续：磁盘不可写');a.refresh_status()
        self.assertIn('记录',a.fault_var.get());self.assertIn('磁盘',a.fault_var.get())
        a.toggle_demo_view();self.root.update();a.refresh_status()
        self.assertTrue(a.fault_label.winfo_ismapped())
if __name__=='__main__':unittest.main()

"""v9.2 checks against the exact CB045654 recording that exposed v9.1 gaps.

Read-only/offline: no serial worker and Serial is guarded in GUI checks.
"""
from pathlib import Path
import csv,math,sys,tkinter as tk,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
sys.path.insert(0,str(ROOT/'tests'))
from clean_monitor import CleanMonitor,REFERENCE,ACTUAL,ENVELOPE
from clean_semantics import mode_status
from unified_protocol import decode_unified,UnifiedHistory
import amfm_semantics as semantics
from test_clean_monitor import frame
REAL_PATH=Path(__file__).resolve().parents[1]/'monitor'/'records'/'J280_AllModes_COM7_20261102_143123_811745_492921_unified.csv'
CACHE=None
LEGACY=('梯形','七段S','正弦速度','正弦位置')
EXPECTED={1:'AM',2:'FM',3:'心形'}

def real_samples():
    global CACHE
    if CACHE is None:
        CACHE=[]
        if REAL_PATH.exists():
            with REAL_PATH.open(encoding='utf-8-sig',newline='') as stream:
                for n,row in enumerate(csv.DictReader(stream),2):
                    if n>10000:break
                    f=decode_unified(row['raw_line'])
                    if f.trajectory_config_tag==0xCB045654:
                        CACHE.append((float(row['elapsed_s']),f,int(row.get('connection_segment',0)),n))
    return CACHE

def steady_samples(profile):
    return [(t,f,seg,n) for t,f,seg,n in real_samples()
            if f.active_trajectory_profile==profile and f.trajectory_phase==2
            and f.flag(5) and f.base_valid and f.fault==0]

def envelope_report():
    result={}
    for j,name in EXPECTED.items():
        samples=steady_samples(j)
        found=sum(semantics.upper_envelope_degrees(f) is not None
                  and semantics.lower_envelope_degrees(f) is not None for t,f,seg,n in samples)
        result[name]={'steady_frames':len(samples),'frames_with_both_envelopes':found,
                      'missing_rate':(1-found/len(samples)) if samples else None,
                      'CL_ms':sorted({f.trajectory_cycle_ms for t,f,seg,n in samples}),
                      'first_csv_row':samples[0][3] if samples else None,
                      'last_csv_row':samples[-1][3] if samples else None}
    return result

class V92RecordTests(unittest.TestCase):
    def setUp(self):
        if not REAL_PATH.exists():self.skipTest('Optional original recording unavailable on this computer')
    def test_actual_tag_and_three_steady_modes_are_present(self):
        self.assertTrue(real_samples())
        for j in EXPECTED:self.assertGreater(len(steady_samples(j)),100)
    def test_actual_steady_envelopes_are_never_missing(self):
        with patch.object(semantics,'SEMANTICS_PATH',ROOT/'config/__missing__.json'):
            for name,data in envelope_report().items():
                with self.subTest(mode=name):
                    self.assertGreater(data['steady_frames'],0)
                    self.assertEqual(data['missing_rate'],0.0,data)
    def test_names_from_real_dip_and_active_profile_are_am_fm_heart(self):
        for t,f,seg,n in real_samples():
            m=mode_status(f)
            self.assertNotIn('配置未识别',m['selected'],(n,m))
            if f.selected_dip_mode:
                self.assertIn(EXPECTED[f.selected_dip_mode],m['selected'])
            self.assertFalse(any(x in m['selected']+' '+m['actual'] for x in LEGACY),(n,m))
            if f.flag(5) and f.active_trajectory_profile in EXPECTED:
                self.assertIn(EXPECTED[f.active_trajectory_profile],m['actual'],(n,m))
    def test_fm_record_120_second_cycle_keeps_both_fixed_bounds(self):
        samples=steady_samples(2)
        self.assertEqual({f.trajectory_cycle_ms for t,f,seg,n in samples},{120000})
        for t,f,seg,n in samples:
            self.assertAlmostEqual(semantics.upper_envelope_degrees(f),(f.endpoint_degrees or 0)+90)
            self.assertAlmostEqual(semantics.lower_envelope_degrees(f),(f.endpoint_degrees or 0)-90)
    def test_am_and_heart_reference_stays_inside_planned_bounds(self):
        # RF is integer engineering counts (360/408 degree quantization).
        for j in (1,3):
            for t,f,seg,n in steady_samples(j):
                upper=semantics.upper_envelope_degrees(f)
                lower=semantics.lower_envelope_degrees(f)
                self.assertIsNotNone(upper,(j,n))
                self.assertIsNotNone(lower,(j,n))
                self.assertGreaterEqual(upper,lower)
                self.assertLessEqual(f.reference_degrees,upper+360/408+.05,(j,n,f.reference_degrees,upper,lower))
                self.assertGreaterEqual(f.reference_degrees,lower-360/408-.05,(j,n,f.reference_degrees,upper,lower))

class V92GuiTests(unittest.TestCase):
    def setUp(self):
        self.guard=patch('serial.Serial',side_effect=AssertionError('Offline only: COM forbidden'))
        self.guard.start();self.addCleanup(self.guard.stop)
        self.root=tk.Tk();self.app=CleanMonitor(self.root,mode='replay',create_worker=False)
        self.root.geometry('1280x720');self.root.update()
    def tearDown(self):
        if not self.app.closing:self.app.close()
    def test_dark_blue_reference_red_actual_yellow_envelopes(self):
        self.assertEqual((REFERENCE,ACTUAL,ENVELOPE),('#C44E52','#4C72B0','#C59A3D'))
        colors={n:c for n,c,g in self.app.primary_plot.series}
        self.assertEqual(colors['参考'],REFERENCE)
        self.assertEqual(colors['实际'],ACTUAL)
        self.assertEqual(colors['上包络'],ENVELOPE)
        self.assertEqual(colors['下包络'],ENVELOPE)
    def test_actual_record_task_details_have_no_legacy_trajectory_names(self):
        if not REAL_PATH.exists():self.skipTest('Optional original recording unavailable')
        a=self.app
        a.toggle_task_details()
        for j,name in EXPECTED.items():
            t,f,seg,n=steady_samples(j)[30]
            a.process_frame(f,t,record=False);a.refresh_status();self.root.update()
            self.assertIn(f'{j:02b}',a.mode_summary_var.get())
            self.assertIn(name,a.mode_summary_var.get())
            self.assertIn(name,a.task_compact_var.get())
            self.assertFalse(any(x in a.task_compact_var.get()+' '+a.sw4_var.get() for x in LEGACY),
                             a.task_compact_var.get()+' '+a.sw4_var.get())
        self.assertTrue(a.task_frame.winfo_ismapped())
        self.assertIsNone(a.worker)
    def test_both_envelopes_really_render_for_actual_am_fm_heart(self):
        if not REAL_PATH.exists():self.skipTest('Optional original recording unavailable')
        a=self.app;p=a.primary_plot
        yellow=tuple(int(ENVELOPE[i:i+2],16) for i in (1,3,5))
        for j in EXPECTED:
            samples=steady_samples(j);h=UnifiedHistory()
            for t,f,seg,n in samples:h.append(f,t,seg)
            right=samples[-1][0]
            p.draw(h.window(right,120),right,120)
            self.root.update_idletasks()
            im=p.last_raster
            self.assertIsNotNone(im)
            # Both named world groups have data, and the yellow layer survives
            # actual/reference occlusion in the final raster.
            groups={n:g for n,c,g in p._world_groups}
            self.assertTrue(groups['上包络'],j);self.assertTrue(groups['下包络'],j)
            count=sum(px==yellow for px in im.getdata())
            self.assertGreater(count,im.width*.3,(j,count,im.size))
    def test_requested_dash_behavior_applies_to_reference_only(self):
        from clean_widgets import CleanPlot
        for name in ('参考','规划'):self.assertTrue(CleanPlot.is_dashed(name))
        for name in ('实际','估算','上包络','下包络'):self.assertFalse(CleanPlot.is_dashed(name))
if __name__=='__main__':unittest.main(verbosity=2)

"""Regression for responsive, lossless UI batching; no real serial access."""
from pathlib import Path
import csv,sys,tempfile,time,tkinter as tk,unittest
from unittest.mock import patch,Mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness
from clean_monitor import CleanMonitor
from test_clean_monitor import frame
from test_unified_runtime import wire_v2
from unified_protocol import UnifiedRecorder
from wave_monitor import LinkEvent

class SmoothUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):enable_dpi_awareness()
    def setUp(self):
        self.guard=patch('serial.Serial',side_effect=AssertionError('Offline tests never open COM'));self.guard.start()
        self.root=tk.Tk();self.app=CleanMonitor(self.root,mode='replay',create_worker=False)
        self.addCleanup(self.guard.stop)
    def tearDown(self):
        if not self.app.closing:self.app.close()
    def test_burst_is_bounded_but_all_frames_and_csv_rows_survive(self):
        a=self.app;a.mode='live';a.wanted=a.connected=True
        a.poll_packet_limit=8;a.poll_budget_ms=1000
        with tempfile.TemporaryDirectory(dir=ROOT/'tests') as folder:
            a.recorder=UnifiedRecorder(folder,'OFFLINE')
            wires=[wire_v2(Q=i+1,T=(i+1)*100,P=i+100) for i in range(40)]
            for i in range(0,40,10):a.events.put(LinkEvent('data',b''.join(wires[i:i+10]),time.monotonic()))
            with patch.object(a,'_sync_frame',wraps=a._sync_frame) as sync:
                a.poll_events()
                self.assertLess(a.valid,40);self.assertLessEqual(a.last_poll_packets,8)
                self.assertGreater(len(a._packet_backlog)+a.events.qsize(),0)
                polls=1
                while a._packet_backlog or not a.events.empty():
                    a.poll_events();polls+=1
                    self.assertLess(polls,30)
                self.assertEqual(a.valid,40);self.assertEqual(len(a.history.samples),40)
                self.assertEqual(a.last_frame.snapshot_sequence,40)
                self.assertEqual(sync.call_count,polls);self.assertLess(sync.call_count,40)
            csv_path=a.recorder.csv_path;a.finish_recording()
            with csv_path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
            self.assertEqual(len(rows),40)
            self.assertEqual([int(x['snapshot_sequence']) for x in rows],list(range(1,41)))
            self.assertEqual(int(rows[-1]['actual_position_units']),139)
            self.assertEqual([s.frame.raw for s in a.history.samples],[w.decode('ascii').strip() for w in wires])
    def test_idle_polls_do_not_rebuild_status_every15ms(self):
        a=self.app;now=time.monotonic()
        with patch('clean_monitor.time.monotonic',return_value=now):
            with patch.object(a,'refresh_status',wraps=a.refresh_status) as refresh:
                for _ in range(20):a.poll_events()
                self.assertEqual(refresh.call_count,1)
        self.assertEqual(a.status_interval_ms,100)
    def test_fault_is_visible_without_waiting_for_next_status_deadline(self):
        a=self.app;a.mode='live';a.wanted=a.connected=True
        a.events.put(LinkEvent('data',wire_v2(Q=1,T=100,M=5,F=0),time.monotonic()));a.poll_events()
        a.events.put(LinkEvent('data',wire_v2(Q=2,T=200,M=5,F=2),time.monotonic()));a.poll_events()
        self.assertIn('F=2',a.fault_var.get())
        self.assertEqual(a.last_frame.fault,2)
    def test_hidden_diagnostics_are_lazy_and_open_with_latest_frame(self):
        a=self.app
        with patch.object(a,'update_frame_display',wraps=a.update_frame_display) as fmt:
            for i in range(20):a.process_frame(frame(Q=i,T=i*100,P=100+i),i*.1,record=False)
            self.assertEqual(fmt.call_count,0)
            n=len(a.history.samples)
            a.toggle_advanced();self.root.update_idletasks()
            self.assertGreaterEqual(fmt.call_count,1);self.assertEqual(len(a.history.samples),n)
            self.assertEqual(a.raw_var.get(),'原始X：'+a.last_frame.raw)
            self.assertIn(f'Q={a.last_frame.snapshot_sequence}',a.parameter_var.get())
    def test_records_tab_does_not_paint_hidden_dashboard(self):
        a=self.app;a.process_frame(frame(),1,record=False);self.root.update_idletasks()
        a.notebook.select(a.pages['records']);self.root.update_idletasks()
        with patch.object(a.primary_plot,'draw',wraps=a.primary_plot.draw) as primary:
            with patch.object(a.speed_plot,'draw',wraps=a.speed_plot.draw) as speed:
                a.mark_dirty();a.redraw()
                self.assertEqual(primary.call_count,0);self.assertEqual(speed.call_count,0)
        a.notebook.select(a.pages['live']);self.root.update_idletasks()
        with patch.object(a.primary_plot,'draw',wraps=a.primary_plot.draw) as primary:
            a.mark_dirty();a.redraw();self.assertEqual(primary.call_count,1)
    def test_raw_diagnostic_tab_does_not_paint_hidden_dynamic_plots(self):
        a=self.app;a.process_frame(frame(),1,record=False);a.toggle_advanced();self.root.update_idletasks()
        a.advanced_notebook.select(1);self.root.update_idletasks()
        with patch.object(a.advanced_plots[0],'draw',wraps=a.advanced_plots[0].draw) as dynamic:
            a.mark_dirty();a.redraw();self.assertEqual(dynamic.call_count,0)
        self.assertEqual(a.raw_var.get(),'原始X：'+a.last_frame.raw)
    def test_over_budget_redraw_leaves_button_dispatch_time(self):
        a=self.app;a.dirty=False;a._last_span=a.span_var.get()
        with patch('clean_monitor.time.perf_counter',side_effect=(1.,1.2)):
            with patch.object(a.root,'after',wraps=a.root.after) as after:
                a.redraw()
                self.assertEqual(after.call_args.args[0],8)
    def test_direct_frame_updates_stay_immediate(self):
        a=self.app;a.process_frame(frame(P=150,U=10),1,record=False)
        self.assertIn('+',a.card_values['position'].get());self.assertEqual(a.card_values['pwm'].get(),'10%')
        self.assertFalse(a._frame_sync_pending)

if __name__=='__main__':unittest.main(verbosity=2)

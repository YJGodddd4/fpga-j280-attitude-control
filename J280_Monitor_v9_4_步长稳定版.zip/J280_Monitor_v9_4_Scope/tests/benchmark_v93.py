"""Real incoming-frame GUI benchmark, isolated from serial and firmware.

Run with --app-root to compare old/new versions in separate processes.
This uses each actual CSV frame without changing timestamps, fields or segments.
"""
from pathlib import Path
import argparse,cProfile,csv,io,json,statistics,sys,time,tkinter as tk,pstats
from unittest.mock import patch

REAL_PATH=Path(__file__).resolve().parents[1]/'monitor'/'records'/'J280_AllModes_COM7_20261102_143123_811745_492921_unified.csv'
ROOT=Path(__file__).resolve().parents[1]
def summary(values):
    return {'mean_ms':statistics.mean(values),'p95_ms':sorted(values)[max(0,int(.95*len(values))-1)],'max_ms':max(values)}
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--app-root',type=Path,default=ROOT)
    p.add_argument('--output',type=Path)
    p.add_argument('--count',type=int,default=25)
    p.add_argument('--profile',action='store_true')
    p.add_argument('--source',type=Path,default=REAL_PATH)
    p.add_argument('--end-at',type=float)
    p.add_argument('--revision',default='initial_batch_rgba')
    args=p.parse_args()
    sys.path.insert(0,str(args.app_root/'monitor'))
    from clean_capture import enable_dpi_awareness
    enable_dpi_awareness()
    from clean_monitor import CleanMonitor
    from unified_protocol import decode_unified
    import clean_widgets as widgets
    samples=[]
    with args.source.open(encoding='utf-8-sig',newline='') as stream:
        for row in csv.DictReader(stream):
            t=float(row['elapsed_s'])
            if args.end_at is not None and t>args.end_at:break
            samples.append((t,decode_unified(row['raw_line']),int(row['connection_segment'])))
    assert len(samples)>args.count+50
    serial_calls=[]
    with patch('serial.Serial',side_effect=AssertionError('Benchmark never opens COM')):
        root=tk.Tk();app=CleanMonitor(root,mode='replay',create_worker=False)
        root.geometry('1366x768');root.update()
        def cancel():
            for token in root.tk.call('after','info'):
                try:root.after_cancel(token)
                except tk.TclError:pass
        cancel()
        app.span_var.set('300');app.main_view_var.set('位置')
        for t,f,seg in samples[:-args.count]:
            app.connection_segment=seg;app.history.append(f,t,seg)
        app.last_frame=app.history.samples[-1].frame;app.valid=len(app.history.samples)
        app._replay_right=app.history.samples[-1].t
        app._sync_frame();app.refresh_status()
        app.open_zoom(app.primary_plot);app._zoom_windows[0][0].geometry('1366x768')
        root.update();cancel();app.mark_dirty();app.redraw();root.update_idletasks();cancel()
        times=[];ingest=[];draw=[];group_counts=[];allocations=[];raster_pixels=[];allocated_bytes=[]
        profiler=cProfile.Profile()
        if args.profile:profiler.enable()
        for t,f,seg in samples[-args.count:]:
            allocated=[];original_new=widgets.Image.new
            def count_new(mode,size,*a,**kw):
                allocated.append((mode,size))
                return original_new(mode,size,*a,**kw)
            widgets.Image.new=count_new
            try:
                start=time.perf_counter();app.connection_segment=seg;app.process_frame(f,t,record=False)
                a=time.perf_counter();app.refresh_status()
                app._replay_right=t;app.mark_dirty();app.redraw();root.update_idletasks();cancel()
                end=time.perf_counter()
            finally:widgets.Image.new=original_new
            times.append((end-start)*1000);ingest.append((a-start)*1000);draw.append((end-a)*1000)
            plots=app.main_plots+[app._zoom_windows[0][1]]
            group_counts.append(sum(len(gs) for plot in plots for _,_,gs in plot._world_groups))
            allocations.append(len(allocated));raster_pixels.append(sum(w*h for mode,(w,h) in allocated))
            allocated_bytes.append(sum(w*h*({'1':1/8,'L':1,'RGB':3,'RGBA':4}.get(mode,4)) for mode,(w,h) in allocated))
        if args.profile:profiler.disable()
        data={'app_root':str(args.app_root),'source':str(args.source),'profiling_enabled':args.profile,'renderer_revision':args.revision,'selected_span_s':300,
              'real_frames':len(samples),'incoming_frames':args.count,'source_end_s':samples[-1][0],
              'scenario':'300s selected, incoming real frames, dashboard3plots plus1366x768 position zoom; draw+Tk idle painting',
              'total':summary(times),'ingest':summary(ingest),'draw_status_paint':summary(draw),
              'mean_continuity_groups':statistics.mean(group_counts),
              'mean_Image_new_calls':statistics.mean(allocations),
              'mean_Image_new_pixel_count':statistics.mean(raster_pixels),
              'approx_allocated_RGBA_MiB_per_incoming_frame':statistics.mean(raster_pixels)*4/2**20,
              'Image_new_allocated_MiB_per_incoming_frame':statistics.mean(allocated_bytes)/2**20,
              'serial_port_opened':False,'records_or_firmware_modified':False}
        if args.profile:
            stats=io.StringIO();pstats.Stats(profiler,stream=stats).sort_stats('cumulative').print_stats(22)
            data['profile_top']=stats.getvalue()
        app.close()
    if args.output:
        args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(data,ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())

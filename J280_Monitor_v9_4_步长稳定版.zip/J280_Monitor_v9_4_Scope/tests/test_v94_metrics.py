"""Tracking metrics follow dashboard validity without changing recorded data."""
from pathlib import Path
import csv, queue, sys, tempfile, unittest
from collections import deque
from unittest.mock import Mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
from unified_protocol import UnifiedHistory, UnifiedRecorder, decode_unified
from test_unified_runtime import wire_v2
from unified_monitor import UnifiedMonitor
from unified_protocol import UnifiedStreamDecoder
from clean_monitor import CleanMonitor
from wave_monitor import LinkEvent


def sample(index=1, **updates):
    values=dict(Q=index,T=index*100,O=1,J=3,D=3,N=2,M=5,F=0,K=1,R=1,
                FL=0x633f,P=128,RF=120,Y=120,H=100,EP=100,
                CF=0xC1020D3F,CL=56000,TA=560,TE=560,PH=2,EL=10000)
    values.update(updates)
    return decode_unified(wire_v2(**values))


class TrackingMetricsTests(unittest.TestCase):
    def test_inactive_fault_and_nonbalance_frames_are_not_tracking_samples(self):
        for changes in ({'R':0},{'F':2},{'M':6}):
            with self.subTest(changes=changes):
                history=UnifiedHistory();history.append(sample(**changes),1,1)
                result=history.metrics(1,10)
                self.assertEqual(result['position_samples'],0)
                self.assertIsNone(result['position_rmse_degrees'])
                self.assertEqual(result['samples'],1)

    def test_valid_balanced_frame_still_enters_rmse(self):
        history=UnifiedHistory()
        for index,changes in enumerate(({'R':0},{'F':2},{'M':6},{}),1):
            history.append(sample(index,P=120+index*2,**changes),index,1)
        result=history.metrics(4,10)
        self.assertEqual(result['samples'],4)
        self.assertEqual(result['position_samples'],1)
        self.assertAlmostEqual(result['position_rmse_degrees'],8*360/408)

    def test_metric_filter_preserves_raw_samples_and_csv(self):
        history=UnifiedHistory()
        frames=[sample(index,**changes) for index,changes in
                enumerate(({'R':0},{'F':2},{'M':6},{}),1)]
        with tempfile.TemporaryDirectory() as folder:
            recorder=UnifiedRecorder(folder,'OFFLINE')
            try:
                for index,frame in enumerate(frames,1):
                    continuity=history.append(frame,index,1)
                    recorder.append(frame,index,1,continuity)
            finally:
                recorder.close()
            before=recorder.csv_path.read_bytes();points=tuple(history.samples)
            self.assertEqual(history.metrics(4,10)['position_samples'],1)
            self.assertEqual(tuple(history.samples),points)
            self.assertEqual(recorder.csv_path.read_bytes(),before)
            with recorder.csv_path.open(encoding='utf-8-sig',newline='') as stream:
                rows=list(csv.DictReader(stream))
            self.assertEqual(len(rows),4)
            self.assertEqual([row['raw_line'] for row in rows],[frame.raw for frame in frames])


class ReplayTimeTests(unittest.TestCase):
    def monitor_without_gui(self):
        app=UnifiedMonitor.__new__(UnifiedMonitor)
        app.mode='live';app.valid=7;app.paused_at=None;app.connection_segment=1
        app.history=UnifiedHistory();app.last_frame=sample(99)
        app.history.append(app.last_frame,9.9,1)
        app.recorder=Mock();app.legacy={};app.last_ff=None;app.last_received_at=4
        for name in ('finish_recording','update_frame_display','refresh_status','mark_dirty','record_var'):
            setattr(app,name,Mock())
        return app

    def write_record(self,folder,times):
        path=Path(folder)/'capture_unified.csv'
        with path.open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.writer(stream)
            writer.writerow(('elapsed_s','connection_segment','raw_line'))
            for index,t in enumerate(times,1):writer.writerow((t,1,sample(index).raw))
        return path

    def test_time_regression_is_rejected_before_existing_state_changes(self):
        app=self.monitor_without_gui()
        previous=(app.recorder,app.last_frame,tuple(app.history.samples),app.valid,app.mode)
        with tempfile.TemporaryDirectory() as folder:
            path=self.write_record(folder,(0,2,1))
            content=path.read_bytes()
            with self.assertRaisesRegex(ValueError,'CSV'):
                app.load_replay(path)
            self.assertEqual(path.read_bytes(),content)
        app.finish_recording.assert_not_called()
        self.assertIs(app.recorder,previous[0]);self.assertIs(app.last_frame,previous[1])
        self.assertEqual(tuple(app.history.samples),previous[2])
        self.assertEqual((app.valid,app.mode),previous[3:])

    def test_equal_timestamps_are_allowed_and_retain_both_frames(self):
        app=self.monitor_without_gui()
        with tempfile.TemporaryDirectory() as folder:
            path=self.write_record(folder,(1,1));content=path.read_bytes()
            app.load_replay(path)
            self.assertEqual(path.read_bytes(),content)
        self.assertEqual(app.mode,'replay');self.assertEqual(app.valid,2)
        self.assertEqual([p.t for p in app.history.samples],[1,1])
        self.assertEqual([p.frame.snapshot_sequence for p in app.history.samples],[1,2])


class SessionQueueTests(unittest.TestCase):
    def monitor_without_gui(self):
        app=CleanMonitor.__new__(CleanMonitor)
        app.events=queue.Queue();app._packet_backlog=deque();app._frame_sync_pending=False
        app.history=UnifiedHistory();app.decoder=UnifiedStreamDecoder()
        app.valid=0;app.last_frame=None;app.last_received_at=None;app.last_ff=None
        app.connection_segment=0;app.connected=True;app.wanted=True;app.mode='live'
        app.last_error='';app.previous_counts=[0]*5;app.session_start=100.
        app.closing=False;app.poll_packet_limit=64;app.poll_budget_ms=1000
        app.poll_after_id=None;app._status_refreshed_at=0;app.status_interval_ms=100
        app.event_poll_ms=15;app.ui_batch_count=0;app.legacy={};app.recorder=Mock()
        for name in ('root','mark_dirty','refresh_status','_sync_frame','finish_recording','update_controls'):
            setattr(app,name,Mock())
        return app

    def drain(self,app):
        for _ in range(10):
            app.poll_events()
            if not app._packet_backlog and app.events.empty():return
        self.fail('The bounded event queue did not drain')

    def test_old_session_events_count_toward_budget_but_only_new_frame_is_recorded(self):
        app=self.monitor_without_gui();app.poll_packet_limit=2
        old=wire_v2(Q=77,T=7700);new=wire_v2(Q=1,T=100)
        for event in (LinkEvent('disconnected',None,99),LinkEvent('data',old,99.1),
                      LinkEvent('data',old,99.2),LinkEvent('data',new,101)):
            app.events.put(event)
        app.poll_events()
        self.assertEqual(app.last_poll_packets,2);self.assertEqual(app.events.qsize(),2)
        self.assertEqual(app.valid,0);self.assertTrue(app.connected)
        self.drain(app)
        self.assertEqual(app.valid,1);self.assertEqual(len(app.history.samples),1)
        self.assertEqual(app.last_frame.snapshot_sequence,1)
        self.assertEqual(app.history.samples[0].t,1)
        self.assertEqual(app.decoder.received_bytes,len(new))
        self.assertEqual(app.recorder.append.call_count,1)
        self.assertEqual(app.recorder.append.call_args.args[0].raw,new.decode('ascii').strip())

    def test_automatic_reconnect_in_same_session_keeps_both_connection_segments(self):
        app=self.monitor_without_gui();app.connected=False
        for event in (LinkEvent('connected','OFFLINE',101),
                      LinkEvent('data',wire_v2(Q=1,T=100),101.1),
                      LinkEvent('error',{'retry':True,'message':'offline test'},101.2),
                      LinkEvent('connected','OFFLINE',102),
                      LinkEvent('data',wire_v2(Q=2,T=200),102.1)):
            app.events.put(event)
        self.drain(app)
        self.assertEqual(app.session_start,100)
        self.assertEqual(app.valid,2);self.assertTrue(app.connected)
        self.assertEqual([p.frame.snapshot_sequence for p in app.history.samples],[1,2])
        self.assertEqual([p.segment for p in app.history.samples],[1,2])
        self.assertEqual(app.recorder.append.call_count,2)
        app.finish_recording.assert_not_called()


if __name__=='__main__':unittest.main(verbosity=2)

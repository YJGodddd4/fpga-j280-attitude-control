"""Rendering regressions for long, fragmented live windows; no serial I/O."""
from pathlib import Path
import sys,math,types,tkinter as tk,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness
from clean_widgets import CleanPlot,Image
from clean_monitor import REFERENCE,ACTUAL
enable_dpi_awareness()

class GroupedAntialiasTests(unittest.TestCase):
    def test_fragmented_strokes_share_one_cropped_antialias_image(self):
        layer=Image.new('RGBA',(1200,400),(0,0,0,0))
        groups=[[(float(x),100.),(float(x+20),100.)] for x in range(10,1100,40)]
        create=Image.new
        with patch('clean_widgets.Image.new',wraps=create) as spy:
            CleanPlot.paint_reference_groups(layer,groups,REFERENCE)
        self.assertEqual(spy.call_count,2,'one AA mask and one compact color image per series, not per continuity group')
        mode,size,*_=spy.call_args_list[0].args
        self.assertEqual(mode,'L')
        self.assertLess(size[1],40,'horizontal references should use a thin ROI')
        self.assertLess(size[0],layer.width*2+1)
        self.assertTrue(layer.getbbox())

    def test_disconnected_groups_are_not_joined(self):
        layer=Image.new('RGBA',(500,160),(0,0,0,0))
        CleanPlot.paint_reference_groups(layer,[[(10.,80.),(100.,80.)],[(300.,80.),(490.,80.)]],REFERENCE)
        self.assertTrue(any(layer.getpixel((x,80))[3] for x in range(10,100)))
        self.assertTrue(any(layer.getpixel((x,80))[3] for x in range(300,490)))
        self.assertFalse(any(layer.getpixel((x,y))[3] for x in range(110,290) for y in range(65,96)))

    def test_strokes_still_have_round_dashes_and_gaps_when_steep(self):
        layer=Image.new('RGBA',(180,280),(0,0,0,0))
        CleanPlot.paint_reference_groups(layer,[[(40.,10.),(45.,270.)]],REFERENCE)
        ink_rows=sum(any(layer.getpixel((x,y))[3]>128 for x in range(35,52)) for y in range(12,268))
        self.assertGreater(ink_rows,150)
        self.assertLess(ink_rows,245,'ordinary dashed stroke must retain visible gaps')
        self.assertEqual(CleanPlot.REFERENCE_WIDTH,2.5)
        self.assertEqual(CleanPlot.ACTUAL_WIDTH,2)

    def test_coverage_mask_matches_previous_geometry_without_color_ringing(self):
        from PIL import ImageDraw,ImageChops
        for color in (REFERENCE,ACTUAL,'#1e40af'):
            for groups in (
                [[(10.,30.),(230.,30.)]],
                [[(20.,10.),(25.,145.)]],
                [[(5.25,15.5),(70.,90.),(120.,20.)],[(160.,60.),(230.,120.)]]
            ):
                a=Image.new('RGBA',(250,160),(0,0,0,0));b=a.copy()
                CleanPlot.paint_reference_groups(a,groups,color)
                # Previous full-RGBA supersampling, independent of new mask.
                for coords in groups:
                    ink=Image.new('RGBA',(500,320),(0,0,0,0));pen=ImageDraw.Draw(ink)
                    for path in CleanPlot.dashed_paths(coords):
                        xy=[(x*2,y*2) for x,y in path]
                        pen.line(xy,fill=color,width=5,joint='curve')
                        for x,y in (xy[0],xy[-1]):
                            pen.ellipse((x-2,y-2,x+2,y+2),fill=color)
                    b.alpha_composite(ink.resize(b.size,Image.Resampling.LANCZOS))
                # RGBa Lanczos can overshoot RGB when alpha is clipped at255.
                # Preserve its geometric coverage (within1 alpha level), while
                # opaque ink must keep the exact requested scientific palette.
                alpha=ImageChops.difference(a.getchannel('A'),b.getchannel('A'))
                self.assertLessEqual(alpha.getextrema()[1],1)
                from PIL import ImageColor
                expected=ImageColor.getrgb(color)
                pixels=a.load()
                opaque=[pixels[x,y][:3] for y in range(a.height) for x in range(a.width) if pixels[x,y][3]==255]
                self.assertTrue(opaque)
                self.assertTrue(all(pixel==expected for pixel in opaque))

    def test_single_group_helper_matches_grouped_entry(self):
        group=[(10.,10.),(80.,50.),(100.,10.)]
        a=Image.new('RGBA',(140,80),(0,0,0,0));b=a.copy()
        CleanPlot.paint_reference(a,group,REFERENCE)
        CleanPlot.paint_reference_groups(b,[group],REFERENCE)
        self.assertEqual(a.tobytes(),b.tobytes())

    def test_empty_and_offscreen_strokes_do_not_allocate_images(self):
        layer=Image.new('RGBA',(100,100),(0,0,0,0));create=Image.new
        with patch('clean_widgets.Image.new',wraps=create) as spy:
            CleanPlot.paint_reference_groups(layer,[],REFERENCE)
            CleanPlot.paint_reference_groups(layer,[[(-50.,10.),(-20.,80.)]],REFERENCE)
        self.assertEqual(spy.call_count,0)
        self.assertIsNone(layer.getbbox())

class PlotRasterCacheTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.geometry('900x500')
        self.plot=CleanPlot(self.root,'cache','units',[('参考',REFERENCE,lambda f:f.q),('实际',ACTUAL,lambda f:f.p)],fixed_range=(-2,2))
        self.plot.pack(fill='both',expand=True);self.root.update()
        self.points=[self.sample(i) for i in range(30)]
    def tearDown(self):
        self.root.update_idletasks();self.root.destroy()
    @staticmethod
    def sample(i,epoch=0):
        f=types.SimpleNamespace(q=math.sin(i/4),p=.75*math.sin(i/4))
        return types.SimpleNamespace(t=i*.1,segment=0,epoch=epoch,frame=f)

    def test_identical_image_is_not_uploaded_to_tk_again(self):
        p=self.plot;p.draw(self.points,3,3)
        counters=(p.raster_builds,p.raster_uploads,p.cache_misses);raster=p.last_raster;photo=p._photo
        p.draw(list(self.points),3,3);p.draw(self.points,3,3,True)
        self.assertEqual((p.raster_builds,p.raster_uploads,p.cache_misses),counters)
        self.assertIs(p.last_raster,raster);self.assertIs(p._photo,photo)

    def test_new_real_frame_is_drawn_and_background_is_reused(self):
        p=self.plot;p.draw(self.points,3,3);counters=(p.raster_builds,p.raster_uploads)
        background=p._background
        points=self.points+[self.sample(30)]
        p.draw(points,3,3)
        self.assertEqual((p.raster_builds,p.raster_uploads),(counters[0]+1,counters[1]+1))
        self.assertIs(p._background,background)
        self.assertEqual(len(points),31)
        self.assertEqual(p.last_draw[0],points)

    def test_same_title_and_series_names_new_getters_invalidate_curve(self):
        p=self.plot;p.draw(self.points,3,3);count=p.raster_builds;first=p.last_raster.tobytes()
        p.set_series('cache','units',[('参考',REFERENCE,lambda f:1.),('实际',ACTUAL,lambda f:-1.)])
        p.draw(self.points,3,3)
        self.assertEqual(p.raster_builds,count+1)
        self.assertNotEqual(p.last_raster.tobytes(),first)

    def test_many_breaks_batch_one_antialias_pass_per_series(self):
        p=self.plot
        points=[self.sample(i,i//3) for i in range(90)]
        helper=CleanPlot.paint_reference_groups
        with patch.object(CleanPlot,'paint_reference_groups',wraps=helper) as spy:
            p.draw(points,9,9)
        self.assertEqual(spy.call_count,1)
        self.assertEqual(len(p._world_groups[0][2]),30)
        self.assertEqual(len(points),90)

    def test_scrolling_moves_cached_curves_without_rebuilding_values(self):
        p=self.plot;p.draw(self.points,4,3);builds=p.raster_builds;misses=p.cache_misses
        p.draw(self.points,4.01,3)
        self.assertEqual(p.raster_builds,builds);self.assertEqual(p.cache_misses,misses)
        self.assertEqual(p.raster_uploads,2)

if __name__=='__main__':unittest.main(verbosity=2)

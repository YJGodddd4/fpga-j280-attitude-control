"""Slope-independent reference dashes; offline, without Tk or a serial port."""
import math
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'monitor'))
import clean_widgets
from clean_widgets import CleanPlot


def length(path):
    return sum(math.dist(a,b) for a,b in zip(path,path[1:]))


class DashGeometryTests(unittest.TestCase):
    def test_horizontal_has_short_consistent_gaps(self):
        paths=CleanPlot.dashed_paths([(0.,0.),(40.,0.)])
        self.assertEqual(paths,[[(0.,0.),(8.,0.)],[(13.,0.),(21.,0.)],
                                [(26.,0.),(34.,0.)],[(39.,0.),(40.,0.)]])

    def test_vertical_uses_same_arc_lengths(self):
        h=CleanPlot.dashed_paths([(0.,0.),(40.,0.)])
        v=CleanPlot.dashed_paths([(0.,0.),(0.,40.)])
        self.assertEqual(v,[[(y,x) for x,y in path] for path in h])

    def test_steep_and_diagonal_do_not_become_x_stripes(self):
        for end in ((24.,32.),(0.4,math.sqrt(1600-.16))):
            paths=CleanPlot.dashed_paths([(0.,0.),end])
            for got,expected in zip([length(p) for p in paths],[8.,8.,8.,1.]):
                self.assertAlmostEqual(got,expected,places=8)
            for a,b in zip(paths,paths[1:]):
                self.assertAlmostEqual(math.dist(a[-1],b[0]),5.,places=8)

    def test_dash_retains_corner_instead_of_cutting_across_it(self):
        paths=CleanPlot.dashed_paths([(0.,0.),(4.,0.),(4.,20.)])
        self.assertEqual(paths[0],[(0.,0.),(4.,0.),(4.,4.)])
        self.assertEqual(paths[1],[(4.,9.),(4.,17.)])
        self.assertAlmostEqual(length(paths[0]),8.)

    def test_duplicates_empty_and_discontinuous_calls(self):
        self.assertEqual(CleanPlot.dashed_paths([]),[])
        self.assertEqual(CleanPlot.dashed_paths([(0,0)]),[])
        self.assertEqual(CleanPlot.dashed_paths([(0,0),(0,0)]),[])
        self.assertEqual(CleanPlot.dashed_paths([(0,0),(0,0),(8,0)]),[[(0,0),(8.,0.)]])
        a=CleanPlot.dashed_paths([(0,0),(8,0)])
        b=CleanPlot.dashed_paths([(100,0),(108,0)])
        self.assertEqual(a+b,[[(0,0),(8.,0.)],[(100,0),(108.,0.)]])

    def test_phase_and_invalid_pattern(self):
        paths=CleanPlot.dashed_paths([(0.,0.),(20.,0.)],phase=5.)
        self.assertEqual(paths[0],[(0.,0.),(3.,0.)])
        self.assertEqual(paths[1],[(8.,0.),(16.,0.)])
        with self.assertRaises(ValueError):CleanPlot.dashed_paths([(0,0),(1,1)],on=0)
        with self.assertRaises(ValueError):CleanPlot.dashed_paths([(0,0),(1,1)],off=-1)

    def test_width_and_draw_order_keep_reference_visible(self):
        self.assertGreater(CleanPlot.REFERENCE_WIDTH,CleanPlot.ACTUAL_WIDTH)
        self.assertLessEqual(CleanPlot.REFERENCE_WIDTH,2.5)
        names=['参考','实际','中心','上包络','下包络']
        ordered=sorted([(n,None,None) for n in names],key=CleanPlot.render_priority)
        self.assertEqual([p[0] for p in ordered],['上包络','下包络','中心','实际','参考'])

    @unittest.skipIf(clean_widgets.Image is None,'Pillow unavailable')
    def test_rounded_raster_has_both_ink_and_real_gaps_in_each_direction(self):
        for points,sample in (([(20.,20.),(80.,20.)],lambda x:(x,20)),
                              ([(20.,20.),(20.,80.)],lambda y:(20,y))):
            layer=clean_widgets.Image.new('RGBA',(100,100),(0,0,0,0))
            CleanPlot.paint_reference(layer,points,'#1e40af')
            self.assertGreater(layer.getpixel(sample(24))[3],220)
            self.assertLess(layer.getpixel(sample(30))[3],64)
            self.assertGreater(layer.getpixel(sample(37))[3],220)
            # The centerline occupies a little more than2 pixels, not a heavy bar.
            if sample(24)==(24,20):
                substantial=sum(layer.getpixel((24,y))[3]>100 for y in range(100))
                self.assertIn(substantial,(2,3,4))


class FakeCanvas:
    def __init__(self):self.items={};self.n=0;self.raised=[]
    def winfo_width(self):return 300
    def winfo_height(self):return 200
    def create_line(self,*coords,**kw):
        self.n+=1;self.items[self.n]={'kind':'line','coords':coords,**kw};return self.n
    def create_oval(self,*coords,**kw):
        self.n+=1;self.items[self.n]={'kind':'oval','coords':coords,**kw};return self.n
    def itemconfigure(self,item,**kw):self.items.setdefault(item,{}).update(kw)
    def coords(self,item,*coords):self.items.setdefault(item,{})['coords']=coords
    def tag_raise(self,item):self.raised.append(item)


class NativeFallbackTests(unittest.TestCase):
    def test_native_fallback_splits_vertical_dashes_with_round_caps(self):
        p=object.__new__(CleanPlot);p.canvas=FakeCanvas()
        p.series=[('参考','#1e40af',lambda f:f.v)]
        p.hidden=set();p.title='test';p.unit='';p.fixed_range=(0.,100.)
        p.y_per_div=None;p.y_center=0.
        p.include_zero=True;p._data_signature=None;p._cached_range=(0,1)
        p._world_groups=[];p._curves={};p._item_states={};p._label_text={}
        p._values={};p.cache_misses=0;p.draw_count=0
        def chrome(*args):
            p._x0=0.;p._x1=299.;p._y0=0.;p._y1=199.
            p._yl=['y'+str(i) for i in range(5)];p._xl=['x'+str(i) for i in range(5)]
            p._zero='zero';p._empty='empty'
        p._chrome=chrome
        points=[SimpleNamespace(t=1.,segment=0,epoch=0,frame=SimpleNamespace(v=v))
                for v in (0.,50.,100.)]
        with patch.object(clean_widgets,'Image',None):p.draw(points,1.,1.)
        lines=[item for item in p.canvas.items.values()
               if item.get('kind')=='line' and item.get('state')=='normal']
        self.assertGreater(len(lines),10)
        for item in lines:
            self.assertEqual(item['capstyle'],'round')
            self.assertEqual(item['width'],2.5)
            self.assertNotIn('dash',item)
            xs=item['coords'][::2];ys=item['coords'][1::2]
            self.assertAlmostEqual(max(xs),min(xs))
            self.assertLessEqual(abs(max(ys)-min(ys)),8.000001)
        # Repeated draw reuses its native line pool rather than growing it.
        count=len(p.canvas.items)
        with patch.object(clean_widgets,'Image',None):p.draw(points,1.,1.)
        self.assertEqual(len(p.canvas.items),count)


if __name__=='__main__':unittest.main()

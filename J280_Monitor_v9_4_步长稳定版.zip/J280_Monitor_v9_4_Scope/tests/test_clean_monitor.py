"""Real Tk integration checks with independent literal frames; no real COM."""
from pathlib import Path
import csv,re,sys,tempfile,time,tkinter as tk,unittest
from unittest.mock import patch
PROJECT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PROJECT/'monitor'))
from clean_monitor import CleanMonitor
from unified_protocol import UnifiedRecorder,UnifiedHistory,decode_unified
from test_unified_runtime import wire_v2
from wave_monitor import LinkEvent
TAG=0xC1020D3F
def frame(**changes):
    data=dict(O=1,J=3,D=3,N=2,M=5,F=0,K=1,R=1,FL=0x633f,
              P=130,RF=120,Y=119,H=100,EP=100,A=2959,C=2955,
              U=-35,W=2560,V=2304,CF=TAG,CL=56000,TA=560,TE=560,
              TM=1,PH=2,EL=10000,Q=10,T=1000)
    data.update(changes)
    return decode_unified(wire_v2(**data))
class CleanGuiTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        self.serial_guard=patch('serial.Serial',side_effect=AssertionError('No real serial access in offline test'))
        self.serial_guard.start()

        self.app=CleanMonitor(self.root,mode='replay',create_worker=False)
        self.addCleanup(self.serial_guard.stop)
    def tearDown(self):
        if not self.app.closing:self.app.close()
    def put(self,f=None,t=1.):
        f=frame() if f is None else f
        self.app.process_frame(f,t,record=False);self.app.refresh_status()
        self.app.mark_dirty();self.app.redraw();self.root.update_idletasks()
        return f
    def card_text(self,k):return self.app.card_values[k].get()+' '+self.app.card_details[k].get()
    def has_number(self,text,n,tol=.03):
        vals=[float(x) for x in re.findall(r'[-+]?\d+(?:\.\d+)?',text.replace('−','-'))]
        self.assertTrue(any(abs(x-n)<=tol for x in vals),(text,n))
    def test_two_tabs_six_cards_three_primary_four_advanced(self):
        a=self.app
        self.assertEqual(len(a.notebook.tabs()),2)
        self.assertEqual(set(a.card_values),{'pole','pwm','direction','speed','position','reference'})
        self.assertEqual(len(a.main_plots),3);self.assertEqual(len(a.plots),7)
        self.assertIsNone(a.worker);self.assertEqual(a.span_var.get(),'120')
    def test_requirement2_metrics_correct_units_and_signed_command(self):
        self.put()
        self.has_number(self.card_text('pole'),4);self.assertIn('ADC',self.card_text('pole'))
        self.assertNotIn('°',self.app.card_values['pole'].get())
        self.has_number(self.app.card_values['pwm'].get(),35)
        self.assertNotIn('-35',self.app.card_values['pwm'].get());self.assertIn('%',self.card_text('pwm'))
        self.assertRegex(self.card_text('direction'),'反|负');self.assertRegex(self.card_text('direction'),'命令|给定|U')
        self.has_number(self.card_text('speed'),3600/408);self.assertRegex(self.card_text('speed'),'估算|估计')
        self.has_number(self.card_text('position'),30*360/408)
        self.has_number(self.card_text('reference'),20*360/408);self.has_number(self.card_text('reference'),10*360/408)
    def test_positive_zero_command_and_estimated_motion_distinct(self):
        self.put(frame(U=35));self.assertRegex(self.card_text('direction'),'正')
        self.put(frame(U=0,Q=11,T=1100,W=2560),1.1)
        self.assertRegex(self.card_text('direction'),'停止|零|无驱动')
        self.has_number(self.card_text('pwm'),0);self.has_number(self.card_text('speed'),3600/408)
    def test_uncalibrated_pole_no_false_upright_error(self):
        self.put(frame(K=0,M=0,FL=0));self.assertRegex(self.card_text('pole'),'未标定|—|无效')
    def test_tracking_not_applicable_during_swing_or_recovery(self):
        for mode in (3,6):
            self.put(frame(M=mode),mode)
            self.assertRegex(self.card_text('reference'),'—|暂不适用|起摆|恢复')
            self.assertNotIn('+8.82',self.card_text('reference'))
    def test_invalid_base_never_claims_zero_position(self):
        self.put(frame(FL=0,M=6))
        self.assertIn('—',self.app.card_values['position'].get());self.assertIn('—',self.app.card_values['reference'].get())
    def test_actual_heart_kept_while_dip_selects_fm(self):
        self.put(frame(D=2,J=3,N=4));text=self.app.mode_summary_var.get()
        self.assertIn('心形',text);self.assertIn('FM',text);self.assertRegex(text,'等待|待切|退出|所选')
    def test_unknown_state_and_fault_remain_visible(self):
        self.put(frame(M=15,F=15));self.assertIn('未知',self.app.mode_summary_var.get()+' '+self.app.fault_var.get())
        self.put(frame(M=5,F=2,Q=11,T=1100),1.1);self.assertRegex(self.app.fault_var.get(),'角度|超限|故障')
    def test_stale_values_gray_and_explicit_age(self):
        a=self.app;a.mode='live';a.connected=True;a.last_received_at=time.monotonic();self.put()
        fresh={k:str(w.cget('foreground')) for k,w in a.card_labels.items()}
        a.last_received_at=time.monotonic()-3;a.refresh_status()
        stale={k:str(w.cget('foreground')) for k,w in a.card_labels.items()}
        self.assertTrue(any(fresh[k]!=stale[k] for k in fresh))
        self.assertRegex(a.status_var.get(),'历史|过期|未更新|距今|最后')
        a.connected=False;a.refresh_status();self.assertRegex(a.status_var.get(),'断|未连接|历史|连接')
    def test_replay_explicit_and_cannot_connect(self):
        self.put();self.assertRegex(self.app.status_var.get(),'回放|历史')
        self.app.toggle_connection();self.assertIsNone(self.app.worker);self.assertFalse(self.app.wanted)
    def test_pause_keeps_csv_receiving_and_note_local(self):
        a=self.app
        with tempfile.TemporaryDirectory(dir=PROJECT/'tests') as folder:
            a.recorder=UnifiedRecorder(folder,'OFFLINE');a.process_frame(frame(),1,True)
            a.toggle_pause();frozen=a.paused_at;a.process_frame(frame(Q=11,T=1100,P=135,U=12),1.1,True)
            self.assertEqual(a.paused_at,frozen);self.assertEqual(a.last_frame.actual_position_units,135)
            a.note_var.set('轻推摆杆，离线扰动标记');a.save_note()
            event_path=a.recorder.event_path;csv_path=a.recorder.csv_path;a.finish_recording()
            with csv_path.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
            self.assertEqual(len(rows),2);self.assertEqual(rows[-1]['actual_position_units'],'135')
            self.assertIn('离线扰动标记',event_path.read_text(encoding='utf-8-sig'))
            self.assertRegex(a.pause_button.cget('text'),'继续|恢复')
    def test_advanced_and_demo_preserve_requirement_cards(self):
        a=self.app;self.put();a.toggle_advanced();self.root.update_idletasks()
        self.assertNotEqual(a.advanced_window.state(),'withdrawn')
        a.toggle_demo_view();self.root.update_idletasks();self.assertTrue(a.demo_view.get())
        self.assertEqual(set(a.card_values),{'pole','pwm','direction','speed','position','reference'})
        self.assertEqual(len(a.main_plots),3);self.assertIn('4',self.card_text('pole'));self.assertTrue(a.status_var.get())
        a.toggle_demo_view();self.assertFalse(a.demo_view.get())
    def test_legend_hides_curve_not_history(self):
        a=self.app;self.root.deiconify();self.root.geometry('1280x720')
        for i in range(60):a.process_frame(frame(Q=10+i,T=1000+100*i,EL=10000+100*i,P=130+i%12),i*.1,False)
        self.root.update();a.mark_dirty();a.redraw();p=a.main_plots[0];name,color,_=p.series[1]
        before=(sum(px==tuple(int(color[j:j+2],16) for j in (1,3,5)) for px in p.last_raster.getdata()) if hasattr(p,'last_raster') else sum(p.canvas.type(i)=='line' and p.canvas.itemcget(i,'fill')==color and p.canvas.itemcget(i,'state')!='hidden' for i in p.canvas.find_all()))
        n=len(a.history.samples);p.toggle_series(name);a.mark_dirty();a.redraw()
        self.assertIn(name,p.hidden)
        after=(sum(px==tuple(int(color[j:j+2],16) for j in (1,3,5)) for px in p.last_raster.getdata()) if hasattr(p,'last_raster') else sum(p.canvas.type(i)=='line' and p.canvas.itemcget(i,'fill')==color and p.canvas.itemcget(i,'state')!='hidden' for i in p.canvas.find_all()))
        self.assertLess(after,before);self.assertEqual(len(a.history.samples),n)
        p.toggle_series(name);self.assertNotIn(name,p.hidden)
    def test_replay_segments_scrub_does_not_write_source(self):
        a=self.app
        with tempfile.TemporaryDirectory(dir=PROJECT/'tests') as folder:
            rec=UnifiedRecorder(folder,'OFFLINE');hist=UnifiedHistory()
            for f,t,segment in [(frame(),0,1),(frame(Q=11,T=1100,P=131),.1,1),(frame(Q=0,T=0,P=140),2,2),(frame(Q=1,T=100,P=141),2.1,2)]:
                rec.append(f,t,segment,hist.append(f,t,segment))
            rec.event('user_note','本次轻推',.1);rec.close();before=rec.csv_path.read_bytes()
            a.event_tree.insert('',0,values=('0','old','上一场旧事件'));a.load_replay(rec.csv_path)
            shown=str([a.event_tree.item(i,'values') for i in a.event_tree.get_children()])
            self.assertIn('本次轻推',shown);self.assertNotIn('上一场旧事件',shown)
            self.assertEqual(len(a.history.samples),4);self.assertNotEqual(a.history.samples[1].epoch,a.history.samples[2].epoch)
            self.assertIsNone(a.worker);self.assertRegex(a.status_var.get(),'回放|历史');self.assertEqual(before,rec.csv_path.read_bytes())
            a.seek_replay('0');self.assertEqual(a.last_frame.actual_position_units,130)
            a.seek_replay('2.1');self.assertEqual(a.last_frame.actual_position_units,141)
    def test_fake_connection_events_never_open_serial(self):
        a=self.app;a.mode='live';a.wanted=True
        a.events.put(LinkEvent('connected','FAKE',time.monotonic()));a.poll_events();self.assertTrue(a.connected)
        a.events.put(LinkEvent('data',wire_v2(Q=11),time.monotonic()));a.poll_events();self.assertGreater(a.valid,0)
        a.events.put(LinkEvent('disconnected',None,time.monotonic()));a.poll_events();self.assertFalse(a.connected);a.wanted=False
if __name__=='__main__':unittest.main()

"""Run offline v9.1 checks, optionally including the full previous regression set.

Examples:
  python tests/verify_v91.py --quick
  python tests/verify_v91.py --output tests/v91_verification_result.json

No serial connection is created. GUI tests create temporary monitor windows.
"""
from pathlib import Path
import argparse,hashlib,io,json,sys,unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
sys.path.insert(0,str(ROOT/'tests'))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--quick',action='store_true',help='Run only the11 focused v9.1 checks')
    parser.add_argument('--output',type=Path,help='Optional JSON result path; omitted means stdout only')
    args=parser.parse_args()
    from clean_capture import enable_dpi_awareness
    enable_dpi_awareness()
    names=['test_v91_fixes'] if args.quick else [
        'test_protocol','test_wave_monitor','test_autoswing_monitor',
        'test_position_monitor','test_unified_monitor','test_unified_runtime',
        'test_centered_profiles','test_amfm_monitor','test_derivative_filter_status',
        'test_clean_semantics','test_clean_monitor','test_clean_performance',
        'test_v91_fixes']
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
    log=io.StringIO()
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    from test_v91_fixes import REAL_SAMPLE
    sample=None
    if REAL_SAMPLE:
        frame,name,row=REAL_SAMPLE
        sample={'filename':name,'row_number':row,
                'config_tag':f'{frame.trajectory_config_tag:08X}',
                'active_profile':frame.active_trajectory_profile}
    report={'success':result.wasSuccessful(),'tests':result.testsRun,
            'skipped':[(str(t),reason) for t,reason in result.skipped],
            'failures':[(str(t),trace) for t,trace in result.failures],
            'errors':[(str(t),trace) for t,trace in result.errors],
            'real_user_sample':sample,'offline_only':True,
            'FPGA_modified':False,'serial_commands_sent':False,
            'reference_style':'#C44E52 muted red dashed',
            'actual_style':'#4C72B0 blue solid',
            'envelope_style':'#C59A3D soft gold solid',
            'display_size_checked':'1280x720'}
    if args.output:
        report['source_sha256']={
            p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for name in ('monitor','config','tests')
            for p in (ROOT/name).glob('*') if p.suffix in ('.py','.json','.cmd')
            and p.name not in ('verification_result.json','v91_verification_result.json')}
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'},ensure_ascii=False,indent=2))
    if not result.wasSuccessful():
        print(log.getvalue(),file=sys.stderr)
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':
    raise SystemExit(main())

"""Capture production UI using only the bundled real recording; never open COM."""
from pathlib import Path
import sys,tkinter as tk
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness,capture_window
from clean_monitor import CleanMonitor
from test_v92_fixes import REAL_PATH,steady_samples

def main():
    enable_dpi_awareness()
    destination=ROOT/'previews';destination.mkdir(exist_ok=True)
    with patch('serial.Serial',side_effect=AssertionError('No real serial access')):
        root=tk.Tk();app=CleanMonitor(root,mode='replay',create_worker=False)
        app.load_replay(REAL_PATH)
        # Pick a true steady AM interval ending in the supplied record.
        samples=steady_samples(1);end=samples[-1][0]
        app.main_view_var.set('位置');app.seek_replay(end);app.span_var.set('20')
        for size in ('1000x640','1280x720','1366x768'):
            root.geometry(size);root.update();app.mark_dirty();app.redraw();root.update()
            for w in (app.span_box,app.scope_reset_button,app.pause_button,app.primary_plot.canvas,app.speed_plot.canvas,app.pole_plot.canvas):
                assert w.winfo_ismapped(),str(w)
                x,y=w.winfo_rootx()-root.winfo_rootx(),w.winfo_rooty()-root.winfo_rooty()
                assert x>=0 and y>=0 and x+w.winfo_width()<=root.winfo_width()+1 and y+w.winfo_height()<=root.winfo_height()+1,(size,str(w))
            capture_window(root,destination/f'v94_main_{size}.png')
        app.primary_plot.set_y_scale(50,0)
        app.open_zoom(app.primary_plot)
        win,plot,source=app._zoom_windows[-1]
        win.geometry('1100x760');root.update();app.mark_dirty();app.redraw();root.update()
        for dial in (plot.time_dial,plot.amplitude_dial):assert dial.winfo_ismapped()
        capture_window(win,destination/'v94_scope_dual_dial.png')
        plot.set_y_scale(5,15);app.span_var.set('2');app.seek_replay(end-.5)
        root.update();app.mark_dirty();app.redraw();root.update()
        capture_window(win,destination/'v94_scope_detail.png')
        app.close()
    print('PASS: real CSV previews at 1000/1280/1366px and dual-dial scope; no COM access.')
    return 0
if __name__=='__main__':raise SystemExit(main())

from pathlib import Path
import sys,json,time,statistics,tkinter as tk
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
from clean_capture import enable_dpi_awareness,capture_window
enable_dpi_awareness()
from clean_monitor import CleanMonitor
root=tk.Tk();app=CleanMonitor(root,mode='demo',create_worker=False)
app.load_demo();root.geometry('1366x768');root.update();app.mark_dirty();app.redraw();root.update_idletasks()
# Cached, repeatedly scrolling the current120-second window. No invented samples.
times=[];items=[]
for k in range(65):
    app._replay_right=120+k/30
    started=time.perf_counter();app.mark_dirty();app.redraw();root.update_idletasks()
    if k>=5:times.append((time.perf_counter()-started)*1000)
    items.append(sum(len(p.canvas.find_all()) for p in app.main_plots))
data={'scope':'Three visible plots,120s/1201 simulated samples,1366x768; draw plus Tk idle painting; no hardware',
'target_fps':30,'target_interval_ms':33,'event_poll_ms':15,
'mean_draw_and_paint_ms':statistics.mean(times),'p95_draw_and_paint_ms':sorted(times)[int(.95*len(times))-1],
'max_draw_and_paint_ms':max(times),'stable_canvas_items':max(items)==min(items),'canvas_items':max(items),
'measured_frame_count':len(times),'serial_port_opened':False}
(ROOT/'tests/performance_result.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
# Clean previews contain only this application, never the screen behind it.
app._replay_right=120;app.mark_dirty();app.redraw();root.update()
capture_window(root,ROOT/'previews/clean_main_1366x768.png')
root.geometry('1280x720');root.update();app.mark_dirty();app.redraw();root.update()
capture_window(root,ROOT/'previews/clean_main_1280x720.png')
app.open_zoom(app.primary_plot);root.update();app.mark_dirty();app.redraw();root.update()
capture_window(app._zoom_windows[0][0],ROOT/'previews/clean_zoom_heart.png')
app._zoom_windows[0][0].withdraw();app.notebook.select(app.pages['records']);root.update()
capture_window(root,ROOT/'previews/clean_records.png')
print(json.dumps(data,ensure_ascii=False,indent=2));app.close()

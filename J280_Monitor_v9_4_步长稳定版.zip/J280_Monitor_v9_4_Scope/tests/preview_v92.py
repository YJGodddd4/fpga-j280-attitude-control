"""Capture real user recording with corrected v9.2 presentation.

Only raw received frames are plotted; no synthetic curves/measurements are
created. Planned envelopes come from the firmware-qualified display math.
"""
from pathlib import Path
import json,sys,tkinter as tk
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness,capture_window
from clean_monitor import CleanMonitor
from unified_monitor import mod_stop_meaning,sw4_meaning
from test_v92_fixes import steady_samples,EXPECTED,REAL_PATH,envelope_report

def main():
    enable_dpi_awareness()
    destination=ROOT/'previews';destination.mkdir(exist_ok=True)
    output=[]
    assert REAL_PATH.exists(),'Current recording is required; no synthetic substitute.'
    with patch('serial.Serial',side_effect=AssertionError('No COM port in real CSV replay')):
        root=tk.Tk();app=CleanMonitor(root,mode='replay',create_worker=False)
        root.geometry('1366x768');root.update()
        app.toggle_task_details()
        for j,name,span in ((1,'AM',50),(2,'FM',80),(3,'Heart',70)):
            samples=steady_samples(j)
            last=max(n for n,p in enumerate(samples) if p[1].selected_dip_mode==j)
            samples=samples[:last+1]
            assert samples
            app.history.clear();app.last_frame=None;app._loading_replay=True
            for t,f,seg,n in samples:
                app.history.append(f,t,seg);app.last_frame=f;app.valid+=1
                app.connection_segment=seg
            # Use the production final-frame path so card, task, hint and mode
            # all describe exactly this frame.
            app._loading_replay=False;app._setup_replay();app._sync_frame()
            app.sw4_var.set(mod_stop_meaning(f) or sw4_meaning(f))
            app.span_var.set(str(span))
            app.record_var.set('真实CSV历史回放 · '+REAL_PATH.name)
            app.refresh_status();app.connect_button.configure(state='disabled')
            root.update();app.mark_dirty();app.redraw();root.update()
            assert app.task_frame.winfo_ismapped() and app.worker is None and app.recorder is None
            expected=EXPECTED[j]
            assert expected in app.mode_summary_var.get()
            assert '配置未识别' not in app.task_compact_var.get()
            assert '梯形/S' not in app.sw4_var.get()
            image=destination/f'v92_real_{name}_1366x768.png'
            capture_window(root,image);output.append(str(image))
            app.open_zoom(app.primary_plot)
            win,plot,original=app._zoom_windows[-1]
            win.geometry('1366x768');root.update()
            app.mark_dirty();app.redraw();root.update()
            zoom=destination/f'v92_real_{name}_zoom_1366x768.png'
            capture_window(win,zoom);output.append(str(zoom));win.withdraw()
        app.close()
    print(json.dumps({'source':str(REAL_PATH),'images':output,
                      'envelope_coverage':envelope_report(),
                      'synthetic_measurements':False,'serial_port_opened':False},
                     ensure_ascii=False,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())

from pathlib import Path
import sys,json,unittest,hashlib
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness
enable_dpi_awareness()
names=['test_protocol','test_wave_monitor','test_autoswing_monitor','test_position_monitor','test_unified_monitor','test_unified_runtime','test_centered_profiles','test_amfm_monitor','test_derivative_filter_status','test_clean_semantics','test_clean_monitor','test_clean_performance']
suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
with (ROOT/'tests/verification_output.log').open('w',encoding='utf-8') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
data={'success':result.wasSuccessful(),'tests':result.testsRun,'failures':[(str(t),s) for t,s in result.failures],'errors':[(str(t),s) for t,s in result.errors],'serial_port_opened':False,'serial_commands_sent':False,'FPGA_modified':False,'target_display_fps':30,'event_poll_ms':15}
data['source_sha256']={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for folder in ('monitor','config','tests') for p in (ROOT/folder).glob('*') if p.suffix in ('.py','.json','.cmd') and p.name!='verification_result.json'}
(ROOT/'tests/verification_result.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in data.items() if k!='source_sha256'},ensure_ascii=False,indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)

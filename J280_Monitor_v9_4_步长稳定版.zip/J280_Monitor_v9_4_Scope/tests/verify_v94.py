"""Run the legacy regression suite plus v9.4 display controls, entirely offline."""
from pathlib import Path
import argparse,io,json,sys,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'));sys.path.insert(0,str(ROOT/'tests'))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'verification_summary.json')
    args=parser.parse_args()
    from clean_capture import enable_dpi_awareness
    enable_dpi_awareness()
    names=['test_protocol','test_wave_monitor','test_autoswing_monitor',
           'test_position_monitor','test_unified_monitor','test_unified_runtime',
           'test_centered_profiles','test_amfm_monitor','test_derivative_filter_status',
           'test_clean_semantics','test_clean_monitor','test_clean_performance',
           'test_v91_fixes','test_v92_fixes','test_v92_strokes',
           'test_v93_render','test_v93_ui','test_v93_performance',
           'test_v94_scope','test_v94_metrics']
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(n) for n in names)
    stream=io.StringIO()
    with patch('serial.Serial',side_effect=AssertionError('Offline validation must not open a serial port')):
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    from test_v92_fixes import REAL_PATH,envelope_report
    data={'version':'v9.4','success':result.wasSuccessful(),'tests':result.testsRun,
          'skipped':[(str(t),reason) for t,reason in result.skipped],
          'failures':[(str(t),trace) for t,trace in result.failures],
          'errors':[(str(t),trace) for t,trace in result.errors],
          'real_record':REAL_PATH.relative_to(ROOT).as_posix(),
          'envelope_coverage':envelope_report(),
          'serial_port_opened':False,'FPGA_modified':False,
          'hardware_validation':False}
    args.output.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    (args.output.parent/'v94_test_log.txt').write_text(stream.getvalue(),encoding='utf-8')
    print(json.dumps(data,ensure_ascii=False,indent=2))
    return 0 if result.wasSuccessful() else 1

if __name__=='__main__':raise SystemExit(main())

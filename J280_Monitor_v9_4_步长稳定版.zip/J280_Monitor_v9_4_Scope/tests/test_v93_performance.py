"""Integration performance behavior, no wall-clock thresholds or COM access."""
from pathlib import Path
import csv,sys,tkinter as tk,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'monitor'))
sys.path.insert(0,str(ROOT/'tests'))
from clean_capture import enable_dpi_awareness
from clean_monitor import CleanMonitor
from unified_protocol import decode_unified
from benchmark_v93 import REAL_PATH
enable_dpi_awareness()

class VisibleSurfaceCacheTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.samples=[]
        with REAL_PATH.open(encoding='utf-8-sig',newline='') as stream:
            for row in csv.DictReader(stream):
                cls.samples.append((float(row['elapsed_s']),decode_unified(row['raw_line']),int(row['connection_segment'])))
    def setUp(self):
        self.no_serial=patch('serial.Serial',side_effect=AssertionError('No COM in performance tests'))
        self.no_serial.start()
        self.root=tk.Tk();self.app=CleanMonitor(self.root,mode='replay',create_worker=False)
        self.root.geometry('1280x720');self.root.update();self.cancel()
        a=self.app;a.span_var.set('300');a.main_view_var.set('位置')
        for t,f,seg in self.samples[:-1]:a.connection_segment=seg;a.history.append(f,t,seg)
        a.last_frame=a.history.samples[-1].frame;a._replay_right=a.history.samples[-1].t
        a._sync_frame();a.refresh_status()
        a.open_zoom(a.primary_plot);self.root.update();self.cancel()
        a.mark_dirty();a.redraw();self.root.update_idletasks();self.cancel()
        self.plots=a.main_plots+[a._zoom_windows[0][1]]
    def cancel(self):
        for token in self.root.tk.call('after','info'):
            try:self.root.after_cancel(token)
            except tk.TclError:pass
    def tearDown(self):
        self.app.close();self.no_serial.stop()
    def test_repeated_dashboard_and_zoom_draws_do_not_upload_unchanged_images(self):
        a=self.app
        before=[(p.raster_builds,p.raster_uploads,p.cache_misses) for p in self.plots]
        raw=[s.frame.raw for s in a.history.samples]
        for _ in range(5):
            a.mark_dirty();a.redraw();self.root.update_idletasks();self.cancel()
        after=[(p.raster_builds,p.raster_uploads,p.cache_misses) for p in self.plots]
        self.assertEqual(before,after)
        self.assertEqual(raw,[s.frame.raw for s in a.history.samples])
        self.assertIsNone(a.worker);self.assertIsNone(a.recorder)
    def test_next_actual_frame_updates_all_visible_surfaces_without_losing_history(self):
        a=self.app;before=[p.raster_uploads for p in self.plots];n=len(a.history.samples)
        t,f,seg=self.samples[-1]
        a.connection_segment=seg;a.process_frame(f,t,record=False)
        a._replay_right=t;a.mark_dirty();a.redraw();self.root.update_idletasks();self.cancel()
        self.assertEqual(len(a.history.samples),n+1)
        self.assertEqual(a.history.samples[-1].frame.raw,f.raw)
        self.assertEqual(a.last_frame.raw,f.raw)
        self.assertEqual([p.raster_uploads for p in self.plots],[v+1 for v in before])
        self.assertTrue(all(p.last_draw[0][-1].frame.raw==f.raw for p in self.plots))

if __name__=='__main__':unittest.main(verbosity=2)

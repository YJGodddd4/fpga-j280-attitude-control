"""Protocol and file recording only. This module never opens a serial port."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import re
from uuid import uuid4


# Current FPGA telemetry is 52 ASCII bytes, followed by CR LF.
# Frames can also be adjacent without line endings when a capture is replayed.
FRAME_LENGTH = 52
_FRAME = re.compile(
    r"A=([0-9A-Fa-f]{4}) C=([0-9A-Fa-f]{4}) "
    r"P=([0-9A-Fa-f]{8}) T=([0-9A-Fa-f]{8}) "
    r"U=([0-9A-Fa-f]{2}) R=([01]) K=([01]) F=([0-9A-Fa-f])"
)


def _signed(value: int, bits: int) -> int:
    return value - (1 << bits) if value & (1 << (bits - 1)) else value


@dataclass(frozen=True)
class Frame:
    angle: int
    center: int
    position: int
    target: int
    command: int
    running: bool
    calibrated: bool
    fault: int
    raw: str


def decode_frame(data: bytes | str) -> Frame:
    """Decode one complete frame; raise ValueError for malformed/out-of-range data."""
    try:
        text = data.decode("ascii") if isinstance(data, bytes) else data
    except UnicodeDecodeError as exc:
        raise ValueError("Telemetry is not ASCII") from exc
    if not isinstance(text, str):
        raise ValueError("A frame must be bytes or str")
    text = text.strip("\r\n \t")
    match = _FRAME.fullmatch(text)
    if match is None:
        raise ValueError("Frame does not match A/C/P/T/U/R/K/F telemetry")
    a, c, p, t, u, r, k, f = (int(part, 16) for part in match.groups())
    command = _signed(u, 8)
    if a > 4095 or c > 4095:
        raise ValueError("Angle or center exceeds the 12-bit numeric scale")
    if not -100 <= command <= 100:
        raise ValueError("Internal command exceeds -100..100 percent")
    return Frame(a, c, _signed(p, 32), _signed(t, 32), command,
                 bool(r), bool(k), f, text)


class StreamDecoder:
    """Recover fixed-format frames from arbitrary chunks and prefix noise.

    Leading CR/LF/spaces/tabs between packets are framing, not discarded noise.
    invalid_frames counts rejected complete A= candidates, not individual bytes.
    The retained buffer is bounded; normally it is at most 51 bytes.
    """

    MAX_BUFFER = 4096

    def __init__(self):
        self.buffer = bytearray()
        self.invalid_frames = 0
        self.discarded_bytes = 0
        self.received_bytes = 0

    def feed(self, data: bytes) -> list[Frame]:
        if not isinstance(data, (bytes, bytearray, memoryview)):
            raise TypeError("feed() requires bytes-like input")
        self.received_bytes += len(data)
        self.buffer.extend(data)
        frames = []
        while self.buffer:
            trim = 0
            while trim < len(self.buffer) and self.buffer[trim] in b"\r\n \t":
                trim += 1
            if trim:
                del self.buffer[:trim]
            if not self.buffer:
                break
            anchor = self.buffer.find(b"A=")
            if anchor < 0:
                # Keep a trailing A so a split header A | =... is not lost.
                keep = 1 if self.buffer[-1:] == b"A" else 0
                self.discarded_bytes += len(self.buffer) - keep
                self.buffer = self.buffer[-keep:] if keep else bytearray()
                break
            if anchor:
                self.discarded_bytes += anchor
                del self.buffer[:anchor]
            if len(self.buffer) < FRAME_LENGTH:
                break
            candidate = bytes(self.buffer[:FRAME_LENGTH])
            try:
                frame = decode_frame(candidate)
            except ValueError:
                self.invalid_frames += 1
                self.discarded_bytes += 2
                del self.buffer[:2]
                continue
            frames.append(frame)
            del self.buffer[:FRAME_LENGTH]
        if len(self.buffer) > self.MAX_BUFFER:
            dropped = len(self.buffer) - self.MAX_BUFFER
            self.discarded_bytes += dropped
            del self.buffer[:dropped]
        return frames


def _host_time() -> str:
    return datetime.now().astimezone().isoformat(timespec="milliseconds")


class Recorder:
    """Flush each received frame/event to disk; no serial/control side effects.

    elapsed is the caller's monotonic session time in seconds. segment identifies
    a connection interval; it must change after a disconnect/reconnect gap.
    angle_error_adc is A-C, not the complete angle-loop error when outer control
    is active. position_minus_target_units is P-T (the display deviation).
    """

    COLUMNS = (
        "host_time", "elapsed_s", "segment", "angle_adc", "center_adc",
        "angle_error_adc", "position_units", "target_units",
        "position_minus_target_units", "command_pct", "running", "calibrated",
        "fault", "note", "raw_line",
    )
    EVENT_COLUMNS = ("host_time", "elapsed_s", "kind", "message", "note")

    def __init__(self, folder, port, note=""):
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        token = re.sub(r"[^A-Za-z0-9_-]", "_", str(port)) or "port"
        stem = f"J280_{token}_{datetime.now():%Y%m%d_%H%M%S_%f}_{uuid4().hex[:6]}"
        self.csv_path = folder / (stem + ".csv")
        self.event_path = folder / (stem + "_events.csv")
        self.rows = 0
        self.note = str(note)
        self._closed = False
        self._csv_file = self.csv_path.open("x", encoding="utf-8-sig", newline="")
        try:
            self._event_file = self.event_path.open("x", encoding="utf-8-sig", newline="")
        except OSError:
            self._csv_file.close()
            raise
        try:
            self._writer = csv.writer(self._csv_file)
            self._events = csv.writer(self._event_file)
            self._writer.writerow(self.COLUMNS)
            self._events.writerow(self.EVENT_COLUMNS)
            self._csv_file.flush()
            self._event_file.flush()
        except OSError:
            self._csv_file.close()
            self._event_file.close()
            self._closed = True
            raise

    def _check_open(self):
        if self._closed:
            raise OSError("The recording has already been closed")

    def append(self, frame: Frame, elapsed, segment):
        self._check_open()
        self._writer.writerow((
            _host_time(), f"{float(elapsed):.6f}", segment, frame.angle, frame.center,
            frame.angle - frame.center if frame.calibrated else "",
            frame.position, frame.target, frame.position - frame.target,
            frame.command, int(frame.running), int(frame.calibrated), frame.fault,
            self.note, frame.raw,
        ))
        self._csv_file.flush()
        self.rows += 1

    def event(self, kind, message, elapsed):
        self._check_open()
        self._events.writerow((_host_time(), f"{float(elapsed):.6f}", str(kind), str(message), self.note))
        self._event_file.flush()

    def set_note(self, note, elapsed):
        self.note = str(note)
        self.event("note_changed", self.note, elapsed)

    def close(self):
        if self._closed:
            return
        first_error = None
        for stream in (self._csv_file, self._event_file):
            try:
                try:
                    stream.flush()
                finally:
                    stream.close()
            except OSError as exc:
                if first_error is None:
                    first_error = exc
        self._closed = True
        if first_error is not None:
            raise first_error

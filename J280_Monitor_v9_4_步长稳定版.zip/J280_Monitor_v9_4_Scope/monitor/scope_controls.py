"""Display-only oscilloscope timebase helpers and a keyboard-accessible dial."""
import bisect
import math
import tkinter as tk
from tkinter import ttk

TIME_DIVS=(.125,.25,.5,1.,2.,5.,10.,20.,30.,60.,120.,300.,450.)

def scope_window_seconds(value):
    try:
        span=float(value)
    except (TypeError,ValueError):
        return 30.
    return min(1800.,max(.5,span)) if math.isfinite(span) else 30.

def step_time_div(current_span,direction):
    current=scope_window_seconds(current_span)/4
    if direction>0:
        index=bisect.bisect_left(TIME_DIVS,current-1e-9)-1
    else:
        index=bisect.bisect_right(TIME_DIVS,current+1e-9)
    return 4*TIME_DIVS[max(0,min(len(TIME_DIVS)-1,index))]

def number(value):
    return f'{float(value):.6g}'

class ScopeDial(ttk.Frame):
    """Drag upward, wheel upward or press Up to magnify by one scale step."""
    def __init__(self,parent,title,command,textvariable):
        super().__init__(parent)
        self.command=command
        self._wheel_remainder=0.
        self._angle=135.
        self.canvas=tk.Canvas(self,width=54,height=54,bg='#f3f6fa',
            highlightthickness=1,highlightbackground='#d6e0eb',takefocus=True,cursor='hand2')
        self.canvas.grid(row=0,column=0,rowspan=2,padx=(0,8))
        ttk.Label(self,text=title,font=('Microsoft YaHei UI',9,'bold')).grid(row=0,column=1,sticky='sw')
        ttk.Label(self,textvariable=textvariable,foreground='#1479b8',width=25).grid(row=1,column=1,sticky='nw')
        self.canvas.create_oval(7,7,47,47,fill='white',outline='#9eafc1',width=2)
        self._pointer=self.canvas.create_line(27,27,38,16,fill='#1479b8',width=3,capstyle='round')
        self.canvas.bind('<Button-1>',self._start)
        self.canvas.bind('<B1-Motion>',self._drag)
        self.canvas.bind('<MouseWheel>',self._wheel)
        self.canvas.bind('<Button-4>',lambda e:self._turn(1))
        self.canvas.bind('<Button-5>',lambda e:self._turn(-1))
        for key,direction in (('Up',1),('Right',1),('Down',-1),('Left',-1)):
            self.canvas.bind('<'+key+'>',lambda e,d=direction:self._turn(d))
        self.canvas.bind('<FocusIn>',lambda e:self.canvas.configure(highlightbackground='#1479b8'))
        self.canvas.bind('<FocusOut>',lambda e:self.canvas.configure(highlightbackground='#d6e0eb'))

    def _turn(self,direction):
        self.command(direction)
        self._angle=(self._angle-direction*25)%360
        a=math.radians(self._angle)
        self.canvas.coords(self._pointer,27,27,27+15*math.cos(a),27-15*math.sin(a))
        return 'break'

    def _start(self,event):
        self.canvas.focus_set()
        self._drag_y=event.y

    def _drag(self,event):
        distance=self._drag_y-event.y
        steps=int(distance/12)
        if steps:
            self._drag_y-=steps*12
            for _ in range(min(20,abs(steps))):
                self._turn(1 if steps>0 else -1)
        return 'break'

    def _wheel(self,event):
        self._wheel_remainder+=getattr(event,'delta',0)
        steps=math.trunc(self._wheel_remainder/120)
        self._wheel_remainder-=steps*120
        for _ in range(min(20,abs(steps))):
            self._turn(1 if steps>0 else -1)
        return 'break'

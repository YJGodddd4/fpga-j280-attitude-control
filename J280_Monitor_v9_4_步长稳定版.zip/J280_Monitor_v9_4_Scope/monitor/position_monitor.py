"""Read-only O=5103 multi-turn relative monitor. No commands transmitted."""
from __future__ import annotations

import argparse
import csv
import math
import os
from pathlib import Path
import queue
import time
import tkinter as tk
from tkinter import filedialog,ttk

from position_protocol import (BALANCE_LABELS,DIP_LABELS,STEP_DEGREES,TASK_LABELS,
    PositionHistory,PositionRecorder,PositionStreamDecoder,decode_position,
    position_status,quantized_delta_units,sw4_meaning)
from wave_monitor import Plot,SerialWorker

ROOT=Path(__file__).resolve().parent
NOTICE=('只读：SW2减、SW3加；长按连发，两键组合切换步长。支持多圈相对旋转，+720°就是正转两圈，不取模360°。\n'
        '规划结束后按下SW4确认；采样实际位置为新基准，E清零。移动中按下不排队，结束后需松开再按。\n'
        '0.1°是编辑步长，不是定位精度；408工程单位/转约为0.882°/单位。SW1启停、SW5复位；关闭监测不停止电机。')


def format_angle(value):return '—（无本次home）' if value is None else f'{value:+.3f}°'


class PositionMonitor:
    def __init__(self,root,mode='live',create_worker=True):
        self.root=root;self.mode=mode;self.allow_worker=create_worker
        self.worker=None;self.recorder=None;self.events=queue.Queue();self.history=PositionHistory()
        self.decoder=PositionStreamDecoder();self.connected=self.wanted=False;self.closing=False
        self.last_frame=None;self.last_received_at=None;self.connection_segment=0
        self.session_start=time.monotonic();self.valid=0;self.invalid_total=self.legacy_total=self.bytes_total=self.incompatible_total=0
        self.last_error='';self.last_status='尚未连接';self.last_continuity=None;self.paused_at=None;self.dirty=True
        root.title('J280 · 多圈连续相对定位监测 · v5.2 · 只读 · O5103')
        sw,sh=root.winfo_screenwidth(),root.winfo_screenheight()
        root.geometry(f'{min(1200,sw-60)}x{min(920,sh-90)}');root.minsize(min(950,sw-60),min(750,sh-90))
        style=ttk.Style(root);style.configure('TLabel',font=('Microsoft YaHei UI',9))
        self.port_var=tk.StringVar(value='COM7');self.auto_var=tk.BooleanVar(value=True)
        self.span_var=tk.StringVar(value='30');self.status_var=tk.StringVar();self.stats_var=tk.StringVar()
        self.task_var=tk.StringVar(value='任务状态：等待O=5103快照')
        self.switch_var=tk.StringVar();self.sw4_var=tk.StringVar();self.raw_var=tk.StringVar();self.record_var=tk.StringVar()
        self.values={key:tk.StringVar(value='—') for key in ('edit','confirmed','executable','actual')}
        self.details={key:tk.StringVar() for key in self.values}
        body=ttk.Frame(root,padding=12);body.pack(fill='both',expand=True)
        ttk.Label(body,text='J280 · 多圈连续相对定位 v5.2：从实际位置继续旋转',font=('Microsoft YaHei UI',17,'bold')).pack(anchor='w')
        ttk.Label(body,text=NOTICE,foreground='#975516',wraplength=1130).pack(anchor='w',pady=(5,6))
        bar=ttk.Frame(body);bar.pack(fill='x',pady=3)
        ttk.Label(bar,text='串口').pack(side='left')
        self.port_box=ttk.Combobox(bar,textvariable=self.port_var,width=10);self.port_box.pack(side='left',padx=5)
        ttk.Button(bar,text='刷新',command=self.refresh_ports).pack(side='left')
        ttk.Label(bar,text='115200 · 8N1',foreground='#52667d').pack(side='left',padx=10)
        self.connect_button=ttk.Button(bar,text='连接监测',command=self.toggle_connection);self.connect_button.pack(side='left')
        self.auto_box=ttk.Checkbutton(bar,text='断线自动重连',variable=self.auto_var);self.auto_box.pack(side='left',padx=8)
        self.replay_button=ttk.Button(bar,text='回放位置CSV',command=self.choose_replay);self.replay_button.pack(side='right')
        self.status_label=ttk.Label(body,textvariable=self.status_var,wraplength=1130);self.status_label.pack(anchor='w')
        ttk.Label(body,textvariable=self.stats_var,font=('Microsoft YaHei UI',8),foreground='#64758a').pack(anchor='w',pady=(1,5))
        cards=ttk.Frame(body);cards.pack(fill='x')
        for i,(key,title) in enumerate([('edit','待编辑旋转增量 E'),('confirmed','本次已确认增量 G'),
                                       ('executable','本次量化执行增量'),('actual','实际 / 规划（相对本次基准）')]):
            card=ttk.LabelFrame(cards,text=title,padding=(8,4));card.grid(row=0,column=i,sticky='nsew',padx=(0,5) if i<3 else 0)
            cards.columnconfigure(i,weight=1,uniform='positioncards')
            ttk.Label(card,textvariable=self.values[key],font=('Microsoft YaHei UI',17,'bold'),foreground='#1764a7').pack(anchor='w')
            ttk.Label(card,textvariable=self.details[key],font=('Microsoft YaHei UI',8),wraplength=260).pack(anchor='w')
        ttk.Label(body,textvariable=self.task_var,font=('Microsoft YaHei UI',11,'bold'),wraplength=1130).pack(anchor='w',pady=(6,2))
        ttk.Label(body,textvariable=self.switch_var,wraplength=1130).pack(anchor='w')
        self.sw4_label=ttk.Label(body,textvariable=self.sw4_var,foreground='#975516',wraplength=1130);self.sw4_label.pack(anchor='w')
        controls=ttk.Frame(body);controls.pack(fill='x',pady=5)
        ttk.Label(controls,text='显示窗口').pack(side='left')
        ttk.Combobox(controls,textvariable=self.span_var,state='readonly',width=6,values=('5','10','20','30','60','120')).pack(side='left',padx=5)
        ttk.Label(controls,text='秒（横轴：主机接收时间）').pack(side='left')
        self.pause_button=ttk.Button(controls,text='暂停波形',command=self.toggle_pause);self.pause_button.pack(side='left',padx=10)
        ttk.Button(controls,text='打开记录文件夹',command=self.open_records).pack(side='right')
        plots=ttk.Frame(body);plots.pack(fill='both',expand=True)
        for i in range(2):plots.columnconfigure(i,weight=1,uniform='positionplots');plots.rowconfigure(i,weight=1,uniform='positionplots')
        self.plots=[
            Plot(plots,'本次规划、实际旋转与执行增量','度；相对本次确认基准，新任务分段显示，408单位/转',[
                ('给定R','#176ec4',lambda f:f.reference_degrees),('实际P','#16846c',lambda f:f.position_degrees),
                ('执行目标','#d38a10',lambda f:f.executable_degrees)]),
            Plot(plots,'规划与实际摆臂速度','度/秒；原始V/W÷256×360/408',[
                ('规划V','#176ec4',lambda f:f.reference_speed_degrees),('实际W','#16846c',lambda f:f.actual_speed_degrees)]),
            Plot(plots,'摆杆相对直立偏差 A−C（O帧B−C）','ADC计数（不是度，也不是完整PID误差）',[
                ('A−C','#a44dbe',lambda f:f.angle_error_adc),('零线','#a0aab5',lambda f:0)])]
        self.plots[0].grid(row=0,column=0,columnspan=2,sticky='nsew',pady=(0,5))
        self.plots[1].grid(row=1,column=0,sticky='nsew',padx=(0,5));self.plots[2].grid(row=1,column=1,sticky='nsew')
        for plot in self.plots:plot.canvas.bind('<Configure>',lambda event:self.mark_dirty())
        ttk.Label(body,textvariable=self.record_var,font=('Microsoft YaHei UI',8),foreground='#52667d').pack(anchor='w',pady=(3,0))
        ttk.Label(body,textvariable=self.raw_var,font=('Consolas',8),wraplength=1130,foreground='#64758a').pack(anchor='w')
        root.protocol('WM_DELETE_WINDOW',self.close)
        if mode=='live':self.refresh_ports()
        self.refresh_status();root.after(50,self.poll_events);root.after(120,self.redraw)

    def mark_dirty(self):self.dirty=True
    def elapsed(self,at=None):return max(0,(time.monotonic() if at is None else at)-self.session_start)
    def refresh_ports(self):
        try:
            from serial.tools import list_ports
            self.port_box['values']=[p.device for p in list_ports.comports()]
        except Exception as exc:self.status_var.set(f'读取串口列表失败：{exc}')
    def event(self,kind,message,at=None):
        if self.recorder is not None:
            try:self.recorder.event(kind,message,self.elapsed(at))
            except OSError as exc:self.record_error(exc)
    def record_error(self,exc):
        self.finish_recording();self.record_var.set(f'记录失败，实时显示继续：{exc}')
    def finish_recording(self):
        current,self.recorder=self.recorder,None
        if current is not None:
            try:current.close();self.record_var.set('记录已保存：'+current.csv_path.name)
            except OSError as exc:self.record_var.set(f'记录关闭异常：{exc}')
    def update_controls(self):
        self.connect_button.configure(text='断开监测' if self.wanted else '连接监测')
        self.port_box.configure(state='disabled' if self.wanted else 'normal')
        self.auto_box.configure(state='disabled' if self.wanted else 'normal')
        self.replay_button.configure(state='disabled' if self.wanted else 'normal')
    def toggle_connection(self):
        if self.wanted:
            self.wanted=self.connected=False
            if self.worker is not None:self.worker.disconnect()
            self.event('manual_disconnect','用户断开只读监测');self.finish_recording()
            self.last_status='已断开，保留历史位置快照';self.update_controls();self.refresh_status();return
        if not self.allow_worker:self.status_var.set('离线检查不允许连接真实串口。');return
        port=self.port_var.get().strip()
        if not port:self.status_var.set('请选择串口。');return
        self.finish_recording();self.mode='live';self.history.clear();self.decoder=PositionStreamDecoder()
        self.last_frame=self.last_received_at=None;self.valid=0;self.invalid_total=self.legacy_total=self.bytes_total=self.incompatible_total=0
        self.connection_segment=0;self.session_start=time.monotonic();self.paused_at=None
        if self.worker is None:self.worker=SerialWorker(self.events);self.worker.start()
        try:self.recorder=PositionRecorder(ROOT/'records',port);self.record_var.set('独立O记录：'+self.recorder.csv_path.name)
        except OSError as exc:self.record_error(exc)
        self.connected=False;self.wanted=True;self.last_error='';self.last_status=f'正在连接{port}'
        self.worker.connect(port,self.auto_var.get());self.update_controls();self.mark_dirty()

    def process_frame(self,f,elapsed,record=True):
        continuity=self.history.append(f,elapsed,self.connection_segment);self.last_continuity=continuity
        self.last_frame=f;self.valid+=1
        self.values['edit'].set(f'{f.edit_deci/10:+.1f}°')
        self.details['edit'].set(f'下一次旋转；编辑不移动，可执行{quantized_delta_units(f.edit_deci)*360/408:+.3f}°')
        self.values['confirmed'].set(f'{f.confirmed_deci/10:+.1f}°')
        self.details['confirmed'].set(f'任务ID I={f.task_id}（0x{f.task_id:04X}），确认接受时更新')
        self.values['executable'].set(format_angle(f.executable_degrees))
        self.details['executable'].set('等待本次home，不能执行相对位置任务' if not f.anchor_valid else
                                       f'基准H={f.home_units}；增量{f.executable_delta_units:+d}；终点={f.executable_target_units}'
                                       +('；已达32位坐标表示边界，饱和不回绕' if f.position_representation_saturated else ''))
        self.values['actual'].set('— / —（无home）' if not f.anchor_valid else f'{f.position_degrees:+.2f}° / {f.reference_degrees:+.2f}°')
        self.details['actual'].set('每次确认以实际位置建新基准；参考R连续，不重置编码器')
        self.task_var.set(f'任务：{TASK_LABELS[f.task_state]}（S={f.task_state}）　步长：{STEP_DEGREES[f.step_index]:g}°　'
                          f'上次任务中断：{"是" if f.interrupted else "否"}　规划时长：{f.duration_ms/1000:.3f}s')
        extra='；失衡恢复中，旧任务不能记为成功' if f.balance_mode==6 else ''
        self.switch_var.set(f'拨码：{DIP_LABELS[f.dip_mode]}　平衡模式：{BALANCE_LABELS.get(f.balance_mode,str(f.balance_mode))}（M={f.balance_mode:X}）'
                            f'　内部命令U={f.command_pct:+d}%（非实测PWM）'+extra)
        self.sw4_var.set(sw4_meaning(f));self.raw_var.set('原始O快照：'+f.raw)
        if record and self.recorder is not None:
            try:
                self.recorder.append(f,elapsed,self.connection_segment,continuity)
                if continuity.reason:self.recorder.event('telemetry_segment',continuity.reason,elapsed)
            except OSError as exc:self.record_error(exc)
        self.mark_dirty()

    def poll_events(self):
        if self.closing:return
        for _ in range(200):
            try:e=self.events.get_nowait()
            except queue.Empty:break
            if e.kind=='connected' and self.wanted:
                self.connected=True;self.connection_segment+=1;self.last_error=''
                self.invalid_total+=self.decoder.invalid_positions;self.legacy_total+=self.decoder.legacy_frames
                self.incompatible_total+=self.decoder.incompatible_positions
                self.bytes_total+=self.decoder.received_bytes;self.decoder=PositionStreamDecoder()
                self.last_received_at=None;self.last_status='串口已打开，等待O=5103快照';self.event('connected',str(e.value),e.at)
            elif e.kind=='error' and self.wanted:
                self.connected=False;self.last_error=e.value['message'];self.last_status='串口中断；等待自动重连' if e.value['retry'] else '串口连接失败'
                self.event('serial_error',self.last_error,e.at)
                if not e.value['retry']:self.wanted=False;self.finish_recording();self.update_controls()
            elif e.kind=='disconnected':self.connected=False
            elif e.kind=='data' and self.wanted:
                frames=self.decoder.feed(e.value)
                if frames:self.last_received_at=e.at
                for f in frames:self.process_frame(f,self.elapsed(e.at))
        self.refresh_status();self.root.after(50,self.poll_events)

    def refresh_status(self):
        age=None if self.last_received_at is None else time.monotonic()-self.last_received_at
        text,fresh=position_status(self.last_frame,age,self.connected,self.mode)
        if self.mode=='live' and not fresh and self.incompatible_total+self.decoder.incompatible_positions:
            text='检测到旧版O=5101/5102位置数据；本窗口需要配套v5.2多圈O=5103固件，字段宽度或任务含义不同。 '+text
        if self.mode=='live' and not self.connected:text+=' '+self.last_status+(f'：{self.last_error}' if self.last_error else '')
        if self.paused_at is not None:text+=' 波形暂停；接收与记录继续。'
        self.status_var.set(text);self.status_label.configure(foreground='#14734f' if fresh else '#a13b39')
        self.sw4_label.configure(foreground='#975516' if fresh else '#925595')
        f=self.last_frame
        clock='' if f is None else f' · FPGA T={f.uptime_ms}ms Q={f.snapshot_seq}'
        self.stats_var.set(f'有效O {self.valid} · 字节{self.bytes_total+self.decoder.received_bytes} · '
                           f'坏O {self.invalid_total+self.decoder.invalid_positions} · 识别旧A/M {self.legacy_total+self.decoder.legacy_frames} · '
                           f'旧版O {self.incompatible_total+self.decoder.incompatible_positions} · '
                           f'累计丢号{self.history.lost_snapshots} · 连接段{self.connection_segment}'+clock)

    def redraw(self):
        if self.closing:return
        key=(self.dirty,self.span_var.get(),self.paused_at)
        if self.dirty or getattr(self,'_last_draw_key',None)!=key:
            right=self.paused_at if self.paused_at is not None else (self.history.samples[-1].t if self.history.samples else 0)
            span=float(self.span_var.get());points=self.history.window(right,span)
            for plot in self.plots:plot.draw(points,right,span,self.paused_at is not None)
            self.dirty=False;self._last_draw_key=(False,self.span_var.get(),self.paused_at)
        self.root.after(120,self.redraw)
    def toggle_pause(self):
        self.paused_at=(self.history.samples[-1].t if self.history.samples else 0) if self.paused_at is None else None
        self.pause_button.configure(text='继续波形' if self.paused_at is not None else '暂停波形');self.mark_dirty()
    def open_records(self):
        folder=ROOT/'records';folder.mkdir(parents=True,exist_ok=True)
        try:os.startfile(str(folder))
        except OSError as exc:self.record_var.set(f'打开记录失败：{exc}')
    def choose_replay(self):
        if self.wanted:return
        path=filedialog.askopenfilename(title='回放位置O快照',filetypes=[('Position CSV','*_position.csv'),('CSV','*.csv')],initialdir=str(ROOT))
        if path:
            try:self.load_replay(path)
            except (OSError,ValueError,KeyError) as exc:self.status_var.set(f'回放失败：{exc}')
    def load_replay(self,path):
        frames=[]
        with Path(path).open(encoding='utf-8-sig',newline='') as stream:
            for row in csv.DictReader(stream):
                elapsed=float(row['elapsed_s'])
                if not math.isfinite(elapsed) or elapsed<0:raise ValueError('CSV接收时间无效')
                frames.append((decode_position(row['raw_line']),elapsed,int(row.get('connection_segment') or 0)))
        if not frames:raise ValueError('CSV没有有效O快照')
        self.finish_recording();self.mode='replay';self.history.clear();self.valid=0;self.paused_at=None
        for frame,elapsed,connection in frames:self.connection_segment=connection;self.process_frame(frame,elapsed,record=False)
        self.record_var.set('离线回放：'+Path(path).name+'；不改原记录，不代表当前板卡。')
        self.refresh_status();self.mark_dirty()
    def close(self):
        if self.closing:return
        self.closing=True;self.root.update_idletasks()
        if self.worker is not None:self.worker.shutdown();self.worker.join(timeout=.5)
        self.finish_recording();self.root.destroy()


def demo_line(index):
    position=round(20*math.sin(index/15));reference=round(20*math.sin(index/15+.08))
    return (f'O=5103 D=0 S=2 E=00000000 G=0000012C H=00000064 R={(100+reference)&0xffffffff:08X} '
            f'P={(100+position)&0xffffffff:08X} V=00000100 W=000000C0 K=1 A=1 I=0001 Z=0 M=5 '
            f'U=03 B={2955+round(3*math.sin(index)):04X} C={2955:04X} T={index*100:08X} Q={index:08X} L=0000000000001388')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--ui-check',action='store_true');parser.add_argument('--demo',action='store_true');parser.add_argument('--replay',type=Path)
    args=parser.parse_args();mode='demo' if args.ui_check or args.demo else 'replay' if args.replay else 'live'
    root=tk.Tk()
    if args.ui_check:root.withdraw()
    app=PositionMonitor(root,mode=mode,create_worker=mode=='live')
    if mode=='demo':
        for i in range(301):app.process_frame(decode_position(demo_line(i)),i/10,record=False)
        app.connect_button.configure(state='disabled');app.replay_button.configure(state='disabled');app.refresh_status()
    elif args.replay:app.load_replay(args.replay)
    if args.ui_check:
        root.update_idletasks();app.redraw()
        assert app.worker is None and app.recorder is None and len(app.history.samples)==301
        assert all(plot.canvas.find_all() for plot in app.plots)
        assert app.last_frame.anchor_valid and '任务' in app.task_var.get()
        print('PASS: self-contained O position cards, three plots and demo; no serial port opened')
        app.close();return 0
    root.mainloop();return 0


if __name__=='__main__':raise SystemExit(main())

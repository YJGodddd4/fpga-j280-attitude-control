"""Offline protocol/GUI checks. No serial ports are opened or written."""
import csv
from pathlib import Path
import tempfile
import time
import tkinter as tk
import unittest

from j280_protocol import Recorder, decode_frame
from autoswing_protocol import (AutoRecorder, ExtendedStreamDecoder, decode_diagnostic,
                               diagnostic_status, DIAGNOSTIC_LENGTH)
from wave_monitor import Monitor, LinkEvent, FAULTS, VARIANT_TITLE, VARIANT_NOTICE

ROOT=Path(__file__).resolve().parent
A=b'A=0B90 C=0B90 P=FFFFFFF6 T=00000000 U=EC R=1 K=1 F=0\r\n'
M=b'M=3 W=FFFFFF80 N=01 Q=1 Z=1\r\n'


class DiagnosticTests(unittest.TestCase):
    def test_positive_negative_speed_and_units(self):
        self.assertEqual(len(M.rstrip(b'\r\n')),DIAGNOSTIC_LENGTH)
        d=decode_diagnostic(M)
        self.assertEqual(d.velocity_q8,-128)
        self.assertEqual(d.velocity_adc_per_ms,-.5)
        self.assertEqual(decode_diagnostic(M.replace(b'FFFFFF80',b'00000180')).velocity_adc_per_ms,1.5)
        self.assertEqual(decode_diagnostic(M.replace(b'FFFFFF80',b'80000000')).velocity_q8,-2147483648)
        self.assertEqual(decode_diagnostic(M.replace(b'FFFFFF80',b'7FFFFFFF')).velocity_q8,2147483647)

    def test_reject_malformed_diagnostic(self):
        for data in [b'M=3 W=FFFFFF80 N=01 Q=2 Z=1',b'M=3 W=FFFF N=01 Q=1 Z=1',b'\xff',None]:
            with self.subTest(data=data),self.assertRaises(ValueError):decode_diagnostic(data)

    def test_arbitrary_chunking_mixed_and_adjacent_lines(self):
        for size in [1,2,7,26,52,4096]:
            decoder=ExtendedStreamDecoder();frames=[];diagnostics=[]
            wire=A+M+A.rstrip(b'\r\n')+M.rstrip(b'\r\n')
            for i in range(0,len(wire),size):
                frames.extend(decoder.feed(wire[i:i+size]))
                diagnostics.extend(decoder.pop_diagnostics())
            self.assertEqual(len(frames),2)
            self.assertEqual(len(diagnostics),2)
            self.assertEqual(decoder.invalid_frames,0)
            self.assertEqual(decoder.invalid_diagnostics,0)
            self.assertEqual(decoder.discarded_bytes,0)
            self.assertEqual(decoder.received_bytes,len(wire))

    def test_legacy_firmware_does_not_wait_for_diagnostic(self):
        decoder=ExtendedStreamDecoder()
        frames=decoder.feed(A+A)
        self.assertEqual(frames,[decode_frame(A),decode_frame(A)])
        self.assertEqual(decoder.pop_diagnostics(),[])

    def test_damaged_mode_recovers_next_regular_frame(self):
        decoder=ExtendedStreamDecoder()
        frames=decoder.feed(M.replace(b'Q=1',b'Q=9')+A)
        self.assertEqual(len(frames),1)
        self.assertEqual(decoder.invalid_frames,0)
        self.assertEqual(decoder.invalid_diagnostics,1)

    def test_diagnostic_has_independent_freshness(self):
        d=decode_diagnostic(M)
        for age,connected in [(2,True),(.01,False),(None,True)]:
            text,fresh=diagnostic_status(d,age,connected)
            self.assertFalse(fresh)
            self.assertIn('当前模式不可判断',text)
        text,fresh=diagnostic_status(d,.1,True)
        self.assertTrue(fresh)
        self.assertIn('-0.500 ADC计数/ms',text)
        self.assertIn('不是度/秒',text)
        self.assertIn('M=3',text)
        self.assertIn('N=01',text)
        self.assertIn('N=AB',diagnostic_status(decode_diagnostic(M.replace(b'N=01',b'N=AB')),.1,True)[0])
        self.assertEqual(FAULTS[3],'采集、编码器或全局行程异常')
        self.assertEqual(FAULTS[7],'启动运动确认不足')
        self.assertFalse(diagnostic_status(d,.1,True,'replay')[1])
        self.assertIn('尚未收到',diagnostic_status(None,None,True)[0])

    def test_mode_csv_separate_and_normal_columns_unchanged(self):
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(base.resolve()))
            writer=AutoRecorder(folder,'TEST','fixture')
            writer.append(decode_frame(A),1,1)
            writer.append_diagnostic(decode_diagnostic(M),1.02,1)
            writer.close();writer.close()
            with writer.csv_path.open(encoding='utf-8-sig',newline='') as f:
                normal=list(csv.reader(f))
            with writer.mode_path.open(encoding='utf-8-sig',newline='') as f:
                modes=list(csv.DictReader(f))
            self.assertEqual(tuple(normal[0]),Recorder.COLUMNS)
            self.assertEqual(len(normal),2)
            self.assertEqual(modes[0]['elapsed_s'],'1.020000')
            self.assertEqual(modes[0]['velocity_q8'],'-128')
            self.assertEqual(modes[0]['velocity_adc_per_ms'],'-0.500000')
            self.assertEqual(modes[0]['note'],'fixture')
            with self.assertRaises(OSError):writer.append_diagnostic(decode_diagnostic(M),2,1)


class GuiTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        self.app=Monitor(self.root,mode='replay',create_worker=False)

    def tearDown(self):
        self.app.close()

    def test_diagnostic_live_then_stale_without_worker(self):
        app=self.app;app.mode='live';app.connected=True
        self.assertIn(VARIANT_TITLE,self.root.title())
        self.assertEqual(app.variant_notice.cget('text'),VARIANT_NOTICE)
        self.assertEqual(app.variant_notice.winfo_manager(),'pack')
        self.assertIn('SW1人工停止',VARIANT_NOTICE)
        self.assertIn('SW5复位',VARIANT_NOTICE)
        self.assertIn('不表示有自动保护',FAULTS[0])
        app.process_diagnostic(decode_diagnostic(M),1,1,record=False)
        app.refresh_status()
        self.assertIn('模式：自动起摆',app.diagnostic_var.get())
        self.assertIsNone(app.worker)
        app.last_diagnostic_at=time.monotonic()-2
        app.refresh_status()
        self.assertIn('当前模式不可判断',app.diagnostic_var.get())
        app.connected=False
        app.refresh_status()
        self.assertIn('历史诊断',app.diagnostic_var.get())

    def test_mixed_data_events_keep_regular_waveform_and_diagnostic(self):
        app=self.app;app.mode='live';app.wanted=app.connected=True
        app.events.put(LinkEvent('data',A+M,time.monotonic()))
        app.poll_events()
        self.assertEqual(app.valid,1)
        self.assertEqual(app.diagnostic_count,1)
        self.assertEqual(len(app.history.samples),1)
        self.assertEqual(app.decoder.discarded_bytes,0)
        self.assertIn('流程运行',app.details['command'].get())

    def test_legacy_frame_updates_even_without_mode(self):
        app=self.app;app.mode='live';app.wanted=app.connected=True
        app.events.put(LinkEvent('data',A,time.monotonic()))
        app.poll_events()
        self.assertEqual(app.valid,1)
        self.assertEqual(app.values['position'].get(),'-10')
        self.assertIn('尚未收到',app.diagnostic_var.get())

    def test_recovery_mode_is_not_labeled_as_fault_or_finished_balance(self):
        app=self.app;app.mode='live';app.connected=True
        app.process_diagnostic(decode_diagnostic(b'M=6 W=00000000 N=2B Q=1 Z=1\r\n'),1,1,record=False)
        app.refresh_status()
        self.assertIn('失衡恢复／切入续摆',app.diagnostic_var.get())
        self.assertNotIn('等待下垂',app.diagnostic_var.get())
        self.assertNotIn('故障停机',app.diagnostic_var.get())
        app.last_diagnostic_at=time.monotonic()-2
        app.refresh_status()
        self.assertIn('历史诊断',app.diagnostic_var.get())

    def test_capture_hold_mode_and_placeholder_target_explanation(self):
        self.assertIn('自动起摆·运动续摆',VARIANT_TITLE)
        self.assertIn('运动中无需先停稳或回到下垂',VARIANT_NOTICE)
        for phrase in ('捕获锁定新位置T','编码器P连续','M2/3/6时T=0表示未锁定',
                       '不是要求回0','M4/5为本次锁位','M行与A行异步'):
            self.assertIn(phrase,VARIANT_NOTICE)
        for mode,phrase in [(2,'尚未锁位'),(3,'等待直立锁位'),(4,'本次捕获锁位'),
                           (5,'保持本次锁位'),(6,'切入续摆')]:
            raw=f'M={mode:X} W=00000000 N=01 Q=1 Z=1'
            self.assertIn(phrase,diagnostic_status(decode_diagnostic(raw),.1,True)[0])

    def test_asynchronous_mode_never_rewrites_a_frame_target_or_position(self):
        app=self.app;app.mode='live';app.connected=True
        frame=decode_frame(A)
        app.process_frame(frame,1,1,record=False)
        details=app.details['position'].get()
        for mode in (3,5,6):
            app.process_diagnostic(decode_diagnostic(f'M={mode:X} W=00000000 N=01 Q=1 Z=1'),
                                   1.02,1,record=False)
            app.refresh_status()
            self.assertEqual(app.last_frame,frame)
            self.assertEqual(app.history.samples[-1].frame,frame)
            self.assertEqual(app.details['position'].get(),details)
            self.assertEqual(app.values['position'].get(),'-10')
        self.assertIn('算术差',details)
        self.assertEqual(len(app.history.samples),1)


if __name__=='__main__':
    unittest.main(verbosity=2)

"""Capture only this application's window, even when another app overlaps it."""
def enable_dpi_awareness():
    import ctypes
    try: ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
    except (AttributeError,OSError):
        try: ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except (AttributeError,OSError): pass

def capture_window(root,path):
    import ctypes
    from ctypes import wintypes
    from PIL import Image
    u=ctypes.windll.user32;g=ctypes.windll.gdi32
    u.GetParent.argtypes=[wintypes.HWND];u.GetParent.restype=wintypes.HWND
    u.GetDC.argtypes=[wintypes.HWND];u.GetDC.restype=wintypes.HDC
    u.ReleaseDC.argtypes=[wintypes.HWND,wintypes.HDC]
    u.GetClientRect.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.RECT)]
    u.PrintWindow.argtypes=[wintypes.HWND,wintypes.HDC,wintypes.UINT]
    g.CreateCompatibleDC.argtypes=[wintypes.HDC];g.CreateCompatibleDC.restype=wintypes.HDC
    g.CreateCompatibleBitmap.argtypes=[wintypes.HDC,ctypes.c_int,ctypes.c_int];g.CreateCompatibleBitmap.restype=wintypes.HBITMAP
    g.SelectObject.argtypes=[wintypes.HDC,wintypes.HANDLE];g.SelectObject.restype=wintypes.HANDLE
    g.DeleteObject.argtypes=[wintypes.HANDLE];g.DeleteDC.argtypes=[wintypes.HDC]
    class BIH(ctypes.Structure):
        _fields_=[("biSize",wintypes.DWORD),("biWidth",wintypes.LONG),("biHeight",wintypes.LONG),("biPlanes",wintypes.WORD),("biBitCount",wintypes.WORD),("biCompression",wintypes.DWORD),("biSizeImage",wintypes.DWORD),("biXPelsPerMeter",wintypes.LONG),("biYPelsPerMeter",wintypes.LONG),("biClrUsed",wintypes.DWORD),("biClrImportant",wintypes.DWORD)]
    g.GetDIBits.argtypes=[wintypes.HDC,wintypes.HBITMAP,wintypes.UINT,wintypes.UINT,ctypes.c_void_p,ctypes.c_void_p,wintypes.UINT]
    root.update_idletasks()
    hwnd=u.GetParent(root.winfo_id()) or root.winfo_id()
    rect=wintypes.RECT();u.GetClientRect(hwnd,ctypes.byref(rect))
    w,h=rect.right-rect.left,rect.bottom-rect.top
    if w<=0 or h<=0:raise RuntimeError("Window has no drawable area")
    dc=u.GetDC(hwnd);mem=g.CreateCompatibleDC(dc);bitmap=g.CreateCompatibleBitmap(dc,w,h)
    old=g.SelectObject(mem,bitmap)
    try:
        if not u.PrintWindow(hwnd,mem,3):raise RuntimeError("Application-window capture failed")
        info=BIH(ctypes.sizeof(BIH),w,-h,1,32,0,w*h*4,0,0,0,0)
        buffer=ctypes.create_string_buffer(w*h*4)
        g.SelectObject(mem,old)
        if g.GetDIBits(mem,bitmap,0,h,buffer,ctypes.byref(info),0)!=h:raise RuntimeError("Cannot read application-window bitmap")
        Image.frombytes("RGB",(w,h),buffer.raw,"raw","BGRX").save(path)
    finally:
        g.SelectObject(mem,old);g.DeleteObject(bitmap);g.DeleteDC(mem);u.ReleaseDC(hwnd,dc)

"""Self-contained O=5103 multi-turn relative snapshots and read-only logging."""
from __future__ import annotations

from collections import deque
import csv
from dataclasses import dataclass, fields
from datetime import datetime
from pathlib import Path
import re
from uuid import uuid4

from autoswing_protocol import decode_diagnostic
from j280_protocol import decode_frame, _signed, _host_time

POSITION_LENGTH=174
COUNTS_PER_TURN=408
POSITION_MIN=-2147483648
POSITION_MAX=2147483647
_POSITION=re.compile(
    r'O=(5103) D=([0-9A-Fa-f]) S=([0-9A-Fa-f]) E=([0-9A-Fa-f]{8}) G=([0-9A-Fa-f]{8}) '
    r'H=([0-9A-Fa-f]{8}) R=([0-9A-Fa-f]{8}) P=([0-9A-Fa-f]{8}) '
    r'V=([0-9A-Fa-f]{8}) W=([0-9A-Fa-f]{8}) K=([0-9A-Fa-f]) A=([01]) '
    r'I=([0-9A-Fa-f]{4}) Z=([01]) M=([0-9A-Fa-f]) U=([0-9A-Fa-f]{2}) '
    r'B=([0-9A-Fa-f]{4}) C=([0-9A-Fa-f]{4}) T=([0-9A-Fa-f]{8}) '
    r'Q=([0-9A-Fa-f]{8}) L=([0-9A-Fa-f]{16})')
_LEGACY_POSITION=re.compile(_POSITION.pattern.replace('(5103)','(510[12])')
    .replace('E=([0-9A-Fa-f]{8}) G=([0-9A-Fa-f]{8})','E=([0-9A-Fa-f]{4}) G=([0-9A-Fa-f]{4})')
    .replace('L=([0-9A-Fa-f]{16})','L=([0-9A-Fa-f]{8})'))
# Internal O fields include A= and M=, so resynchronization uses full legacy headers.
_NEXT_HEADER=re.compile(rb'O=|A=[0-9A-Fa-f]{4} C=|M=[0-9A-Fa-f] W=')
TASK_LABELS={0:'无本次home',1:'保持待命',2:'规划移动',3:'等待实际收敛／可确认下一次',4:'已到位',
             5:'拨码切换／平滑减速',6:'预留模式待命',7:'任务中断'}
DIP_LABELS={0:'00 任意位置',1:'01 预留（不执行轨迹）',2:'10 预留（不执行轨迹）',3:'11 预留（不执行轨迹）'}
STEP_DEGREES={0:.1,1:1.0,2:10.0}
BALANCE_LABELS={0:'待机',1:'就绪',2:'初始激励',3:'自动起摆',4:'直立捕获／接管',5:'平衡',6:'失衡恢复／续摆'}


def round_away(numerator,denominator):
    """Round an exact rational to nearest integer; ties away from zero."""
    if denominator<=0:raise ValueError('denominator must be positive')
    sign=-1 if numerator<0 else 1
    return sign*((abs(int(numerator))*2+denominator)//(2*denominator))


def quantized_delta_units(request_deci):
    return round_away(int(request_deci)*COUNTS_PER_TURN,3600)


@dataclass(frozen=True)
class PositionFrame:
    version:int
    dip_mode:int
    task_state:int
    edit_deci:int
    confirmed_deci:int
    home_units:int
    reference_units:int
    position_units:int
    reference_velocity_q8:int
    actual_velocity_q8:int
    step_index:int
    anchor_valid:bool
    task_id:int
    interrupted:bool
    balance_mode:int
    command_pct:int
    angle_adc:int
    center_adc:int
    uptime_ms:int
    snapshot_seq:int
    duration_ms:int
    raw:str

    @property
    def requested_delta_units(self):return quantized_delta_units(self.confirmed_deci)
    @property
    def executable_target_units(self):
        return min(POSITION_MAX,max(POSITION_MIN,self.home_units+self.requested_delta_units)) if self.anchor_valid else None
    @property
    def executable_delta_units(self):
        return self.executable_target_units-self.home_units if self.anchor_valid else None
    @property
    def position_representation_saturated(self):
        return self.anchor_valid and self.home_units+self.requested_delta_units!=self.executable_target_units
    @property
    def executable_degrees(self):
        return self.executable_delta_units*360/COUNTS_PER_TURN if self.anchor_valid else None
    @property
    def reference_degrees(self):
        return (self.reference_units-self.home_units)*360/COUNTS_PER_TURN if self.anchor_valid else None
    @property
    def position_degrees(self):
        return (self.position_units-self.home_units)*360/COUNTS_PER_TURN if self.anchor_valid else None
    @property
    def reference_speed_degrees(self):return self.reference_velocity_q8/256*360/COUNTS_PER_TURN
    @property
    def actual_speed_degrees(self):return self.actual_velocity_q8/256*360/COUNTS_PER_TURN
    @property
    def angle_error_adc(self):return self.angle_adc-self.center_adc


def decode_position(data):
    try:text=data.decode('ascii') if isinstance(data,bytes) else data
    except UnicodeDecodeError as exc:raise ValueError('Position snapshot is not ASCII') from exc
    if not isinstance(text,str):raise ValueError('Position snapshot requires bytes or str')
    text=text.strip('\r\n \t')
    match=_POSITION.fullmatch(text)
    if match is None:raise ValueError('Position snapshot requires O=5103; use the matching multi-turn firmware and monitor')
    v=[int(part,16) for part in match.groups()]
    if v[1]>3 or v[2]>7 or v[10]>2:raise ValueError('Position mode, state or step is outside supported range')
    command=_signed(v[15],8)
    if abs(command)>100 or v[16]>4095 or v[17]>4095:raise ValueError('PWM command or ADC value is outside numeric range')
    return PositionFrame(v[0],v[1],v[2],_signed(v[3],32),_signed(v[4],32),
                         *(_signed(x,32) for x in v[5:10]),v[10],bool(v[11]),v[12],
                         bool(v[13]),v[14],command,v[16],v[17],v[18],v[19],v[20],text)


class PositionStreamDecoder:
    """Decode O only; recognize valid old A/M without using them as O fields."""
    MAX_BUFFER=4096
    def __init__(self):
        self.buffer=bytearray()
        self.received_bytes=self.discarded_bytes=self.invalid_positions=self.invalid_legacy=self.legacy_frames=0
        self.incompatible_positions=0

    def feed(self,data):
        if not isinstance(data,(bytes,bytearray,memoryview)):raise TypeError('feed requires bytes-like data')
        self.received_bytes+=len(data);self.buffer.extend(data);frames=[]
        while self.buffer:
            trim=0
            while trim<len(self.buffer) and self.buffer[trim] in b'\r\n \t':trim+=1
            if trim:del self.buffer[:trim]
            if not self.buffer:break
            anchors=[x for token in (b'O=',b'A=',b'M=') if (x:=self.buffer.find(token))>=0]
            if not anchors:
                keep=1 if self.buffer[-1:] in (b'O',b'A',b'M') else 0
                self.discarded_bytes+=len(self.buffer)-keep
                self.buffer=self.buffer[-keep:] if keep else bytearray();break
            skip=min(anchors)
            if skip:self.discarded_bytes+=skip;del self.buffer[:skip]
            kind=chr(self.buffer[0]);length={'O':POSITION_LENGTH,'A':52,'M':27}[kind]
            old_position=kind=='O' and self.buffer.startswith((b'O=5101 ',b'O=5102 '))
            if old_position:length=158
            later=_NEXT_HEADER.search(self.buffer,2)
            if later is not None and later.start()<length:
                self._reject(kind);self.discarded_bytes+=later.start();del self.buffer[:later.start()];continue
            if len(self.buffer)<length:break
            raw=bytes(self.buffer[:length])
            if old_position:
                try:legacy=_LEGACY_POSITION.fullmatch(raw.decode('ascii'))
                except UnicodeDecodeError:legacy=None
                if legacy is not None:
                    values=[int(value,16) for value in legacy.groups()]
                    if values[1]<=3 and values[2]<=7 and values[10]<=2 and abs(_signed(values[15],8))<=100 and values[16]<=4095 and values[17]<=4095:
                        self.incompatible_positions+=1;del self.buffer[:length];continue
            try:d={'O':decode_position,'A':decode_frame,'M':decode_diagnostic}[kind](raw)
            except ValueError:
                self._reject(kind);self.discarded_bytes+=2;del self.buffer[:2];continue
            if kind=='O':frames.append(d)
            else:self.legacy_frames+=1
            del self.buffer[:length]
        return frames

    def _reject(self,kind):
        if kind=='O':self.invalid_positions+=1
        else:self.invalid_legacy+=1


def sw4_meaning(frame):
    if frame.balance_mode in (0,1):return 'SW4：停机标定；不会启动位置移动。'
    if not frame.anchor_valid or frame.balance_mode==6:return 'SW4：当前无可用home；等待直立捕获后再确认位置。'
    if frame.dip_mode!=0:return 'SW4：当前拨码为预留模式，不执行位置轨迹。'
    if frame.task_state in (1,3,4):return 'SW4：按下后以当时实际位置为新基准，开始位置任务；E确认后清零。'
    if frame.task_state==2:return 'SW4：移动中按下确认忽略，不排队；结束后需松开再按。SW2/SW3可预编辑。'
    return 'SW4：当前任务状态不接受位置确认；待命／规划结束／到位时才接受。'


def position_status(frame,age,connected,mode='live'):
    if mode!='live':return '离线／演示：曲线和按键说明不是板卡当前状态。',False
    if frame is None:return '尚未收到O=5103自含位置快照；旧A/M不能替代位置状态。',False
    if not connected or age is None or age>=1.2:
        return '历史位置快照：断线或数据陈旧；所有数值及SW4说明仅为历史，当前状态不可判断。',False
    return f'位置通信正常；最近O快照距今{max(0,age):.1f}秒；各字段来自同一板端快照。',True


@dataclass(frozen=True)
class PositionSample:
    t:float
    segment:int
    epoch:int
    frame:PositionFrame


@dataclass(frozen=True)
class Continuity:
    segment:int
    seq_gap:int
    reason:str


class PositionHistory:
    def __init__(self,limit=18000):
        self.samples=deque(maxlen=limit);self.epoch=0;self.lost_snapshots=0
    def clear(self):
        self.samples.clear();self.epoch+=1;self.lost_snapshots=0
    def append(self,frame,elapsed,connection_segment):
        reasons=[];gap=0
        if self.samples:
            previous=self.samples[-1];old=previous.frame
            if previous.segment!=connection_segment:reasons.append('串口连接段变化')
            else:
                if frame.snapshot_seq<old.snapshot_seq:reasons.append('快照seq回退：可能复位或32位回绕')
                elif frame.snapshot_seq>old.snapshot_seq+1:
                    gap=frame.snapshot_seq-old.snapshot_seq-1
                    self.lost_snapshots+=gap;reasons.append(f'快照丢号{gap}')
                if frame.uptime_ms<old.uptime_ms:reasons.append('FPGA时间回退：可能复位或32位回绕')
                if frame.anchor_valid!=old.anchor_valid or (frame.anchor_valid and frame.home_units!=old.home_units):
                    reasons.append('本次home有效性或基准变化')
                if frame.task_id!=old.task_id:
                    reasons.append(f'新位置任务：任务ID变化{old.task_id}→{frame.task_id}，非编码器复位')
        if reasons:self.epoch+=1
        self.samples.append(PositionSample(float(elapsed),connection_segment,self.epoch,frame))
        return Continuity(self.epoch,gap,'；'.join(reasons))
    def window(self,right,span):return [p for p in self.samples if max(0,right-span)<=p.t<=right]


RAW_COLUMNS=tuple(f.name for f in fields(PositionFrame) if f.name!='raw')
POSITION_COLUMNS=('host_time','elapsed_s','connection_segment','segment',*RAW_COLUMNS,
                  'edit_degrees','confirmed_degrees','requested_delta_units','executable_delta_units','executable_target_units',
                  'executable_degrees','relative_reference_degrees','relative_position_degrees',
                  'reference_speed_degrees_s','actual_speed_degrees_s','angle_error_adc',
                  'seq_gap','segment_reason','raw_line')


class PositionRecorder:
    def __init__(self,folder,port):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        token=re.sub(r'[^A-Za-z0-9_-]','_',str(port)) or 'port'
        stem=f'J280_Position_{token}_{datetime.now():%Y%m%d_%H%M%S_%f}_{uuid4().hex[:6]}'
        self.csv_path=folder/(stem+'_position.csv');self.event_path=folder/(stem+'_position_events.csv')
        self._closed=False;self.rows=0
        self._data=self.csv_path.open('x',encoding='utf-8-sig',newline='')
        try:self._events=self.event_path.open('x',encoding='utf-8-sig',newline='')
        except OSError:self._data.close();raise
        try:
            self._writer=csv.writer(self._data);self._event_writer=csv.writer(self._events)
            self._writer.writerow(POSITION_COLUMNS)
            self._event_writer.writerow(('host_time','elapsed_s','kind','message'))
            self._data.flush();self._events.flush()
        except OSError:
            self._data.close();self._events.close();self._closed=True;raise
    def append(self,f,elapsed,connection_segment,continuity):
        if self._closed:raise OSError('Position recording is already closed')
        raw=[]
        for key in RAW_COLUMNS:
            value=getattr(f,key);raw.append(int(value) if isinstance(value,bool) else value)
        self._writer.writerow((_host_time(),f'{float(elapsed):.6f}',connection_segment,continuity.segment,*raw,
            f.edit_deci/10,f.confirmed_deci/10,f.requested_delta_units,f.executable_delta_units,f.executable_target_units,
            f.executable_degrees,f.reference_degrees,f.position_degrees,f.reference_speed_degrees,
            f.actual_speed_degrees,f.angle_error_adc,continuity.seq_gap,continuity.reason,f.raw))
        self._data.flush();self.rows+=1
    def event(self,kind,message,elapsed):
        if self._closed:raise OSError('Position recording is already closed')
        self._event_writer.writerow((_host_time(),f'{float(elapsed):.6f}',kind,message));self._events.flush()
    def close(self):
        if self._closed:return
        self._closed=True;error=None
        for stream in (self._data,self._events):
            try:
                try:stream.flush()
                finally:stream.close()
            except OSError as exc:
                if error is None:error=exc
        if error is not None:raise error

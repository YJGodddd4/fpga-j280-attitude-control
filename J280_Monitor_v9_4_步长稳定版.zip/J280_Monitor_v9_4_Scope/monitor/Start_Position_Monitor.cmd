@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title J280 v5.2 Multi-turn Relative Position Tasks - O5103
set "J280_POSITION_ROOT=%~dp0"
set "J280_POSITION_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist "%J280_POSITION_PYTHON%" goto missing_python
if not exist "%J280_POSITION_ROOT%position_monitor.py" goto missing_files
if not exist "%J280_POSITION_ROOT%position_protocol.py" goto missing_files
if not exist "%J280_POSITION_ROOT%wave_monitor.py" goto missing_files
if not exist "%J280_POSITION_ROOT%autoswing_protocol.py" goto missing_files
if not exist "%J280_POSITION_ROOT%j280_protocol.py" goto missing_files
if not exist "%J280_POSITION_ROOT%lib\serial\__init__.py" goto missing_files
"%J280_POSITION_PYTHON%" -E -X utf8 -u "%J280_POSITION_ROOT%position_monitor.py" %* 2>"%J280_POSITION_ROOT%position_monitor_startup_error.log"
set "J280_POSITION_RESULT=%ERRORLEVEL%"
if not "%J280_POSITION_RESULT%"=="0" goto failed
exit /b 0
:missing_python
echo The bundled Python runtime was not found:
echo %J280_POSITION_PYTHON%
goto wait_error
:missing_files
echo Required files are missing. Extract the COMPLETE monitor folder.
goto wait_error
:failed
echo Position monitor could not start. Details:
type "%J280_POSITION_ROOT%position_monitor_startup_error.log"
:wait_error
echo.
echo Please keep this window open and report the error.
pause
exit /b 1

"""Repeat offline tests and launcher checks; never open a real serial port."""
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent.parent/'J280_Position_v5_1'/'monitor'

def run(command):
    return subprocess.run(command,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                          encoding='utf-8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)

suite=run([sys.executable,'-E','-X','utf8','-m','unittest','-v','test_position_monitor',
           'test_protocol','test_wave_monitor','test_autoswing_monitor'])
(ROOT/'position_monitor_tests.log').write_text(suite.stdout,encoding='utf-8')
assert suite.returncode==0,suite.stdout
count=int(re.search(r'Ran (\d+) tests',suite.stdout).group(1))
launcher=run(['cmd.exe','/d','/c',str(ROOT/'启动连续相对定位监测.cmd'),'--ui-check'])
(ROOT/'position_monitor_ui_check.log').write_text(launcher.stdout,encoding='utf-8')
assert launcher.returncode==0,launcher.stdout
assert 'no serial port opened' in launcher.stdout,launcher.stdout

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

retained={}
for name in ('wave_monitor.py','autoswing_protocol.py','j280_protocol.py'):
    identical=(ROOT/name).read_bytes()==(PREVIOUS/name).read_bytes()
    assert identical,name
    retained[name]={'sha256':sha(ROOT/name),'identical_to_v5_1':identical}
report={
    'variant':'Position_v5_2_multiturn_relative',
    'position_protocol_marker':'5103',
    'position_line_length_without_crlf':174,'position_line_length_with_crlf':176,
    'protocol_and_gui_tests':count,'legacy_tests_retained':27,'new_position_tests':count-27,
    'result':'PASS','launcher_ui_check':'PASS',
    'test_command':'python -E -X utf8 -m unittest -v test_position_monitor test_protocol test_wave_monitor test_autoswing_monitor',
    'ui_check_command':'启动连续相对定位监测.cmd --ui-check',
    'serial_port_opened':False,'serial_bytes_transmitted':False,'read_only':True,
    'hardware_tested':False,'native_fpga_firmware_tested_by_monitor_suite':False,
    'numeric_target_input_present':False,'default_serial':'COM7 115200 8N1',
    'only_self_contained_o_used_for_position_ui_and_csv':True,
    'legacy_5101_5102_identified_and_rejected_with_matching_firmware_guidance':True,
    'relative_task_base':'H is actual absolute P sampled at each accepted confirmation; G is this task incremental request, E clears on acceptance.',
    'sw4_acceptance_states':[1,3,4],
    'sw4_position_confirm_edge':'Debounced press; presses in MOVING are ignored, not queued.',
    'request_width_bits':32,'duration_ms_width_bits':64,
    'multiturn_request_examples_degrees':[720,-720,3600,-3600],
    'modulo_360_applied':False,
    'settling_is_not_labeled_arrived_when_accepting_next_task':True,
    'task_id_change_including_same_home_and_wrap_segments_without_encoder_reset_claim':True,
    'multiple_relative_tasks_csv_replay_preserves_bases_ids_and_segment_breaks':True,
    'actual_speed_not_rebased_or_zeroed_by_monitor_on_new_task':True,
    'quantization':'Nearest integer, halfway away from zero; absolute target clamp32(H+round_away(G*408/3600)), executable delta is that target minus H.',
    'signed32_position_representation_boundary_saturates_not_wraps':True,
    'unmodified_reused_files':retained,
    'verification_scope':'Offline parser, GUI drawing, fake serial worker tests, CSV recording/replay and Chinese CMD launcher only. No real port, transmitted command, hardware motion or FPGA build by this suite.',
    'source_sha256':{p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.suffix in ('.py','.cmd','.md')},
    'verified_at':datetime.now(timezone(timedelta(hours=8))).isoformat(),
}
(ROOT/'monitor_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k] for k in ('variant','protocol_and_gui_tests','result','launcher_ui_check','serial_port_opened','serial_bytes_transmitted')},ensure_ascii=True,indent=2))

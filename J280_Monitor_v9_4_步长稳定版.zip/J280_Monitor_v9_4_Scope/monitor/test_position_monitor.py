"""Offline O snapshot and GUI tests. No real serial handles or commands."""
import csv
from pathlib import Path
import tempfile
import time
import tkinter as tk
import unittest

from position_protocol import (POSITION_COLUMNS,POSITION_LENGTH,RAW_COLUMNS,PositionHistory,
    PositionRecorder,PositionStreamDecoder,decode_position,position_status,quantized_delta_units,
    round_away,sw4_meaning)
from position_monitor import PositionMonitor,NOTICE
from wave_monitor import LinkEvent

ROOT=Path(__file__).resolve().parent
A=b'A=0B90 C=0B90 P=FFFFFFF6 T=00000000 U=EC R=1 K=1 F=0\r\n'
M=b'M=3 W=FFFFFF80 N=01 Q=1 Z=1\r\n'


def wire(**changes):
    items=dict(O=0x5103,D=0,S=1,E=75,G=-75,H=100,R=91,P=92,V=104448,W=-104448,
               K=0,A=1,I=0xffff,Z=0,M=5,U=-20,B=2957,C=2955,T=1000,Q=10,L=5000)
    items.update(changes);parts=[]
    for key,value in items.items():
        legacy=items['O'] in (0x5101,0x5102)
        width=1 if key in ('D','S','K','A','Z','M') else 2 if key=='U' else 4 if key in ('O','I','B','C') else (4 if legacy else 8) if key in ('E','G') else (8 if legacy else 16) if key=='L' else 8
        parts.append(f'{key}={value&((1<<(4*width))-1):0{width}X}')
    return (' '.join(parts)+'\r\n').encode('ascii')


class PositionProtocolTests(unittest.TestCase):
    def test_exact_line_width_signed_fields_unsigned_id_time_sequence(self):
        raw=wire(E=-2147483648,G=2147483647,H=-2147483648,R=2147483647,P=-1,V=-2147483648,W=2147483647,
                 U=-100,T=0xffffffff,Q=0x80000000,L=0xffffffffffffffff)
        self.assertEqual(len(raw),POSITION_LENGTH+2)
        f=decode_position(raw)
        self.assertEqual((f.edit_deci,f.confirmed_deci),(-2147483648,2147483647))
        self.assertEqual((f.home_units,f.reference_units,f.position_units),(-2147483648,2147483647,-1))
        self.assertEqual((f.reference_velocity_q8,f.actual_velocity_q8),(-2147483648,2147483647))
        self.assertEqual((f.task_id,f.uptime_ms,f.snapshot_seq,f.duration_ms),(65535,4294967295,2147483648,18446744073709551615))
        self.assertEqual(f.command_pct,-100)

    def test_quantization_round_away_and_requested_angle_are_distinct(self):
        self.assertEqual(round_away(1,2),1);self.assertEqual(round_away(-1,2),-1)
        self.assertEqual(quantized_delta_units(75),9);self.assertEqual(quantized_delta_units(-75),-9)
        self.assertEqual(quantized_delta_units(1),0);self.assertEqual(quantized_delta_units(-1),0)
        self.assertEqual((quantized_delta_units(1800),quantized_delta_units(-1800)),(204,-204))
        f=decode_position(wire(G=-75))
        self.assertEqual(f.executable_target_units,91)
        self.assertAlmostEqual(f.executable_degrees,-9*360/408)
        self.assertNotEqual(f.confirmed_deci/10,f.executable_degrees)
        self.assertIn('不是定位精度',NOTICE)

    def test_home_relative_positions_speed_units_and_missing_home(self):
        f=decode_position(wire())
        self.assertAlmostEqual(f.reference_degrees,-9*360/408)
        self.assertAlmostEqual(f.position_degrees,-8*360/408)
        self.assertEqual((f.reference_speed_degrees,f.actual_speed_degrees),(360,-360))
        self.assertEqual(f.angle_error_adc,2)
        missing=decode_position(wire(A=0,S=0))
        for value in (missing.reference_degrees,missing.position_degrees,missing.executable_degrees,missing.executable_target_units):
            self.assertIsNone(value)

    def test_next_task_uses_actual_confirmation_base_not_previous_target(self):
        # Previous reference301 is still continuous, but actual310 is the new base.
        f=decode_position(wire(E=0,G=300,H=310,P=310,R=301,I=2,S=2,W=5120))
        self.assertEqual(f.edit_deci,0);self.assertEqual(f.confirmed_deci,300)
        self.assertEqual(f.executable_target_units,344)
        self.assertAlmostEqual(f.executable_degrees,30)
        self.assertEqual(f.position_degrees,0)
        self.assertAlmostEqual(f.reference_degrees,-9*360/408)
        self.assertEqual(f.actual_velocity_q8,5120)  # H changes do not zero measured W.
        third=decode_position(wire(E=0,G=-150,H=350,P=350,R=344,I=3,S=2))
        self.assertEqual(third.executable_target_units,333)
        self.assertAlmostEqual(third.executable_degrees,-15)

    def test_multiturn_requests_do_not_modulo_and_exceed_old_signed16_range(self):
        for request,units in ((7200,816),(-7200,-816),(36000,4080),(-36000,-4080)):
            with self.subTest(request=request):
                f=decode_position(wire(E=request,G=request,H=310,P=310,R=301,L=0x100000001))
                self.assertEqual(f.edit_deci,request);self.assertEqual(f.confirmed_deci,request)
                self.assertEqual(f.executable_delta_units,units)
                self.assertEqual(f.executable_target_units,310+units)
                self.assertAlmostEqual(f.executable_degrees,request/10)
                self.assertEqual(f.duration_ms,4294967297)
        self.assertEqual(decode_position(wire(E=2147483647,G=-2147483648)).confirmed_deci,-2147483648)

    def test_extreme_absolute_position_saturates_and_csv_matches_executable_target(self):
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        cases=[(2147483637,2147483647,2147483647,10),(-2147483638,-2147483648,-2147483648,-10)]
        with tempfile.TemporaryDirectory(dir=base) as folder:
            history=PositionHistory();recorder=PositionRecorder(folder,'TEST')
            for index,(home,goal,target,delta) in enumerate(cases):
                f=decode_position(wire(H=home,G=goal,Q=10+index))
                self.assertTrue(f.position_representation_saturated)
                self.assertEqual(f.executable_target_units,target)
                self.assertEqual(f.executable_delta_units,delta)
                self.assertAlmostEqual(f.executable_degrees,delta*360/408)
                recorder.append(f,1+index/10,1,history.append(f,1+index/10,1))
            recorder.close()
            with recorder.csv_path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
            self.assertEqual([row['executable_target_units'] for row in rows],['2147483647','-2147483648'])
            self.assertEqual([row['executable_delta_units'] for row in rows],['10','-10'])
            self.assertNotEqual(rows[0]['requested_delta_units'],rows[0]['executable_delta_units'])

    def test_both_legacy_short_frames_mix_with_new_wide_frames_at_every_split(self):
        stream=wire(O=0x5101)+A+wire(O=0x5102)+M+wire(G=7200,Q=11)
        for split in range(len(stream)+1):
            decoder=PositionStreamDecoder()
            frames=decoder.feed(stream[:split])+decoder.feed(stream[split:])
            self.assertEqual([f.confirmed_deci for f in frames],[7200])
            self.assertEqual(decoder.incompatible_positions,2)
            self.assertEqual(decoder.legacy_frames,2)
            self.assertEqual(decoder.invalid_positions,0)

    def test_same_home_new_task_id_and_task_id_wrap_segment_without_reset_claim(self):
        history=PositionHistory()
        history.append(decode_position(wire(I=65535,Q=10,H=310)),1,1)
        previous_epoch=history.epoch
        c=history.append(decode_position(wire(I=0,Q=11,T=1100,H=310,E=0,G=300,S=2)),1.1,1)
        self.assertGreater(history.epoch,previous_epoch)
        self.assertIn('新位置任务',c.reason);self.assertIn('非编码器复位',c.reason)
        self.assertNotIn('可能复位',c.reason)
        self.assertEqual(c.seq_gap,0)

    def test_old_5101_is_identified_but_never_used_as_relative_task(self):
        decoder=PositionStreamDecoder()
        old=wire(O=0x5101)
        self.assertEqual(decoder.feed(old),[])
        self.assertEqual(decoder.incompatible_positions,1)
        self.assertEqual(decoder.invalid_positions,0)
        self.assertEqual([f.version for f in decoder.feed(A+M+wire())],[0x5103])
        self.assertEqual(decoder.legacy_frames,2)

    def test_malformed_version_order_flags_ranges_and_nontext(self):
        bad=[wire(O=0x5101),wire(O=0x5102),wire(D=4),wire(S=8),wire(K=3),wire(A=2),wire(Z=2),
             wire(U=101),wire(B=4096),wire(C=4096),wire().replace(b'E=0000004B G=FFFFFFB5',b'G=FFFFFFB5 E=0000004B'),b'\xff',None]
        for raw in bad:
            with self.subTest(raw=raw),self.assertRaises(ValueError):decode_position(raw)

    def test_every_split_single_byte_and_glued_legacy_a_m_o(self):
        content=A+wire()+M+wire(Q=11).rstrip(b'\r\n')+wire(Q=12).rstrip(b'\r\n')
        for cut in range(len(content)+1):
            decoder=PositionStreamDecoder();frames=[]
            for part in (content[:cut],content[cut:]):frames.extend(decoder.feed(part))
            self.assertEqual([f.snapshot_seq for f in frames],[10,11,12])
            self.assertEqual((decoder.invalid_positions,decoder.invalid_legacy,decoder.legacy_frames,decoder.discarded_bytes),(0,0,2,0))
        decoder=PositionStreamDecoder();frames=[]
        for byte in content:frames.extend(decoder.feed(bytes([byte])))
        self.assertEqual(len(frames),3)
        self.assertEqual(decoder.invalid_positions,0)

    def test_internal_a_m_fields_do_not_act_as_frame_headers_and_bad_o_recovers(self):
        decoder=PositionStreamDecoder()
        self.assertEqual(decoder.feed(wire()),[decode_position(wire())])
        self.assertEqual((decoder.legacy_frames,decoder.invalid_legacy),(0,0))
        decoder=PositionStreamDecoder()
        frames=decoder.feed(b'O=5103 short\r\n'+A+M+wire())
        self.assertEqual(len(frames),1)
        self.assertEqual(decoder.invalid_positions,1)
        self.assertEqual(decoder.legacy_frames,2)
        self.assertEqual(PositionStreamDecoder().feed(A+M),[])
        decoder.feed(b'noise'*2000)
        self.assertLessEqual(len(decoder.buffer),decoder.MAX_BUFFER)

    def test_loss_reconnect_seq_uptime_regression_and_home_changes_segment(self):
        h=PositionHistory()
        h.append(decode_position(wire(Q=10)),1,1)
        continuity=h.append(decode_position(wire(Q=13,T=1300)),1.3,1)
        self.assertEqual(continuity.seq_gap,2);self.assertEqual(h.lost_snapshots,2)
        self.assertIn('丢号2',continuity.reason)
        previous_epoch=h.epoch
        continuity=h.append(decode_position(wire(Q=0,T=0)),1.4,1)
        self.assertGreater(h.epoch,previous_epoch);self.assertIn('seq回退',continuity.reason);self.assertIn('时间回退',continuity.reason)
        continuity=h.append(decode_position(wire(Q=20,T=2000)),2,2)
        self.assertEqual(continuity.seq_gap,0);self.assertIn('连接段变化',continuity.reason)
        continuity=h.append(decode_position(wire(Q=21,T=2100,A=0,M=6,S=7,Z=1)),2.1,2)
        self.assertIn('home有效性',continuity.reason)
        continuity=h.append(decode_position(wire(Q=22,T=2200,H=500,P=500,R=500,A=1)),2.2,2)
        self.assertIn('home有效性',continuity.reason)
        self.assertEqual(h.samples[-1].frame.position_degrees,0)

    def test_csv_contains_all_atomic_fields_times_raw_line_gaps_and_no_home_blanks(self):
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(base.resolve()))
            recorder=PositionRecorder(folder,'TEST');history=PositionHistory()
            f=decode_position(wire(A=0,S=0))
            recorder.append(f,1,1,history.append(f,1,1))
            f=decode_position(wire(Q=13,T=1300,A=1));continuity=history.append(f,1.3,1)
            recorder.append(f,1.3,1,continuity);recorder.event('telemetry_segment',continuity.reason,1.3)
            recorder.close();recorder.close()
            with recorder.csv_path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
            self.assertEqual(tuple(rows[0]),POSITION_COLUMNS)
            self.assertTrue(set(RAW_COLUMNS).issubset(rows[0]))
            self.assertEqual(rows[0]['relative_position_degrees'],'')
            self.assertEqual(rows[0]['executable_target_units'],'')
            self.assertEqual(rows[1]['snapshot_seq'],'13');self.assertEqual(rows[1]['uptime_ms'],'1300')
            self.assertEqual(rows[1]['duration_ms'],'5000');self.assertEqual(rows[1]['task_id'],'65535')
            self.assertEqual(rows[1]['seq_gap'],'2');self.assertEqual(rows[1]['raw_line'],f.raw)
            self.assertEqual(rows[1]['elapsed_s'],'1.300000');self.assertIn('T',rows[1]['host_time'])
            self.assertTrue(recorder.csv_path.name.endswith('_position.csv'))
            with self.assertRaises(OSError):recorder.append(f,2,1,continuity)

    def test_stale_offline_disconnect_and_sw4_acceptance_policy(self):
        f=decode_position(wire())
        self.assertTrue(position_status(f,.1,True)[1])
        for age,connected in [(2,True),(None,True),(.1,False)]:
            text,fresh=position_status(f,age,connected);self.assertFalse(fresh);self.assertIn('当前状态不可判断',text)
        self.assertFalse(position_status(f,.1,True,'replay')[1])
        self.assertIn('不能替代',position_status(None,None,True)[0])
        self.assertIn('开始位置任务',sw4_meaning(f))
        self.assertIn('确认忽略',sw4_meaning(decode_position(wire(S=2))))
        self.assertIn('开始位置任务',sw4_meaning(decode_position(wire(S=3))))
        self.assertIn('停机标定',sw4_meaning(decode_position(wire(M=0))))
        self.assertIn('预留模式',sw4_meaning(decode_position(wire(D=1))))


class PositionGuiTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        self.app=PositionMonitor(self.root,mode='replay',create_worker=False)
    def tearDown(self):self.app.close()

    def test_cards_show_edit_confirm_quantized_actual_and_task_from_one_o(self):
        app=self.app;app.mode='live';app.wanted=app.connected=True
        app.events.put(LinkEvent('data',A+wire()+M,time.monotonic()));app.poll_events()
        self.assertEqual(app.valid,1);self.assertEqual(app.decoder.legacy_frames,2)
        self.assertEqual(app.values['edit'].get(),'+7.5°');self.assertEqual(app.values['confirmed'].get(),'-7.5°')
        self.assertIn('-7.941°',app.values['executable'].get())
        self.assertIn('保持待命',app.task_var.get());self.assertIn('65535',app.details['confirmed'].get())
        self.assertIn('开始位置任务',app.sw4_var.get());self.assertIn('00 任意位置',app.switch_var.get())
        self.assertEqual(app.last_frame.angle_adc,2957)
        self.assertIsNone(app.worker)

    def test_no_home_and_interrupted_recovery_never_become_arrived(self):
        app=self.app
        app.process_frame(decode_position(wire(A=0,S=7,M=6,Z=1)),1,record=False)
        self.assertIn('无本次home',app.values['executable'].get())
        self.assertIn('无home',app.values['actual'].get())
        self.assertIn('任务中断',app.task_var.get());self.assertNotIn('已到位',app.task_var.get())
        self.assertIn('旧任务不能记为成功',app.switch_var.get())
        app.process_frame(decode_position(wire(Q=11,T=1100,H=500,P=500,R=500,S=1)),1.1,record=False)
        self.assertIn('保持待命',app.task_var.get());self.assertNotIn('已到位',app.task_var.get())
        self.assertEqual(app.last_frame.position_degrees,0)
        self.assertNotEqual(app.history.samples[0].epoch,app.history.samples[1].epoch)

    def test_wait_actual_settle_reserved_mode_and_no_numeric_control_entry(self):
        app=self.app
        app.process_frame(decode_position(wire(S=3)),1,record=False)
        self.assertIn('等待实际收敛',app.task_var.get());self.assertIn('开始位置任务',app.sw4_var.get())
        app.process_frame(decode_position(wire(Q=11,T=1100,S=6,D=2)),1.1,record=False)
        self.assertIn('预留模式待命',app.task_var.get());self.assertIn('10 预留',app.switch_var.get())
        self.assertIn('不执行位置轨迹',app.sw4_var.get())
        def widgets(parent):
            for child in parent.winfo_children():yield child;yield from widgets(child)
        self.assertFalse(any(widget.winfo_class() in ('Entry','TEntry','Spinbox','TSpinbox') for widget in widgets(self.root)))

    def test_relative_task_rebase_cards_and_history_do_not_fake_arrival(self):
        app=self.app
        app.process_frame(decode_position(wire(H=192,P=310,R=301,G=960,I=1,S=3)),1,record=False)
        self.assertIn('开始位置任务',app.sw4_var.get())
        self.assertIn('等待实际收敛',app.task_var.get())
        app.process_frame(decode_position(wire(H=310,P=310,R=301,E=0,G=300,I=2,S=2,Q=11,T=1100)),1.1,record=False)
        self.assertEqual(app.values['edit'].get(),'+0.0°')
        self.assertEqual(app.values['confirmed'].get(),'+30.0°')
        self.assertIn('基准H=310',app.details['executable'].get())
        self.assertIn('终点=344',app.details['executable'].get())
        self.assertIn('+0.00° / -7.94°',app.values['actual'].get())
        self.assertIn('规划移动',app.task_var.get());self.assertNotIn('已到位',app.task_var.get())
        self.assertNotEqual(app.history.samples[0].epoch,app.history.samples[1].epoch)
        self.assertIn('v5.2',self.root.title());self.assertIn('O5103',self.root.title())

    def test_legacy_5101_shows_matching_firmware_guidance_and_no_values(self):
        app=self.app;app.mode='live';app.wanted=app.connected=True
        app.events.put(LinkEvent('data',wire(O=0x5101),time.monotonic()));app.poll_events()
        self.assertEqual(app.valid,0);self.assertIsNone(app.last_frame)
        self.assertIn('旧版O=5101',app.status_var.get())
        self.assertIn('配套v5.2多圈O=5103固件',app.status_var.get())
        self.assertEqual(app.values['confirmed'].get(),'—')

    def test_multiturn_cards_and_uint64_duration_csv_round_trip(self):
        app=self.app;f=decode_position(wire(E=-7200,G=36000,H=310,P=310,R=301,L=0xffffffffffffffff))
        app.process_frame(f,1,record=False)
        self.assertEqual(app.values['edit'].get(),'-720.0°')
        self.assertEqual(app.values['confirmed'].get(),'+3600.0°')
        self.assertIn('+3600.000°',app.values['executable'].get())
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            history=PositionHistory();recorder=PositionRecorder(folder,'TEST')
            recorder.append(f,1,1,history.append(f,1,1));recorder.close()
            with recorder.csv_path.open(encoding='utf-8-sig',newline='') as stream:row=next(csv.DictReader(stream))
            self.assertEqual(row['duration_ms'],'18446744073709551615')
            self.assertEqual(row['confirmed_deci'],'36000')
            app.load_replay(recorder.csv_path)
            self.assertEqual(app.last_frame,f)

    def test_extreme_position_representation_warning_uses_saturated_target(self):
        self.app.process_frame(decode_position(wire(H=2147483637,G=2147483647)),1,record=False)
        self.assertIn('+8.824°',self.app.values['executable'].get())
        self.assertIn('坐标表示边界',self.app.details['executable'].get())
        self.assertIn('终点=2147483647',self.app.details['executable'].get())

    def test_legacy_5102_shows_matching_firmware_guidance_and_no_values(self):
        app=self.app;app.mode='live';app.wanted=app.connected=True
        app.events.put(LinkEvent('data',wire(O=0x5102),time.monotonic()));app.poll_events()
        self.assertEqual(app.valid,0);self.assertIn('旧版O=5101/5102',app.status_var.get())
        self.assertIn('O=5103固件',app.status_var.get())

    def test_old_a_m_cannot_refresh_stale_o_and_disconnect_is_historical(self):
        app=self.app;app.mode='live';app.wanted=app.connected=True
        app.events.put(LinkEvent('data',wire(),time.monotonic()));app.poll_events()
        app.last_received_at=time.monotonic()-2
        app.events.put(LinkEvent('data',A+M,time.monotonic()));app.poll_events()
        self.assertIn('历史位置快照',app.status_var.get())
        app.last_received_at=time.monotonic();app.connected=False;app.refresh_status()
        self.assertIn('当前状态不可判断',app.status_var.get())

    def test_three_waveforms_are_atomic_o_values_and_position_csv_replays(self):
        app=self.app
        f=decode_position(wire());app.process_frame(f,1,record=False)
        self.root.update_idletasks();app.redraw()
        self.assertEqual(len(app.plots),3)
        self.assertTrue(all(plot.canvas.find_all() for plot in app.plots))
        self.assertEqual(app.plots[2].series[0][2](f),2)
        self.assertEqual(app.plots[2].series[1][2](f),0)
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            self.assertTrue(Path(folder).resolve().is_relative_to(base.resolve()))
            recorder=PositionRecorder(folder,'TEST');history=PositionHistory()
            recorder.append(f,1,1,history.append(f,1,1));recorder.close()
            app.load_replay(recorder.csv_path)
            self.assertEqual(app.last_frame,f)
            self.assertEqual(app.mode,'replay');self.assertIsNone(app.worker)
            self.assertIn('离线',app.status_var.get())


    def test_multiple_relative_tasks_csv_replay_keeps_bases_ids_and_no_fake_arrival(self):
        app=self.app;history=PositionHistory()
        frames=[decode_position(wire(H=192,P=310,R=301,G=960,I=1,S=3,Q=10)),
                decode_position(wire(H=310,P=310,R=301,E=0,G=300,I=2,S=2,Q=11,T=1100)),
                decode_position(wire(H=310,P=344,R=344,E=-150,G=300,I=2,S=3,Q=12,T=1200)),
                decode_position(wire(H=344,P=344,R=344,E=0,G=-150,I=3,S=2,Q=13,T=1300))]
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            recorder=PositionRecorder(folder,'TEST')
            for index,f in enumerate(frames):
                recorder.append(f,1+index/10,1,history.append(f,1+index/10,1))
            recorder.close()
            with recorder.csv_path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
            self.assertEqual([r['task_id'] for r in rows],['1','2','2','3'])
            self.assertEqual([r['home_units'] for r in rows],['192','310','310','344'])
            self.assertIn('新位置任务',rows[1]['segment_reason'])
            app.load_replay(recorder.csv_path)
            self.assertEqual([p.frame for p in app.history.samples],frames)
            self.assertEqual(app.last_frame.executable_target_units,327)
            self.assertEqual(app.values['confirmed'].get(),'-15.0°')
            self.assertIn('规划移动',app.task_var.get());self.assertNotIn('已到位',app.task_var.get())
            self.assertIsNone(app.worker)


if __name__=='__main__':unittest.main(verbosity=2)

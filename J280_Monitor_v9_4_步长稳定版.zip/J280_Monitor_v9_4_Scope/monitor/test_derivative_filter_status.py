"""[D_LPF修改] Offline verification of the hardware-provided FL14 indicator."""
import unittest
from unified_protocol import decode_unified
from unified_monitor import derivative_filter_status
from test_unified_runtime import wire_v2

class DerivativeFilterStatusTests(unittest.TestCase):
    def test_enabled_bit_is_read_from_packet(self):
        f=decode_unified(wire_v2(FL=0x4000,AD=500,LD=87))
        self.assertTrue(f.flag(14));self.assertIn('已启用',derivative_filter_status(f))
    def test_same_gains_without_bit_remain_disabled(self):
        f=decode_unified(wire_v2(FL=0,AD=500,LD=87))
        self.assertIn('未启用',derivative_filter_status(f))
    def test_neighboring_flags_do_not_enable_filter(self):
        f=decode_unified(wire_v2(FL=0xBFFF))
        self.assertFalse(f.flag(14));self.assertIn('未启用',derivative_filter_status(f))

"""v8.7 delegates all current and legacy display checks to the unified verifier."""
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name("verify_unified_monitor.py")),run_name="__main__")

"""Runtime trajectory edit telemetry checks; no real serial ports."""
import csv
from pathlib import Path
import tempfile
import tkinter as tk
import unittest
from unified_protocol import *
from unified_monitor import UnifiedMonitor,trajectory_summary,window_seconds,SPAN_OPTIONS
from test_unified_monitor import wire
ROOT=Path(__file__).resolve().parent

def wire_v2(**updates):
    # Independent appended literal, not assembled from parser FIELDS.
    base=wire(**updates).decode('ascii').strip().replace('X=8001','X=8002',1)
    suffix='TE=0000012C TA=0000012C TZ=2 TI=0001 TM=00000001 EA=0000012C EB=0000012C EC=00000064'
    out=[]
    for part in suffix.split():
        key,raw=part.split('=');width=len(raw)
        if key in updates:raw=f'{updates[key]&((1<<(4*width))-1):0{width}X}'
        out.append(key+'='+raw)
    return (base+' '+' '.join(out)+'\r\n').encode('ascii')

class RuntimeProtocolTests(unittest.TestCase):
    def test_512_length_and_all_runtime_signed_fields(self):
        b=wire_v2(TE=-7200,TA=7200,EA=-36000,EB=600,EC=-200,TI=65535,TM=24)
        self.assertEqual(len(b),512);f=decode_unified(b)
        self.assertEqual(f.version,0x8002);self.assertEqual(len(f.values),54)
        self.assertEqual((f.trajectory_edit_degrees,f.trajectory_accepted_degrees,f.trajectory_step_degrees),(-720,720,10))
        self.assertEqual((f.trapezoid_edit_deci,f.scurve_edit_deci,f.sine_edit_deci),(-36000,600,-200))
        self.assertEqual((f.trajectory_run_id,f.trajectory_time_stretch),(65535,24))
    def test_old_8001_never_invents_runtime_values(self):
        f=decode_unified(wire());self.assertEqual(f.version,0x8001);self.assertFalse(f.has_runtime)
        self.assertEqual(len(f.values),46);self.assertIsNone(f.trajectory_edit_degrees)
        self.assertIsNone(f.trajectory_accepted_degrees);self.assertIsNone(f.trajectory_step_degrees)
        with self.assertRaises(AttributeError):_ = f.selected_trajectory_edit_deci
        self.assertIn('未上报',trajectory_summary(f))
    def test_step_indices_and_unknown_future_index(self):
        for index,expected in ((0,.1),(1,1),(2,10),(15,None)):
            f=decode_unified(wire_v2(TZ=index));self.assertEqual(f.trajectory_step_degrees,expected)
            self.assertIsInstance(trajectory_summary(f),str)
    def test_mixed_versions_arbitrary_chunks_atomic_and_no_internal_headers(self):
        stream=wire()+wire_v2(Q=11,T=1100)+wire(Q=12,T=1200)+wire_v2(Q=13,T=1300)
        for size in (1,2,7,31,425,510,8192):
            decoder=UnifiedStreamDecoder();packets=[]
            for i in range(0,len(stream),size):packets.extend(decoder.feed(stream[i:i+size]))
            self.assertEqual([p.kind for p in packets],['X']*4)
            self.assertEqual([p.frame.version for p in packets],[0x8001,0x8002,0x8001,0x8002])
            self.assertEqual(decoder.invalid_x,0);self.assertEqual(decoder.legacy_count,0)
    def test_wrong_version_wrong_length_and_corruption_recovery(self):
        for malformed in (wire_v2().replace(b'X=8002',b'X=8001'),wire().replace(b'X=8001',b'X=8002'),
                          wire_v2().replace(b'TA=0000012C',b'TA=ZZZZZZZZ')):
            with self.assertRaises(ValueError):decode_unified(malformed)
            decoder=UnifiedStreamDecoder();packets=decoder.feed(malformed+wire_v2(Q=11))
            self.assertEqual([p.kind for p in packets],['X'])
            self.assertEqual(packets[0].frame.snapshot_sequence,11)
    def test_accepted_and_run_id_segment_but_edit_only_keeps_continuity(self):
        h=UnifiedHistory()
        h.append(decode_unified(wire_v2()),1,1)
        c=h.append(decode_unified(wire_v2(Q=11,T=1100,TE=7200,EA=7200)),1.1,1)
        self.assertEqual(c.reason,'')
        c=h.append(decode_unified(wire_v2(Q=12,T=1200,TA=7200,TI=2)),1.2,1)
        self.assertIn('轨迹运行ID',c.reason);self.assertIn('接受角度',c.reason)
        c=h.append(decode_unified(wire(Q=13,T=1300)),1.3,1)
        self.assertIn('协议版本变化',c.reason)
    def test_csv_mixed_versions_keeps_missing_empty_and_version_explicit(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'_offline_tests') as folder:
            rec=UnifiedRecorder(folder,'FAKE');h=UnifiedHistory()
            for i,b in enumerate((wire(),wire_v2(Q=11,TE=-7200,TA=300,TI=42,TM=24))):
                f=decode_unified(b);rec.append(f,i,1,h.append(f,i,1))
            rec.close()
            with rec.csv_path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
            self.assertEqual(rows[0]['protocol_version'],'8001')
            for _,_,name,_ in FIELDS_RUNTIME:self.assertEqual(rows[0][name],'')
            self.assertEqual(rows[1]['protocol_version'],'8002')
            self.assertEqual(rows[1]['selected_trajectory_edit_deci'],'-7200')
            self.assertEqual(rows[1]['accepted_trajectory_deci'],'300')
            self.assertEqual(rows[1]['trajectory_time_stretch'],'24')
            self.assertEqual(rows[1]['raw_line'],f.raw)
    def test_real_rtl_uart_512_byte_fixture_all_54_values(self):
        payload=(ROOT.parent/'tests/unified_uart_fixture.txt').read_bytes()
        self.assertEqual(len(payload),512);self.assertTrue(payload.endswith(b'\r\n'))
        f=decode_unified(payload)
        old=decode_unified((ROOT/'fixtures/unified_uart_v8001.txt').read_bytes())
        expected=dict(old.values);expected.update(
            selected_trajectory_edit_deci=7200,accepted_trajectory_deci=7200,
            trajectory_step_index=2,trajectory_run_id=42,trajectory_time_stretch=24,
            trapezoid_edit_deci=7200,scurve_edit_deci=-600,sine_edit_deci=200)
        self.assertEqual(dict(f.values),expected)
        decoder=UnifiedStreamDecoder();packets=[]
        for byte in payload:packets.extend(decoder.feed(bytes([byte])))
        self.assertEqual(len(packets),1);self.assertEqual(packets[0].kind,'X')
        self.assertEqual(dict(packets[0].frame.values),expected)

class RuntimeGuiTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw();self.app=UnifiedMonitor(self.root,mode='replay',create_worker=False)
    def tearDown(self):self.app.close()
    def test_long_window_options_default_and_clamped_boundaries(self):
        self.assertEqual(self.app.span_var.get(),'120')
        self.assertEqual(SPAN_OPTIONS[-3:],('300','600','1800'))
        for value,expected in ((None,30),('bad',30),('nan',30),('inf',30),('-inf',30),(-1,5),(0,5),(5,5),(300,300),(600,600),(1800,1800),(1801,1800),(1e20,1800)):
            self.assertEqual(window_seconds(value),expected)
        self.app.process_frame(decode_unified(wire_v2()),1,record=False)
        self.app.span_var.set('1800');self.app.redraw()
        self.assertTrue(all(plot.canvas.find_all() for plot in self.app.plots))
        self.assertIsNone(self.app.worker)
    def test_running_edit_and_accepted_are_separate_and_not_applied_early(self):
        f=decode_unified(wire_v2(D=3,O=1,J=1,N=2,FL=0x233f,TE=-200,TA=300,EA=300,EB=-600,EC=-200,TI=42,TM=24))
        self.app.process_frame(f,1,record=False);s=self.app.position_var.get()
        self.assertIn('TE=-20.0',s);self.assertIn('TA=+30.0',s)
        self.assertIn('有符号半幅',s);self.assertIn('TI=42',s);self.assertIn('TM=24',s)
        self.assertIn('停止旧轨迹',self.app.details['mode'].get());self.assertIsNone(self.app.worker)
    def test_preparing_not_physical_motion_and_zero_cannot_start(self):
        f=decode_unified(wire_v2(D=2,O=1,J=2,N=6,FL=0x230f))
        self.app.process_frame(f,1,record=False)
        self.assertIn('尚未运动',self.app.overview_var.get())
        self.assertIn('尚未开始实物运动',self.app.sw4_var.get())
        f=decode_unified(wire_v2(D=2,O=1,J=2,N=1,TE=0,FL=0x230f))
        self.app.process_frame(f,1.1,record=False)
        self.assertIn('不开始运动',self.app.sw4_var.get())
    def test_old_version_display_is_missing_not_zero_and_gains_from_frame(self):
        self.app.process_frame(decode_unified(wire()),1,record=False)
        self.assertIn('X8001兼容：未上报',self.app.position_var.get())
        f=decode_unified(wire_v2(AD=400,LP=7,LD=70))
        self.app.process_frame(f,1.1,record=False)
        self.assertIn('40/1/400',self.app.parameter_var.get())
        self.assertIn('7/70',self.app.parameter_var.get())
    def test_new_and_old_csv_replay_without_real_connection(self):
        with tempfile.TemporaryDirectory(dir=ROOT/'_offline_tests') as folder:
            rec=UnifiedRecorder(folder,'FAKE');h=UnifiedHistory()
            for i,b in enumerate((wire(),wire_v2(Q=11,TE=-7200,TA=300,TI=42))):
                f=decode_unified(b);rec.append(f,i,1,h.append(f,i,1))
            rec.close();content=rec.csv_path.read_bytes();self.app.load_replay(rec.csv_path)
            self.assertEqual(self.app.last_frame.version,0x8002)
            self.assertEqual(self.app.last_frame.selected_trajectory_edit_deci,-7200)
            self.assertIsNone(self.app.worker);self.assertEqual(content,rec.csv_path.read_bytes())

if __name__=='__main__':unittest.main()

"""J280 v9.4 scope read-only monitor. The serial/parser/recorder core is unchanged."""
from __future__ import annotations
import argparse
import bisect
import csv
import math
import queue
from collections import deque
from pathlib import Path
import time
import tkinter as tk
from tkinter import font as tkfont
from tkinter import ttk, messagebox
from unified_monitor import (UnifiedMonitor,demo_line,
    active_profile_label,selected_mode_label,trajectory_summary)
from unified_protocol import UnifiedStreamDecoder,UnifiedHistory,decode_unified,label,BALANCE_LABELS,FAULT_LABELS,sw4_meaning
from clean_widgets import CleanPlot
from scope_controls import TIME_DIVS,scope_window_seconds as window_seconds,step_time_div,number,ScopeDial
from clean_semantics import dashboard_values,mode_status,tracking_available
from amfm_semantics import (upper_envelope_degrees,lower_envelope_degrees,
    modulation_summary,modulated_data,heart_data,heart_config,heart_bounds_at,stop_meaning as mod_stop_meaning)

BLUE='#1479b8';GREEN='#16846c';PURPLE='#9566b6';ORANGE='#db8b30'
REFERENCE='#C44E52';ACTUAL='#4C72B0';ENVELOPE='#C59A3D'
MUTED='#8793a3';INK='#24374b';BG='#f3f6fa'

class CleanMonitor(UnifiedMonitor):
    def __init__(self,root,mode='live',create_worker=True):
        # The existing controller owns the sole receiver, parser and recorder.
        # Its first layout is removed before the event loop begins.
        root.withdraw()
        self._packet_backlog=deque();self._batching_packets=False
        self._frame_sync_pending=False;self._status_refreshed_at=0.
        self.status_interval_ms=100;self.poll_budget_ms=8;self.poll_packet_limit=64
        self.ui_batch_count=0;self.last_poll_packets=0
        super().__init__(root,mode=mode,create_worker=create_worker)
        for widget in list(root.winfo_children()):widget.destroy()
        self.plots=[];self.card_values={};self.card_details={};self.card_labels={}
        self.card_detail_labels={};self._card_position_step_snapshot=None
        self._card_position_step_confirmed=None
        self.demo_view=tk.BooleanVar(value=False);self.task_details=tk.BooleanVar(value=False)
        self.main_view_var=tk.StringVar(value='自动')
        self.timebase_var=tk.StringVar(value=number(window_seconds(self.span_var.get())/4))
        self._scope_wheel_remainders={}
        self._zoom_scope_controls=[]
        self.mode_summary_var=tk.StringVar(value='拨码 — · 等待板卡状态');self.fault_var=tk.StringVar()
        self.compact_metrics_var=tk.StringVar(value='等待有效数据')
        self.task_compact_var=tk.StringVar(value='任务详情：等待数据')
        self.record_summary_var=tk.StringVar();self.replay_position_var=tk.DoubleVar(value=0)
        self.replay_position_text=tk.StringVar(value='尚未加载记录')
        self._replay_samples=[];self._replay_times=[];self._replay_right=None;self._loading_replay=False
        self._setting_slider=False;self._task_visible=False;self._main_kind=None
        self._zoom_windows=[];self._metrics_at=0.;self._diag_refresh_at=0.;self.redraw_interval_ms=33;self.event_poll_ms=15
        self._build_clean_layout()
        root.title('J280 · 实时监测 v9.4 · 示波器 · 只读')
        sw,sh=root.winfo_screenwidth(),root.winfo_screenheight()
        root.geometry(f'{min(1280,sw-40)}x{min(800,sh-70)}');root.minsize(min(1000,sw-40),min(640,sh-70))
        root.bind('<F11>',lambda _:self.toggle_demo_view())
        self.refresh_status();self.update_controls()
        if mode=='live':self.refresh_ports()
        root.deiconify()

    def _build_clean_layout(self):
        style=ttk.Style(self.root)
        try:style.theme_use('clam')
        except tk.TclError:pass
        style.configure('TFrame',background=BG);style.configure('TLabel',background=BG,foreground=INK,font=('Microsoft YaHei UI',9))
        style.configure('TButton',font=('Microsoft YaHei UI',9),padding=(8,4),width=0,background='white',foreground=INK,bordercolor='#d6e0eb',lightcolor='white',darkcolor='white')
        style.configure('TNotebook',background=BG,borderwidth=0)
        style.configure('TNotebook.Tab',padding=(16,5),font=('Microsoft YaHei UI',10),background=BG,foreground='#64748b')
        style.map('TNotebook.Tab',background=[('selected','white')],foreground=[('selected',BLUE)])
        style.configure('Card.TFrame',background='white',borderwidth=1,relief='solid',bordercolor='#dce5ef')
        style.configure('Card.TLabel',background='white')
        style.configure('CardValue.TLabel',background='white',font=('Microsoft YaHei UI',16,'bold'),foreground=BLUE)
        style.configure('CardTitle.TLabel',background='white',font=('Microsoft YaHei UI',9),foreground='#65778b')
        style.configure('CardDetail.TLabel',background='white',font=('Microsoft YaHei UI',8),foreground='#7b8999')
        body=ttk.Frame(self.root,padding=(12,9));body.pack(fill='both',expand=True);self.body=body
        header=ttk.Frame(body);header.pack(fill='x')
        ttk.Label(header,text='J280',font=('Microsoft YaHei UI',19,'bold'),foreground=INK).pack(side='left')
        ttk.Label(header,text='串口').pack(side='left')
        self.port_box=ttk.Combobox(header,textvariable=self.port_var,width=8);self.port_box.pack(side='left',padx=5)
        self.connect_button=ttk.Button(header,text='连接监测',command=self.toggle_connection);self.connect_button.pack(side='left')
        self.settings_button=ttk.Button(header,text='连接设置',command=self.show_settings);self.settings_button.pack(side='left',padx=4)
        self.help_button=ttk.Button(header,text='帮助',command=self.show_help);self.help_button.pack(side='right')
        self.advanced_button=ttk.Button(header,text='高级诊断',command=self.toggle_advanced);self.advanced_button.pack(side='right',padx=4)
        self.demo_button=ttk.Button(header,text='演示视图',command=self.toggle_demo_view);self.demo_button.pack(side='right',padx=4)
        self.replay_button=ttk.Button(header,text='打开回放',command=self.choose_replay);self.replay_button.pack(side='right',padx=4)
        statebar=ttk.Frame(body);statebar.pack(fill='x',pady=(7,4))
        self.status_label=ttk.Label(statebar,textvariable=self.status_var,font=('Microsoft YaHei UI',9,'bold'));self.status_label.pack(side='left')
        ttk.Label(statebar,textvariable=self.mode_summary_var,foreground='#52677e').pack(side='right')
        self.fault_label=ttk.Label(body,textvariable=self.fault_var,foreground='#b64a3b',wraplength=1200)
        self.fault_label.pack(fill='x',pady=(0,3))
        self.notebook=ttk.Notebook(body);self.notebook.pack(fill='both',expand=True)
        self.pages={}
        for key,title in [('live','实时监测'),('records','记录回放')]:
            page=ttk.Frame(self.notebook,padding=(7,7));self.notebook.add(page,text=title);self.pages[key]=page
        self.notebook.bind('<<NotebookTabChanged>>',lambda _:self.mark_dirty())
        live=self.pages['live']
        cards=ttk.Frame(live);cards.pack(fill='x',pady=(0,6));self.cards_frame=cards
        titles=[('pole','摆杆直立偏差'),('pwm','PWM给定占空比'),('direction','驱动方向'),('speed','摆臂速度估算'),('position','实际位置'),('dip','拨码 / 任务'),('setting','步长 / 设定角度')]
        for i,(key,title) in enumerate(titles):
            frame=ttk.Frame(cards,style='Card.TFrame',padding=(9,5));frame.grid(row=0,column=i,sticky='nsew',padx=(0,5) if i<len(titles)-1 else 0)
            cards.columnconfigure(i,weight=1,uniform='cards')
            self.card_values[key]=tk.StringVar(value='—');self.card_details[key]=tk.StringVar(value='等待有效数据')
            ttk.Label(frame,text=title,style='CardTitle.TLabel').pack(anchor='w')
            value=ttk.Label(frame,textvariable=self.card_values[key],style='CardValue.TLabel');value.pack(anchor='w',pady=(4,2));self.card_labels[key]=value
            detail=ttk.Label(frame,textvariable=self.card_details[key],style='CardDetail.TLabel',wraplength=176);detail.pack(anchor='w')
            self.card_detail_labels[key]=detail
        cards.bind('<Configure>',lambda _:self._layout_card_details())
        tools=ttk.Frame(live);tools.pack(fill='x',pady=(0,5));self.plot_tools=tools
        ttk.Label(tools,text='时基').pack(side='left')
        self.span_box=ttk.Combobox(tools,textvariable=self.timebase_var,values=tuple(number(v) for v in TIME_DIVS),state='readonly',width=6);self.span_box.pack(side='left',padx=4)
        self.span_box.bind('<<ComboboxSelected>>',self._select_timebase)
        ttk.Label(tools,text='秒/格').pack(side='left')
        self.pause_button=ttk.Button(tools,text='暂停显示',command=self.toggle_pause);self.pause_button.pack(side='left',padx=7)
        self.scope_reset_button=ttk.Button(tools,text='复位视图',command=self.reset_scope);self.scope_reset_button.pack(side='left',padx=(0,7))
        self.follow_box=ttk.Combobox(tools,textvariable=self.main_view_var,values=('自动','位置','起摆'),state='readonly',width=7)
        self.follow_box.pack(side='left');self.follow_box.bind('<<ComboboxSelected>>',lambda _:self._update_main_view())
        self.task_button=ttk.Button(tools,text='任务详情 ▾',command=self.toggle_task_details);self.task_button.pack(side='left',padx=7)
        ttk.Label(tools,textvariable=self.compact_metrics_var,foreground='#5f778e').pack(side='right')
        self.scope_hint=ttk.Label(tools,text='滚轮时基 · Ctrl+滚轮幅值',foreground='#7b8999')
        self.scope_hint.pack(side='right',padx=10)
        tools.bind('<Configure>',self._layout_scope_hint)
        self.task_frame=ttk.Frame(live,padding=(8,4))
        ttk.Label(self.task_frame,textvariable=self.task_compact_var,wraplength=1170,justify='left',foreground='#52677e').pack(anchor='w')
        ttk.Label(self.task_frame,textvariable=self.sw4_var,wraplength=1170,foreground='#9b7034').pack(anchor='w',pady=(3,0))
        grid=ttk.Frame(live);grid.pack(fill='both',expand=True);self.plot_grid=grid
        grid.columnconfigure(0,weight=1,uniform='main');grid.columnconfigure(1,weight=1,uniform='main')
        grid.rowconfigure(0,weight=3);grid.rowconfigure(1,weight=2)
        p=self._new_plot(grid,'摆臂位置 · 参考与实际','° · 相对本次基准 · 点击图例显示/隐藏',self._position_series())
        p.grid(row=0,column=0,columnspan=2,sticky='nsew',pady=(0,5));self.primary_plot=p;p.hidden.add('中心')
        p=self._new_plot(grid,'摆臂速度 · 规划与估算','°/s · 编码器估算',[('规划',REFERENCE,lambda f:f.reference_speed_degrees),('估算',ACTUAL,lambda f:f.actual_speed_degrees)])
        p.grid(row=1,column=0,sticky='nsew',padx=(0,5));self.speed_plot=p
        p=self._new_plot(grid,'摆杆直立偏差','ADC计数 · A−C，非完整内环误差',[('偏差',ACTUAL,lambda f:f.angle_error_adc if f.calibrated else None)])
        p.grid(row=1,column=1,sticky='nsew');self.pole_plot=p
        self.main_plots=[self.primary_plot,self.speed_plot,self.pole_plot]
        self._build_records()
        self._build_settings()
        self._build_advanced()
        footer=ttk.Frame(body);self.footer=footer;footer.pack(fill='x',side='bottom',before=self.notebook,pady=(5,0))
        ttk.Label(footer,text='只读监测 · 暂停或关闭窗口不会停止装置',foreground='#8b714e',font=('Microsoft YaHei UI',8)).pack(side='left')
        ttk.Label(footer,textvariable=self.record_var,foreground='#8290a1',font=('Microsoft YaHei UI',8),anchor='e').pack(side='right',fill='x',expand=True)
        self.main_view_var.trace_add('write',lambda *_:self._update_main_view())
        self.span_var.trace_add('write',lambda *_:self._sync_timebase())

    def _position_series(self):
        return [('参考',REFERENCE,lambda f:f.reference_degrees),('实际',ACTUAL,lambda f:f.position_degrees),
                ('中心', '#a4afbd',lambda f:f.endpoint_degrees),('上包络',ENVELOPE,upper_envelope_degrees),('下包络',ENVELOPE,lower_envelope_degrees)]
    def _new_plot(self,parent,title,unit,series):
        p=CleanPlot(parent,title,unit,series);p.on_change=self.mark_dirty
        p.canvas.bind('<Double-Button-1>',lambda e,plot=p:self.open_zoom(plot))
        p.canvas.bind('<Configure>',lambda _:self.mark_dirty());self._bind_scope_wheel(p);self.plots.append(p);return p

    def _build_records(self):
        page=self.pages['records']
        ttk.Label(page,text='数据与实验记录',font=('Microsoft YaHei UI',13,'bold')).pack(anchor='w',pady=(3,7))
        ttk.Label(page,textvariable=self.record_var,wraplength=1150,foreground='#52677e').pack(anchor='w',pady=(0,8))
        ttk.Label(page,text='连接后自动保存CSV。标记只写入本地记录，不向板卡发送命令。',foreground='#8190a1').pack(anchor='w')
        row=ttk.Frame(page);row.pack(fill='x',pady=9)
        self.note_entry=ttk.Entry(row,textvariable=self.note_var);self.note_entry.pack(side='left',fill='x',expand=True)
        ttk.Button(row,text='保存备注',command=self.save_note).pack(side='left',padx=5)
        ttk.Button(row,text='标记扰动',command=self.mark_disturbance).pack(side='left')
        ttk.Button(row,text='记录文件夹',command=self.open_records).pack(side='left',padx=5)
        ttk.Button(row,text='打开CSV回放',command=self.choose_replay).pack(side='left')
        replay=ttk.LabelFrame(page,text='回放查看位置',padding=10);replay.pack(fill='x',pady=(4,10))
        ttk.Label(replay,textvariable=self.replay_position_text).pack(anchor='w')
        self.replay_scale=ttk.Scale(replay,from_=0,to=1,variable=self.replay_position_var,command=self.seek_replay,state='disabled')
        self.replay_scale.pack(fill='x',pady=(7,0))
        self.record_summary_var.set('尚无记录。回放不会修改原CSV；拖动滑块可查看对应时刻。')
        ttk.Label(page,textvariable=self.record_summary_var,wraplength=1150,foreground='#52677e').pack(anchor='w',pady=(1,8))
        self.event_tree=ttk.Treeview(page,columns=('time','kind','message'),show='headings',height=7)
        for name,title,width in [('time','时间',100),('kind','事件',140),('message','内容',800)]:
            self.event_tree.heading(name,text=title);self.event_tree.column(name,width=width,stretch=name=='message')
        self.event_tree.pack(fill='both',expand=True)

    def _build_settings(self):
        self.settings_window=tk.Toplevel(self.root);self.settings_window.title('连接设置');self.settings_window.withdraw()
        self.settings_window.protocol('WM_DELETE_WINDOW',self.settings_window.withdraw);self.settings_window.resizable(False,False)
        box=ttk.Frame(self.settings_window,padding=18);box.pack(fill='both',expand=True)
        ttk.Label(box,text='串口参数固定：115200 波特 · 8N1',font=('Microsoft YaHei UI',11,'bold')).pack(anchor='w')
        self.auto_box=ttk.Checkbutton(box,text='断线后自动重新连接',variable=self.auto_var);self.auto_box.pack(anchor='w',pady=12)
        ttk.Button(box,text='刷新串口列表',command=self.refresh_ports).pack(anchor='w')
        ttk.Label(box,text='连接过程异常会显示在顶部状态栏；详细信息保存在启动错误日志。',wraplength=380,foreground='#718196').pack(anchor='w',pady=12)
        ttk.Button(box,text='完成',command=self.settings_window.withdraw).pack(anchor='e')

    def _build_advanced(self):
        self.advanced_window=tk.Toplevel(self.root);self.advanced_window.title('J280 · 高级诊断（只读）');self.advanced_window.geometry('1100x720');self.advanced_window.withdraw()
        self.advanced_window.protocol('WM_DELETE_WINDOW',self._hide_advanced)
        tabs=ttk.Notebook(self.advanced_window);tabs.pack(fill='both',expand=True,padx=10,pady=10);self.advanced_notebook=tabs
        dynamic=ttk.Frame(tabs,padding=6);raw=ttk.Frame(tabs,padding=8)
        tabs.add(dynamic,text='输出与动态');tabs.add(raw,text='参数与协议')
        for i in range(2):dynamic.columnconfigure(i,weight=1);dynamic.rowconfigure(i,weight=1)
        specs=[('内部控制命令','% · 带符号给定，非实测PWM',[('U',PURPLE,lambda f:f.command_pct)]),
               ('摆杆速度估计','ADC计数/ms',[('PV',GREEN,lambda f:f.pole_velocity_adc_ms)]),
               ('规划加速度','°/s² · 规划量，非机械实测',[('AC',BLUE,lambda f:f.reference_acceleration_degrees)]),
               ('规划加加速度 jerk','°/s³ · 规划量，非机械实测',[('JK',PURPLE,lambda f:f.reference_jerk_degrees)])]
        self.advanced_plots=[]
        for i,(title,unit,series) in enumerate(specs):
            p=self._new_plot(dynamic,title,unit,series);p.grid(row=i//2,column=i%2,sticky='nsew',padx=3,pady=3);self.advanced_plots.append(p)
        ttk.Label(raw,textvariable=self.stats_var,wraplength=1030,foreground='#7c8b9e').pack(anchor='w',pady=(0,8))
        text=tk.Text(raw,wrap='word',font=('Consolas',10),bg='white',fg=INK,relief='flat',padx=10,pady=8)
        scroll=ttk.Scrollbar(raw,orient='vertical',command=text.yview);text.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');text.pack(fill='both',expand=True);self.record_text=text
        tabs.bind('<<NotebookTabChanged>>',lambda _:(self._refresh_record_text(),self.mark_dirty()))

    def show_settings(self):
        self.settings_window.deiconify();self.settings_window.lift()
    def show_help(self):
        messagebox.showinfo('使用帮助','监测只接收数据，不发送启动、位置、标定或调参命令。\n\n'
            'SW1：板上全局启停；SW2/SW3：编辑下次目标；SW4：确认或平滑停止；SW5：复位。\n'
            'PWM是内部给定，驱动方向是命令方向，速度来自编码器估算。摆杆偏差单位仍为ADC计数。\n\n'
            '暂停仅冻结波形，接收和CSV记录继续；关闭窗口不会停止电机。\n'
            '滚轮调时基，Ctrl+滚轮调当前图幅值；双击打开双旋钮放大窗口。\n'
            '每图横纵各4格；缩放只改变视图；复位视图恢复30秒和自动纵轴。\n'
            '点击图例隐藏/恢复曲线；任务详情展示已接受值与下次编辑值。\n'
            '高级诊断保留PID、前馈、U、加速度、jerk与原始协议。',parent=self.root)
    def toggle_advanced(self):
        if self.advanced_window.state()=='withdrawn':
            self.advanced_window.deiconify();self.advanced_window.lift();self._diag_refresh_at=0.;self._refresh_record_text();self.mark_dirty()
            self.advanced_button.configure(text='收起诊断')
        else:self._hide_advanced()
    def _hide_advanced(self):
        self.advanced_window.withdraw();self.advanced_button.configure(text='高级诊断')
    def toggle_task_details(self):
        self.task_details.set(not self.task_details.get());self._apply_task_visibility()
    def _apply_task_visibility(self):
        show=self.task_details.get() and not self.demo_view.get()
        if show:self.task_frame.pack(fill='x',before=self.plot_grid,pady=(0,5))
        else:self.task_frame.pack_forget()
        self._task_visible=show;self.task_button.configure(text='收起详情 ▴' if show else '任务详情 ▾');self.mark_dirty()
    def toggle_demo_view(self):
        value=not self.demo_view.get();self.demo_view.set(value)
        self.demo_button.configure(text='退出演示视图' if value else '演示视图')
        if value:
            self.settings_button.pack_forget();self.advanced_button.pack_forget();self.task_button.pack_forget();self._hide_advanced()
        else:
            self.settings_button.pack(side='left',padx=4)
            self.advanced_button.pack(side='right',before=self.demo_button,padx=4)
            self.task_button.pack(side='left',padx=7)
        self._apply_task_visibility();self.mark_dirty()

    def _update_main_view(self):
        if not hasattr(self,'primary_plot'):return
        f=self.last_frame;kind=self.main_view_var.get()
        if kind=='自动':kind='起摆' if f is None or f.balance_mode!=5 else '位置'
        if kind==self._main_kind:return
        self._main_kind=kind
        if kind=='起摆':
            self.primary_plot.set_series('起摆过程 · 摆杆ADC','ADC计数 · 显示自动跟随实际平衡阶段',
                [('摆杆ADC',ACTUAL,lambda f:f.angle_adc),('直立',REFERENCE,lambda f:f.center_adc if f.calibrated else None),('下垂',REFERENCE,lambda f:f.down_center_adc)])
        else:self.primary_plot.set_series('摆臂位置 · 参考与实际','° · 相对本次基准 · 点击图例显示/隐藏',self._position_series())
        self.mark_dirty()

    @staticmethod
    def _set_if_changed(var,value):
        if var.get()!=value:var.set(value)
    def process_frame(self,f,elapsed,record=True):
        # History and CSV retain every received frame; only the view is coalesced.
        result=super().process_frame(f,elapsed,record,update_display=False)
        if hasattr(self,'card_values') and not self._loading_replay:
            if self._batching_packets:self._frame_sync_pending=True
            else:self._sync_frame()
        return result
    def _sync_frame(self):
        f=self.last_frame
        if f is None:return
        for key,d in dashboard_values(f).items():
            if key in self.card_values:
                self._set_if_changed(self.card_values[key],d['value']);self._set_if_changed(self.card_details[key],d['detail'])
        self._sync_task_cards(f)
        m=mode_status(f)
        self._set_if_changed(self.sw4_var,mod_stop_meaning(f) or sw4_meaning(f))
        short=lambda text:text.replace('AM幅度调制往返','AM').replace('FM频率调制往返','FM').replace('心形包络往返','心形')
        self._current_mode_summary=(f"拨码 {short(m['selected'])}  |  执行 {short(m['actual'])} · {m['status']}"+
                                    (' · 等待切换' if m['pending'] else ''))
        self._set_if_changed(self.mode_summary_var,self._current_mode_summary)
        # Selection D/TE is independent of the still active J/TA.
        chosen=m['selected']
        if f.selected_dip_mode==0:
            editing=f'下次定位增量 {f.edit_deci/10:+.1f}°'
        elif f.has_runtime:
            editing=f'下次轨迹编辑 {f.selected_trajectory_edit_deci/10:+.1f}° · 步长 {f.trajectory_step_degrees or 0:g}°'
        else:editing='该旧协议未提供下次轨迹编辑值'
        if not f.system_active or f.balance_mode!=5:
            execution=f"执行状态：{m['status']} · 跟踪误差暂不适用"
        elif f.reference_owner==1 and f.has_runtime and f.flag(5) and f.active_trajectory_profile in (1,2,3):
            data=modulated_data(f);heart=heart_data(f)
            if heart:
                timing=f"心形 {heart['period_s']:g}s＋保持 {heart['gap_s']:g}s"
            elif data:
                timing=f"{'包络' if f.active_trajectory_profile==1 else '变速'}周期 {data['modulation_period_s']:g}s"
                if data.get('cycle_metadata_mismatch'):
                    timing+=f"（板卡周期字段 {data['reported_cycle_s']:g}s）"
            else:timing=f"板卡周期字段 {f.trajectory_cycle_ms/1000:g}s"
            execution=(f"实际执行：{m['actual']} · 本次已接受 {f.accepted_trajectory_deci/10:+.1f}° · "
                       f"{timing} · 周期计数 {f.trajectory_cycle_count}")
        else:
            execution=(f"实际执行：定位 / 保持 · 已确认增量 {f.confirmed_deci/10:+.1f}° · "
                       f"任务 {f.position_task_id} · 规划 {f.position_duration_ms/1000:g}s")
        self._set_if_changed(self.task_compact_var,f'拨码 {chosen} · {editing}\n{execution}')
        self.speed_plot.unit='°/s · 编码器估算；详细测速方法见高级诊断'
        self._update_main_view()

    def process_packet(self,p,at):
        result=super().process_packet(p,at)
        if p.kind=='O':
            # Position step K belongs to O5103; trajectory step TZ is different.
            self._card_position_step_snapshot=(p.frame,self.connection_segment,at)
            if self._batching_packets:self._frame_sync_pending=True
            elif self.last_frame is not None:self._sync_task_cards(self.last_frame)
        if p.kind in ('O','X') and self.last_frame is not None:
            f=self.last_frame
            if self.mode=='live' and f.flag(0) and f.selected_dip_mode==0:
                # Retain pairs seen within a batch before a newer O replaces
                # the pending snapshot; widget updates remain coalesced.
                self._position_card_step(f)
            else:
                self._card_position_step_snapshot=None
                self._card_position_step_confirmed=None
        return result

    def _position_card_step(self,f):
        # O and X may arrive in separate serial reads. Commit only a matched
        # snapshot, then hold it while the next pair is still in transit.
        now=time.monotonic()
        pending=getattr(self,'_card_position_step_snapshot',None)
        if pending is not None:
            old,segment,received_at=pending
            if (segment==self.connection_segment and 0<=now-received_at<1.2
                    and old.uptime_ms==f.uptime_ms
                    and old.snapshot_seq==f.snapshot_sequence and old.dip_mode==0):
                self._card_position_step_confirmed=pending
        confirmed=getattr(self,'_card_position_step_confirmed',None)
        if confirmed is None:return None
        old,segment,received_at=confirmed
        if (segment!=self.connection_segment or not 0<=now-received_at<1.2
                or f.uptime_ms<old.uptime_ms):
            self._card_position_step_confirmed=None
            return None
        # Unknown K must remain unknown, rather than retaining an older value.
        return {0:.1,1:1.,2:10.}.get(old.step_index)

    def _task_card_values(self,f):
        names={0:'定位',1:'AM',2:'FM',3:'心形'}
        dip=f.selected_dip_mode
        if self.mode!='live' or not f.flag(0) or dip!=0:
            self._card_position_step_snapshot=None
            self._card_position_step_confirmed=None
        if not f.flag(0):
            return {'dip':{'value':'—','detail':'等待拨码稳定'},
                    'setting':{'value':'—','detail':'等待拨码稳定'}}
        if dip not in names:
            return {'dip':{'value':f'未知 {dip:X}','detail':'未知拨码状态'},
                    'setting':{'value':'—','detail':'未知拨码状态'}}
        selected={'value':f'{dip:02b} · {names[dip]}','detail':'拨码所选任务'}
        step=None
        if dip==0:
            angle=f.edit_deci/10
            if self.mode=='live':step=self._position_card_step(f)
            meaning='定位增量'
        elif f.has_runtime:
            angle=f.selected_trajectory_edit_deci/10
            step=f.trajectory_step_degrees
            meaning='心形最大偏移' if dip==3 else f'{names[dip]}半幅'
        else:
            return {'dip':selected,'setting':{'value':'—','detail':'旧协议未提供轨迹编辑值'}}
        step_text='未上报' if step is None else f'{step:g}°'
        return {'dip':selected,
                'setting':{'value':f'{angle:+.1f}°','detail':f'步长 {step_text} · {meaning}'}}

    def _sync_task_cards(self,f):
        for key,data in self._task_card_values(f).items():
            self._set_if_changed(self.card_values[key],data['value'])
            self._set_if_changed(self.card_details[key],data['detail'])
        self._layout_card_details()

    def _layout_card_details(self):
        if not getattr(self,'card_detail_labels',None):return
        width=max(60,min(176,(self.cards_frame.winfo_width()-30)//7-18))
        if getattr(self,'_card_detail_width',None)!=width:
            self._card_detail_width=width
            for label in self.card_detail_labels.values():label.configure(wraplength=width)
        # Only the two added cards adapt long mode/angle values to their width.
        for key in ('dip','setting'):
            label=self.card_labels[key];value=self.card_values[key].get()
            if getattr(label,'_card_value_layout',None)==(value,width):continue
            label._card_value_layout=(value,width)
            size=16
            while size>8 and tkfont.Font(self.root,family='Microsoft YaHei UI',size=size,weight='bold').measure(value)>width:
                size-=1
            if getattr(label,'_card_value_size',None)!=size:
                label.configure(font=('Microsoft YaHei UI',size,'bold'));label._card_value_size=size
    def refresh_status(self):
        self._status_refreshed_at=time.monotonic()
        super().refresh_status()
        if not hasattr(self,'card_labels') or not self.card_labels:return
        now=time.monotonic();age=None if self.last_received_at is None else max(0,now-self.last_received_at)
        fresh=self.mode=='live' and self.connected and age is not None and age<1.2
        if self.mode=='demo':
            text='演示数据 · 非实机';col='#b37d25'
        elif self.mode=='replay':
            text='历史回放 · 非实时';col='#8a69ab'
        elif fresh:
            text=f'通信正常 · {age:.1f}s前更新';col=GREEN
        elif self.connected and self.last_frame is None:
            text='串口已连接 · 等待有效数据';col='#b37d25'
        elif self.last_frame is not None:
            text='历史数据 · '+(f'{age:.1f}s未更新' if age is not None else '已断开');col=MUTED
        else:text=self.last_status or '尚未连接';col=MUTED
        if self.paused_at is not None and self.mode=='live':text+='  | 波形暂停，数值与记录继续'
        self._set_if_changed(self.status_var,text)
        # The compatibility status formatter also uses this label, so restore
        # the compact view's colour after it; card colours remain cached below.
        self.status_label.configure(foreground=col)
        card_state=(fresh,self.mode=='demo')
        if getattr(self,'_card_color_state',None)!=card_state:
            self._card_color_state=card_state
            for k,w in self.card_labels.items():
                w.configure(foreground=({'reference':REFERENCE,'position':ACTUAL,'speed':ACTUAL,'pole':ACTUAL}.get(k,BLUE)) if fresh or self.mode=='demo' else MUTED)
        f=self.last_frame;alert=''
        if '异常' in self.record_var.get() or '失败' in self.record_var.get():alert='记录提示：'+self.record_var.get()
        if f is not None and f.fault:alert=f'故障：{label(FAULT_LABELS,f.fault)}（F={f.fault}）'
        elif self.last_error:alert='连接异常：'+self.last_error[:180]
        elif self.mode=='replay':alert='当前查看历史记录；图表和数值不代表此刻板卡状态。'
        elif self.mode=='demo':alert='离线界面演示，所有曲线为模拟数据；没有连接串口。'
        if ('异常' in self.record_var.get() or '失败' in self.record_var.get()) and '记录提示' not in alert:
            alert += '  |  记录提示：'+self.record_var.get()
        width=max(300,self.root.winfo_width()-45)
        if getattr(self,'_wrap_width',None)!=width:
            self._wrap_width=width;self.fault_label.configure(wraplength=width)
            for child in self.task_frame.winfo_children():
                if isinstance(child,ttk.Label):child.configure(wraplength=width-30)
        self._set_if_changed(self.fault_var,alert)
        if alert:
            if not self.fault_label.winfo_manager():self.fault_label.pack(fill='x',before=self.notebook,pady=(0,3))
        elif self.fault_label.winfo_manager():self.fault_label.pack_forget()
        if self.mode=='live' and self.last_frame is not None and not fresh:
            self._set_if_changed(self.mode_summary_var,'历史 · '+getattr(self,'_current_mode_summary','拨码 —'))
        self._set_if_changed(self.record_summary_var,self.metric_var.get()+'\n'+('暂停显示仍会继续自动记录。' if self.mode=='live' else '回放仅查看，不修改原CSV。'))
    def _refresh_record_text(self):
        if hasattr(self,'advanced_window'):
            if self.advanced_window.state()=='withdrawn':return
            now=time.monotonic()
            if now-getattr(self,'_diag_refresh_at',0)<.2:return
            self._diag_refresh_at=now
            # Removed legacy pages no longer format dozens of strings per X.
            # Opening diagnostics always formats the most recent atomic frame.
            if self.last_frame is not None:self.update_frame_display(self.last_frame)
        super()._refresh_record_text()
    def poll_events(self):
        if self.closing:return
        token=getattr(self,'poll_after_id',None)
        if token:
            try:self.root.after_cancel(token)
            except tk.TclError:pass
        started=time.monotonic();handled=0;state_changed=False
        self._batching_packets=True
        try:
            # A backlog is spread over bounded callbacks, never discarded.
            while handled<self.poll_packet_limit:
                if handled and (time.monotonic()-started)*1000>=self.poll_budget_ms:break
                if self._packet_backlog:
                    packet,at=self._packet_backlog.popleft()
                    if self.wanted:self.process_packet(packet,at)
                    handled+=1;continue
                try:e=self.events.get_nowait()
                except queue.Empty:break
                handled+=1
                if e.at<self.session_start:continue
                if e.kind=='connected' and self.wanted:
                    self.connected=True;self.connection_segment+=1;self.last_error='';self.last_received_at=None
                    d=self.decoder;self.previous_counts=[a+b for a,b in zip(self.previous_counts,(d.received_bytes,d.invalid_x,d.invalid_legacy,d.legacy_count,d.unsupported_o))]
                    self.decoder=UnifiedStreamDecoder();self.last_status='串口打开，等待完整X=8002/8001'
                    self.event('connected',str(e.value),e.at);state_changed=True
                elif e.kind=='error' and self.wanted:
                    self.connected=False;self.last_error=e.value['message'];self.last_status='等待重连' if e.value['retry'] else '连接失败'
                    self.event('serial_error',self.last_error,e.at);state_changed=True
                    if not e.value['retry']:self.wanted=False;self.finish_recording();self.update_controls()
                elif e.kind=='disconnected':self.connected=False;state_changed=True
                elif e.kind=='data' and self.wanted:
                    self._packet_backlog.extend((packet,e.at) for packet in self.decoder.feed(e.value))
        finally:self._batching_packets=False
        self.last_poll_packets=handled
        if self._frame_sync_pending:
            self._frame_sync_pending=False;self._sync_frame();self.ui_batch_count+=1
        f=self.last_frame
        status_key=(self.mode,self.connected,self.wanted,self.last_error,f.fault if f else None,f.balance_mode if f else None)
        if state_changed or status_key!=getattr(self,'_poll_status_key',None) or time.monotonic()-self._status_refreshed_at>=self.status_interval_ms/1000:
            self._poll_status_key=status_key;self.refresh_status()
        delay=5 if self._packet_backlog or not self.events.empty() else self.event_poll_ms
        self.poll_after_id=self.root.after(delay,self.poll_events)
    def _layout_scope_hint(self,event):
        if event.width<1200:self.scope_hint.pack_forget()
        elif not self.scope_hint.winfo_manager():self.scope_hint.pack(side='right',padx=10)
    def _sync_timebase(self):
        self.timebase_var.set(number(window_seconds(self.span_var.get())/4))
        self.mark_dirty()
        self._refresh_scope_controls()
    def _select_timebase(self,event=None):
        self.span_var.set(number(float(self.timebase_var.get())*4))
    def step_timebase(self,direction):
        self.span_var.set(number(step_time_div(self.span_var.get(),direction)))
    def reset_scope(self):
        self.span_var.set('30')
        for p in self.plots:p.reset_y_scale()
        for win,p,original in self._zoom_windows:p.reset_y_scale()
        self._scope_wheel_remainders.clear()
        self._refresh_scope_controls();self.mark_dirty()
    def _bind_scope_wheel(self,plot):
        for pattern in ('<MouseWheel>','<Button-4>','<Button-5>'):
            plot.canvas.bind(pattern,lambda e,p=plot:self._scope_wheel(e,p))
    def _scope_wheel(self,event,plot):
        vertical=bool(getattr(event,'state',0)&0x4)
        key=(plot,vertical)
        num=getattr(event,'num',None)
        if num in (4,5):steps=1 if num==4 else -1
        else:
            value=self._scope_wheel_remainders.get(key,0)+getattr(event,'delta',0)
            steps=math.trunc(value/120);self._scope_wheel_remainders[key]=value-steps*120
        for _ in range(min(20,abs(steps))):
            direction=1 if steps>0 else -1
            if vertical:plot.step_y_scale(direction)
            else:self.step_timebase(direction)
        self._refresh_scope_controls()
        return 'break'
    def _refresh_scope_controls(self):
        for plot,amplitude,center in self._zoom_scope_controls:
            amplitude.set(plot.scale_text())
            # Do not replace an in-progress center edit on timer ticks.
            if self.root.focus_get() is not getattr(plot,'_center_entry',None):
                mid=plot.y_center if plot.y_per_div is not None else sum(plot._cached_range)/2
                center.set(number(mid))
    def open_zoom(self,source):
        for win,plot,original in self._zoom_windows:
            if original is source:
                win.deiconify();win.lift();self.mark_dirty();return
        win=tk.Toplevel(self.root);win.title('J280 · 示波器放大波形 · 只读')
        win.geometry('1100x760');win.minsize(850,500)
        ttk.Label(win,textvariable=self.status_var,padding=(10,3),foreground='#936b31').pack(fill='x')
        ttk.Label(win,textvariable=self.mode_summary_var,padding=(10,3)).pack(fill='x')
        controls=ttk.Frame(win,padding=(12,6));controls.pack(fill='x')
        plot=CleanPlot(win,source.title,source.unit,source.series)
        plot.hidden=set(source.hidden);plot._cached_range=source._cached_range
        plot._source_signature=(source.title,source.unit,tuple(n for n,c,g in source.series))
        if source.y_per_div is not None:plot.set_y_scale(source.y_per_div,source.y_center)
        amplitude=tk.StringVar(value=plot.scale_text());center=tk.StringVar(value=number(sum(plot._cached_range)/2))
        plot.time_dial=ScopeDial(controls,'时基 · 秒/格',self.step_timebase,self.timebase_var)
        plot.time_dial.pack(side='left',padx=(0,20))
        def change_amplitude(direction):
            plot.step_y_scale(direction);self._refresh_scope_controls()
        plot.amplitude_dial=ScopeDial(controls,'幅值 · 单位/格',change_amplitude,amplitude)
        plot.amplitude_dial.pack(side='left',padx=(0,12))
        edit=ttk.Frame(controls);edit.pack(side='left')
        ttk.Label(edit,text='纵轴中心').grid(row=0,column=0,sticky='w')
        entry=ttk.Entry(edit,textvariable=center,width=12);entry.grid(row=1,column=0);plot._center_entry=entry
        error=tk.StringVar()
        def apply_center(event=None):
            try:
                value=float(center.get())
                if not math.isfinite(value) or abs(value)>1e9:raise ValueError
                scale=plot.y_per_div or (plot._cached_range[1]-plot._cached_range[0])/4
                plot.set_y_scale(scale,value);error.set('');self._refresh_scope_controls()
            except ValueError:error.set('中心需为±1e9内的数值')
            return 'break'
        entry.bind('<Return>',apply_center)
        ttk.Button(edit,text='应用',command=apply_center).grid(row=1,column=1,padx=5)
        def auto_amplitude():
            plot.reset_y_scale();error.set('');self._refresh_scope_controls()
        ttk.Button(edit,text='自动幅值',command=auto_amplitude).grid(row=0,column=1,padx=5)
        ttk.Label(win,textvariable=error,foreground='#b64c3c').pack(anchor='w',padx=12)
        ttk.Label(win,text='旋钮：上下拖动 / 滚轮 / 方向键    波形：滚轮调时基 · Ctrl+滚轮调幅值    横纵各4格 · 时基联动，幅值独立',
                  padding=(12,3),foreground='#64758a').pack(fill='x')
        plot.pack(fill='both',expand=True,padx=10,pady=(0,10));plot.on_change=self.mark_dirty
        self._bind_scope_wheel(plot)
        self._zoom_windows.append((win,plot,source));self._zoom_scope_controls.append((plot,amplitude,center))
        win.protocol('WM_DELETE_WINDOW',win.withdraw)
        win.bind('<Configure>',lambda e:self.mark_dirty());self.mark_dirty()
    def redraw(self):
        if self.closing:return
        draw_started=time.perf_counter()
        token=getattr(self,'redraw_after_id',None)
        if token:
            try:self.root.after_cancel(token)
            except tk.TclError:pass
        now=time.monotonic()
        scroll=(self.mode=='live' and self.connected and self.paused_at is None and
                self.last_received_at is not None and now-self.last_received_at<1.2 and
                self.history.samples and self.history.samples[-1].t>window_seconds(self.span_var.get()))
        if self.dirty or getattr(self,'_last_span',None)!=self.span_var.get() or scroll:
            right=self._replay_right if self.mode in ('replay','demo') and self._replay_right is not None else self.paused_at
            if right is None:
                right=self.elapsed(now) if scroll else (self.history.samples[-1].t if self.history.samples else 0)
            span=window_seconds(self.span_var.get());points=self.history.window(right,span)
            main_visible=self.notebook.select()==str(self.pages['live']) and self.root.state()!='iconic'
            advanced_visible=(self.advanced_window.state() not in ('withdrawn','iconic') and self.advanced_notebook.index('current')==0)
            visible=(self.main_plots if main_visible else [])+(self.advanced_plots if advanced_visible else [])
            for p in visible:p.draw(points,right,span,self.paused_at is not None)
            for win,plot,original in self._zoom_windows:
                if win.state() not in ('withdrawn','iconic'):
                    signature=(original.title,original.unit,tuple(n for n,c,g in original.series))
                    if getattr(plot,'_source_signature',None)!=signature:
                        plot.set_series(original.title,original.unit,original.series);plot._source_signature=signature
                    plot.draw(points,right,span,self.paused_at is not None)
            self._refresh_scope_controls()
            if now-self._metrics_at>=.5:
                self._metrics_at=now;m=self.history.metrics(right,span)
                if m:
                    rmse='—' if m['position_rmse_degrees'] is None else f"{m['position_rmse_degrees']:.2f}°"
                    self.compact_metrics_var.set(f"RMS {rmse}  ·  摆杆峰值 {m['pole_peak_adc']} ADC")
                    self.metric_var.set(f"窗口最后连续段：{m['samples']}点；位置误差RMS={rmse}；摆杆偏差峰值={m['pole_peak_adc']} ADC；内部命令峰值={m['command_peak_pct']}%。")
                else:self.compact_metrics_var.set('等待有效数据');self.metric_var.set('窗口统计：等待有效快照。')
            self.dirty=False;self._last_span=self.span_var.get()
        cost_ms=(time.perf_counter()-draw_started)*1000
        self.last_redraw_ms=cost_ms
        self.redraw_after_id=self.root.after(max(8,round(self.redraw_interval_ms-cost_ms)),self.redraw)
    def close(self):
        # Cancel all callbacks belonging to this one Tk interpreter before destroy.
        for token in self.root.tk.call('after','info'):
            try:self.root.after_cancel(token)
            except tk.TclError:pass
        super().close()
    def toggle_pause(self):
        if self.mode in ('replay','demo') and self._replay_right is not None:
            self.paused_at=None if self.paused_at is not None else self._replay_right
        else:self.paused_at=(self.history.samples[-1].t if self.history.samples else 0) if self.paused_at is None else None
        self.pause_button.configure(text='继续显示' if self.paused_at is not None else '暂停显示');self.mark_dirty();self.refresh_status()
    def event(self,kind,message,at=None):
        super().event(kind,message,at)
        if hasattr(self,'event_tree'):
            t=self.elapsed(at);self.event_tree.insert('',0,values=(f'{t:.1f}s',kind,message))
    def save_note(self):
        super().save_note()
        if self.recorder is not None and self.note_var.get().strip():self.note_var.set('')
    def mark_disturbance(self):
        if not self.note_var.get().strip():self.note_var.set('手动扰动标记')
        self.save_note()
    def load_replay(self,path):
        self._loading_replay=True
        try:super().load_replay(path)
        finally:self._loading_replay=False
        self.event_tree.delete(*self.event_tree.get_children())
        event_path=Path(path).with_name(Path(path).name.replace('_unified.csv','_events.csv'))
        if event_path!=Path(path) and event_path.exists():
            with event_path.open(encoding='utf-8-sig',newline='') as stream:
                for row in csv.DictReader(stream):
                    self.event_tree.insert('',0,values=(f"{float(row['elapsed_s']):.1f}s",row.get('kind',''),row.get('message','')))
        self._setup_replay();self._sync_frame();self.refresh_status();self.notebook.select(self.pages['live'])
    def _setup_replay(self):
        self._replay_samples=list(self.history.samples);self._replay_times=[p.t for p in self._replay_samples]
        if not self._replay_samples:return
        self._replay_right=self._replay_times[-1];self._setting_slider=True
        self.replay_scale.configure(from_=self._replay_times[0],to=max(self._replay_times[-1],self._replay_times[0]+.001),state='normal')
        self.replay_position_var.set(self._replay_right);self._setting_slider=False
        self.replay_position_text.set(f'查看 {self._replay_right:.1f}s / {self._replay_times[-1]:.1f}s')
        self.mark_dirty()
    def seek_replay(self,value):
        if self._setting_slider or not self._replay_times or self.mode not in ('replay','demo'):return
        t=max(self._replay_times[0],min(float(value),self._replay_times[-1]))
        idx=max(0,bisect.bisect_right(self._replay_times,t)-1);p=self._replay_samples[idx]
        history,valid=self.history,self.valid
        self.history=UnifiedHistory();self.connection_segment=p.segment
        try:self.process_frame(p.frame,p.t,record=False)
        finally:self.history,self.valid=history,valid
        self._replay_right=t;self.paused_at=t if self.paused_at is not None else None
        self.replay_position_text.set(f'查看 {t:.1f}s / {self._replay_times[-1]:.1f}s')
        self.mark_dirty();self.refresh_status()
    def toggle_connection(self):
        self._packet_backlog.clear();self._frame_sync_pending=False
        self._card_position_step_snapshot=None;self._card_position_step_confirmed=None
        if not self.wanted:self.event_tree.delete(*self.event_tree.get_children())
        self._replay_right=None;self._replay_samples=[];self._replay_times=[]
        self.replay_scale.configure(state='disabled')
        super().toggle_connection()
        if self.wanted:
            for k in self.card_values:self.card_values[k].set('—');self.card_details[k].set('等待新数据')
            self.mode_summary_var.set('拨码 — · 等待板卡状态')
    def load_demo(self):
        self.mode='demo';self.connected=self.wanted=False;self._loading_replay=True
        h=heart_config(0xC1020D3F).copy();h['gap_ms']=3000
        for i in range(1201):
            t=i*.1;upper,lower=heart_bounds_at(i*100,560,h)
            local=t%59
            q=(upper+lower)/2-(upper-lower)/2*math.cos(2*math.pi*local/4) if local<56 else 0.
            unit=408/360
            actual=q+1.2*math.sin(1.7*t)
            lastq=(self.history.samples[-1].frame.reference_degrees or 0) if self.history.samples else 0
            v=(q-lastq)/.1
            line=demo_line(i,T=i*100,Q=i,D=3,O=1,M=5,K=1,R=1,
                A=2955+round(4*math.sin(1.7*t)),C=2955,H=0,P=round(actual*unit),RF=round(q*unit),Y=round(q*unit),EP=0,
                V=round(v*unit*256),W=round((v+2*math.cos(1.7*t))*unit*256),
                U=round(10*math.sin(2*math.pi*t/4)),S=6,J=3,N=2,CY=int(t//59),EL=i*100,PH=2,
                CF=0xC1020D3F,CL=59000,TE=560,TA=560,EC=560,FL=0x623f)
            self.process_frame(decode_unified(line),t,record=False)
        self._loading_replay=False;self._setup_replay();self._sync_frame()
        self.connect_button.configure(state='disabled');self.refresh_status();self.mark_dirty()

def main():
    p=argparse.ArgumentParser(description='J280 compact read-only monitor')
    p.add_argument('--demo',action='store_true');p.add_argument('--ui-check',action='store_true')
    p.add_argument('--replay',type=Path);p.add_argument('--screenshot-dir',type=Path)
    args=p.parse_args();mode='demo' if args.demo or args.ui_check else 'replay' if args.replay else 'live'
    from clean_capture import enable_dpi_awareness
    enable_dpi_awareness()
    root=tk.Tk();app=CleanMonitor(root,mode=mode,create_worker=mode=='live')
    if mode=='demo':app.load_demo()
    elif args.replay:app.load_replay(args.replay)
    if args.ui_check:
        for size in ('1280x720','1366x768'):
            root.geometry(size);root.update();app.mark_dirty();app.redraw();root.update()
            assert len(app.notebook.tabs())==2 and len(app.main_plots)==3 and len(app.card_values)==7
            assert app.worker is None and app.recorder is None
            for w in [app.notebook,app.port_box,app.pause_button,*app.card_labels.values(),*[p.canvas for p in app.main_plots]]:
                assert w.winfo_ismapped(),str(w)
                x,y=w.winfo_rootx()-root.winfo_rootx(),w.winfo_rooty()-root.winfo_rooty()
                assert 0<=x and x+w.winfo_width()<=root.winfo_width()+1,(size,str(w),'x')
                assert 0<=y and y+w.winfo_height()<=root.winfo_height()+1,(size,str(w),'y')
            if args.screenshot_dir:
                args.screenshot_dir.mkdir(parents=True,exist_ok=True)
                from clean_capture import capture_window
                capture_window(root,args.screenshot_dir/f'clean_main_{size}.png')
        app.toggle_advanced();root.update();app.mark_dirty();app.redraw();root.update()
        assert len(app.advanced_plots)==4
        app._hide_advanced();app.toggle_demo_view();root.update();assert all(w.winfo_ismapped() for w in app.card_labels.values())
        app.toggle_demo_view();app.toggle_task_details();root.update();app.toggle_task_details()
        assert app.worker is None and app.recorder is None
        print('PASS: compact two-page monitor, seven core cards, three main/four advanced plots; no serial port opened.')
        app.close();return 0
    root.mainloop();return 0
if __name__=='__main__':raise SystemExit(main())

"""Self-contained v8.7 monitor verification. Offline; no COM handles."""
from datetime import datetime,timezone,timedelta
import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent
def run(args):
    r=subprocess.run(args,cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
        encoding='utf-8',errors='replace',creationflags=subprocess.CREATE_NO_WINDOW)
    if r.returncode:raise AssertionError(r.stdout)
    return r.stdout
suite=run([sys.executable,'-E','-X','utf8','-m','unittest','discover','-s',str(ROOT),'-p','test_*.py'])
(ROOT/'unified_monitor_tests.log').write_text(suite,encoding='utf-8')
count=int(re.search(r'Ran (\d+) tests',suite).group(1))
heart=run([sys.executable,'-E','-X','utf8',str(PROJECT/'tests/heart_monitor_checks.py')])
(ROOT/'heart_monitor_tests.log').write_text(heart,encoding='utf-8')
h=json.loads((PROJECT/'tests/heart_monitor_result.json').read_text())
assert h['success']
launcher=run([sys.executable,'-E','-X','utf8',str(ROOT/'unified_monitor.py'),'--ui-check'])
assert 'no serial port opened' in launcher
(ROOT/'unified_monitor_ui_check.log').write_text(launcher,encoding='utf-8')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report={
 'variant':'J280_AllModes_v8_7_Heart','result':'PASS','launcher_ui_check':'PASS',
 'protocol_and_gui_tests':count,'new_heart_tests':h['tests'],'total_tests':count+h['tests'],
 'heart_rom_samples_compared':h['complete_rom_samples_compared'],'heart_tag':h['tag'],
 'display_window_default_seconds':120,'display_window_max_seconds':1800,
 'marker':'X=8002','compatible_marker':'X=8001','line_without_crlf':510,'line_with_crlf':512,
 'legacy_tag11_remains_sine':True,'negative_heart_is_mirrored':True,
 'derived_envelopes_use_atomic_board_cf_el_ta':True,'exit_envelopes_hidden_private_phase':True,
 'csv_raw_frames_preserved':True,'wire_contract_changed':False,
 'gui_layout':'5 tabs/8 plots,1280x680 and1366x768',
 'read_only':True,'serial_port_opened':False,'serial_bytes_transmitted':False,'hardware_tested':False,
 'source_sha256':{p.name:sha(p) for p in sorted(ROOT.iterdir()) if p.suffix in ('.py','.cmd','.md')},
 'semantics_sha256':sha(PROJECT/'config/modulated_semantics.json'),
 'contract_sha256':sha(PROJECT/'config/unified_protocol.json'),
 'heart_test_sha256':sha(PROJECT/'tests/heart_monitor_checks.py'),
 'verified_at':datetime.now(timezone(timedelta(hours=8))).isoformat()}
(ROOT/'unified_monitor_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('source_sha256',)},ensure_ascii=False))

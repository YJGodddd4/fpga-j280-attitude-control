@echo off
if not exist "%~dp0Start_Unified_Monitor.cmd" goto missing
call "%~dp0Start_Unified_Monitor.cmd" %*
exit /b %ERRORLEVEL%
:missing
echo Please extract the complete monitor folder before starting.
pause
exit /b 1

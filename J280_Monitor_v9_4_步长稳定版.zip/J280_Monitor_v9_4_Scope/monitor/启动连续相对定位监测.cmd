@echo off
setlocal EnableExtensions DisableDelayedExpansion
call "%~dp0Start_Position_Monitor.cmd" %*
exit /b %ERRORLEVEL%

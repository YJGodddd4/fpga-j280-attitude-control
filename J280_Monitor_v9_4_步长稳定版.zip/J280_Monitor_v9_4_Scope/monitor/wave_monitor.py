"""J280 PID response viewer. Serial access is receive-only."""
from __future__ import annotations

import argparse
from collections import deque
import csv
from dataclasses import dataclass
import math
import os
from pathlib import Path
import queue
import sys
import threading
import time
import tkinter as tk
from tkinter import filedialog, ttk

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "lib"))
from j280_protocol import Frame, decode_frame
from autoswing_protocol import (AutoRecorder as Recorder, ExtendedStreamDecoder as StreamDecoder,
                               diagnostic_status)

VERSION = "3.4 ResumeSwing v5"
VARIANT_TITLE = "自动起摆·运动续摆"
VARIANT_NOTICE = ("每次直立捕获锁定新位置T；失衡后目标作废、退出PID后切入续摆，编码器P连续。运动中无需先停稳或回到下垂。\n"
                  "M2/3/6时T=0表示未锁定，不是要求回0；M4/5为本次锁位。M行与A行异步，不能据上一M行判定某条A帧。\n"
                  "SW1人工停止，SW5复位；关闭监测不会停止电机。位置限位与总超时停机未启用。")
FAULTS = {0: "F=0（不表示有自动保护）", 1: "尚未标定", 2: "角度超范围", 3: "采集、编码器或全局行程异常",
          4: "手动标定失败", 5: "位置超范围", 6: "起摆超时", 7: "启动运动确认不足",
          8: "摆臂速度超限", 9: "起摆脉冲次数上限", 10: "接管超时",
          11: "自动参考或手动标定未就绪", 12: "角度跳变", 13: "PID故障"}


@dataclass
class LinkEvent:
    kind: str
    value: object
    at: float


class SerialWorker(threading.Thread):
    """Own the serial handle in one thread; never transmit serial bytes."""
    def __init__(self, events, factory=None, retry_seconds=2.0):
        super().__init__(daemon=True, name="J280-read-only-serial")
        self.events = events
        self.commands = queue.Queue()
        self.factory = factory
        self.retry_seconds = retry_seconds
        self.stop_requested = threading.Event()
        self.handle = None
        self.wanted_port = None
        self.auto_retry = True
        self.next_retry = 0.0

    def connect(self, port, auto_retry):
        self.commands.put(("connect", (port, auto_retry)))

    def disconnect(self):
        self.commands.put(("disconnect", None))

    def shutdown(self):
        self.stop_requested.set()

    def emit(self, kind, value=None):
        self.events.put(LinkEvent(kind, value, time.monotonic()))

    def close_handle(self):
        current, self.handle = self.handle, None
        if current is not None:
            try:
                current.close()
            except Exception:
                pass

    def create_handle(self):
        if self.factory is not None:
            return self.factory(self.wanted_port)
        import serial
        port = serial.Serial()
        port.port = self.wanted_port
        port.baudrate = 115200
        port.bytesize = serial.EIGHTBITS
        port.parity = serial.PARITY_NONE
        port.stopbits = serial.STOPBITS_ONE
        port.timeout = 0
        port.xonxoff = port.rtscts = port.dsrdtr = False
        port.dtr = port.rts = False
        try:
            port.open()
        except Exception:
            port.close()
            raise
        return port

    def fail(self, exc):
        self.close_handle()
        retry = self.auto_retry and bool(self.wanted_port)
        self.emit("error", {"message": str(exc), "retry": retry})
        self.next_retry = time.monotonic() + self.retry_seconds
        if not retry:
            self.wanted_port = None

    def run(self):
        try:
            while not self.stop_requested.is_set():
                while True:
                    try:
                        command, value = self.commands.get_nowait()
                    except queue.Empty:
                        break
                    self.close_handle()
                    if command == "connect":
                        self.wanted_port, self.auto_retry = value
                        self.next_retry = 0.0
                    elif command == "disconnect":
                        self.wanted_port = None
                        self.emit("disconnected")
                if self.wanted_port and self.handle is None and time.monotonic() >= self.next_retry:
                    try:
                        self.handle = self.create_handle()
                        self.emit("connected", self.wanted_port)
                    except Exception as exc:
                        self.fail(exc)
                if self.handle is not None:
                    try:
                        waiting = self.handle.in_waiting
                        if waiting:
                            packet = self.handle.read(min(waiting, 8192))
                            if packet:
                                self.emit("data", packet)
                    except Exception as exc:
                        self.fail(exc)
                self.stop_requested.wait(0.02)
        finally:
            self.close_handle()


@dataclass(frozen=True)
class Sample:
    t: float
    segment: int
    epoch: int
    frame: Frame


class History:
    def __init__(self, limit=18000):
        self.samples = deque(maxlen=limit)
        self.epoch = 0

    def clear(self):
        self.samples.clear()
        self.epoch += 1

    def append(self, frame, elapsed, segment):
        if self.samples:
            previous = self.samples[-1].frame
            if previous.calibrated != frame.calibrated or (
                frame.calibrated and previous.center != frame.center
            ):
                self.epoch += 1
        self.samples.append(Sample(elapsed, segment, self.epoch, frame))

    def window(self, right, seconds):
        left = max(0.0, right - seconds)
        return [point for point in self.samples if left <= point.t <= right]


class Plot(ttk.Frame):
    def __init__(self, parent, title, unit, series, fixed_range=None, include_zero=True):
        super().__init__(parent)
        self.title, self.unit, self.series = title, unit, series
        self.fixed_range = fixed_range
        self.include_zero = include_zero
        self.canvas = tk.Canvas(self, bg="white", highlightthickness=1,
                                highlightbackground="#dbe3ed", height=190)
        self.canvas.pack(fill="both", expand=True)

    @staticmethod
    def label(value):
        if abs(value) >= 10000:
            return f"{value/1000:.1f}k"
        return f"{value:.1f}" if abs(value) < 10 and value != 0 else f"{value:.0f}"

    def draw(self, points, right, span, paused=False):
        c = self.canvas
        width, height = max(c.winfo_width(), 200), max(c.winfo_height(), 140)
        c.delete("all")
        x0, x1, y0, y1 = 65, width-18, 44, height-31
        if x1 <= x0 or y1 <= y0:
            return
        view_right = max(span, right)
        view_left = max(0.0, view_right-span)
        prepared = []
        values = []
        for name, color, getter in self.series:
            sequence = [(point, getter(point.frame)) for point in points]
            prepared.append((name, color, sequence))
            values.extend(float(value) for _, value in sequence if value is not None)
        if self.fixed_range is not None:
            low, high = self.fixed_range
        else:
            bounds = values+[0.0] if self.include_zero else values or [0.0]
            low, high = min(bounds), max(bounds)
            middle = (high+low)/2
            delta = max(high-low, 10.0)
            low, high = middle-delta*.6, middle+delta*.6
        if high <= low:
            high = low + 1
        def px(t):
            return x0+(t-view_left)/span*(x1-x0)
        def py(value):
            return y1-(value-low)/(high-low)*(y1-y0)
        c.create_text(12, 15, text=self.title+("（波形暂停）" if paused else ""), anchor="w",
                      fill="#18293d", font=("Microsoft YaHei UI", 10, "bold"))
        c.create_text(12, 33, text=self.unit, anchor="w", fill="#63758a", font=("Microsoft YaHei UI", 8))
        for tick in range(5):
            yy = y0+(y1-y0)*tick/4
            value = high-(high-low)*tick/4
            c.create_line(x0, yy, x1, yy, fill="#edf1f6")
            c.create_text(x0-7, yy, text=self.label(value), anchor="e", fill="#64758a", font=("Consolas", 8))
        for tick in range(5):
            xx = x0+(x1-x0)*tick/4
            value = view_left+span*tick/4
            c.create_line(xx, y0, xx, y1, fill="#edf1f6")
            c.create_text(xx, y1+15, text=f"{value:.0f}s", fill="#64758a", font=("Consolas", 8))
        if low <= 0 <= high:
            c.create_line(x0, py(0), x1, py(0), fill="#acb8c7", dash=(3, 3))
        legend_x = x1
        for name, color, sequence in reversed(prepared):
            c.create_text(legend_x, 33, text=name, anchor="e", fill=color, font=("Microsoft YaHei UI", 8, "bold"))
            legend_x -= max(60, len(name)*9+18)
            group = []
            previous = None
            def finish():
                if len(group) >= 4:
                    c.create_line(*group, fill=color, width=2)
                elif len(group) == 2:
                    c.create_oval(group[0]-2, group[1]-2, group[0]+2, group[1]+2, fill=color, outline=color)
            for point, value in sequence:
                continuous = previous is not None and (
                    previous.segment == point.segment and previous.epoch == point.epoch
                    and 0 <= point.t-previous.t <= 0.65
                )
                if value is None or not continuous:
                    finish()
                    group = []
                if value is not None and view_left <= point.t <= view_right:
                    group.extend((px(point.t), py(float(value))))
                previous = point if value is not None else None
            finish()
        if not points:
            c.create_text((x0+x1)/2, (y0+y1)/2, text="等待有效数据", fill="#8390a0", font=("Microsoft YaHei UI", 12))


class Monitor:
    def __init__(self, root, mode="live", create_worker=True):
        self.root, self.mode = root, mode
        root.title("J280 "+VARIANT_TITLE+" · 只读 · V"+VERSION)
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        root.geometry(f"{min(1180,sw-60)}x{min(890,sh-90)}")
        root.minsize(min(900,sw-60), min(700,sh-90))
        style = ttk.Style(root)
        style.configure("TLabel", font=("Microsoft YaHei UI", 9))
        style.configure("TButton", font=("Microsoft YaHei UI", 9))
        self.events = queue.Queue()
        self.worker = SerialWorker(self.events) if create_worker and mode == "live" else None
        if self.worker is not None:
            self.worker.start()
        self.history = History()
        self.decoder = StreamDecoder()
        self.recorder = None
        self.connected = self.wanted = False
        self.segment = 0
        self.session_start = time.monotonic()
        self.last_frame = self.last_received_at = None
        self.last_diagnostic = self.last_diagnostic_at = None
        self.diagnostic_count = self.invalid_modes_total = 0
        self.received = self.valid = self.invalid_total = self.discarded_total = 0
        self.paused_at = None
        self.dirty = True
        self.last_status = "尚未连接"
        self.last_error = ""
        self.closing = False
        self.port_var = tk.StringVar(value="COM7")
        self.auto_var = tk.BooleanVar(value=True)
        self.span_var = tk.StringVar(value="30")
        self.note_var = tk.StringVar()
        self.status_var = tk.StringVar(value="尚未连接；请先关闭占用同一串口的旧监测工具。")
        self.stats_var = tk.StringVar(value="有效帧 0 · 收到字节 0")
        self.record_var = tk.StringVar(value="连接后自动保存CSV；断线后仍保留之前的数据。")
        self.raw_var = tk.StringVar(value="原始数据：等待 A=… C=… P=… 文本遥测")
        self.diagnostic_var = tk.StringVar(value="尚未收到模式诊断；常规波形可独立接收。")
        self.values = {key: tk.StringVar(value="—") for key in ("angle", "error", "position", "command")}
        self.details = {key: tk.StringVar(value="") for key in self.values}

        body = ttk.Frame(root, padding=12)
        body.pack(fill="both", expand=True)
        heading = ttk.Frame(body)
        heading.pack(fill="x")
        ttk.Label(heading, text="J280 · "+VARIANT_TITLE, font=("Microsoft YaHei UI", 15, "bold")).pack(side="left")
        ttk.Label(heading, text="只接收数据 · 不发送启动、标定或调参命令", foreground="#52667d").pack(side="right")
        self.variant_notice = ttk.Label(body, text=VARIANT_NOTICE, foreground="#a52d18",
                                        font=("Microsoft YaHei UI", 10, "bold"), wraplength=1100)
        self.variant_notice.pack(anchor="w", fill="x", pady=(5, 0))
        toolbar = ttk.Frame(body)
        toolbar.pack(fill="x", pady=(9, 5))
        ttk.Label(toolbar, text="串口").pack(side="left")
        self.port_box = ttk.Combobox(toolbar, textvariable=self.port_var, width=10)
        self.port_box.pack(side="left", padx=(6, 6))
        ttk.Button(toolbar, text="刷新", command=self.refresh_ports).pack(side="left")
        ttk.Label(toolbar, text="115200 · 8N1", foreground="#52667d").pack(side="left", padx=12)
        self.connect_button = ttk.Button(toolbar, text="连接监测", command=self.toggle_connection)
        self.connect_button.pack(side="left", padx=4)
        self.auto_box = ttk.Checkbutton(toolbar, text="断线自动重连", variable=self.auto_var)
        self.auto_box.pack(side="left", padx=8)
        self.replay_button = ttk.Button(toolbar, text="回放CSV", command=self.choose_replay)
        self.replay_button.pack(side="right")
        self.status_label = ttk.Label(body, textvariable=self.status_var, foreground="#52667d")
        self.status_label.pack(anchor="w")
        ttk.Label(body, textvariable=self.stats_var, font=("Microsoft YaHei UI", 8), foreground="#61748a").pack(anchor="w", pady=(1, 6))

        cards = ttk.Frame(body)
        cards.pack(fill="x")
        titles = [("angle", "摆杆角度 A"), ("error", "相对直立偏差 A−C"),
                  ("position", "摆臂位置 P"), ("command", "内部电机命令 U")]
        for index, (key, title) in enumerate(titles):
            card = ttk.LabelFrame(cards, text=title, padding=(10, 2, 10, 5))
            card.grid(row=0, column=index, sticky="nsew", padx=(0, 6 if index<3 else 0))
            cards.columnconfigure(index, weight=1, uniform="cards")
            ttk.Label(card, textvariable=self.values[key], font=("Microsoft YaHei UI", 20, "bold"), foreground="#1666ad").pack(anchor="w")
            ttk.Label(card, textvariable=self.details[key], font=("Microsoft YaHei UI", 8), wraplength=230).pack(anchor="w")

        diagnostic_box = ttk.LabelFrame(body, text="模式诊断（独立接收，不代表P/I/D分项）", padding=(8, 4))
        diagnostic_box.pack(fill="x", pady=(6, 0))
        self.diagnostic_label = ttk.Label(diagnostic_box, textvariable=self.diagnostic_var,
                                          foreground="#52667d", wraplength=1100)
        self.diagnostic_label.pack(anchor="w")

        controls = ttk.Frame(body)
        controls.pack(fill="x", pady=7)
        ttk.Label(controls, text="显示窗口").pack(side="left")
        spans = ttk.Combobox(controls, textvariable=self.span_var, width=5, state="readonly", values=("5", "10", "20", "30", "60", "120"))
        spans.pack(side="left", padx=5)
        spans.bind("<<ComboboxSelected>>", lambda event: self.mark_dirty())
        ttk.Label(controls, text="秒").pack(side="left")
        self.pause_button = ttk.Button(controls, text="暂停波形", command=self.toggle_pause)
        self.pause_button.pack(side="left", padx=8)
        ttk.Button(controls, text="清空显示", command=self.clear_display).pack(side="left")
        ttk.Button(controls, text="打开记录文件夹", command=self.open_records).pack(side="right")

        plots = ttk.Frame(body)
        plots.pack(fill="both", expand=True)
        for index in range(2):
            plots.columnconfigure(index, weight=1, uniform="plots")
            plots.rowconfigure(index, weight=1, uniform="plots")
        self.plots = [
            Plot(plots, "摆杆角度与标定中心", "ADC计数（不是度）", [
                ("A", "#176ec4", lambda f:f.angle),
                ("C", "#d38a10", lambda f:f.center if f.calibrated else None)], include_zero=False),
            Plot(plots, "相对直立偏差 A−C", "ADC计数；不是含外环修正的完整内环误差", [
                ("A−C", "#16846c", lambda f:f.angle-f.center if f.calibrated else None)]),
            Plot(plots, "摆臂连续位置与本次锁位目标", "408单位/转；起摆／恢复时T=0为无目标占位", [
                ("P", "#176ec4", lambda f:f.position), ("T", "#d38a10", lambda f:f.target)]),
            Plot(plots, "控制器总输出 U", "百分比；内部命令，并非实体PWM实测", [
                ("U", "#a44dbe", lambda f:f.command)], fixed_range=(-100,100)),
        ]
        for index, plot in enumerate(self.plots):
            plot.grid(row=index//2, column=index%2, sticky="nsew", padx=(0,6) if index%2==0 else (0,0), pady=(0,6))
            plot.canvas.bind("<Configure>", lambda event:self.mark_dirty())

        note_row = ttk.Frame(body)
        note_row.pack(fill="x", pady=(4, 2))
        ttk.Label(note_row, text="本次参数备注").pack(side="left")
        ttk.Entry(note_row, textvariable=self.note_var).pack(side="left", fill="x", expand=True, padx=7)
        ttk.Button(note_row, text="保存备注", command=self.save_note).pack(side="left")
        ttk.Label(body, textvariable=self.record_var, font=("Microsoft YaHei UI", 8), foreground="#52667d").pack(anchor="w")
        ttk.Label(body, textvariable=self.raw_var, font=("Consolas", 9), foreground="#52667d").pack(anchor="w", pady=(2, 2))
        ttk.Label(body, text="只读；R表示流程运行，不等同PID或实体PWM已输出。模式诊断另存_modes.csv。SW1人工停止／SW5复位；关闭监测不会停止电机。",
                  font=("Microsoft YaHei UI", 8), foreground="#52667d", wraplength=1100).pack(anchor="w")
        root.protocol("WM_DELETE_WINDOW", self.close)
        if mode == "live":
            self.refresh_ports()
        else:
            self.status_var.set("演示模式：模拟曲线，未连接板卡。" if mode=="demo" else "离线回放：不是板卡实时状态。")
            self.status_label.configure(foreground="#925595")
        root.after(50, self.poll_events)
        root.after(120, self.redraw)

    def mark_dirty(self):
        self.dirty = True

    def refresh_ports(self):
        try:
            from serial.tools import list_ports
            devices = [entry.device for entry in list_ports.comports()]
            self.port_box["values"] = devices
            if not devices:
                self.last_status = "未发现串口；连接串口USB后点击刷新。"
                self.status_var.set(self.last_status)
        except Exception as exc:
            self.status_var.set(f"串口列表读取失败：{exc}")

    def elapsed(self, at=None):
        return max(0.0, (time.monotonic() if at is None else at)-self.session_start)

    def log_event(self, kind, message, at=None):
        if self.recorder is not None:
            try:
                self.recorder.event(kind, message, self.elapsed(at))
            except OSError as exc:
                self.record_error(exc)

    def record_error(self, exc):
        current, self.recorder = self.recorder, None
        if current is not None:
            try:
                current.close()
            except OSError:
                pass
        self.record_var.set(f"保存记录失败，实时监测继续：{exc}")

    def finish_recording(self):
        if self.recorder is not None:
            current, self.recorder = self.recorder, None
            try:
                current.close()
                self.record_var.set("记录已保存："+current.csv_path.name)
            except OSError as exc:
                self.record_var.set(f"记录关闭异常：{exc}")

    def toggle_connection(self):
        if self.wanted:
            self.wanted = self.connected = False
            if self.worker is not None:
                self.worker.disconnect()
            self.log_event("manual_disconnect", "用户断开监测")
            self.finish_recording()
            self.last_status = "监测已断开；下方保留历史曲线。"
            self.update_controls()
            return
        port = self.port_var.get().strip()
        if not port:
            self.status_var.set("请选择串口。")
            return
        if self.worker is None:
            self.worker = SerialWorker(self.events)
            self.worker.start()
        self.mode = "live"
        self.history.clear()
        self.decoder = StreamDecoder()
        self.received = self.valid = self.invalid_total = self.discarded_total = 0
        self.last_frame = self.last_received_at = None
        self.last_diagnostic = self.last_diagnostic_at = None
        self.diagnostic_count = self.invalid_modes_total = 0
        self.session_start = time.monotonic()
        self.segment = 0
        self.paused_at = None
        self.pause_button.configure(text="暂停波形")
        self.finish_recording()
        try:
            self.recorder = Recorder(ROOT/"records", port, self.note_var.get())
            self.record_var.set("自动记录："+self.recorder.csv_path.name)
        except OSError as exc:
            self.record_error(exc)
        self.wanted = True
        self.connected = False
        self.last_error = ""
        self.last_status = f"正在连接 {port}…"
        self.worker.connect(port, self.auto_var.get())
        self.update_controls()
        self.mark_dirty()

    def update_controls(self):
        self.connect_button.configure(text="断开监测" if self.wanted else "连接监测")
        self.port_box.configure(state="disabled" if self.wanted else "normal")
        self.auto_box.configure(state="disabled" if self.wanted else "normal")
        self.replay_button.configure(state="disabled" if self.wanted else "normal")

    def process_frame(self, frame, elapsed, segment, record=True):
        self.history.append(frame, elapsed, segment)
        self.last_frame = frame
        self.values["angle"].set(str(frame.angle))
        self.values["error"].set(f"{frame.angle-frame.center:+d}" if frame.calibrated else "未标定")
        self.values["position"].set(f"{frame.position:+d}")
        self.values["command"].set(f"{frame.command:+d}%")
        self.details["angle"].set(f"C={frame.center}" if frame.calibrated else "C：尚未标定")
        self.details["error"].set("参考有效" if frame.calibrated else "参考尚未就绪；见模式诊断")
        self.details["position"].set(f"T={frame.target:+d}；P−T={frame.position-frame.target:+d}（算术差；锁位时才是位置误差）")
        self.details["command"].set(("流程运行" if frame.running else "流程停止")+"；"+FAULTS.get(frame.fault,f"故障{frame.fault}"))
        self.raw_var.set("原始帧："+frame.raw)
        if record and self.recorder is not None:
            try:
                self.recorder.append(frame, elapsed, segment)
            except OSError as exc:
                self.record_error(exc)
        self.dirty = True

    def process_diagnostic(self, diagnostic, elapsed, segment, received_at=None, record=True):
        self.last_diagnostic = diagnostic
        self.last_diagnostic_at = time.monotonic() if received_at is None else received_at
        self.diagnostic_count += 1
        if record and self.recorder is not None:
            try:
                self.recorder.append_diagnostic(diagnostic, elapsed, segment)
            except OSError as exc:
                self.record_error(exc)

    def poll_events(self):
        if self.closing:
            return
        for _ in range(200):
            try:
                event = self.events.get_nowait()
            except queue.Empty:
                break
            if event.kind == "connected":
                if not self.wanted:
                    continue
                self.connected = True
                self.segment += 1
                self.invalid_total += self.decoder.invalid_frames
                self.invalid_modes_total += self.decoder.invalid_diagnostics
                self.discarded_total += self.decoder.discarded_bytes
                self.decoder = StreamDecoder()
                self.last_diagnostic = self.last_diagnostic_at = None
                self.last_status = "串口已打开，等待有效帧。"
                self.log_event("connected", str(event.value), event.at)
            elif event.kind == "error":
                if not self.wanted:
                    continue
                self.connected = False
                self.last_error = event.value["message"]
                retry = event.value["retry"]
                self.last_status = "串口暂不可用；每2秒自动重连。" if retry else "连接失败，请刷新并检查串口。"
                self.log_event("serial_error", self.last_error, event.at)
                if not retry:
                    self.wanted = False
                    self.finish_recording()
                    self.update_controls()
            elif event.kind == "disconnected":
                self.connected = False
            elif event.kind == "data" and self.wanted:
                self.received += len(event.value)
                frames = self.decoder.feed(event.value)
                diagnostics = self.decoder.pop_diagnostics()
                if frames:
                    self.last_received_at = event.at
                    self.valid += len(frames)
                    for frame in frames:
                        self.process_frame(frame, self.elapsed(event.at), self.segment)
                for diagnostic in diagnostics:
                    self.process_diagnostic(diagnostic, self.elapsed(event.at), self.segment, event.at)
                if not frames and diagnostics and self.valid == 0:
                    self.raw_var.set("已收到模式诊断，等待A/C/P/T/U常规帧。")
                elif not frames and self.valid == 0:
                    preview = event.value[:70].decode("ascii",errors="backslashreplace").replace("\r"," ").replace("\n"," ")
                    self.raw_var.set("收到字节，尚未匹配协议："+preview)
        self.refresh_status()
        self.root.after(50, self.poll_events)

    def refresh_status(self):
        diagnostic_age = None if self.last_diagnostic_at is None else time.monotonic()-self.last_diagnostic_at
        diagnostic_message, diagnostic_fresh = diagnostic_status(
            self.last_diagnostic, diagnostic_age, self.connected, self.mode)
        self.diagnostic_var.set(diagnostic_message)
        self.diagnostic_label.configure(foreground="#14734f" if diagnostic_fresh else "#925595")
        if self.mode != "live":
            return
        age = None if self.last_received_at is None else time.monotonic()-self.last_received_at
        fresh = self.connected and age is not None and age < 1.2
        if fresh:
            message = f"通信正常 · 最近有效帧距今 {age:.1f} 秒"
            color = "#14734f"
        elif self.connected:
            if self.last_received_at is not None:
                message = f"数据已过期 {age:.1f} 秒 · 保留历史曲线，不能据此判断板卡当前状态。"
            elif self.received:
                message = "已收到字节，但未匹配当前文本协议；请确认115200及下载的固件。"
            else:
                message = "串口已打开，但未收到字节；请检查串口USB、供电和当前固件。"
            color = "#a15e0a"
        else:
            message = self.last_status
            if self.last_frame is not None:
                message += " 当前数值为历史数据。"
            color = "#a13b39" if self.wanted else "#52667d"
        if self.paused_at is not None:
            message += " 波形已暂停，收数和记录仍继续。"
        self.status_var.set(message)
        self.status_label.configure(foreground=color)
        bad = self.invalid_total+self.decoder.invalid_frames
        discarded = self.discarded_total+self.decoder.discarded_bytes
        self.stats_var.set(f"有效帧 {self.valid} · 收到字节 {self.received} · 无效候选 {bad} · 丢弃字节 {discarded}"+
                           f" · 模式诊断 {self.diagnostic_count} · 无效诊断 {self.invalid_modes_total+self.decoder.invalid_diagnostics}"+
                           (" · "+self.last_error[:100] if not self.connected and self.last_error else ""))
        if not fresh and self.last_frame is not None:
            self.details["command"].set("历史值；板卡当前状态未知")
        elif fresh and self.last_frame is not None:
            f=self.last_frame
            self.details["command"].set(("流程运行" if f.running else "流程停止")+"；"+FAULTS.get(f.fault,f"故障{f.fault}"))

    def redraw(self):
        if self.closing:
            return
        if self.dirty:
            right = self.paused_at if self.paused_at is not None else (
                self.history.samples[-1].t if self.history.samples else 0.0)
            span=float(self.span_var.get())
            points=self.history.window(right,span)
            for plot in self.plots:
                plot.draw(points,right,span,self.paused_at is not None)
            self.dirty=False
        self.root.after(120,self.redraw)

    def toggle_pause(self):
        if self.paused_at is None:
            self.paused_at=self.history.samples[-1].t if self.history.samples else 0.0
            self.pause_button.configure(text="继续波形")
        else:
            self.paused_at=None
            self.pause_button.configure(text="暂停波形")
        self.mark_dirty()

    def clear_display(self):
        self.history.clear()
        self.paused_at=None
        self.pause_button.configure(text="暂停波形")
        self.log_event("clear_display","仅清空波形；CSV记录保留")
        self.mark_dirty()

    def save_note(self):
        if self.recorder is not None:
            try:
                self.recorder.set_note(self.note_var.get(),self.elapsed())
                self.record_var.set("备注已保存；记录："+self.recorder.csv_path.name)
            except OSError as exc:
                self.record_error(exc)
        else:
            self.record_var.set("备注将在下次连接时一并保存；它不会改变板卡参数。")

    def open_records(self):
        try:
            folder=ROOT/"records"
            folder.mkdir(parents=True,exist_ok=True)
            os.startfile(str(folder))
        except OSError as exc:
            self.record_var.set(f"打开文件夹失败：{exc}")

    def choose_replay(self):
        if self.wanted:
            return
        path=filedialog.askopenfilename(title="回放J280记录",filetypes=[("CSV记录","*.csv")],initialdir=str(ROOT))
        if path:
            try:
                self.load_replay(Path(path))
            except (OSError,ValueError,KeyError) as exc:
                self.status_var.set(f"回放失败：{exc}")

    def load_replay(self,path):
        samples=[]
        with Path(path).open(encoding="utf-8-sig",newline="") as saved:
            for row in csv.DictReader(saved):
                frame=decode_frame(row["raw_line"])
                elapsed=float(row["elapsed_s"])
                if not math.isfinite(elapsed) or elapsed<0:
                    raise ValueError("记录时间无效")
                segment=int(row.get("segment") or 0)
                samples.append((frame,elapsed,segment))
        if not samples:
            raise ValueError("记录中没有有效数据")
        self.mode="replay"
        self.history.clear()
        self.paused_at=None
        for frame,elapsed,segment in samples:
            self.process_frame(frame,elapsed,segment,record=False)
        self.valid=len(samples)
        self.status_var.set("离线回放："+Path(path).name+"；不是板卡实时状态。")
        self.status_label.configure(foreground="#925595")
        self.stats_var.set(f"已载入 {len(samples)} 帧；可切换显示窗口、暂停或清空显示。")
        self.record_var.set("回放不会改写原记录文件。")
        self.mark_dirty()

    def load_demo(self):
        self.history.clear()
        for index in range(301):
            t=index/10
            offset=int(12*math.sin(t*2.1)*math.exp(-t/18)+3*math.sin(t*0.7))
            pos=int(55*math.sin(t*.52)*math.exp(-t/22))
            output=int(max(-100,min(100,offset*1.8+7*math.cos(t*2.1))))
            raw=(f"A={2960+offset:04X} C=0B90 P={pos&0xffffffff:08X} "
                 f"T=00000000 U={output&0xff:02X} R=1 K=1 F=0")
            self.process_frame(decode_frame(raw),t,1,record=False)
        self.status_var.set("演示模式：这些是模拟曲线，未连接串口、未控制板卡。")
        self.stats_var.set("演示数据301帧 · 用于查看界面，不是实物平衡验证")
        self.connect_button.configure(state="disabled")
        self.replay_button.configure(state="disabled")
        self.dirty=True

    def close(self):
        self.closing=True
        if self.worker is not None:
            self.worker.shutdown()
            self.worker.join(timeout=.5)
        self.finish_recording()
        self.root.destroy()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--demo",action="store_true")
    parser.add_argument("--ui-check",action="store_true")
    parser.add_argument("--replay",type=Path)
    args=parser.parse_args()
    mode="demo" if args.demo or args.ui_check else "replay" if args.replay else "live"
    root=tk.Tk()
    if args.ui_check:
        root.withdraw()
    app=Monitor(root,mode=mode,create_worker=mode=="live")
    if mode=="demo":
        app.load_demo()
    elif args.replay:
        app.load_replay(args.replay)
    if args.ui_check:
        root.update_idletasks()
        app.redraw()
        assert len(app.history.samples)==301
        assert app.worker is None and app.recorder is None
        assert all(plot.canvas.find_all() for plot in app.plots)
        print("PASS: four waveform panels, numeric fields and demo; no serial port opened")
        app.close()
        return 0
    root.mainloop()
    return 0


if __name__=="__main__":
    raise SystemExit(main())

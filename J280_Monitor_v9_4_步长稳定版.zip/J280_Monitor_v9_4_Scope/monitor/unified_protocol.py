"""Read-only atomic X8002/X8001 telemetry, independent legacy packets and CSV."""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from datetime import datetime
import csv
import math
import re
from pathlib import Path
from types import MappingProxyType
from uuid import uuid4
from j280_protocol import _signed, _host_time, decode_frame
from autoswing_protocol import decode_diagnostic
from feedforward_protocol import decode_feedforward,DIAGNOSTIC_LENGTH,DIAGNOSTIC_FIELDS
from position_protocol import decode_position, quantized_delta_units

# Fixed wire contract, tested against config/unified_protocol.json.
FIELDS_V1=[
 ('T',8,'uptime_ms',False),('Q',8,'snapshot_sequence',False),
 ('D',1,'selected_dip_mode',False),('O',1,'reference_owner',False),
 ('M',1,'balance_mode',False),('F',1,'fault',False),('K',1,'calibrated',False),
 ('R',1,'system_active',False),('A',4,'angle_adc',False),('C',4,'center_adc',False),
 ('P',8,'actual_position_units',True),('Y',8,'pid_target_units',True),
 ('RF',8,'planner_reference_units',True),('H',8,'active_base_units',True),
 ('EP',8,'trajectory_endpoint_units',True),('V',8,'reference_velocity_q8',True),
 ('W',8,'actual_velocity_q8',True),('U',2,'command_pct',True),('B',2,'duty_limit_pct',False),
 ('E',8,'edit_deci',True),('G',8,'confirmed_deci',True),('S',1,'position_task_state',False),
 ('I',4,'position_task_id',False),('Z',1,'position_interrupted',False),
 ('L',16,'position_duration_ms',False),('J',1,'active_trajectory_profile',False),
 ('N',1,'trajectory_state',False),('CY',8,'trajectory_cycle_count',False),
 ('EL',8,'trajectory_elapsed_ms',False),('PH',4,'trajectory_phase',False),
 ('AC',8,'reference_acceleration_q8',True),('JK',8,'reference_jerk_q8',True),
 ('FL',4,'flags',False),('PV',8,'pole_velocity_q8',True),('PC',2,'swing_pulse_count',False),
 ('DC',4,'down_center_adc',False),('PK',4,'peak_amplitude_adc',False),
 ('CL',8,'trajectory_cycle_ms',False),('CF',8,'trajectory_config_tag',False),
 ('AP',8,'angle_kp_100',False),('AI',8,'angle_ki_100',False),('AD',8,'angle_kd_100',False),
 ('LP',8,'location_kp_10',False),('LD',8,'location_kd_10',False),
 ('PM',8,'position_min_move_ms',False),('PD',8,'position_ms_per_degree',False)]
FIELDS_RUNTIME=[('TE',8,'selected_trajectory_edit_deci',True),
 ('TA',8,'accepted_trajectory_deci',True),('TZ',1,'trajectory_step_index',False),
 ('TI',4,'trajectory_run_id',False),('TM',8,'trajectory_time_stretch',False),
 ('EA',8,'trapezoid_edit_deci',True),('EB',8,'scurve_edit_deci',True),
 ('EC',8,'sine_edit_deci',True)]
FIELDS=FIELDS_V1+FIELDS_RUNTIME
X_LENGTH_V1=425
X_LENGTH=510
_X1=re.compile('X=(8001)'+''.join(' '+key+r'=([0-9A-Fa-f]{'+str(width)+'})' for key,width,_,_ in FIELDS_V1))
_X2=re.compile('X=(8002)'+''.join(' '+key+r'=([0-9A-Fa-f]{'+str(width)+'})' for key,width,_,_ in FIELDS))
_HEADER=re.compile(rb'X=800[12] |Z=8601 |O=510[123] |A=[0-9A-Fa-f]{4} C=|M=[0-9A-Fa-f] W=')
_STRONG_HEADER=re.compile(rb'X=800[12] |Z=8601 |O=510[123] ')
PROFILE_LABELS={0:'无运行轨迹',1:'梯形速度往返',2:'七段S曲线往返',3:'正弦位置扫描'}
DIP_LABELS={0:'00 连续相对定位',1:'01 梯形速度往返',2:'10 七段S曲线往返',3:'11 正弦位置扫描'}
BALANCE_LABELS={0:'待机',1:'就绪',2:'初始激励',3:'自动起摆',4:'直立捕获／接管',5:'平衡',6:'失衡恢复／续摆'}
POSITION_LABELS={0:'无定位基准',1:'保持待命',2:'规划移动',3:'等待实际收敛／可续任务',4:'已到位',5:'位置减速',6:'轨迹模式待命',7:'任务中断'}
TRAJECTORY_LABELS={0:'未接管',1:'待启动',2:'运动',3:'驻留',4:'停止过渡',5:'任务中断',6:'参数计算准备中（尚未运动）'}
FAULT_LABELS={0:'无故障代码',1:'尚未标定',2:'角度超范围',3:'采集／编码器／全局行程异常',
              4:'手动标定失败',5:'位置超范围',6:'起摆超时',7:'启动运动确认不足',8:'摆臂速度超限',
              9:'起摆脉冲次数上限',10:'接管超时',11:'参考或手动标定未就绪',12:'角度跳变',13:'PID故障'}

def label(mapping,value):return mapping.get(value,f'未知状态 {value:X}')
def clamp32(value):return min(2147483647,max(-2147483648,value))

@dataclass(frozen=True)
class UnifiedFrame:
    values:object
    raw:str
    version:int=0x8001
    def __getattr__(self,name):
        try:return self.values[name]
        except KeyError:raise AttributeError(name) from None
    def flag(self,bit):return bool(self.flags & (1<<bit))
    @property
    def has_runtime(self):return self.version==0x8002
    @property
    def trajectory_edit_degrees(self):return self.selected_trajectory_edit_deci/10 if self.has_runtime else None
    @property
    def trajectory_accepted_degrees(self):return self.accepted_trajectory_deci/10 if self.has_runtime else None
    @property
    def trajectory_step_degrees(self):return {0:.1,1:1.,2:10.}.get(self.trajectory_step_index) if self.has_runtime else None
    @property
    def base_valid(self):return self.flag(3)
    @property
    def reference_degrees(self):return (self.planner_reference_units-self.active_base_units)*360/408 if self.base_valid else None
    @property
    def position_degrees(self):return (self.actual_position_units-self.active_base_units)*360/408 if self.base_valid else None
    @property
    def endpoint_units(self):
        if not self.base_valid:return None
        return self.trajectory_endpoint_units if self.reference_owner==1 else clamp32(self.active_base_units+quantized_delta_units(self.confirmed_deci))
    @property
    def endpoint_degrees(self):return (self.endpoint_units-self.active_base_units)*360/408 if self.base_valid else None
    @property
    def reference_speed_degrees(self):return self.reference_velocity_q8/256*360/408
    @property
    def actual_speed_degrees(self):return self.actual_velocity_q8/256*360/408
    @property
    def reference_acceleration_degrees(self):return self.reference_acceleration_q8/256*360/408 if self.flag(9) and self.base_valid else None
    @property
    def reference_jerk_degrees(self):return self.reference_jerk_q8/256*360/408 if self.flag(8) and self.base_valid else None
    @property
    def pole_velocity_adc_ms(self):return self.pole_velocity_q8/256
    @property
    def angle_error_adc(self):return self.angle_adc-self.center_adc
    @property
    def tracking_error_degrees(self):return (self.actual_position_units-self.planner_reference_units)*360/408 if self.base_valid else None
    @property
    def switch_pending(self):return self.reference_owner==1 and self.selected_dip_mode!=self.active_trajectory_profile

def decode_unified(data):
    try:text=data.decode('ascii') if isinstance(data,bytes) else data
    except UnicodeDecodeError as exc:raise ValueError('X snapshot is not ASCII') from exc
    if not isinstance(text,str):raise ValueError('X snapshot requires text or bytes')
    text=text.strip('\r\n \t');match=_X2.fullmatch(text) or _X1.fullmatch(text)
    if match is None:raise ValueError('Expected a complete self-contained X=8002 or X=8001 snapshot')
    version=int(match.group(1),16);fields=FIELDS if version==0x8002 else FIELDS_V1
    values={}
    for raw,(key,width,name,signed) in zip(match.groups()[1:],fields):
        n=int(raw,16);values[name]=_signed(n,width*4) if signed else n
    if values['angle_adc']>4095 or values['center_adc']>4095 or values['down_center_adc']>4095 or values['peak_amplitude_adc']>8191:
        raise ValueError('ADC field outside numeric scale')
    if abs(values['command_pct'])>100 or values['duty_limit_pct']>100:raise ValueError('Internal command outside percent scale')
    if any(values[k]>1 for k in ('calibrated','system_active','position_interrupted')):raise ValueError('Boolean field outside range')
    return UnifiedFrame(MappingProxyType(values),text,version)

@dataclass(frozen=True)
class Packet:
    kind:str
    frame:object

class UnifiedStreamDecoder:
    """No associations are inferred between old A/M/O and the authoritative X."""
    MAX_BUFFER=8192
    def __init__(self):
        self.buffer=bytearray();self.received_bytes=0;self.discarded_bytes=0
        self.invalid_x=0;self.invalid_legacy=0;self.legacy_count=0;self.unsupported_o=0;self.diagnostic_count=0;self.invalid_diagnostic=0
    def feed(self,data):
        if not isinstance(data,(bytes,bytearray,memoryview)):raise TypeError('feed requires bytes')
        self.received_bytes+=len(data);self.buffer.extend(data);result=[]
        while self.buffer:
            trim=0
            while trim<len(self.buffer) and self.buffer[trim] in b'\r\n \t':trim+=1
            if trim:del self.buffer[:trim]
            if not self.buffer:break
            h=_HEADER.search(self.buffer)
            if h is None:
                # Preserve a partial header across arbitrary serial chunk cuts.
                keep=min(len(self.buffer),15);self.discarded_bytes+=len(self.buffer)-keep
                if keep:self.buffer=self.buffer[-keep:]
                break
            if h.start():self.discarded_bytes+=h.start();del self.buffer[:h.start()]
            kind=chr(self.buffer[0]);old_o=kind=='O' and self.buffer.startswith((b'O=5101 ',b'O=5102 '))
            length={'X':X_LENGTH if self.buffer.startswith(b'X=8002 ') else X_LENGTH_V1,'O':158 if old_o else 174,'A':52,'M':27,'Z':DIAGNOSTIC_LENGTH}[kind]
            # A=... C=... occurs inside X itself. Never use that internal
            # header as a resynchronization point while an X is in progress.
            later=(_STRONG_HEADER if kind in ('X','Z') else _HEADER).search(self.buffer,2)
            newline=self.buffer.find(b'\n')
            if later is not None and later.start()<length:
                self._reject(kind);self.discarded_bytes+=later.start();del self.buffer[:later.start()];continue
            if 0<=newline<length:
                self._reject(kind);self.discarded_bytes+=newline+1;del self.buffer[:newline+1];continue
            if len(self.buffer)<length:break
            if kind in ('X','Z'):
                # Version 8001 is a prefix of 8002. Require its real CRLF so a
                # mislabeled long frame cannot masquerade as a shorter snapshot.
                if len(self.buffer)<length+2:break
                if self.buffer[length:length+2]!=b'\r\n':
                    boundaries=[n for n in ((newline+1 if newline>=0 else 0),(later.start() if later is not None else 0)) if n>0]
                    if not boundaries:break
                    end=min(boundaries);self._reject(kind);self.discarded_bytes+=end;del self.buffer[:end];continue
            raw=bytes(self.buffer[:length])
            if old_o:
                self.unsupported_o+=1;del self.buffer[:length];continue
            try:f={'X':decode_unified,'O':decode_position,'A':decode_frame,'M':decode_diagnostic,'Z':decode_feedforward}[kind](raw)
            except ValueError:
                self._reject(kind)
                # Whole corrupt X must not be decoded again through its A/M fields.
                if kind in ('X','Z') and newline>=0:
                    self.discarded_bytes+=newline+1;del self.buffer[:newline+1]
                else:self.discarded_bytes+=2;del self.buffer[:2]
                continue
            result.append(Packet(kind,f));self.legacy_count+=kind not in ('X','Z');self.diagnostic_count+=kind=='Z';del self.buffer[:length]
        if len(self.buffer)>self.MAX_BUFFER:
            n=len(self.buffer)-self.MAX_BUFFER;self.discarded_bytes+=n;del self.buffer[:n]
        return result
    def _reject(self,kind):
        if kind=='X':self.invalid_x+=1
        elif kind=='Z':self.invalid_diagnostic+=1
        else:self.invalid_legacy+=1

def sw4_meaning(f):
    if f.balance_mode in (0,1):return 'SW4：停机标定沿用原逻辑；不启动位置或轨迹。'
    if f.balance_mode!=5 or not f.base_valid:return 'SW4：等待平衡接管完成；失衡续摆成功不等于旧轨迹完成。'
    if f.reference_owner==1:
        if f.selected_dip_mode==0:return 'SW4：等待轨迹停止和位置接管；00不会抢占当前运动。'
        if f.flag(6):return 'SW4：停止请求已接受，正在完成停止过渡；不会排队启动新轨迹。'
        if f.trajectory_state==6:return 'SW4：启动参数正在计算，尚未开始实物运动；等待准备完成，不排队重复启动。'
        if f.flag(5):return 'SW4：按下请求平滑停止；梯形/S在单程末停止，正弦按包络退出。'
        if f.trajectory_state==1 and f.has_runtime and f.selected_trajectory_edit_deci==0:return 'SW4：当前编辑角度为0，不开始运动；先用SW2/SW3编辑角度。'
        if f.trajectory_state==1:return 'SW4：约20ms消抖后按下，启动所选轨迹；中心在运行期间固定。'
        return 'SW4：轨迹未处于待启动状态，请查看模式和过渡状态。'
    if f.selected_dip_mode!=0:return 'SW4：等待轨迹模块接管；切换拨码不会自动启动。'
    if f.position_task_state in (1,3,4):return 'SW4：按下确认本次旋转增量，以当时实际位置为基准；E随后清零。'
    return 'SW4：位置移动/减速中按下确认忽略，不排队；结束后松开再按。'

def unified_status(frame,age,connected,mode='live'):
    if mode!='live':return '离线／演示数据：不代表板卡当前状态；未连接真实串口。',False
    if frame is None:return '等待完整X=8002/8001快照；兼容A/M/O不能替代统一快照。',False
    if not connected or age is None or age>=1.2:return '历史统一快照：断线或数据陈旧，当前板卡状态不可判断。',False
    return f'统一通信正常：最近X距今{max(0,age):.2f}秒；全部主显示来自同一快照。',True

@dataclass(frozen=True)
class Sample:
    t:float
    segment:int
    epoch:int
    frame:UnifiedFrame

@dataclass(frozen=True)
class Continuity:
    segment:int
    seq_gap:int
    reason:str

class UnifiedHistory:
    def __init__(self,limit=24000):self.samples=deque(maxlen=limit);self.epoch=0;self.lost_snapshots=0
    def clear(self):self.samples.clear();self.epoch+=1;self.lost_snapshots=0
    def append(self,f,elapsed,connection_segment):
        reasons=[];gap=0
        if self.samples:
            p=self.samples[-1];old=p.frame
            if p.segment!=connection_segment:reasons.append('串口连接段变化')
            else:
                if f.snapshot_sequence<old.snapshot_sequence:reasons.append('快照序号回退：可能复位或回绕')
                elif f.snapshot_sequence>old.snapshot_sequence+1:
                    gap=f.snapshot_sequence-old.snapshot_sequence-1;self.lost_snapshots+=gap;reasons.append(f'快照丢号{gap}')
                if f.uptime_ms<old.uptime_ms:reasons.append('板卡时间回退：可能复位或回绕')
                if f.version!=old.version:reasons.append('统一协议版本变化，运行编辑字段不跨版本推断')
                if f.trajectory_config_tag!=old.trajectory_config_tag:reasons.append('轨迹配置CF变化，曲线定义不跨配置连接')
                if f.has_runtime and old.has_runtime:
                    if f.trajectory_run_id!=old.trajectory_run_id:reasons.append('轨迹运行ID变化')
                    if f.accepted_trajectory_deci!=old.accepted_trajectory_deci:reasons.append('轨迹接受角度变化')
                if (f.base_valid,f.active_base_units)!=(old.base_valid,old.active_base_units):reasons.append('基准有效性／本段基准变化')
                if f.position_task_id!=old.position_task_id:reasons.append('位置任务ID变化，非编码器复位')
                if (f.reference_owner,f.active_trajectory_profile)!=(old.reference_owner,old.active_trajectory_profile):reasons.append('参考接管／实际轨迹变化')
                if f.flag(5)!=old.flag(5):reasons.append('轨迹运行边界')
                if f.trajectory_elapsed_ms<old.trajectory_elapsed_ms:reasons.append('轨迹时间重新开始，非板卡复位')
        if reasons:self.epoch+=1
        self.samples.append(Sample(float(elapsed),connection_segment,self.epoch,f))
        return Continuity(self.epoch,gap,'；'.join(reasons))
    def window(self,right,span):return [p for p in self.samples if max(0,right-span)<=p.t<=right]
    def metrics(self,right,span):
        points=self.window(right,span)
        if not points:return None
        # Only the latest uninterrupted epoch enters a displayed comparison.
        epoch=points[-1].epoch;frames=[p.frame for p in points if p.epoch==epoch]
        errors=[f.tracking_error_degrees for f in frames if f.tracking_error_degrees is not None and f.balance_mode==5 and f.system_active and f.fault==0]
        return {'samples':len(frames),'position_samples':len(errors),
                'position_rmse_degrees':math.sqrt(sum(e*e for e in errors)/len(errors)) if errors else None,
                'pole_peak_adc':max(abs(f.angle_error_adc) for f in frames),
                'command_peak_pct':max(abs(f.command_pct) for f in frames)}

RAW_COLUMNS=tuple(name for _,_,name,_ in FIELDS)
DERIVED_COLUMNS=('reference_degrees','position_degrees','endpoint_degrees','reference_speed_degrees',
                 'actual_speed_degrees','reference_acceleration_degrees','reference_jerk_degrees',
                 'pole_velocity_adc_ms','angle_error_adc','tracking_error_degrees',
                 'trajectory_edit_degrees','trajectory_accepted_degrees','trajectory_step_degrees')
UNIFIED_COLUMNS=('host_time','elapsed_s','connection_segment','segment','protocol_version',*RAW_COLUMNS,*DERIVED_COLUMNS,'seq_gap','segment_reason','raw_line')

class UnifiedRecorder:
    def __init__(self,folder,port):
        folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
        token=re.sub(r'[^A-Za-z0-9_-]','_',str(port)) or 'port'
        stem=f'J280_AllModes_{token}_{datetime.now():%Y%m%d_%H%M%S_%f}_{uuid4().hex[:6]}'
        self.csv_path=folder/(stem+'_unified.csv');self.event_path=folder/(stem+'_events.csv');self._closed=False;self.rows=0
        self.diagnostic_path=self.csv_path.with_name(self.csv_path.name.replace('_unified.csv','_feedforward.csv'));self._diagnostics=None;self.diagnostic_rows=0
        self._data=self.csv_path.open('x',encoding='utf-8-sig',newline='')
        try:self._events=self.event_path.open('x',encoding='utf-8-sig',newline='')
        except OSError:self._data.close();raise
        try:
            self._writer=csv.writer(self._data);self._event_writer=csv.writer(self._events)
            self._writer.writerow(UNIFIED_COLUMNS);self._event_writer.writerow(('host_time','elapsed_s','kind','message'))
            self._data.flush();self._events.flush()
        except OSError:self._data.close();self._events.close();self._closed=True;raise
    def append(self,f,elapsed,connection_segment,continuity):
        if self._closed:raise OSError('Unified recording is closed')
        self._writer.writerow((_host_time(),f'{float(elapsed):.6f}',connection_segment,continuity.segment,f'{f.version:04X}',
                              *(getattr(f,k,None) for k in RAW_COLUMNS),*(getattr(f,k) for k in DERIVED_COLUMNS),
                              continuity.seq_gap,continuity.reason,f.raw))
        self._data.flush();self.rows+=1
    def append_diagnostic(self,f,elapsed,connection_segment):
        if self._closed:raise OSError('Unified recording is closed')
        if self._diagnostics is None:
            self._diagnostics=self.diagnostic_path.open('x',encoding='utf-8-sig',newline='')
            self._diagnostic_writer=csv.writer(self._diagnostics)
            self._diagnostic_writer.writerow(('host_time','elapsed_s','connection_segment','diagnostic_version',
                *(name for _,_,name,_ in DIAGNOSTIC_FIELDS),'raw_line'))
        self._diagnostic_writer.writerow((_host_time(),f'{float(elapsed):.6f}',connection_segment,'8601',
            *(getattr(f,name) for _,_,name,_ in DIAGNOSTIC_FIELDS),f.raw))
        self._diagnostics.flush();self.diagnostic_rows+=1
    def event(self,kind,message,elapsed):
        if self._closed:raise OSError('Unified recording is closed')
        self._event_writer.writerow((_host_time(),f'{float(elapsed):.6f}',kind,message));self._events.flush()
    def close(self):
        if self._closed:return
        self._closed=True;error=None
        for stream in (self._data,self._events,self._diagnostics):
            if stream is None:continue
            try:
                try:stream.flush()
                finally:stream.close()
            except OSError as exc:
                if error is None:error=exc
        if error is not None:raise error

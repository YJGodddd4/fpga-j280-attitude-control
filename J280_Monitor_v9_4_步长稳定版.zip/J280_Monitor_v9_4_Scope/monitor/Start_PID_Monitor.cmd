@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title J280 Simple AutoSwing - NO AUTO PROTECTION
set "J280_WAVE_ROOT=%~dp0"
set "J280_WAVE_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist "%J280_WAVE_PYTHON%" goto missing_python
if not exist "%J280_WAVE_ROOT%wave_monitor.py" goto missing_files
if not exist "%J280_WAVE_ROOT%j280_protocol.py" goto missing_files
if not exist "%J280_WAVE_ROOT%lib\serial\__init__.py" goto missing_files
"%J280_WAVE_PYTHON%" -E -X utf8 -u "%J280_WAVE_ROOT%wave_monitor.py" %* 2>"%J280_WAVE_ROOT%startup_error.log"
set "J280_WAVE_RESULT=%ERRORLEVEL%"
if not "%J280_WAVE_RESULT%"=="0" goto failed
exit /b 0
:missing_python
echo The Python runtime was not found:
echo %J280_WAVE_PYTHON%
goto wait_error
:missing_files
echo Required files are missing. Extract the COMPLETE monitor folder.
goto wait_error
:failed
echo J280 monitor could not start. Details:
type "%J280_WAVE_ROOT%startup_error.log"
:wait_error
echo.
echo Please keep this window open and report the error.
pause
exit /b 1

@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul
title J280 Monitor v9.4 - Oscilloscope - Clean Dashboard - Read-only
set "J280_UNIFIED_ROOT=%~dp0"
set "J280_UNIFIED_PYTHON=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if not exist "%J280_UNIFIED_PYTHON%" goto missing_python
if not exist "%J280_UNIFIED_ROOT%clean_monitor.py" goto missing_files
if not exist "%J280_UNIFIED_ROOT%unified_protocol.py" goto missing_files
if not exist "%J280_UNIFIED_ROOT%feedforward_protocol.py" goto missing_files
if not exist "%J280_UNIFIED_ROOT%wave_monitor.py" goto missing_files
if not exist "%J280_UNIFIED_ROOT%position_protocol.py" goto missing_files
if not exist "%J280_UNIFIED_ROOT%lib\serial\__init__.py" goto missing_files
"%J280_UNIFIED_PYTHON%" -E -X utf8 -u "%J280_UNIFIED_ROOT%clean_monitor.py" %* 2>"%J280_UNIFIED_ROOT%unified_monitor_startup_error.log"
set "J280_UNIFIED_RESULT=%ERRORLEVEL%"
if not "%J280_UNIFIED_RESULT%"=="0" goto failed
exit /b 0
:missing_python
echo Bundled Python runtime was not found:
echo %J280_UNIFIED_PYTHON%
goto wait_error
:missing_files
echo Required monitor files are missing. Extract the complete monitor folder.
goto wait_error
:failed
echo Unified monitor could not start. Details:
type "%J280_UNIFIED_ROOT%unified_monitor_startup_error.log"
:wait_error
echo.
echo Keep this window open and report the error.
pause
exit /b 1

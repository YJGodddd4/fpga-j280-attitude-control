"""[FASTAB修改] Offline semantic tests only: no GUI creation, serial port or hardware."""
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
import unified_monitor as monitor

NEW_TAG=0xA1B2C3D4
OLD_TAG=0x78D5D332  # verified shipped legacy trapezoid/S/sine configuration


def frame(selected=1,active=1,tag=NEW_TAG,**updates):
    values=dict(has_runtime=True,selected_dip_mode=selected,active_trajectory_profile=active,
        trajectory_config_tag=tag,trajectory_step_degrees=10,selected_trajectory_edit_deci=900,
        trapezoid_edit_deci=900,scurve_edit_deci=900,sine_edit_deci=900,
        accepted_trajectory_deci=-900,trajectory_run_id=7,trajectory_time_stretch=1,
        trajectory_cycle_ms=10000,trajectory_state=2)
    values.update(updates)
    return SimpleNamespace(**values)


class CenteredProfileSemanticsTests(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory()
        self.path=Path(self.directory.name)/'trajectory_semantics.json'
        self.write_tags([f'{NEW_TAG:08X}'])
        self.registration=patch.object(monitor,'TRAJECTORY_SEMANTICS_PATH',self.path)
        self.registration.start()

    def tearDown(self):
        self.registration.stop()
        self.directory.cleanup()

    def write_tags(self,tags):
        self.path.write_text(json.dumps({'centered_half_amplitude_tags':tags}),encoding='utf-8')

    def test_registered_current_tag_uses_half_amplitude_for_all_profiles(self):
        for profile in (1,2,3):
            with self.subTest(profile=profile):
                edit,active=monitor.trajectory_semantics(frame(profile,profile))
                self.assertIn('有符号半幅',edit)
                self.assertIn('有符号半幅',active)
                summary=monitor.trajectory_summary(frame(profile,profile))
                self.assertEqual(summary.count('有符号半幅'),2)
                self.assertNotIn('有符号单程',summary)

    def test_old_tag_retains_single_stroke_for_a_b_and_half_amplitude_for_c(self):
        for profile in (1,2):
            with self.subTest(profile=profile):
                edit,active=monitor.trajectory_semantics(frame(profile,profile,OLD_TAG))
                self.assertIn('有符号单程',edit)
                self.assertIn('有符号单程',active)
        edit,active=monitor.trajectory_semantics(frame(3,3,OLD_TAG))
        self.assertIn('有符号半幅',edit)
        self.assertIn('有符号半幅',active)

    def test_switch_to_sine_does_not_relabel_running_old_a_as_half_amplitude(self):
        summary=monitor.trajectory_summary(frame(3,1,OLD_TAG))
        te,ta=summary.split('已接受TA=',1)
        self.assertIn('有符号半幅',te)
        self.assertIn('有符号单程',ta)
        self.assertIn('实际梯形速度往返',ta)

    def test_switch_from_sine_to_b_does_not_relabel_running_sine_as_single_stroke(self):
        summary=monitor.trajectory_summary(frame(2,3,OLD_TAG))
        te,ta=summary.split('已接受TA=',1)
        self.assertIn('有符号单程',te)
        self.assertIn('有符号半幅',ta)
        self.assertIn('实际正弦位置扫描',ta)

    def test_new_switch_to_position_keeps_running_b_half_amplitude_label(self):
        edit,active=monitor.trajectory_semantics(frame(0,2))
        self.assertEqual(edit,'无轨迹')
        self.assertIn('有符号半幅',active)

    def test_registration_is_reloaded_after_build_appends_a_new_tag(self):
        newer=0x11223344
        self.assertIn('有符号单程',monitor.trajectory_semantics(frame(tag=newer))[0])
        self.write_tags([f'{NEW_TAG:08X}',f'{newer:08x}'])
        self.assertIn('有符号半幅',monitor.trajectory_semantics(frame(tag=newer))[0])

    def test_missing_or_invalid_registration_does_not_guess_a_b_semantics(self):
        for payload in (None,'not json',json.dumps({}),json.dumps({'centered_half_amplitude_tags':'bad'}),
                        json.dumps({'centered_half_amplitude_tags':['not-hex!']})):
            with self.subTest(payload=payload):
                if payload is None:self.path.unlink(missing_ok=True)
                else:self.path.write_text(payload,encoding='utf-8')
                edit,active=monitor.trajectory_semantics(frame())
                self.assertIn('未确认',edit)
                self.assertIn('未确认',active)
                self.assertNotIn('有符号半幅',edit)
                self.assertNotIn('有符号单程',edit)
                self.assertIn('有符号半幅',monitor.trajectory_semantics(frame(3,3))[0])

    def test_full_stroke_start_tag_describes_endpoint_geometry(self):
        self.path.write_text(json.dumps({'centered_half_amplitude_tags':[f'{NEW_TAG:08X}'],
            'full_stroke_start_tags':[f'{NEW_TAG:08X}']}),encoding='utf-8')
        for profile in (1,2):
            summary=monitor.trajectory_summary(frame(profile,profile,trajectory_cycle_ms=7000))
            self.assertIn('单程=2×TA，从当前端点起步',summary)
            self.assertIn('CL=7.000s',summary)
        self.assertNotIn('从当前端点起步',monitor.trajectory_summary(frame(3,3)))

    def test_old_packet_without_runtime_fields_keeps_missing_fields_notice(self):
        self.assertIn('X8001兼容：未上报',monitor.trajectory_summary(frame(has_runtime=False)))


if __name__=='__main__':unittest.main()

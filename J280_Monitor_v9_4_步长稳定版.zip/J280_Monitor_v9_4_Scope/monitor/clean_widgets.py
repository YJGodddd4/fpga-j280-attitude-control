"""Reusable Canvas plots with cached sample values and pixel-aware decimation."""
import math,time
from collections import OrderedDict
import tkinter as tk
from tkinter import ttk, font as tkfont
try:
    from PIL import Image,ImageDraw,ImageTk
except ImportError:
    Image=ImageDraw=ImageTk=None
class CleanPlot(ttk.Frame):
    def __init__(self,parent,title,unit,series,fixed_range=None,include_zero=True):
        super().__init__(parent)
        self.title,self.unit,self.series=title,unit,list(series)
        self.fixed_range,self.include_zero=fixed_range,include_zero
        self.y_per_div=None;self.y_center=0.
        self.hidden=set();self.last_draw=None;self.legend_regions=[]
        self.canvas=tk.Canvas(self,bg='white',highlightthickness=1,highlightbackground='#dde5ee',height=160)
        self.canvas.pack(fill='both',expand=True)
        self.canvas.bind('<Button-1>',self._click);self.canvas.bind('<Motion>',self._motion)
        self.on_change=lambda:None;self._values=OrderedDict();self._signature=None
        self._curves={};self.last_draw_ms=0.;self.draw_count=0;self.cache_misses=0
        self._data_signature=None;self._cached_range=(-1.,1.);self._world_groups=[]
        self._label_text={};self._item_states={};self._photo=None;self._image_id=None
        self._layer_signature=None;self._curve_layer=None
        self._present_signature=None;self._background_signature=None;self._background=None
        self._series_revision=0;self.raster_builds=0;self.raster_uploads=0
    def _click(self,e):
        for x0,y0,x1,y1,name in self.legend_regions:
            if x0<=e.x<=x1 and y0<=e.y<=y1:self.toggle_series(name);return
    def _motion(self,e):
        self.canvas.configure(cursor='hand2' if any(a<=e.x<=c and b<=e.y<=d for a,b,c,d,n in self.legend_regions) else '')
    def toggle_series(self,name):
        if name not in {s[0] for s in self.series}:return
        if name in self.hidden:self.hidden.remove(name)
        else:self.hidden.add(name)
        self._signature=None;self.on_change()
        if self.last_draw:self.draw(*self.last_draw)
    def set_y_scale(self,per_div=None,center=None):
        """Set display units per vertical grid division; None restores auto.

        This changes only the view. Samples, getters, metrics and CSV values
        remain in their original engineering units.
        """
        if per_div is not None:
            per_div=float(per_div)
            if not math.isfinite(per_div) or per_div<=0:
                raise ValueError('Units per division must be finite and positive')
            per_div=min(1e9,max(1e-6,per_div))
        if center is None:
            center=(sum(self._cached_range)/2 if self.y_per_div is None and per_div is not None else self.y_center)
        center=float(center)
        if not math.isfinite(center):raise ValueError('Vertical center must be finite')
        if per_div is not None:
            low,high=center-2*per_div,center+2*per_div
            if not (math.isfinite(low) and math.isfinite(high) and high>low):
                raise ValueError('Vertical range cannot be represented at this center')
        if (per_div,center)==(self.y_per_div,self.y_center):return False
        self.y_per_div,self.y_center=per_div,center
        self._signature=None;self._data_signature=None;self._layer_signature=None;self._present_signature=None
        self.on_change()
        if self.last_draw:self.draw(*self.last_draw)
        return True
    def step_y_scale(self,direction):
        if not direction:return False
        current=self.y_per_div
        if current is None:current=(self._cached_range[1]-self._cached_range[0])/4
        stops=[n*10.**power for power in range(-6,10) for n in (1,2,5) if 1e-6<=n*10.**power<=1e9]
        if direction>0:
            options=[n for n in stops if n<current*(1-1e-10)]
            value=options[-1] if options else stops[0]
        else:
            options=[n for n in stops if n>current*(1+1e-10)]
            value=options[0] if options else stops[-1]
        return self.set_y_scale(value)
    def reset_y_scale(self):return self.set_y_scale(None)
    def scale_text(self):
        if self.y_per_div is None:return '自动'
        unit=self.unit.split('·',1)[0].strip()
        return f'{self.y_per_div:.6g} {unit}/格'
    def set_series(self,title,unit,series):
        if (title,unit)!=(self.title,self.unit):self.y_per_div=None;self.y_center=0.
        self.title,self.unit,self.series=title,unit,list(series)
        self._values.clear();self._signature=None;self._data_signature=None
        self._layer_signature=None;self._present_signature=None;self._series_revision+=1
        for group in self._curves.values():
            for line,dot in group:self.canvas.delete(line);self.canvas.delete(dot)
        self._curves={}
    @staticmethod
    def is_dashed(name):
        return name in ('参考','规划','直立','下垂','中心') or name.startswith('规划')
    @staticmethod
    def render_priority(item):
        name=item[0]
        if '包络' in name:return 0
        if name=='中心':return 1
        if CleanPlot.is_dashed(name):return 3
        return 2
    REFERENCE_WIDTH=2.5
    ACTUAL_WIDTH=2
    DASH_ON=8.
    DASH_OFF=5.
    @staticmethod
    def dashed_paths(points,on=8.,off=5.,phase=0.):
        """Split a displayed polyline by arc length, independent of its slope.

        Vertices inside a dash are retained. The extra endpoints interpolate
        only the displayed straight line between samples, never sensor data.
        A new discontinuous group starts its own dash; gaps are never bridged.
        """
        if on<=0 or off<=0:raise ValueError('Dash and gap lengths must be positive')
        if len(points)<2:return []
        phase=float(phase)%(on+off)
        drawing=phase<on
        remaining=on-phase if drawing else on+off-phase
        current=[points[0]] if drawing else []
        paths=[]
        for start,end in zip(points,points[1:]):
            dx,dy=end[0]-start[0],end[1]-start[1]
            length=math.hypot(dx,dy)
            if length<=1e-10:continue
            at=0.
            while at<length-1e-10:
                step=min(remaining,length-at);at+=step
                point=(start[0]+dx*at/length,start[1]+dy*at/length)
                if drawing:current.append(point)
                remaining-=step
                if remaining<=1e-10:
                    if drawing and len(current)>=2:paths.append(current)
                    drawing=not drawing
                    remaining=on if drawing else off
                    current=[point] if drawing else []
        if drawing and len(current)>=2:paths.append(current)
        return paths
    @staticmethod
    def clip_paths(points,left,top,right,bottom):
        """Clip a polyline without connecting separate exits and re-entries.

        The returned edge intersections are display geometry only. Original
        sample values and the cached world geometry are never modified.
        """
        if not points:return []
        def inside(p):return left<=p[0]<=right and top<=p[1]<=bottom
        if all(inside(p) for p in points):return [points]
        if len(points)==1:return []
        def code(x,y):
            return (1 if x<left else 2 if x>right else 0)|(4 if y<top else 8 if y>bottom else 0)
        def segment(start,end):
            ax,ay=start;bx,by=end
            # Cohen-Sutherland sets the intersected coordinate exactly to its
            # edge, avoiding catastrophic cancellation at huge offscreen Y.
            for _ in range(8):
                ca,cb=code(ax,ay),code(bx,by)
                if not (ca|cb):return (ax,ay),(bx,by)
                if ca&cb:return None
                out=ca or cb
                if out&12:
                    y=top if out&4 else bottom
                    d=by-ay
                    if d==0:return None
                    ratio=(y-ay)/d
                    x=ax+(bx-ax)*ratio
                else:
                    x=left if out&1 else right
                    d=bx-ax
                    if d==0:return None
                    ratio=(x-ax)/d
                    y=ay+(by-ay)*ratio
                if not (math.isfinite(x) and math.isfinite(y)):return None
                if out==ca:ax,ay=x,y
                else:bx,by=x,y
            return None
        result=[];path=[]
        for a,b in zip(points,points[1:]):
            pair=segment(a,b)
            if pair is None:
                if path:result.append(path);path=[]
                continue
            a,b=pair
            if path and abs(path[-1][0]-a[0])<1e-7 and abs(path[-1][1]-a[1])<1e-7:
                if b!=path[-1]:path.append(b)
            else:
                if path:result.append(path)
                path=[a,b]
        if path:result.append(path)
        return result
    @staticmethod
    def paint_reference(layer,coords,color):
        """Compatibility helper; grouped drawing avoids one full image per gap."""
        CleanPlot.paint_reference_groups(layer,[coords],color)
    @staticmethod
    def paint_reference_groups(layer,groups,color):
        """Paint all disjoint paths of one series with a single small AA image.

        Gaps retain their own dash phase. The supersampled image is cropped to
        the visible stroke bounds, including cap/filter support, rather than
        allocated and downsampled over the whole plot for every continuity gap.
        """
        paths=[]
        for coords in groups:
            for visible in CleanPlot.clip_paths(coords,0,0,layer.width-1,layer.height-1):
                paths.extend(CleanPlot.dashed_paths(visible,CleanPlot.DASH_ON,CleanPlot.DASH_OFF))
        if not paths:return
        margin=4
        xx=[p[0] for path in paths for p in path]
        yy=[p[1] for path in paths for p in path]
        x0=max(0,math.floor(min(xx))-margin);x1=min(layer.width,math.ceil(max(xx))+margin+1)
        y0=max(0,math.floor(min(yy))-margin);y1=min(layer.height,math.ceil(max(yy))+margin+1)
        if x1<=x0 or y1<=y0:return
        scale=2
        size=(x1-x0,y1-y0)
        # Supersample coverage only, not four identical color channels.
        mask=Image.new('L',(size[0]*scale,size[1]*scale),0)
        pen=ImageDraw.Draw(mask)
        width=round(CleanPlot.REFERENCE_WIDTH*scale);radius=(width-1)/2
        for path in paths:
            xy=[((x-x0)*scale,(y-y0)*scale) for x,y in path]
            pen.line(xy,fill=255,width=width,joint='curve')
            for x,y in (xy[0],xy[-1]):
                pen.ellipse((x-radius,y-radius,x+radius,y+radius),fill=255)
        mask=mask.resize(size,Image.Resampling.LANCZOS)
        ink=Image.new('RGBA',size,color);ink.putalpha(mask)
        layer.alpha_composite(ink,(x0,y0))
    @staticmethod
    def label(v):
        if abs(v)>=10000:return f'{v/1000:.1f}k'
        return f'{v:.1f}' if abs(v)<10 and v else f'{v:.0f}'
    def _row(self,f):
        key=id(f);entry=self._values.get(key)
        if entry is not None and entry[0] is f:return entry[1]
        values=[]
        for name,col,getter in self.series:
            v=getter(f)
            if v is not None and not math.isfinite(float(v)):v=None
            values.append(v)
        self._values[key]=(f,tuple(values));self.cache_misses+=1
        if len(self._values)>20000:
            for _ in range(1000):self._values.popitem(last=False)
        return values
    def _chrome(self,w,h,paused):
        sig=(w,h,self.title,self.unit,tuple((n,c) for n,c,g in self.series),tuple(sorted(self.hidden)),paused,self.y_per_div,self.y_center)
        if sig==self._signature:return
        self._signature=sig;c=self.canvas;c.delete('chrome');self._label_text.clear();self._item_states.clear()
        self._x0,self._x1,self._y0,self._y1=57,w-17,49,h-28
        x0,x1,y0,y1=self._x0,self._x1,self._y0,self._y1
        c.create_text(12,15,text=self.title+(' · 暂停显示' if paused else ''),anchor='w',fill='#1c3045',font=('Microsoft YaHei UI',10,'bold'),tags='chrome')
        detail=('自动纵轴' if self.y_per_div is None else self.scale_text()+f' · 中心 {self.y_center:.6g}')
        face=tkfont.Font(root=c,family='Microsoft YaHei UI',size=8)
        # Fit the explanation into its own left column on narrow panels.
        available=max(0,x1-face.measure(detail)-28)
        unit=self.unit
        while unit and face.measure(unit)>available:unit=unit[:-1]
        if unit!=self.unit and unit:unit=unit[:-1]+'…'
        c.create_text(12,33,text=unit,anchor='w',fill='#718196',font=face,tags='chrome')
        c.create_text(x1,33,text=detail,anchor='e',fill='#57758c',font=face,tags='chrome')
        self._yl=[];self._xl=[]
        for k in range(5):
            yy=y0+(y1-y0)*k/4;xx=x0+(x1-x0)*k/4
            c.create_line(x0,yy,x1,yy,fill='#edf1f6',tags='chrome')
            c.create_line(xx,y0,xx,y1,fill='#edf1f6',tags='chrome')
            self._yl.append(c.create_text(x0-7,yy,anchor='e',fill='#78879a',font=('Consolas',8),tags='chrome'))
            self._xl.append(c.create_text(xx,y1+14,fill='#78879a',font=('Consolas',8),tags='chrome'))
        self._zero=c.create_line(x0,y0,x1,y0,fill='#b2bfcd',dash=(3,3),tags='chrome')
        self._empty=c.create_text((x0+x1)/2,(y0+y1)/2,text='连接板卡后显示波形',fill='#94a1b1',font=('Microsoft YaHei UI',11),tags='chrome')
        self.legend_regions=[];lx=x1
        for name,col,getter in reversed(self.series):
            item=c.create_text(lx,15,text=name,anchor='e',fill=col if name not in self.hidden else '#adb7c4',font=('Microsoft YaHei UI',8,'bold'),tags=('legend','chrome'))
            box=c.bbox(item);self.legend_regions.append((*box,name));lx=box[0]-16
        c.tag_lower('chrome')
    @staticmethod
    def _decimate(group):
        # Retain the first, last, minimum and maximum per horizontal pixel.
        if len(group)<2:return group
        out=[];bucket=[];previous=None
        def flush():
            if not bucket:return
            picks={0,len(bucket)-1,min(range(len(bucket)),key=lambda i:bucket[i][1]),max(range(len(bucket)),key=lambda i:bucket[i][1])}
            out.extend(bucket[i] for i in sorted(picks))
        for xy in group:
            column=int(xy[0])
            if previous is not None and column!=previous:flush();bucket=[]
            bucket.append(xy);previous=column
        flush();return out
    def _text(self,item,value):
        if self._label_text.get(item)!=value:
            self._label_text[item]=value;self.canvas.itemconfigure(item,text=value)
    def _state(self,item,value):
        if self._item_states.get(item)!=value:
            self._item_states[item]=value;self.canvas.itemconfigure(item,state=value)
    def draw(self,points,right,span,paused=False):
        started=time.perf_counter();self.last_draw=(points,right,span,paused)
        c=self.canvas;w=max(c.winfo_width(),240);h=max(c.winfo_height(),112)
        self._chrome(w,h,paused)
        x0,x1,y0,y1=self._x0,self._x1,self._y0,self._y1
        left=max(0.,max(span,right)-span);end=max(span,right)
        signature=(w,h,span,len(points),id(points[0].frame) if points else None,
                   id(points[-1].frame) if points else None,tuple(sorted(self.hidden)),self.title,self.unit,
                   getattr(self,'_series_revision',0),tuple((n,col) for n,col,g in self.series),self.y_per_div,self.y_center)
        if signature!=self._data_signature:
            self._data_signature=signature
            rows=[self._row(p.frame) for p in points]
            vals=[float(row[i]) for row in rows for i,(n,col,g) in enumerate(self.series) if n not in self.hidden and row[i] is not None]
            if self.y_per_div is not None:low,high=self.y_center-2*self.y_per_div,self.y_center+2*self.y_per_div
            elif self.fixed_range:low,high=self.fixed_range
            else:
                bounds=vals+([0.] if self.include_zero else []) or [0.]
                mid=(min(bounds)+max(bounds))/2;delta=max(max(bounds)-min(bounds),2.)
                low,high=mid-.6*delta,mid+.6*delta
            if high<=low:high=low+1
            self._cached_range=(low,high);self._world_groups=[]
            sx=(x1-x0)/span
            for i,(name,col,getter) in enumerate(self.series):
                groups=[];group=[];prev=None
                if name not in self.hidden:
                    for p,row in zip(points,rows):
                        v=row[i]
                        continuous=prev is not None and prev.segment==p.segment and prev.epoch==p.epoch and 0<=p.t-prev.t<=.65
                        if v is None or not continuous:
                            if group:groups.append(group);group=[]
                        if v is not None:
                            py=(v-low)/(high-low)*(y1-y0)
                            if not math.isfinite(py):py=math.copysign(1e300,v-low)
                            group.append((p.t*sx,py))
                        prev=p if v is not None else None
                    if group:groups.append(group)
                groups=[self._decimate(g) if len(g)>max(10,int(x1-x0)*2) else g for g in groups]
                self._world_groups.append((name,col,groups))
        low,high=self._cached_range;sx=(x1-x0)/span
        for k in range(5):
            value=high-(high-low)*k/4
            if self.y_per_div is not None:
                magnitude=max(abs(low),abs(high),1e-300)
                digits=min(15,max(6,math.floor(math.log10(magnitude))-math.floor(math.log10(self.y_per_div))+2))
                ytext=f'{value:.{digits}g}'
            else:ytext=(f'{value:.6g}' if (high-low)/4<1 else self.label(value))
            self._text(self._yl[k],ytext)
            # Preserve .125 s/div and other fractional grid steps exactly.
            decimals=0
            while decimals<6 and abs(span/4*10**decimals-round(span/4*10**decimals))>1e-7:
                decimals+=1
            self._text(self._xl[k],f'{left+span*k/4:.{decimals}f}s')
        self._state(self._empty,'hidden' if points else 'normal')
        if Image is not None:
            self._state(self._zero,'hidden')
            iw,ih=max(1,round(x1-x0)+1),max(1,round(y1-y0)+1)
            # A timer tick without new data/scrolling is not a new image.
            shift=(left-self._layer_left)*sx if self._layer_signature==signature else 0.
            present=(signature,shift)
            if self._present_signature==present:
                c.tag_raise(self._empty);c.tag_raise('legend')
                self.last_draw_ms=(time.perf_counter()-started)*1000;self.draw_count+=1
                return
            background_signature=(iw,ih,low,high)
            if self._background_signature!=background_signature:
                self._background_signature=background_signature
                self._background=Image.new('RGB',(iw,ih),'white');pen=ImageDraw.Draw(self._background)
                for k in range(5):
                    yy=round((ih-1)*k/4);xx=round((iw-1)*k/4)
                    pen.line((0,yy,iw-1,yy),fill='#edf1f6')
                    pen.line((xx,0,xx,ih-1),fill='#edf1f6')
                if low<=0<=high:
                    yy=round((high/(high-low))*(ih-1))
                    for xx in range(0,iw,7):pen.line((xx,yy,min(iw-1,xx+3),yy),fill='#b2bfcd')
            image=self._background.copy()
            if self._layer_signature!=signature:
                self._layer_signature=signature;self._layer_left=left
                layer=Image.new('RGBA',(iw,ih),(0,0,0,0));curves=ImageDraw.Draw(layer)
                offset=left*sx
                for name,col,groups in sorted(self._world_groups,key=self.render_priority):
                    displayed=[path for group in groups for path in self.clip_paths(
                        [(x-offset,(ih-1)-y) for x,y in group],0,0,iw-1,ih-1)]
                    if self.is_dashed(name):
                        self.paint_reference_groups(layer,(g for g in displayed if len(g)>=2),col)
                    for coords in displayed:
                        if len(coords)>=2:
                            if not self.is_dashed(name):curves.line(coords,fill=col,width=self.ACTUAL_WIDTH)
                        elif coords:
                            x,y=coords[0];curves.ellipse((x-1,y-1,x+1,y+1),fill=col)
                self._curve_layer=layer;self.raster_builds+=1
            shift=(left-self._layer_left)*sx
            # Pixel translation/antialiasing only: no interpolated measurement is
            # inserted into the history, metrics, recorded samples or CSV.
            layer=(self._curve_layer if abs(shift)<1e-9 else
                   self._curve_layer.transform((iw,ih),Image.Transform.AFFINE,
                     (1,0,shift,0,1,0),resample=Image.Resampling.BILINEAR))
            image.paste(layer,(0,0),layer)
            self.last_raster=image
            if self._photo is None or self._photo.width()!=iw or self._photo.height()!=ih:
                self._photo=ImageTk.PhotoImage(image,master=c)
                if self._image_id is None:self._image_id=c.create_image(x0,y0,image=self._photo,anchor='nw')
                else:c.itemconfigure(self._image_id,image=self._photo);c.coords(self._image_id,x0,y0)
            else:self._photo.paste(image)
            self._present_signature=present;self.raster_uploads+=1
            c.tag_raise(self._empty);c.tag_raise('legend')
        else:
            # Functional fallback if Pillow is unavailable.
            if low<=0<=high:
                yy=y1-(0-low)/(high-low)*(y1-y0);c.coords(self._zero,x0,yy,x1,yy);self._state(self._zero,'normal')
            else:self._state(self._zero,'hidden')
            for name,col,groups in sorted(self._world_groups,key=self.render_priority):
                pool=self._curves.setdefault(name,[])
                paths=[]
                for group in groups:
                    coords=[(x0+x-left*sx,y1-y) for x,y in group]
                    # Clip against the actual frame first: a legal vertical
                    # line on the newest-time edge must remain visible. Then
                    # constrain only the clipped display points by half a pen
                    # width, keeping round caps inside the frame. Offscreen
                    # paths are already rejected, never flattened onto an edge.
                    inset=(self.REFERENCE_WIDTH if self.is_dashed(name) else self.ACTUAL_WIDTH)/2
                    for visible in self.clip_paths(coords,x0,y0,x1,y1):
                        visible=[(min(x1-inset,max(x0+inset,x)),min(y1-inset,max(y0+inset,y))) for x,y in visible]
                        paths.extend(self.dashed_paths(visible,self.DASH_ON,self.DASH_OFF)
                                     if len(visible)>=2 and self.is_dashed(name) else [visible])
                for k,coords in enumerate(paths):
                    if k>=len(pool):
                        width=self.REFERENCE_WIDTH if self.is_dashed(name) else self.ACTUAL_WIDTH
                        pool.append((c.create_line(0,0,0,0,fill=col,width=width,capstyle='round',joinstyle='round'),c.create_oval(0,0,0,0,fill=col,outline=col)))
                    line,dot=pool[k]
                    if len(coords)>=2:
                        c.coords(line,*[v for xy in coords for v in xy]);self._state(line,'normal');self._state(dot,'hidden');c.tag_raise(line)
                    else:
                        x,y=coords[0];c.coords(dot,x-1,y-1,x+1,y+1);self._state(dot,'normal');self._state(line,'hidden')
                for line,dot in pool[len(paths):]:self._state(line,'hidden');self._state(dot,'hidden')
            c.tag_raise(self._empty);c.tag_raise('legend')
        self.last_draw_ms=(time.perf_counter()-started)*1000;self.draw_count+=1

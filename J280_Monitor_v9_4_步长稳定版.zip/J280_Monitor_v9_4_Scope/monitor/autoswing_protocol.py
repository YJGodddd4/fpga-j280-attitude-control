"""Additional receive-only diagnostic protocol; never accesses a serial port."""
from __future__ import annotations

import csv
from dataclasses import dataclass
import re

from j280_protocol import FRAME_LENGTH, Frame, Recorder, _host_time, _signed, decode_frame

DIAGNOSTIC_LENGTH = 27
_DIAGNOSTIC = re.compile(r'M=([0-9A-Fa-f]) W=([0-9A-Fa-f]{8}) N=([0-9A-Fa-f]{2}) Q=([01]) Z=([01])')
MODE_LABELS = {0:'待机', 1:'就绪（自动或手动）', 2:'有限初始激励／尚未锁位',
               3:'自动起摆／等待直立锁位', 4:'平衡接管／本次捕获锁位',
               5:'平衡／保持本次锁位', 6:'失衡恢复／切入续摆'}

@dataclass(frozen=True)
class Diagnostic:
    mode: int
    velocity_q8: int
    pulse_count: int
    reference_ready: bool
    motion_valid: bool
    raw: str

    @property
    def velocity_adc_per_ms(self):
        return self.velocity_q8 / 256.0


def decode_diagnostic(data: bytes | str) -> Diagnostic:
    try:
        text = data.decode('ascii') if isinstance(data, bytes) else data
    except UnicodeDecodeError as exc:
        raise ValueError('Diagnostic is not ASCII') from exc
    if not isinstance(text, str):
        raise ValueError('Diagnostic must be bytes or str')
    text = text.strip('\r\n \t')
    match = _DIAGNOSTIC.fullmatch(text)
    if match is None:
        raise ValueError('Diagnostic does not match M/W/N/Q/Z')
    mode, speed, pulses, ready, valid = (int(part,16) for part in match.groups())
    return Diagnostic(mode,_signed(speed,32),pulses,bool(ready),bool(valid),text)


class ExtendedStreamDecoder:
    """Decode A frames plus independent M diagnostics from arbitrary chunks.

    feed() remains backwards compatible: it returns only regular Frame values.
    pop_diagnostics() returns diagnostics separately. No frame association is
    inferred, because the wire protocol has no sequence number or FPGA clock.
    """
    MAX_BUFFER = 4096

    def __init__(self):
        self.buffer = bytearray()
        self.invalid_frames = self.invalid_diagnostics = 0
        self.discarded_bytes = self.received_bytes = 0
        self._diagnostics = []

    def pop_diagnostics(self):
        result,self._diagnostics = self._diagnostics,[]
        return result

    def feed(self,data: bytes) -> list[Frame]:
        if not isinstance(data,(bytes,bytearray,memoryview)):
            raise TypeError('feed() requires bytes-like input')
        self.received_bytes += len(data)
        self.buffer.extend(data)
        frames=[]
        while self.buffer:
            trim=0
            while trim<len(self.buffer) and self.buffer[trim] in b'\r\n \t':
                trim+=1
            if trim: del self.buffer[:trim]
            if not self.buffer: break
            anchors=[x for token in (b'A=',b'M=') if (x:=self.buffer.find(token))>=0]
            if not anchors:
                keep=1 if self.buffer[-1:] in (b'A',b'M') else 0
                self.discarded_bytes += len(self.buffer)-keep
                self.buffer=self.buffer[-keep:] if keep else bytearray()
                break
            anchor=min(anchors)
            if anchor:
                self.discarded_bytes += anchor
                del self.buffer[:anchor]
            is_diag=self.buffer.startswith(b'M=')
            length=DIAGNOSTIC_LENGTH if is_diag else FRAME_LENGTH
            if len(self.buffer)<length: break
            candidate=bytes(self.buffer[:length])
            try:
                decoded=decode_diagnostic(candidate) if is_diag else decode_frame(candidate)
            except ValueError:
                if is_diag: self.invalid_diagnostics+=1
                else: self.invalid_frames+=1
                self.discarded_bytes+=2
                del self.buffer[:2]
                continue
            if is_diag: self._diagnostics.append(decoded)
            else: frames.append(decoded)
            del self.buffer[:length]
        if len(self.buffer)>self.MAX_BUFFER:
            dropped=len(self.buffer)-self.MAX_BUFFER
            self.discarded_bytes+=dropped
            del self.buffer[:dropped]
        return frames


def diagnostic_status(diagnostic,age,connected,mode='live'):
    if mode!='live':
        return '离线／演示：自动起摆模式诊断不代表板卡当前状态。',False
    if diagnostic is None:
        return '尚未收到M/W/N/Q/Z模式诊断；旧固件的A/C/P/T/U波形仍可正常显示。',False
    label=MODE_LABELS.get(diagnostic.mode,f'未知模式{diagnostic.mode:X}')
    if not connected or age is None or age>=1.2:
        return (f'历史诊断：{label}（M={diagnostic.mode:X}，N={diagnostic.pulse_count:02X}）；'
                f'通信已断开或诊断过期，板卡当前模式不可判断。'),False
    return (f'模式：{label}（M={diagnostic.mode:X}）　'
            f'脉冲次数：{diagnostic.pulse_count}（N={diagnostic.pulse_count:02X}，十六进制）　'
            f'自动参考：{"就绪" if diagnostic.reference_ready else "未就绪"}　'
            f'角度运动数据：{"可信" if diagnostic.motion_valid else "不可信"}\n'
            f'角速度：{diagnostic.velocity_adc_per_ms:+.3f} ADC计数/ms（Q8÷256，不是度/秒）；'
            f'最近诊断距今{max(0,age):.1f}秒。'),True


class AutoRecorder(Recorder):
    """Keep legacy frame CSV intact; log M diagnostics in an independent file."""
    MODE_COLUMNS=('host_time','elapsed_s','segment','mode','velocity_q8',
                  'velocity_adc_per_ms','pulse_count','auto_reference_ready',
                  'motion_valid','note','raw_line')

    def __init__(self,folder,port,note=''):
        super().__init__(folder,port,note)
        self.mode_path=self.csv_path.with_name(self.csv_path.stem+'_modes.csv')
        self.mode_rows=0
        self._mode_file=None
        try:
            self._mode_file=self.mode_path.open('x',encoding='utf-8-sig',newline='')
            self._modes=csv.writer(self._mode_file)
            self._modes.writerow(self.MODE_COLUMNS)
            self._mode_file.flush()
        except OSError:
            if self._mode_file is not None: self._mode_file.close()
            super().close()
            raise

    def append_diagnostic(self,diagnostic,elapsed,segment):
        self._check_open()
        self._modes.writerow((_host_time(),f'{float(elapsed):.6f}',segment,
                             diagnostic.mode,diagnostic.velocity_q8,
                             f'{diagnostic.velocity_adc_per_ms:.6f}',
                             diagnostic.pulse_count,int(diagnostic.reference_ready),
                             int(diagnostic.motion_valid),self.note,diagnostic.raw))
        self._mode_file.flush()
        self.mode_rows+=1

    def close(self):
        if self._closed: return
        first_error=None
        if self._mode_file is not None:
            try:
                try: self._mode_file.flush()
                finally: self._mode_file.close()
            except OSError as exc:
                first_error=exc
        try: super().close()
        except OSError as exc:
            if first_error is None:first_error=exc
        if first_error is not None:raise first_error

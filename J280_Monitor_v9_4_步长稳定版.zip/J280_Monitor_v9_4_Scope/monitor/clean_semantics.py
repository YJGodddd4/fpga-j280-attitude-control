"""Presentation-only semantics for the compact monitor; no commands or I/O."""
from __future__ import annotations
from unified_protocol import BALANCE_LABELS,FAULT_LABELS,PROFILE_LABELS,label
from amfm_semantics import profile_label

def tracking_available(frame):
    """Control comparison applies while the current reference is held by balance.

    FL5 means trajectory-running, not global running; requiring it would hide
    legitimate00 positioning and balanced holding comparisons.
    Freshness is deliberately managed by the view, never inferred from values.
    """
    return bool(frame is not None and frame.system_active and frame.balance_mode==5
                and frame.base_valid and frame.fault==0)

def tracking_error(frame):
    return frame.tracking_error_degrees if tracking_available(frame) else None

def pwm_given_percent(frame):
    """Magnitude of internal signed U, not a physical PWM measurement."""
    return abs(frame.command_pct) if frame is not None else None

def drive_direction(frame):
    """Direction of signed command U; mechanical direction is not measured here."""
    if frame is None:return '—'
    if not frame.flag(4):return '未使能'
    if frame.command_pct>0:return '正向命令'
    if frame.command_pct<0:return '反向命令'
    return '停止命令'

def _profile(frame,profile):
    return profile_label(profile,frame.trajectory_config_tag,label(PROFILE_LABELS,profile))

def mode_status(frame):
    """D is selection, J+owner+run state is actual execution; never conflate."""
    if frame is None:
        return {'actual':'等待数据','selected':'—','pending':False,'status':'未连接板卡状态',
                'dip_bits':'—','selected_short':'—','actual_short':'等待数据'}
    dip=frame.selected_dip_mode
    dip_bits=f'{dip:02b}'
    selected_short='定位' if dip==0 else _profile(frame,dip)
    selected=dip_bits+' '+selected_short
    trajectory_active=bool(frame.system_active and frame.balance_mode==5
                           and frame.reference_owner==1 and frame.flag(5)
                           and frame.active_trajectory_profile in (1,2,3))
    if not frame.system_active:
        actual='未运行'
    elif frame.balance_mode in (2,3,4,6):
        actual=label(BALANCE_LABELS,frame.balance_mode)
    elif frame.balance_mode!=5:
        actual=label(BALANCE_LABELS,frame.balance_mode)
    elif trajectory_active:
        actual=_profile(frame,frame.active_trajectory_profile)
    else:actual='定位 / 保持'
    pending=bool(frame.system_active and frame.balance_mode==5 and not frame.fault and
                 ((trajectory_active and dip!=frame.active_trajectory_profile)
                  or (not trajectory_active and dip!=0)))
    status=label(BALANCE_LABELS,frame.balance_mode)
    if not frame.system_active:status='已停止'
    if frame.fault:status='故障：'+label(FAULT_LABELS,frame.fault)
    return {'actual':actual,'selected':selected,'pending':pending,'status':status,
            'dip_bits':dip_bits,'selected_short':selected_short,'actual_short':actual}

def _degrees(x):
    return '—' if x is None else f'{x:+.2f}°'

def _not_applicable(frame):
    if frame is None:return '等待有效数据'
    if not frame.base_valid:return '本段基准无效'
    if frame.fault:return '故障期间不适用'
    if not frame.system_active:return '已停止，误差不适用'
    if frame.balance_mode in (2,3,4,6):return '起摆 / 恢复中不适用'
    return '等待平衡接管'

def dashboard_values(frame):
    """Six cards; returned numerical values are one atomic X snapshot.

    The UI must gray these when stale, explicitly mark replay, and never use
    this function as evidence of a current live connection.
    """
    if frame is None:
        return {k:{'value':'—','detail':'等待有效数据'} for k in
                ('pole','pwm','direction','speed','position','reference')}
    enabled=frame.flag(4)
    u=frame.command_pct
    error=tracking_error(frame)
    return {
        'pole':{'value':f'{frame.angle_error_adc:+d}' if frame.calibrated else '—',
                'detail':'ADC计数 · 相对直立' if frame.calibrated else '尚未标定直立参考'},
        'pwm':{'value':f'{pwm_given_percent(frame):d}%',
               'detail':f'给定 · U={u:+d}% · '+('驱动使能' if enabled else '未使能')},
        'direction':{'value':drive_direction(frame),
                     'detail':'按命令正负，非实测转向'},
        'speed':{'value':f'{frame.actual_speed_degrees:+.2f}',
                 'detail':'°/s · 编码器估算'},
        'position':{'value':_degrees(frame.position_degrees),
                    'detail':'相对本段起点' if frame.base_valid else '本段基准无效'},
        'reference':{'value':_degrees(frame.reference_degrees),
                     'detail':f'误差 {error:+.2f}°（实际−参考）' if error is not None
                              else _not_applicable(frame)}}

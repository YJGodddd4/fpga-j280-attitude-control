"""Independent Z8601 diagnostics and tag-qualified fast-speed descriptions."""
from dataclasses import dataclass
import re
from amfm_semantics import config_for_tag,heart_config
FAST_SPEED_TAGS=frozenset((0xB5FBC6B6,))
DIAGNOSTIC_FIELDS=(
 ('T',8,'uptime_ms',False),('Q',8,'snapshot_sequence',False),
 ('CF',8,'trajectory_config_tag',False),('KA',8,'gain_q16',True),
 ('PD',8,'pd10',True),('FF',8,'feedforward10',True),('TT',9,'total10',True),
 ('LO',8,'location_out10',True),('AC',8,'acceleration_q8',True),
 ('EN',1,'active',False),('SV',1,'speed_valid',False),('LM',1,'limited',False))
DIAGNOSTIC_LENGTH=len('Z=8601')+sum(1+len(k)+1+w for k,w,_,_ in DIAGNOSTIC_FIELDS)
_PATTERN=re.compile('Z=8601'+''.join(' '+k+r'=([0-9A-Fa-f]{'+str(w)+'})' for k,w,_,_ in DIAGNOSTIC_FIELDS))
@dataclass(frozen=True)
class FeedforwardDiagnostic:
    uptime_ms:int
    snapshot_sequence:int
    trajectory_config_tag:int
    gain_q16:int
    pd10:int
    feedforward10:int
    total10:int
    location_out10:int
    acceleration_q8:int
    active:int
    speed_valid:int
    limited:int
    raw:str
    @property
    def gain(self):return self.gain_q16/65536
    def matches(self,f):
        return (self.uptime_ms,self.snapshot_sequence,self.trajectory_config_tag)==(f.uptime_ms,f.snapshot_sequence,f.trajectory_config_tag)
def decode_feedforward(data):
    try: text=data.decode('ascii') if isinstance(data,bytes) else data
    except UnicodeDecodeError as exc:raise ValueError('Z diagnostic is not ASCII') from exc
    if not isinstance(text,str):raise ValueError('Z diagnostic requires text or bytes')
    text=text.strip('\r\n \t');m=_PATTERN.fullmatch(text)
    if m is None:raise ValueError('Expected a complete Z=8601 diagnostic')
    vals={}
    for raw,(key,width,name,signed) in zip(m.groups(),DIAGNOSTIC_FIELDS):
        n=int(raw,16)
        if signed and n&(1<<(width*4-1)):n-=1<<(width*4)
        vals[name]=n
    if any(vals[x] not in (0,1) for x in ('active','speed_valid','limited')):
        raise ValueError('Diagnostic flag outside boolean range')
    if not -(1<<32)<=vals['total10']<(1<<32):raise ValueError('TT is outside signed33')
    if not -1000<=vals['location_out10']<=1000:raise ValueError('LO outside actual controller tilt-command scale')
    return FeedforwardDiagnostic(**vals,raw=text)
def _fast_speed(tag):
    cfg=config_for_tag(tag)
    return tag in FAST_SPEED_TAGS or bool(cfg and cfg.get('speed_estimator',{}).get('id')=='raw1040_window50_update10_alpha_half')

def speed_description(tag):
    if _fast_speed(tag):
        return '度/s；原始编码器50ms滑窗／10ms更新，1/2低通；估算W，不是独立测速传感器'
    return '度/s；旧版工程位置50ms差分；滤波权重未遥测，原版为1/4，可能由用户修改'
def speed_summary(tag):
    return ('W：原始编码器50ms滑动测速、10ms更新、1/2低通；旧速度仅用于00到位判定。'
            if _fast_speed(tag) else
            '旧版W：工程位置50ms差分；原版1/4低通，实际滤波权重未遥测。')
def diagnostic_summary(d):
    state='关闭（KA=0）' if d.gain_q16==0 else ('当前规划输入可用' if d.active else '系数已配置，当前规划输入未使能')
    integral=(f"积分I={(d.total10-d.pd10-d.feedforward10)/10:+.1f}（由TT−PD−FF），" if heart_config(d.trajectory_config_tag) else '')
    return (f'加速度前馈：{state}；KA={d.gain:+.6f}（Q16={d.gain_q16}）。'
            f'\n外环PD={d.pd10/10:+.1f}，前馈FF={d.feedforward10/10:+.1f}，合计={d.total10/10:+.1f}，'
            +integral+f'实际倾角修正LO={d.location_out10/10:+.1f} ADC；限幅={"是" if d.limited else "否"}。'
            +f'测速窗口有效={"是" if d.speed_valid else "否"}。'
            '\nPD/FF/LO来自最近一次50ms外环更新；AC是发送快照时的规划量，二者不保证同一采样时刻。非实测PWM或力矩。')

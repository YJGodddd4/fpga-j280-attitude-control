"""Offline protocol/recording tests; no serial ports are opened."""
import csv
from pathlib import Path
import unittest
from uuid import uuid4

from j280_protocol import Frame, Recorder, StreamDecoder, decode_frame


BASE = b"A=07D0 C=07D0 P=00000198 T=00000000 U=64 R=0 K=1 F=0"
NEGATIVE = b"A=07CF C=07D0 P=FFFFFE68 T=FFFFFFFF U=9C R=1 K=1 F=2"


class DecoderTests(unittest.TestCase):
    def test_positive_and_negative(self):
        frame = decode_frame(BASE + b"\r\n")
        self.assertEqual((frame.angle, frame.center, frame.position, frame.command), (2000, 2000, 408, 100))
        negative = decode_frame(NEGATIVE.decode("ascii"))
        self.assertEqual((negative.position, negative.target, negative.command), (-408, -1, -100))
        self.assertTrue(negative.running)
        self.assertEqual(negative.fault, 2)

    def test_every_split_position(self):
        for split in range(len(BASE) + 1):
            stream = StreamDecoder()
            frames = stream.feed(BASE[:split]) + stream.feed(BASE[split:])
            self.assertEqual(len(frames), 1, split)
            self.assertEqual(stream.received_bytes, len(BASE))
            self.assertEqual(stream.invalid_frames, 0)

    def test_single_bytes_and_standard_newlines(self):
        stream = StreamDecoder()
        frames = []
        payload = BASE + b"\r\n" + NEGATIVE + b"\r\n"
        for byte in payload:
            frames.extend(stream.feed(bytes([byte])))
        self.assertEqual(len(frames), 2)
        self.assertEqual(stream.received_bytes, len(payload))
        self.assertEqual(stream.discarded_bytes, 0)

    def test_multiple_frames_without_newlines(self):
        stream = StreamDecoder()
        frames = stream.feed(BASE + NEGATIVE + BASE)
        self.assertEqual([frame.command for frame in frames], [100, -100, 100])
        self.assertEqual(stream.discarded_bytes, 0)

    def test_noise_and_split_header_recovery(self):
        stream = StreamDecoder()
        self.assertEqual(stream.feed(b"\xaa\x55garbageA"), [])
        frames = stream.feed(BASE[1:] + b"\r\nother noise" + NEGATIVE)
        self.assertEqual([frame.position for frame in frames], [408, -408])
        self.assertGreater(stream.discarded_bytes, 0)

    def test_invalid_range_then_valid_recovery(self):
        invalid = [BASE.replace(b"A=07D0", b"A=FFFF"),
                   BASE.replace(b"C=07D0", b"C=FFFF"),
                   BASE.replace(b"U=64", b"U=7F"),
                   BASE.replace(b"U=64", b"U=80")]
        stream = StreamDecoder()
        frames = stream.feed(b"".join(invalid) + BASE)
        self.assertEqual(len(frames), 1)
        self.assertEqual(stream.invalid_frames, len(invalid))
        for value in invalid:
            with self.assertRaises(ValueError):
                decode_frame(value)

    def test_malformed_and_non_ascii(self):
        for value in (b"\xff" + BASE, BASE[:-2], BASE.replace(b"R=0", b"R=2")):
            with self.assertRaises(ValueError):
                decode_frame(value)
        stream = StreamDecoder()
        frames = stream.feed(BASE.replace(b"A=07D0", b"A=ZZZZ") + BASE)
        self.assertEqual(len(frames), 1)
        self.assertEqual(stream.invalid_frames, 1)

    def test_buffer_bounded_under_noise(self):
        stream = StreamDecoder()
        self.assertEqual(stream.feed(b"x" * 200000 + b"A"), [])
        self.assertLessEqual(len(stream.buffer), stream.MAX_BUFFER)
        self.assertEqual(len(stream.feed(BASE[1:])), 1)
        self.assertEqual(stream.discarded_bytes, 200000)


class RecorderTests(unittest.TestCase):
    def setUp(self):
        self.folder = Path(__file__).resolve().parent / "_offline_tests" / uuid4().hex
        self.folder.mkdir(parents=True)

    def tearDown(self):
        # Only files made in this exact unique test directory are removed.
        for child in self.folder.iterdir():
            if child.is_file():
                child.unlink()
        self.folder.rmdir()

    def test_flush_and_history_survive_fault_reset_and_reconnect(self):
        recorder = Recorder(self.folder, "COM7", note="DUTY=20, outer=0/0")
        first = decode_frame(NEGATIVE)
        reset = decode_frame(b"A=0361 C=07DA P=00000000 T=00000000 U=00 R=0 K=0 F=0")
        recorder.append(first, 1.2, 1)
        recorder.event("disconnected", "port vanished", 1.3)
        recorder.set_note("second interval", 2.0)
        recorder.event("reconnected", "COM7", 2.1)
        recorder.append(reset, 2.2, 2)
        # Read before close to verify per-frame flush.
        with recorder.csv_path.open(encoding="utf-8-sig", newline="") as saved:
            rows = list(csv.DictReader(saved))
        with recorder.event_path.open(encoding="utf-8-sig", newline="") as saved:
            events = list(csv.DictReader(saved))
        self.assertEqual(recorder.rows, 2)
        self.assertEqual((rows[0]["position_units"], rows[0]["command_pct"]), ("-408", "-100"))
        self.assertEqual(rows[0]["position_minus_target_units"], "-407")
        self.assertEqual((rows[0]["running"], rows[0]["fault"]), ("1", "2"))
        self.assertEqual(rows[1]["angle_error_adc"], "")
        self.assertEqual((rows[1]["segment"], rows[1]["note"]), ("2", "second interval"))
        self.assertEqual([event["kind"] for event in events], ["disconnected", "note_changed", "reconnected"])
        self.assertTrue(recorder.csv_path.read_bytes().startswith(b"\xef\xbb\xbf"))
        recorder.close()
        recorder.close()
        with self.assertRaises(OSError):
            recorder.append(first, 3.0, 3)

    def test_bad_record_directory_raises_oserror(self):
        path = self.folder / "not_a_folder"
        path.write_text("x", encoding="ascii")
        with self.assertRaises(OSError):
            Recorder(path, "COM7")


if __name__ == "__main__":
    unittest.main(verbosity=2)

"""Integration checks with fake serial handles; never accesses COM ports."""
import csv
from pathlib import Path
import queue
import time
import tkinter as tk
import unittest
from uuid import uuid4

from j280_protocol import Recorder, decode_frame
from wave_monitor import History, Monitor, SerialWorker

FRAME = b"A=0B90 C=0B90 P=FFFFFFF6 T=00000000 U=EC R=1 K=1 F=0\r\n"


class FakeHandle:
    def __init__(self, packet=b"", fail_read=False):
        self.packet=packet
        self.fail_read=fail_read
        self.closed=False
    @property
    def in_waiting(self):
        if self.fail_read:
            raise OSError("simulated USB removal")
        return len(self.packet)
    def read(self,count):
        result,self.packet=self.packet[:count],self.packet[count:]
        return result
    def close(self):
        self.closed=True
    def write(self,*args):
        raise AssertionError("A read-only monitor must never write")


def wait_event(events,kind,timeout=1.5):
    deadline=time.monotonic()+timeout
    while time.monotonic()<deadline:
        try:
            event=events.get(timeout=.05)
        except queue.Empty:
            continue
        if event.kind==kind:
            return event
    raise AssertionError("Missing event "+kind)


class IntegrationTests(unittest.TestCase):
    def test_read_failure_closes_and_reconnects_without_transmitting(self):
        events=queue.Queue()
        bad=FakeHandle(fail_read=True)
        good=FakeHandle(FRAME)
        handles=[bad,good]
        calls=[]
        def factory(port):
            calls.append(port)
            return handles.pop(0)
        worker=SerialWorker(events,factory,retry_seconds=.01)
        worker.start()
        try:
            worker.connect("TEST",True)
            wait_event(events,"error")
            data=wait_event(events,"data")
            self.assertEqual(decode_frame(data.value).command,-20)
            self.assertEqual(calls,["TEST","TEST"])
            self.assertTrue(bad.closed)
        finally:
            worker.shutdown();worker.join(timeout=1)
        self.assertTrue(good.closed)

    def test_manual_disconnect_cancels_retry(self):
        events=queue.Queue()
        calls=[]
        def factory(port):
            calls.append(port)
            raise OSError("simulated port busy")
        worker=SerialWorker(events,factory,retry_seconds=.03)
        worker.start()
        try:
            worker.connect("TEST",True)
            wait_event(events,"error")
            worker.disconnect()
            wait_event(events,"disconnected")
            count=len(calls)
            time.sleep(.08)
            self.assertEqual(len(calls),count)
        finally:
            worker.shutdown();worker.join(timeout=1)

    def test_history_marks_recalibration_and_keeps_connection_segments(self):
        history=History(limit=3)
        first=decode_frame(FRAME)
        next_frame=decode_frame(FRAME.replace(b"C=0B90",b"C=0B91"))
        history.append(first,1,1)
        history.append(next_frame,1.1,1)
        history.append(next_frame,3,2)
        self.assertNotEqual(history.samples[0].epoch,history.samples[1].epoch)
        self.assertEqual(history.samples[-1].segment,2)
        self.assertEqual(len(history.window(3,.5)),1)

    def test_csv_replay_and_stale_status(self):
        root=tk.Tk();root.withdraw()
        app=Monitor(root,mode="replay",create_worker=False)
        folder=Path(__file__).resolve().parent/"_offline_tests"/uuid4().hex
        folder.mkdir(parents=True)
        writer=Recorder(folder,"TEST","offline fixture")
        try:
            writer.append(decode_frame(FRAME),.1,1)
            writer.append(decode_frame(FRAME),.2,2)
            writer.close()
            app.load_replay(writer.csv_path)
            self.assertEqual(len(app.history.samples),2)
            self.assertEqual(app.values["command"].get(),"-20%")
            self.assertIsNone(app.worker)
            app.mode="live";app.connected=False;app.wanted=False
            app.last_received_at=time.monotonic()-10
            app.refresh_status()
            self.assertIn("历史",app.details["command"].get())
        finally:
            writer.close();app.close()
            for child in folder.iterdir():
                child.unlink()
            folder.rmdir()


if __name__=="__main__":
    unittest.main(verbosity=2)

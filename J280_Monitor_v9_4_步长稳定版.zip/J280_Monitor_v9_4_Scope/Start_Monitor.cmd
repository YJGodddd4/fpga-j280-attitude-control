@echo off
setlocal
cd /d "%~dp0monitor"
call "Start_Clean_Monitor.cmd" %*
exit /b %ERRORLEVEL%

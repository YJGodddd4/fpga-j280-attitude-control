module tb_fastspeed_monitor;
    reg clk=0;always #5 clk=~clk;
    reg rst_n=0,tick_ms=0,capture_event=0;
    reg signed [31:0] encoder_count=0;
    wire signed [31:0] reverse_count=-encoder_count;
    wire signed [31:0] speed_q8,reverse_speed_q8;
    wire speed_valid,speed_update,reverse_valid,reverse_update;
    encoder_speed_monitor dut(.*);
    encoder_speed_monitor opposite(.clk(clk),.rst_n(rst_n),.tick_ms(tick_ms),.capture_event(capture_event),
        .encoder_count(reverse_count),.speed_q8(reverse_speed_q8),.speed_valid(reverse_valid),.speed_update(reverse_update));
    integer checks=0,updates=0,age=0,j;
    reg initialized=0,pending=0,ever_valid=0,mirror_ok=1;
    reg signed [31:0] history[0:50],delta32,reverse_delta32;
    longint signed raw_expected,reverse_raw,expected=0,reverse_expected=0,num,error_value;
    integer pending_age=0;
    function automatic longint signed rounded_ratio(input longint signed a,input longint signed b);
        if(a<0)rounded_ratio=-((-a+b/2)/b);else rounded_ratio=(a+b/2)/b;
    endfunction
    function automatic longint signed clamp(input longint signed a);
        if(a>2147483647)clamp=2147483647;else if(a< -2147483648)clamp=-2147483648;else clamp=a;
    endfunction
    task automatic check(input bit condition,input string text);
        begin checks=checks+1;if(!condition)$fatal(1,"%s age=%0d got=%0d expected=%0d reverse=%0d/%0d",text,age,speed_q8,expected,reverse_speed_q8,reverse_expected);end
    endtask
    always @(posedge clk)begin
        if(!rst_n)begin initialized=0;pending=0;ever_valid=0;expected=0;reverse_expected=0;age=0;mirror_ok=1;end
        else if(capture_event || !initialized)begin
            initialized=1;pending=0;ever_valid=0;expected=0;reverse_expected=0;age=0;mirror_ok=1;
            history[0]=encoder_count;
        end else if(tick_ms)begin
            age=age+1;
            if(age>=50 && age%10==0)begin
                check(!pending,"math finishes before next window");
                delta32=encoder_count-history[(age-50)%51];
                reverse_delta32=-delta32;
                num=$signed(delta32)*64'sd2088960;
                raw_expected=clamp(rounded_ratio(num,1040));
                if(raw_expected!=rounded_ratio(num,1040))mirror_ok=0;
                num=$signed(reverse_delta32)*64'sd2088960;
                reverse_raw=clamp(rounded_ratio(num,1040));
                if(reverse_raw!=rounded_ratio(num,1040))mirror_ok=0;
                expected=expected+rounded_ratio(raw_expected-expected,2);
                reverse_expected=reverse_expected+rounded_ratio(reverse_raw-reverse_expected,2);
                pending=1;pending_age=age;
            end
            history[age%51]=encoder_count;
        end
    end
    always @(posedge clk)begin
        #1;
        if(rst_n && initialized)begin
            if(capture_event)begin
                check(!speed_valid && !reverse_valid && speed_q8==0 && reverse_speed_q8==0,"capture clears published result");
            end else begin
                if(!ever_valid && !speed_update)check(!speed_valid,"no early valid result");
                if(speed_update || reverse_update)begin
                    check(speed_update && reverse_update,"same update timing");
                    check(pending && age==pending_age,"exact 10ms sample/update provenance");
                    check(speed_q8===expected[31:0],"forward independent rational arithmetic");
                    check(reverse_speed_q8===reverse_expected[31:0],"reverse independent rational arithmetic");
                    check(speed_valid && reverse_valid,"valid on publication");
                    if(mirror_ok)check($signed(speed_q8)==-$signed(reverse_speed_q8),"odd symmetry");
                    pending=0;ever_valid=1;updates=updates+1;
                end else if(ever_valid)check(speed_valid && reverse_valid,"valid remains set");
            end
        end
    end
    task automatic one_ms(input integer delta);
        begin
            @(negedge clk);encoder_count=encoder_count+delta;tick_ms=1;
            @(negedge clk);tick_ms=0;
            repeat(98)@(negedge clk);
        end
    endtask
    task automatic capture(input reg signed[31:0] origin);
        begin
            @(negedge clk);encoder_count=origin;capture_event=1;
            repeat(2)@(negedge clk);
            capture_event=0;
        end
    endtask
    initial begin
        repeat(4)@(negedge clk);rst_n=1;
        repeat(3)@(negedge clk);
        // Startup must reject incomplete windows.
        for(j=0;j<49;j=j+1)one_ms(1);
        check(!speed_valid,"startup does not use an incomplete 50ms window");
        one_ms(1);check(speed_valid && speed_q8==50216,"first correct 50ms ramp result");
        for(j=0;j<350;j=j+1)one_ms(1);
        check(speed_q8==100431,"1000 raw counts/s converges at correct engineering scale");
        for(j=0;j<400;j=j+1)one_ms(0);
        check(speed_q8==0 && reverse_speed_q8==0,"stationary exact zero; no persistent 1-LSB residue");
        // Positive and negative 32-bit encoder wrap, through mirrored coordinates.
        capture(32'sh7ffffff0);
        for(j=0;j<400;j=j+1)one_ms(3);
        check(speed_q8==301292,"positive wrap speed has no spike");
        capture(32'sh80000010);
        for(j=0;j<400;j=j+1)one_ms(-3);
        check(speed_q8== -301292,"negative wrap speed has no spike");
        // Cancel an in-flight divide; do not publish any old result after capture.
        capture(32'sd123456789);
        for(j=0;j<49;j=j+1)one_ms(2);
        @(negedge clk);encoder_count=encoder_count+2;tick_ms=1;
        @(negedge clk);tick_ms=0;
        repeat(5)@(negedge clk);
        capture(32'sd987654321);
        for(j=0;j<49;j=j+1)one_ms(0);
        check(!speed_valid,"capture cancels in-flight calculation and starts a fresh 50ms window");
        for(j=0;j<100;j=j+1)one_ms(0);
        check(speed_valid && speed_q8==0,"stationary nonzero absolute encoder origin");
        // Full arithmetic range: raw velocity clips before the 32-bit IIR.
        capture(0);
        for(j=0;j<400;j=j+1)one_ms(100000);
        check(speed_q8==32'sh7fffffff,"positive speed saturation");
        check(reverse_speed_q8==32'sh80000000,"negative speed saturation");
        capture(0);
        // Quantized 0.5Hz sinusoid, independent model at full 1ms precision.
        for(j=1;j<=6000;j=j+1)begin
            @(negedge clk);encoder_count=$rtoi(200.0*$sin(6.283185307179586*j/2000.0));tick_ms=1;
            @(negedge clk);tick_ms=0;
            repeat(98)@(negedge clk);
        end
        for(j=0;j<400;j=j+1)one_ms(0);
        check(speed_q8==0 && reverse_speed_q8==0,"sinusoidal input settles to exact zero");
        check(updates>700,"sufficient publications covered");
        $display("ASSERTIONS=%0d UPDATES=%0d",checks,updates);
        $display("ALL PASS fast-speed independent rational model, wrap, capture, saturation, symmetry, no-zero-bias");
        $finish;
    end
    initial begin #100000000;$fatal(1,"timeout");end
endmodule

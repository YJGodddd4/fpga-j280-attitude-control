from pathlib import Path
import json
ROOT=Path('C:/Users/wnc06/Documents/Codex/2026-11-01/J280_AllModes_v8_6_Feedforward')
p=ROOT/'rtl/telemetry.v'
s=p.read_text(encoding='utf-8-sig')
s=s.replace('    output wire tx\n','''    // Z=8601: independent but same-request controller/measurement diagnostics.
    input wire signed [31:0] ff_gain_q16,ff_pd10,ff_applied10,ff_loc10,ff_acceleration_q8,
    input wire signed [32:0] ff_total10,
    input wire ff_active,ff_limited,speed_valid,
    output wire tx
''')
s=s.replace('    reg active,start;','''    reg [31:0] zk,zpd,zff,zlo,zac;
    reg [35:0] ztt;
    reg zen,zsv,zlm;
    reg active,start;''')
# Fields serialized after the original X CRLF; do not change any old index.
fields=[('T',8,'ot'),('Q',8,'oq'),('CF',8,'xu_trajectory_config_tag'),
        ('KA',8,'zk'),('PD',8,'zpd'),('FF',8,'zff'),('TT',9,'ztt'),
        ('LO',8,'zlo'),('AC',8,'zac'),('EN',1,'zen'),('SV',1,'zsv'),('LM',1,'zlm')]
index=771
extra=[]
for ch in 'Z=8601':
 extra.append(f'            {index}:byte_out="{ch}";');index+=1
for key,width,var in fields:
 extra.append(f'            {index}:byte_out=32;');index+=1
 for ch in key+'=':
  extra.append(f'            {index}:byte_out="{ch}";');index+=1
 for digit in range(width):
  extra.append(f'            {index}:byte_out=hexchar({var} >> {(width-digit-1)*4});');index+=1
extra.append(f'            {index}:byte_out=13;');index+=1
extra.append(f'            {index}:byte_out=10;')
s=s.replace('            770:byte_out=10;','            770:byte_out=10;\n'+'\n'.join(extra))
s=s.replace('            index<=0;active<=0;start<=0;state<=0;','''            zk<=0;zpd<=0;zff<=0;zlo<=0;zac<=0;ztt<=0;zen<=0;zsv<=0;zlm<=0;
            index<=0;active<=0;start<=0;state<=0;''')
s=s.replace('                xu_sine_edit_deci<=u_sine_edit_deci;','''                xu_sine_edit_deci<=u_sine_edit_deci;
                zk<=ff_gain_q16;zpd<=ff_pd10;zff<=ff_applied10;zlo<=ff_loc10;
                zac<=ff_acceleration_q8;ztt<={{3{ff_total10[32]}},ff_total10};
                zen<=ff_active;zsv<=speed_valid;zlm<=ff_limited;''')
s=s.replace('if(index==770) active<=0;',f'if(index=={index}) active<=0;')
p.write_text(s,encoding='utf-8')
print('Z body length',index-771-1,'Z withCRLF',index-771+1,'total batch',index+1)
# New host module: no dependency on serial package, no outbound transport.
(ROOT/'monitor/feedforward_protocol.py').write_text('''"""Independent Z8601 diagnostics and tag-qualified fast-speed descriptions."""
from dataclasses import dataclass
import re
FAST_SPEED_TAGS=frozenset((0xB5FBC6B6,))
DIAGNOSTIC_FIELDS=(
 ('T',8,'uptime_ms',False),('Q',8,'snapshot_sequence',False),
 ('CF',8,'trajectory_config_tag',False),('KA',8,'gain_q16',True),
 ('PD',8,'pd10',True),('FF',8,'feedforward10',True),('TT',9,'total10',True),
 ('LO',8,'location_out10',True),('AC',8,'acceleration_q8',True),
 ('EN',1,'active',False),('SV',1,'speed_valid',False),('LM',1,'limited',False))
DIAGNOSTIC_LENGTH=len('Z=8601')+sum(1+len(k)+1+w for k,w,_,_ in DIAGNOSTIC_FIELDS)
_PATTERN=re.compile('Z=8601'+''.join(' '+k+r'=([0-9A-Fa-f]{'+str(w)+'})' for k,w,_,_ in DIAGNOSTIC_FIELDS))
@dataclass(frozen=True)
class FeedforwardDiagnostic:
    uptime_ms:int
    snapshot_sequence:int
    trajectory_config_tag:int
    gain_q16:int
    pd10:int
    feedforward10:int
    total10:int
    location_out10:int
    acceleration_q8:int
    active:int
    speed_valid:int
    limited:int
    raw:str
    @property
    def gain(self):return self.gain_q16/65536
    def matches(self,f):
        return (self.uptime_ms,self.snapshot_sequence,self.trajectory_config_tag)==(f.uptime_ms,f.snapshot_sequence,f.trajectory_config_tag)
def decode_feedforward(data):
    try: text=data.decode('ascii') if isinstance(data,bytes) else data
    except UnicodeDecodeError as exc:raise ValueError('Z diagnostic is not ASCII') from exc
    if not isinstance(text,str):raise ValueError('Z diagnostic requires text or bytes')
    text=text.strip('\\\\r\\\\n \\\\t');m=_PATTERN.fullmatch(text)
    if m is None:raise ValueError('Expected a complete Z=8601 diagnostic')
    vals={}
    for raw,(key,width,name,signed) in zip(m.groups(),DIAGNOSTIC_FIELDS):
        n=int(raw,16)
        if signed and n&(1<<(width*4-1)):n-=1<<(width*4)
        vals[name]=n
    if any(vals[x] not in (0,1) for x in ('active','speed_valid','limited')):
        raise ValueError('Diagnostic flag outside boolean range')
    if not -(1<<32)<=vals['total10']<(1<<32):raise ValueError('TT is outside signed33')
    if not -1000<=vals['location_out10']<=1000:raise ValueError('LO outside actual controller tilt-command scale')
    return FeedforwardDiagnostic(**vals,raw=text)
def speed_description(tag):
    if tag in FAST_SPEED_TAGS:
        return '度/s；原始编码器50ms滑窗／10ms更新，1/2低通；估算W，不是独立测速传感器'
    return '度/s；旧版工程位置50ms差分；滤波权重未遥测，原版为1/4，可能由用户修改'
def speed_summary(tag):
    return ('W：原始编码器50ms滑动测速、10ms更新、1/2低通；旧速度仅用于00到位判定。'
            if tag in FAST_SPEED_TAGS else
            '旧版W：工程位置50ms差分；原版1/4低通，实际滤波权重未遥测。')
def diagnostic_summary(d):
    state='关闭（KA=0）' if d.gain_q16==0 else ('已作用于本次外环更新' if d.active else '系数已配置，当前未作用')
    return (f'加速度前馈：{state}；KA={d.gain:+.6f}（Q16={d.gain_q16}）。'
            f'\\\\n外环PD={d.pd10/10:+.1f}，前馈FF={d.feedforward10/10:+.1f}，合计={d.total10/10:+.1f}，'
            f'实际倾角修正LO={d.location_out10/10:+.1f} ADC；限幅={"是" if d.limited else "否"}。'
            f'测速窗口有效={"是" if d.speed_valid else "否"}。'
            '\\\\n以上是控制器内部倾角修正，非实测PWM、力矩或P/I/D分项。')
'''.replace('\\\\r','\\r').replace('\\\\n','\\n').replace('\\\\t','\\t'),encoding='utf-8')
# Document standalone framing explicitly.
(ROOT/'tests/ffmonitor_wire_contract.json').write_text(json.dumps({'version':'8601','prefix':'Z','body_length':index-771-1,'with_crlf':index-771+1,'batch_length':index+1,'same_request_as_X':True,'fields':fields},indent=2),encoding='utf-8')

`timescale 1ns/1ps
// New-default reference checks only: base half-amplitude90deg, period7s, ramp6s.
// Independent continuous equations use requested amplitude and expected stretch,
// never the DUT's emitted position/derivatives as the reference oracle.
module sine90_numeric_test #(
 parameter integer REQUEST_DECI=900,
 parameter integer BASE_DECI=900, PERIOD_MS=7000, RAMP_MS=6000,
 parameter CASE_NAME="pos90"
);
 localparam integer ABS_REQUEST=REQUEST_DECI<0 ? -REQUEST_DECI : REQUEST_DECI;
 localparam integer EXPECTED_STRETCH=ABS_REQUEST<=BASE_DECI ? 1 : (ABS_REQUEST+BASE_DECI-1)/BASE_DECI;
 localparam integer EXPECTED_CYCLE=PERIOD_MS*EXPECTED_STRETCH;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123,requested_deci=REQUEST_DECI;
 reg [1:0] selected_mode=3;reg selection_valid=1,confirm_event=0;
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,strict=0,logical_ms=0,last_elapsed=-1,last_pub_ms=-1;
 integer first_pub_ms=-1,first_elapsed=0,expected_r,min_steady=2147483647,max_steady=-2147483647;
 integer entry_points=0,steady_points=0,exit_points=0,saved_publications,waited;
 integer last_phase=-1,expected_clock_elapsed_ms=0;
 // A new reference is scheduled every10logicalms (3000FPGA clocks here).
 // Its arithmetic must publish within that slot; variable phase-pipeline delay
 // is allowed, but a late clock or a missed scheduled sample is not.
 localparam integer PIPELINE_SLOT_LOGICAL_MS=10;
 bit check_math=0;
 real base_t,omega,amp,ramp,s,w,wd,wdd,wddd,bq,bv,ba,bj,q,v,a,j;
 real exit_start_ms=-1.0;
 real physical_age_ms=0.0,reference_age_ms=0.0,elapsed_drift_ms=0.0,publication_latency_ms=0.0;
 function real absr(input real x);absr=x<0?-x:x;endfunction
 function integer round_near(input real x);round_near=x<0?-$rtoi(-x+0.5):$rtoi(x+0.5);endfunction
 task ck(input bit pass,input string message);
  begin assertions=assertions+1;
   if(!pass)$fatal(1,"%s case=%s requested=%0d accepted=%0d stretch=%0d elapsed=%0d logical_ms=%0d last_pub_ms=%0d first_pub_ms=%0d first_elapsed=%0d drift_ms=%0.3f clock_elapsed=%0d expected_clock=%0d latency_ms=%0.3f prepared=%0b phase=%0d previous_phase=%0d state=%0d R=%0d V=%0d A=%0d J=%0d",message,CASE_NAME,REQUEST_DECI,accepted_deci,time_stretch,elapsed_ms,logical_ms,last_pub_ms,first_pub_ms,first_elapsed,elapsed_drift_ms,dut.clock_elapsed_ms,expected_clock_elapsed_ms,publication_latency_ms,dut.prepared,phase,last_phase,trajectory_state,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8);
  end
 endtask
 task analytic_reference;
  begin
   amp=REQUEST_DECI/10.0;omega=2.0*3.14159265358979323846/(PERIOD_MS/1000.0);
   base_t=elapsed_ms/1000.0/EXPECTED_STRETCH;ramp=RAMP_MS/1000.0;
   bq=amp*$sin(omega*base_t);bv=amp*omega*$cos(omega*base_t);
   ba=-amp*omega*omega*$sin(omega*base_t);bj=-amp*omega*omega*omega*$cos(omega*base_t);
   if(phase==3 && exit_start_ms<0)exit_start_ms=elapsed_ms-10.0;
   if(phase==1 || phase==3)begin
    s=phase==1 ? base_t/ramp : (elapsed_ms-exit_start_ms)/1000.0/EXPECTED_STRETCH/ramp;
    if(s<0)s=0;if(s>1)s=1;
    w=10*s*s*s-15*s*s*s*s+6*s*s*s*s*s;
    wd=(30*s*s-60*s*s*s+30*s*s*s*s)/ramp;
    wdd=(60*s-180*s*s+120*s*s*s)/(ramp*ramp);
    wddd=(60-360*s+360*s*s)/(ramp*ramp*ramp);
    if(phase==3)begin w=1-w;wd=-wd;wdd=-wdd;wddd=-wddd;end
   end else begin w=1;wd=0;wdd=0;wddd=0;end
   q=bq*w;
   v=(bv*w+bq*wd)/EXPECTED_STRETCH;
   a=(ba*w+2*bv*wd+bq*wdd)/(EXPECTED_STRETCH*EXPECTED_STRETCH);
   j=(bj*w+3*ba*wd+3*bv*wdd+bq*wddd)/(EXPECTED_STRETCH*EXPECTED_STRETCH*EXPECTED_STRETCH);
  end
 endtask
 always @(posedge clk)begin
  if(rst_n && tick_ms)logical_ms=logical_ms+1;
  // Independent input-clock count: unlike publication timing this does not
  // depend on the variable amount of arithmetic work in entry/steady/exit.
  if(!rst_n || adopt_event)expected_clock_elapsed_ms=0;
  else if(tick_ms && owned && balance_ready && !stop_event && running && dut.prepared)
   expected_clock_elapsed_ms=expected_clock_elapsed_ms+1;
  #1;
  if(target_update)begin
   publications=publications+1;
   ck(owned&&balance_ready&&!stop_event,"only current owner may publish");
   ck(target_value===reference_position,"published target equals displayed reference");
   if(check_math)begin
    strict=strict+1;
    ck(accepted_deci===REQUEST_DECI,"next request cannot change current accepted amplitude");
    ck(time_stretch===EXPECTED_STRETCH,"stretch independently derived from requested/base amplitude");
    ck(cycle_ms===EXPECTED_CYCLE,"CL equals independent base period times stretch");
    ck(dut.base_deci_latched==BASE_DECI,"generated ROM base amplitude is the new90degree default");
    analytic_reference();expected_r=123+round_near(q*408/360.0);
    ck(reference_position>=expected_r-1&&reference_position<=expected_r+1,"position matches independent sine/envelope equation");
    ck(center_position===32'sd123 && endpoint_position===32'sd123,"sine center remains fixed through entry/steady/exit");
    if(elapsed_ms<=20 || phase!=last_phase)$display("SINE90_TIMING case=%s elapsed=%0d logical_ms=%0d previous_elapsed=%0d previous_pub_ms=%0d anchor_pub_ms=%0d anchor_elapsed=%0d clock_elapsed=%0d expected_clock=%0d phase=%0d previous_phase=%0d prepared=%0b",CASE_NAME,elapsed_ms,logical_ms,last_elapsed,last_pub_ms,first_pub_ms,first_elapsed,dut.clock_elapsed_ms,expected_clock_elapsed_ms,phase,last_phase,dut.prepared);
    ck(dut.clock_elapsed_ms===expected_clock_elapsed_ms,"trajectory clock equals independent prepared input-tick count");
    if(last_elapsed>=0)ck(elapsed_ms==last_elapsed+10,"published elapsed advances exactly10ms");
    // elapsed0 is an initial prepared-value publication, not a periodic-clock
    // anchor. Keep9..11 unchanged within a phase; changing phase can change the
    // count of fraction/envelope divisions without changing scheduled elapsed.
    if(last_elapsed>=10 && phase==last_phase)ck(logical_ms-last_pub_ms>=9&&logical_ms-last_pub_ms<=11,"same-phase physical publication cadence is9..11logicalms");
    if(dut.prepared && elapsed_ms>=10 && (first_pub_ms<0 || phase!=last_phase))begin
     first_pub_ms=logical_ms;first_elapsed=elapsed_ms;
    end
    if(first_pub_ms>=0)begin
     // Convert the two nonnegative ages separately to real BEFORE subtracting.
     // elapsed_ms is unsigned: integer-expression subtraction could wrap a
     // legitimate negative1ms scheduling offset to4294967295 and falsely fail.
     physical_age_ms=logical_ms-first_pub_ms;
     reference_age_ms=elapsed_ms;reference_age_ms=reference_age_ms-first_elapsed;
     elapsed_drift_ms=physical_age_ms-reference_age_ms;
     ck(absr(elapsed_drift_ms)<=2,"no accumulating same-phase publication lag after prepared startup");
    end
    // Both operands are converted to real first so a signed timing offset
    // cannot be silently reinterpreted as an unsigned32bit wrap.
    publication_latency_ms=expected_clock_elapsed_ms;
    reference_age_ms=elapsed_ms;publication_latency_ms=publication_latency_ms-reference_age_ms;
    if(elapsed_ms>=10)ck(publication_latency_ms>=0 && publication_latency_ms<PIPELINE_SLOT_LOGICAL_MS,"scheduled sample publishes within its10logicalms arithmetic slot");
    last_elapsed=elapsed_ms;last_pub_ms=logical_ms;last_phase=phase;
    if(phase==1)entry_points=entry_points+1;
    if(phase==2)begin
     steady_points=steady_points+1;
     if(reference_position<min_steady)min_steady=reference_position;
     if(reference_position>max_steady)max_steady=reference_position;
    end
    if(phase==3)exit_points=exit_points+1;
    if(running)begin
     ck(jerk_valid&&acceleration_valid,"sine reports valid analytic derivatives");
     ck(absr(reference_speed_q8-v*408/360.0*256)<12,"velocity has correct envelope and1/stretch scale");
     ck(absr(reference_acceleration_q8-a*408/360.0*256)<14,"acceleration has all envelope terms and1/stretch_squared");
     ck(absr(reference_jerk_q8-j*408/360.0*256)<24,"jerk has all envelope terms and1/stretch_cubed");
    end
   end
  end
 end
 task ms(input integer count);
  integer i;begin for(i=0;i<count;i=i+1)begin
   @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
  end end
 endtask
 task confirm;begin @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;end endtask
 task adopt(input integer new_center);
  begin owned=0;adopt_reference=new_center;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);end
 endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;adopt(123);
  ck(held_idle&&!running&&run_id==0,"capture/adoption cannot auto start a run");
  confirm;check_math=1;ms(1000);
  ck(running&&active_profile==3&&accepted_deci==REQUEST_DECI&&run_id==1,"explicit start accepts requested sine amplitude");
  requested_deci=-7777;ms(2*EXPECTED_CYCLE);
  ck(cycle_count>=2,"at least two whole scaled periods complete");
  ck(strict>=2*EXPECTED_CYCLE/10,"analytic checks cannot pass with skipped publication stream");
  ck(entry_points>=RAMP_MS*EXPECTED_STRETCH/10-2&&steady_points>0,"both entry envelope and steady sine were exercised");
  ck(max_steady>=123+round_near(absr(REQUEST_DECI/10.0)*408/360.0)-1,"steady positive extreme reaches requested amplitude");
  ck(min_steady<=123-round_near(absr(REQUEST_DECI/10.0)*408/360.0)+1,"steady negative extreme reaches requested amplitude");
  confirm;waited=0;
  while(!held_idle&&waited<2*RAMP_MS*EXPECTED_STRETCH+500)begin ms(1);waited=waited+1;end
  ck(held_idle&&!running&&reference_position==123,"SW4 smooth stop ends exactly at fixed sine center");
  ck(exit_points>=RAMP_MS*EXPECTED_STRETCH/10-2,"complete exit envelope received independent derivative checks");
  saved_publications=publications;ms(100);ck(publications==saved_publications,"stopped task does not silently restart");
  $display("ALL PASS sine90 case=%s assertions=%0d publications=%0d strict=%0d cycles=%0d",CASE_NAME,assertions,publications,strict,cycle_count);$finish;
 end
 initial begin #(64'd5000000000);$fatal(1,"sine90 numeric timeout");end
endmodule

module tb_sine90_pos90;sine90_numeric_test #(.REQUEST_DECI(900),.CASE_NAME("pos90")) t();endmodule
module tb_sine90_neg90;sine90_numeric_test #(.REQUEST_DECI(-900),.CASE_NAME("neg90")) t();endmodule
module tb_sine90_small30;sine90_numeric_test #(.REQUEST_DECI(300),.CASE_NAME("small30")) t();endmodule
module tb_sine90_large180;sine90_numeric_test #(.REQUEST_DECI(1800),.CASE_NAME("large180")) t();endmodule

// Exercise real raw panel signals and the actual unparameterized editor default.
module tb_sine90_editor_flow;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123;
 reg [3:0] keys_n=15;reg [1:0] dip_n=0;reg edit_enable=1;
 wire minus_event,plus_event,step_event,confirm_event,selection_valid;
 wire [1:0] selected_mode,step_index;
 wire signed [31:0] requested_deci,trapezoid_deci,scurve_deci,sine_deci;
 position_inputs panel(.clk(clk),.rst_n(rst_n),.tick_ms(tick_ms),.keys_n(keys_n),.dip_n(dip_n),
  .edit_enable(edit_enable),.minus_event(minus_event),.plus_event(plus_event),.step_event(step_event),
  .confirm_event(confirm_event),.dip_mode(selected_mode),.dip_valid(selection_valid));
 trajectory_editor editor(.clk(clk),.rst_n(rst_n),.edit_enable(edit_enable),.selected_mode(selected_mode),.selection_valid(selection_valid),
  .minus_event(minus_event),.plus_event(plus_event),.step_event(step_event),.requested_deci(requested_deci),
  .trapezoid_deci(trapezoid_deci),.scurve_deci(scurve_deci),.sine_deci(sine_deci),.step_index(step_index));
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,saved_publications,saved_id,waited;
 task ck(input bit pass,input string message);
  begin assertions=assertions+1;if(!pass)$fatal(1,"%s editorflow TE=%0d TA=%0d run=%0d stretch=%0d state=%0d phase=%0d",message,requested_deci,accepted_deci,run_id,time_stretch,trajectory_state,phase);end
 endtask
 always @(posedge clk)begin #1;if(target_update)begin
  publications=publications+1;ck(owned&&balance_ready&&!stop_event,"no stale output after ownership/balance/stop changes");
 end end
 task ms(input integer count);integer i;begin for(i=0;i<count;i=i+1)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
 end end endtask
 task raw_keys(input reg [3:0] value);begin @(negedge clk);keys_n=value;repeat(4)@(negedge clk);end endtask
 task press(input reg [3:0] mask);begin raw_keys(~mask);ms(30);raw_keys(15);ms(30);end endtask
 task adopt(input integer new_center);begin
  owned=0;adopt_reference=new_center;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;ms(60);
  ck(selection_valid&&selected_mode==3,"raw DIP11 selects sine");
  ck(requested_deci==900&&sine_deci==900&&trapezoid_deci==900&&scurve_deci==900&&step_index==2,"new default90degree sine preserves other editor defaults and10degree step");
  adopt(123);ms(20);ck(held_idle&&!running&&run_id==0,"adoption waits for a raw SW4 press");
  press(8);ck(running&&accepted_deci==900&&time_stretch==1&&cycle_ms==7000&&run_id==1,"raw SW4 starts90degree7second sine");
  saved_id=run_id;press(4);
  ck(requested_deci==1000&&sine_deci==1000&&accepted_deci==900&&run_id==saved_id&&cycle_ms==7000&&center_position==123,"raw SW3 edits next run only; accepted amplitude/period/center are frozen");
  ck(trapezoid_deci==900&&scurve_deci==900,"editing sine does not alter A/B memories");
  press(8);ck(stop_pending&&running,"raw SW4 during entry queues smooth stop rather than restarting");
  waited=0;while(!held_idle&&waited<13000)begin ms(1);waited=waited+1;end
  ck(held_idle&&!running&&reference_position==123&&accepted_deci==900,"entry finishes and exit returns to same center");
  saved_publications=publications;ms(100);ck(publications==saved_publications&&run_id==saved_id,"next edit cannot auto restart after stopping");
  press(8);ck(running&&accepted_deci==1000&&time_stretch==2&&cycle_ms==14000&&run_id==saved_id+1,"fresh raw SW4 accepts the pending edit and recomputes integer stretch");
  // Abort a live update, then prove recapture does not replay it.
  waited=0;while(dut.math_state==0&&waited<20)begin ms(1);waited=waited+1;end
  ck(dut.math_state!=0,"loss case actually reaches an in-flight numeric pipeline");
  @(negedge clk);balance_ready=0;@(posedge clk);#2;
  ck(!running&&!base_valid&&!target_update&&interrupted,"loss of balance cancels current interpolation/division and publication");
  ms(20);balance_ready=1;adopt(250);ms(20);
  ck(held_idle&&!running&&center_position==250&&reference_position==250,"recapture uses fresh center without replaying old run");
  saved_id=run_id;press(8);ck(running&&run_id==saved_id+1&&center_position==250&&accepted_deci==1000,"only a new raw confirmation starts after recapture");
  waited=0;while(dut.math_state==0&&waited<20)begin ms(1);waited=waited+1;end
  ck(dut.math_state!=0,"reset case actually reaches an in-flight numeric pipeline");
  @(negedge clk);rst_n=0;repeat(4)@(negedge clk);
  ck(!running&&!base_valid&&!target_update&&run_id==0,"reset cancels task and pending output");
  ck(sine_deci==900&&trapezoid_deci==900&&scurve_deci==900&&step_index==2,"reset restores the new90degree default and all independent memories");
  $display("ALL PASS sine90 case=editor_flow assertions=%0d publications=%0d strict=0 cycles=0",assertions,publications);$finish;
 end
 initial begin #(64'd5000000000);$fatal(1,"sine90 editorflow timeout");end
endmodule

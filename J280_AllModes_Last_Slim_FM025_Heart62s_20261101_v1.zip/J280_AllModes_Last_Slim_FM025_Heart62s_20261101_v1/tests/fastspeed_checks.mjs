import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {simulate} from './local_verilog_runtime.mjs';
const here=dirname(fileURLToPath(import.meta.url));
const root=resolve(here,'..');
const names=['rtl/signed_div_const.v','rtl/encoder_speed_monitor.v','tests/tb_fastspeed_monitor.sv'];
const files=await Promise.all(names.map(async path=>({path,data:await readFile(resolve(root,path),'utf8')})));
const result=await simulate({top:'tb_fastspeed_monitor',files,sources:names,timeoutMs:120000});
const count=result.stdout.match(/ASSERTIONS=(\d+) UPDATES=(\d+)/);
const report={success:result.success,backend:result.backend,stage:result.stage,exitCode:result.exitCode,
    assertions:count?Number(count[1]):null,publications:count?Number(count[2]):null,
    input_sha256:Object.fromEntries(files.map(x=>[x.path,createHash('sha256').update(x.data).digest('hex')])),
    estimator:{window_ms:50,update_ms:10,iir_alpha:.5,raw_counts_per_rev:1040,engineering_counts_per_rev:408,
        scale:'Q8 engineering counts per second',phase_delay_at_AM_3p5s_ms:35.0,phase_delay_low_frequency_ms:35,
        comment:'25ms backward differentiation window + about10ms IIR phase; final sampling/telemetry age additional.'},
    stdout:result.stdout,stderr:result.stderr,timings:result.timings};
await writeFile(resolve(here,'fastspeed_result.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify({...report,stdout:result.stdout.slice(-5000)},null,2));
if(!result.success)process.exitCode=1;

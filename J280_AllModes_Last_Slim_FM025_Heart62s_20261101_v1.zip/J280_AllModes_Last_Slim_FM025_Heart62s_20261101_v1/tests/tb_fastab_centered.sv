`timescale 1ns/1ps
// Endpoint-origin A/B oracle: every leg uses the complete stroke, including
// the first. Forward0..2H and reverse2H..0 share the captured startup anchor.
// The runner supplies literals derived from the config; no emitted DUT
// position/derivative/stretch is used to construct the mathematical oracle.
module fastab_centered_numeric #(
 parameter integer MODE=1,REQUEST_DECI=900,BASE_HALF_DECI=900,
 parameter real STROKE_DEGREES=180.0,VMAX=85.714285714286,AMAX=87.463556851312,JMAX=1249.47938359017,
 parameter integer SAMPLE_MS=10,LEG_MS=3150,DWELL_MS=350,CYCLE_MS=7000,UNITS_PER_REV=408,
 parameter CASE_NAME="trap_default"
);
 localparam integer ABS_REQUEST=REQUEST_DECI<0 ? -REQUEST_DECI : REQUEST_DECI;
 localparam integer EXPECTED_STRETCH=ABS_REQUEST<=BASE_HALF_DECI ? 1 : (ABS_REQUEST+BASE_HALF_DECI-1)/BASE_HALF_DECI;
 localparam integer EXPECTED_CYCLE=CYCLE_MS*EXPECTED_STRETCH;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123,requested_deci=REQUEST_DECI;
 reg [1:0] selected_mode=MODE;reg selection_valid=1,confirm_event=0;
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,strict=0,logical_ms=0,last_elapsed=-1,last_pub_ms=-1;
 integer first_pub_ms=-1,first_elapsed=0,last_phase=-1,expected_clock_elapsed_ms=0;
 integer expected_r,expected_endpoint,i,segments=0,waited,saved_publications;
 integer normal_points=0,dwell_points=0,lower_cycles,upper_cycles;
 integer min_normal=2147483647,max_normal=-2147483647;
 reg [31:0] phases_seen=0,phases_required=0;
 bit check_math=0,ignore_a=0,ignore_j=0,in_dwell=0;
 real stage_duration[0:6],stage_control[0:6];
 real plan_total,ta,tv,tj,peak_v,tj_a,candidate_ta,boundary;
 real tbase,local_t,normal_t,leg_seconds,dwell_seconds,cycle_seconds,gain,coeff;
 real q,v,a,j,lq,lv,la,lj,remaining,dt,control;
 real physical_age_ms=0.0,reference_age_ms=0.0,drift_ms=0.0,latency_ms=0.0;
 bit found;
 function real absr(input real x);absr=x<0?-x:x;endfunction
 function real minr(input real x,input real y);minr=x<y?x:y;endfunction
 function integer round_near(input real x);round_near=x<0?-$rtoi(-x+0.5):$rtoi(x+0.5);endfunction
 task ck(input bit pass,input string message);
  begin assertions=assertions+1;
   if(!pass)$fatal(1,"%s case=%s req=%0d TA=%0d TM=%0d elapsed=%0d logical=%0d lastpub=%0d anchor=%0d anchor_elapsed=%0d drift=%0.3f clock=%0d expected_clock=%0d latency=%0.3f phase=%0d oldphase=%0d cycles=%0d state=%0d R=%0d EP=%0d V=%0d A=%0d J=%0d",message,CASE_NAME,REQUEST_DECI,accepted_deci,time_stretch,elapsed_ms,logical_ms,last_pub_ms,first_pub_ms,first_elapsed,drift_ms,dut.clock_elapsed_ms,expected_clock_elapsed_ms,latency_ms,phase,last_phase,cycle_count,trajectory_state,reference_position,endpoint_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8);
  end
 endtask
 task make_plan;
  begin
   for(i=0;i<7;i=i+1)begin stage_duration[i]=0;stage_control[i]=0;end
   // Independently solve the seven integrated constant-jerk stages. A has
   // short corner rounds; B has longer jerk ramps. Both preserve a plateau.
   tj_a=AMAX/JMAX;tj=minr(tj_a,$sqrt(VMAX/JMAX));
   ta=VMAX/(JMAX*tj)-tj;if(ta<0)ta=0;
   peak_v=JMAX*tj*(tj+ta);tv=(STROKE_DEGREES-peak_v*(2*tj+ta))/peak_v;
   if(tv<0)begin
    candidate_ta=-1.5*tj_a+$sqrt(0.25*tj_a*tj_a+STROKE_DEGREES/AMAX);
    if(candidate_ta>=0)begin tj=tj_a;ta=candidate_ta;end
    else begin tj=$pow(STROKE_DEGREES/(2.0*JMAX),1.0/3.0);ta=0;end
    tv=0;
   end
   segments=7;
   stage_duration[0]=tj;stage_duration[1]=ta;stage_duration[2]=tj;stage_duration[3]=tv;
   stage_duration[4]=tj;stage_duration[5]=ta;stage_duration[6]=tj;
   stage_control[0]=JMAX;stage_control[1]=0;stage_control[2]=-JMAX;stage_control[3]=0;
   stage_control[4]=-JMAX;stage_control[5]=0;stage_control[6]=JMAX;
   plan_total=0;phases_required=(32'd1<<8)|(32'd1<<16);
   for(i=0;i<segments;i=i+1)begin
    plan_total=plan_total+stage_duration[i];
    if(stage_duration[i]>1e-9)phases_required=phases_required|(32'd1<<(i+1))|(32'd1<<(i+9));
   end
   ck(LEG_MS/1000.0>=plan_total-1e-8 && LEG_MS/1000.0<plan_total+SAMPLE_MS/1000.0+1e-8,"runner leg duration is one-sample ceiling of independent analytic plan");
   ck(CYCLE_MS==2*(LEG_MS+DWELL_MS),"full normal cycle consists of two full legs and two dwells");
   ck(absr(STROKE_DEGREES*5.0-BASE_HALF_DECI)<1e-8,"runtime base is HALF of the configured full-stroke angle");
  end
 endtask
 task leg_equations(input real seconds);
  integer k;
  begin
   lq=0;lv=0;la=0;lj=0;remaining=seconds;found=0;ignore_a=0;ignore_j=0;boundary=0;
   // A/J can change at a stage boundary. The RTL linearly interpolates ROM
   // samples across one cell; check exact derivatives outside that cell and
   // enforce independent absolute bounds at every sample, including the cell.
   for(k=0;k<segments+1;k=k+1)begin
    if(absr(seconds-boundary)<SAMPLE_MS/1000.0+1e-7)begin ignore_a=1;ignore_j=1;end
    if(k<segments)boundary=boundary+stage_duration[k];
   end
   if(seconds>=plan_total-1e-9)begin lq=STROKE_DEGREES;lv=0;la=0;lj=0;end
   else for(k=0;k<segments;k=k+1)begin
    dt=stage_duration[k];control=stage_control[k];
    if(!found)begin
     if(dt>1e-10 && remaining<dt-1e-9)begin
      begin
       lq=lq+lv*remaining+la*remaining*remaining/2.0+control*remaining*remaining*remaining/6.0;
       lv=lv+la*remaining+control*remaining*remaining/2.0;la=la+control*remaining;lj=control;
      end
      found=1;
     end else begin
      begin lq=lq+lv*dt+la*dt*dt/2.0+control*dt*dt*dt/6.0;lv=lv+la*dt+control*dt*dt/2.0;la=la+control*dt;end
      remaining=remaining-dt;
     end
    end
   end
  end
 endtask
 task expected_reference;
  begin
   gain=REQUEST_DECI/(BASE_HALF_DECI*1.0);tbase=elapsed_ms/1000.0/EXPECTED_STRETCH;
   leg_seconds=LEG_MS/1000.0;dwell_seconds=DWELL_MS/1000.0;cycle_seconds=CYCLE_MS/1000.0;
   q=0;v=0;a=0;j=0;ignore_a=0;ignore_j=0;in_dwell=0;
   normal_t=tbase-$floor(tbase/cycle_seconds)*cycle_seconds;
   if(normal_t<leg_seconds-1e-9)begin
    leg_equations(normal_t);q=lq*gain;v=lv*gain;a=la*gain;j=lj*gain;
    expected_endpoint=123+round_near(2.0*REQUEST_DECI*UNITS_PER_REV/3600.0);
   end else if(normal_t<leg_seconds+dwell_seconds-1e-9)begin
    in_dwell=1;q=2.0*REQUEST_DECI/10.0;
    expected_endpoint=123+round_near(2.0*REQUEST_DECI*UNITS_PER_REV/3600.0);
   end else if(normal_t<2*leg_seconds+dwell_seconds-1e-9)begin
    local_t=normal_t-leg_seconds-dwell_seconds;leg_equations(local_t);
    q=(STROKE_DEGREES-lq)*gain;v=-lv*gain;a=-la*gain;j=-lj*gain;
    expected_endpoint=123;
   end else begin in_dwell=1;q=0;expected_endpoint=123;end
   v=v/EXPECTED_STRETCH;a=a/(EXPECTED_STRETCH*EXPECTED_STRETCH);j=j/(EXPECTED_STRETCH*EXPECTED_STRETCH*EXPECTED_STRETCH);
  end
 endtask
 always @(posedge clk)begin
  if(rst_n&&tick_ms)logical_ms=logical_ms+1;
  if(!rst_n||adopt_event)expected_clock_elapsed_ms=0;
  else if(tick_ms&&owned&&balance_ready&&!stop_event&&running&&dut.prepared)expected_clock_elapsed_ms=expected_clock_elapsed_ms+1;
  #1;
  if(target_update)begin
   publications=publications+1;ck(owned&&balance_ready&&!stop_event,"only a valid owner may publish");
   ck(target_value===reference_position,"published target matches displayed reference");
   if(check_math)begin
    strict=strict+1;
    ck(accepted_deci===REQUEST_DECI,"run edits cannot alter accepted half-amplitude");
    ck(time_stretch===EXPECTED_STRETCH&&cycle_ms===EXPECTED_CYCLE,"time stretch and normal period come from independent half-amplitude contract");
    ck(dut.base_deci_latched==BASE_HALF_DECI,"ROM runtime base is a half-amplitude, not full stroke");
    expected_reference();expected_r=123+round_near(q*UNITS_PER_REV/360.0);
    ck(reference_position>=expected_r-1&&reference_position<=expected_r+1,"position matches independent full-stroke first/return equations");
    ck(center_position==123+round_near(REQUEST_DECI*UNITS_PER_REV/3600.0),"telemetry midpoint is offset from startup anchor by one signed half amplitude");
    ck(endpoint_position>=expected_endpoint-1&&endpoint_position<=expected_endpoint+1,"endpoint is the exact startup anchor or anchor plus one rounded full stroke");
    if(elapsed_ms==0)ck(reference_position===32'sd123,"first full-stroke sample starts exactly at the captured endpoint");
    if(in_dwell)begin
     // Full displacement is rounded ONCE relative to the startup anchor.
     // Fractional requests catch premature half-amplitude rounding.
     ck(reference_position===expected_endpoint && target_value===expected_endpoint && endpoint_position===expected_endpoint,"dwell endpoint equals one rounded full stroke or the original anchor exactly");
     ck(reference_speed_q8===32'sd0 && reference_acceleration_q8===32'sd0,"dwell/leg-end velocity and acceleration are exactly zero");
     ck(reference_jerk_q8===32'sd0,"rounded-trapezoid and S endpoint/dwell jerk are exactly zero");
    end
    if(elapsed_ms<=20||phase!=last_phase)$display("FASTAB_TIMING case=%s elapsed=%0d logical=%0d previous_elapsed=%0d previous_pub=%0d anchor_pub=%0d anchor_elapsed=%0d clock=%0d expected_clock=%0d phase=%0d oldphase=%0d",CASE_NAME,elapsed_ms,logical_ms,last_elapsed,last_pub_ms,first_pub_ms,first_elapsed,dut.clock_elapsed_ms,expected_clock_elapsed_ms,phase,last_phase);
    ck(dut.clock_elapsed_ms===expected_clock_elapsed_ms,"prepared clock equals independent input-tick count");
    if(last_elapsed>=0)ck(elapsed_ms==last_elapsed+SAMPLE_MS,"scheduled elapsed advances exactly one10ms slot");
    if(last_elapsed>=SAMPLE_MS&&phase==last_phase)ck(logical_ms-last_pub_ms>=SAMPLE_MS-1&&logical_ms-last_pub_ms<=SAMPLE_MS+1,"same-phase publication interval is9..11logicalms");
    if(dut.prepared&&elapsed_ms>=SAMPLE_MS&&(first_pub_ms<0||phase!=last_phase))begin first_pub_ms=logical_ms;first_elapsed=elapsed_ms;end
    if(first_pub_ms>=0)begin
     physical_age_ms=logical_ms-first_pub_ms;reference_age_ms=elapsed_ms;reference_age_ms=reference_age_ms-first_elapsed;
     drift_ms=physical_age_ms-reference_age_ms;ck(absr(drift_ms)<=2,"no accumulated same-phase lag; signed differences converted before subtracting");
    end
    latency_ms=expected_clock_elapsed_ms;reference_age_ms=elapsed_ms;latency_ms=latency_ms-reference_age_ms;
    if(elapsed_ms>=SAMPLE_MS)ck(latency_ms>=0&&latency_ms<SAMPLE_MS,"scheduled sample publishes inside its10logicalms arithmetic slot");
    last_elapsed=elapsed_ms;last_pub_ms=logical_ms;last_phase=phase;
    if(phase<32)phases_seen=phases_seen|(32'd1<<phase);else ck(0,"phase fits coverage mask");
    normal_points=normal_points+1;
    if(reference_position<min_normal)min_normal=reference_position;
    if(reference_position>max_normal)max_normal=reference_position;
    if(in_dwell)dwell_points=dwell_points+1;
    if(tbase<cycle_seconds-0.000001)ck(cycle_count==0,"one full outward leg is not a completed round trip");
    lower_cycles=$rtoi($floor((tbase-2*SAMPLE_MS/1000.0)/cycle_seconds));if(lower_cycles<0)lower_cycles=0;
    upper_cycles=$rtoi($floor((tbase+2*SAMPLE_MS/1000.0)/cycle_seconds));
    ck(cycle_count===elapsed_ms/EXPECTED_CYCLE,"cycle counter advances exactly each complete scaled7second round trip, starting at first publication");
    if(running)begin
     ck(acceleration_valid,"A/B analytic acceleration is valid");
     ck(absr(reference_speed_q8-v*UNITS_PER_REV/360.0*256)<12,"velocity matches independent centered spatial/time scaling");
     if(!ignore_a)ck(absr(reference_acceleration_q8-a*UNITS_PER_REV/360.0*256)<14,"acceleration matches independent stage integration");
     ck(absr(reference_speed_q8)<=VMAX*absr(gain)/EXPECTED_STRETCH*UNITS_PER_REV/360.0*256+12,"velocity bounded even at interpolation seams");
     ck(absr(reference_acceleration_q8)<=AMAX*absr(gain)/(EXPECTED_STRETCH*EXPECTED_STRETCH)*UNITS_PER_REV/360.0*256+14,"acceleration bounded even at interpolation seams");
     begin
      ck(jerk_valid,"both rounded trapezoid and seven-segment S report finite piecewise jerk");
      if(!ignore_j)ck(absr(reference_jerk_q8-j*UNITS_PER_REV/360.0*256)<24,"S jerk matches all seven integrated segments with time-stretch cubed");
      ck(absr(reference_jerk_q8)<=JMAX*absr(gain)/(EXPECTED_STRETCH*EXPECTED_STRETCH*EXPECTED_STRETCH)*UNITS_PER_REV/360.0*256+24,"S jerk bounded at every publication");
     end
    end
   end
  end
 end
 task ms(input integer count);integer k;begin for(k=0;k<count;k=k+1)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
 end end endtask
 task confirm;begin @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;end endtask
 task adopt(input integer value);begin
  owned=0;adopt_reference=value;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);
 end endtask
 initial begin
  make_plan();repeat(5)@(negedge clk);rst_n=1;adopt(123);
  ck(held_idle&&!running&&run_id==0,"adoption preserves center and requires explicit confirmation");
  confirm;check_math=1;ms(1000);
  ck(running&&active_profile==MODE&&run_id==1,"explicit start chooses requested A/B profile");
  requested_deci=-7777;
  ms(2*EXPECTED_CYCLE);
  ck(cycle_count>=2,"two full round trips complete with no extra startup leg");
  ck(strict>=2*EXPECTED_CYCLE/SAMPLE_MS,"mathematical checks cannot pass with a skipped publication stream");
  ck(normal_points>0&&dwell_points>0,"both full legs and both endpoint dwells were exercised");
  ck((phases_seen&phases_required)==phases_required,"all nonzero forward/reverse trapezoid or seven-S segments and dwells were observed");
  expected_r=123+round_near(2.0*REQUEST_DECI*UNITS_PER_REV/3600.0);
  ck(max_normal>=(expected_r>123?expected_r:123)-1,"positive extreme covers the full signed stroke");
  ck(min_normal<=(expected_r<123?expected_r:123)+1,"negative extreme covers the full signed stroke");
  confirm;waited=0;
  while(!held_idle&&waited<EXPECTED_CYCLE+500)begin ms(1);waited=waited+1;end
  ck(held_idle&&!running&&reference_position==endpoint_position,"SW4 stops at the current signed endpoint");
  ck(reference_position==123||reference_position==123+round_near(2.0*REQUEST_DECI*UNITS_PER_REV/3600.0),"smooth stop holds one of the two full-stroke endpoints");
  saved_publications=publications;ms(100);ck(publications==saved_publications,"a pending edit cannot auto restart after stop");
  $display("ALL PASS fastab case=%s assertions=%0d publications=%0d strict=%0d cycles=%0d",CASE_NAME,assertions,publications,strict,cycle_count);$finish;
 end
 initial begin #(64'd10000000000);$fatal(1,"centered A/B numeric timeout");end
endmodule

module fastab_centered_editor_flow #(
 parameter integer A_HALF_DECI=900,B_HALF_DECI=900,C_HALF_DECI=900,
 parameter integer A_LEG_MS=3150,B_LEG_MS=3150,A_CYCLE_MS=7000,B_CYCLE_MS=7000,UNITS_PER_REV=408
);
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123;
 reg [3:0] keys_n=15;reg [1:0] dip_n=2;reg edit_enable=1;
 wire minus_event,plus_event,step_event,confirm_event,selection_valid;
 wire [1:0] selected_mode,step_index;
 wire signed [31:0] requested_deci,trapezoid_deci,scurve_deci,sine_deci;
 position_inputs panel(.clk(clk),.rst_n(rst_n),.tick_ms(tick_ms),.keys_n(keys_n),.dip_n(dip_n),
  .edit_enable(edit_enable),.minus_event(minus_event),.plus_event(plus_event),.step_event(step_event),
  .confirm_event(confirm_event),.dip_mode(selected_mode),.dip_valid(selection_valid));
 trajectory_editor editor(.clk(clk),.rst_n(rst_n),.edit_enable(edit_enable),.selected_mode(selected_mode),.selection_valid(selection_valid),
  .minus_event(minus_event),.plus_event(plus_event),.step_event(step_event),.requested_deci(requested_deci),
  .trapezoid_deci(trapezoid_deci),.scurve_deci(scurve_deci),.sine_deci(sine_deci),.step_index(step_index));
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,saved_id,saved_publications,waited,saved_center,next_center;
 function integer round_near(input real x);round_near=x<0?-$rtoi(-x+0.5):$rtoi(x+0.5);endfunction
 task ck(input bit pass,input string message);begin assertions=assertions+1;
  if(!pass)$fatal(1,"%s editorflow mode=%0d TE=%0d TA=%0d A=%0d B=%0d C=%0d run=%0d TM=%0d state=%0d phase=%0d R=%0d center=%0d EP=%0d",message,selected_mode,requested_deci,accepted_deci,trapezoid_deci,scurve_deci,sine_deci,run_id,time_stretch,trajectory_state,phase,reference_position,center_position,endpoint_position);
 end endtask
 always @(posedge clk)begin #1;if(target_update)begin publications=publications+1;ck(owned&&balance_ready&&!stop_event,"only current valid owner publishes");end end
 task ms(input integer count);integer k;begin for(k=0;k<count;k=k+1)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
 end end endtask
 task raw_keys(input reg [3:0] value);begin @(negedge clk);keys_n=value;repeat(4)@(negedge clk);end endtask
 task press(input reg [3:0] mask);begin raw_keys(~mask);ms(30);raw_keys(15);ms(30);end endtask
 task select_mode(input reg [1:0] value);begin @(negedge clk);dip_n=~value;ms(30);ck(selection_valid&&selected_mode==value,"raw group DIP chooses requested profile");end endtask
 task adopt(input integer value);begin owned=0;adopt_reference=value;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);end endtask
 task wait_stopped(input integer timeout_ms);begin waited=0;while(!held_idle&&waited<timeout_ms)begin ms(1);waited=waited+1;end ck(held_idle&&!running,"normal SW4 stop reaches a current-leg endpoint");end endtask
 task reach_inflight;begin waited=0;while(dut.math_state==0&&waited<20)begin ms(1);waited=waited+1;end ck(dut.math_state!=0,"abort/reset actually occurs during live numeric work");end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;ms(60);
  ck(selection_valid&&selected_mode==1,"raw DIP01 selects trapezoid");
  ck(trapezoid_deci==A_HALF_DECI&&scurve_deci==B_HALF_DECI&&sine_deci==C_HALF_DECI&&step_index==2,"all three default half-amplitudes and10degree edit step are correct");
  adopt(123);ms(20);ck(held_idle&&!running&&run_id==0,"capture cannot auto start a profile");
  press(8);ck(running&&accepted_deci==A_HALF_DECI&&time_stretch==1&&cycle_ms==A_CYCLE_MS&&run_id==1,"raw SW4 starts default centered trapezoid");
  saved_id=run_id;press(4);
  ck(trapezoid_deci==A_HALF_DECI+100&&scurve_deci==B_HALF_DECI&&sine_deci==C_HALF_DECI,"raw SW3 changes A memory only");
  ck(accepted_deci==A_HALF_DECI&&run_id==saved_id&&cycle_ms==A_CYCLE_MS&&center_position==123+round_near(A_HALF_DECI*UNITS_PER_REV/3600.0),"RUN edit cannot mutate current accepted amplitude/period/center");
  press(8);ck(stop_pending&&running,"raw SW4 requests a smooth full first-leg stop");
  wait_stopped(A_LEG_MS+1000);
  ck(reference_position==123+round_near(2.0*A_HALF_DECI*UNITS_PER_REV/3600.0)&&reference_position==endpoint_position,"first trapezoid leg stops at the configured full stroke");
  saved_publications=publications;ms(100);ck(publications==saved_publications&&run_id==saved_id,"pending A edit does not silently restart");
  next_center=reference_position;select_mode(2);press(8);
  ck(running&&active_profile==2&&accepted_deci==B_HALF_DECI&&time_stretch==1&&cycle_ms==B_CYCLE_MS&&center_position==next_center+round_near(B_HALF_DECI*UNITS_PER_REV/3600.0),"fresh S run locks the held endpoint as its new origin and reports offset midpoint");
  saved_center=next_center;saved_id=run_id;press(2);
  ck(scurve_deci==B_HALF_DECI-100&&trapezoid_deci==A_HALF_DECI+100&&sine_deci==C_HALF_DECI,"raw SW2 changes B memory only");
  ck(accepted_deci==B_HALF_DECI&&run_id==saved_id&&center_position==saved_center+round_near(B_HALF_DECI*UNITS_PER_REV/3600.0)&&cycle_ms==B_CYCLE_MS,"S run is isolated from edits to its next half-amplitude");
  press(8);wait_stopped(B_LEG_MS+1000);
  ck(reference_position==saved_center+round_near(2.0*B_HALF_DECI*UNITS_PER_REV/3600.0)&&reference_position==endpoint_position,"first S stop holds its full-stroke endpoint");
  select_mode(1);press(8);
  ck(running&&accepted_deci==A_HALF_DECI+100&&time_stretch==2&&cycle_ms==2*A_CYCLE_MS,"fresh confirmation accepts pending A edit and recomputes TM");
  reach_inflight();@(negedge clk);balance_ready=0;@(posedge clk);#2;
  ck(!running&&!base_valid&&!target_update&&interrupted,"loss of balance cancels in-flight work and future publication");
  ms(20);balance_ready=1;adopt(250);ms(20);ck(held_idle&&!running&&center_position==250&&reference_position==250,"recapture adopts a fresh center without replaying a run");
  saved_id=run_id;press(8);ck(running&&run_id==saved_id+1&&accepted_deci==A_HALF_DECI+100&&center_position==250+round_near((A_HALF_DECI+100)*UNITS_PER_REV/3600.0),"explicit raw confirmation is required after recapture");
  reach_inflight();@(negedge clk);rst_n=0;repeat(4)@(negedge clk);
  ck(!running&&!base_valid&&!target_update&&run_id==0,"reset cancels pending trajectory output");
  ck(trapezoid_deci==A_HALF_DECI&&scurve_deci==B_HALF_DECI&&sine_deci==C_HALF_DECI&&step_index==2,"reset restores A/B half-amplitude defaults and unchanged sine default");
  $display("ALL PASS fastab case=editor_flow assertions=%0d publications=%0d strict=0 cycles=0",assertions,publications);$finish;
 end
 initial begin #(64'd10000000000);$fatal(1,"centered A/B editor flow timeout");end
endmodule

# v8.7 心形轨迹离线验证

所有测试仅运行计算与RTL仿真；不打开串口、不运行下载器、不控制电机。

## 复现顺序

在工程目录执行：

1. `python tests/heart_reference.py`
2. `python tests/heart_rom_check.py`
3. `node tests/heart_run.mjs`
4. `python tests/heart_collect_results.py`

第3步默认调用本包既有的 `tests/fastspeed_wasm_adapter.mjs`。该适配器引用开发机器上已安装的 Icarus WebAssembly 运行时。换电脑时，需要把这个适配器中的运行时模块位置改为本机实际位置；运行时本体未附入本工程。仿真接口沿用现有 `simulate(options)`。亦可用本包原生仿真适配器配置本机Questa运行环境。

可以只选一组，例：`node tests/heart_run.mjs pos56`。
全部组名：pos56、neg56、pos30、neg30、pos90、neg90、exit_early、exit_mid、lifecycle、pair_am、pair_fm。

## 数学与数值依据

- `heart_reference.py` 用独立三阶Taylor级数运算实现确认后的上下包络公式，不导入生产生成器。对5600个10ms参考点检查包络、时间镜像、心尖、首尾归零，并用有限差分独立检查速度、加速度与jerk。
- `heart_rom_check.py` 将生产ROM的22,400个q/v/a/j值与独立公式的对称四舍五入值逐个进行精确比较；另核对AM/FM参考ROM、AM/FM原启停门控与基础模块哈希保持。
- `heart_numeric.sv` 在实际RTL每个10ms发布点检查位置、速度、加速度、jerk、固定56秒周期、正负缩放、锁定原点、每次任务独立接受编辑值，以及无累计计算延迟。±30°、±56°、±90°每组均覆盖至少两完整周期。
- `heart_exit_numeric.sv` 专门检查首秒与非零位置中途的两秒C3退出，导数使用乘积法则独立计算。
- `heart_lifecycle.sv` 从原始按键与拨码进入，检查默认560、SW2/SW3编辑、组合键步长、SW4确认、运行中仅编辑下次请求、零输入、负输入、拨码切换、失衡取消、重新捕获不重播、总停止与复位。
- `heart_pairs.sv` 逐仿真FPGA时钟比较00以外保留的AM/FM任务输出，基准task/tables/mem是本包内的 `heart_baseline_*` 文件，不依赖外部原工程。
- 结果记录为 `heart_*_result.json`，统一汇总为 `heart_verification_summary.json`；汇总脚本要求每组记录的源文件哈希与当前文件完全一致。

位置整数输出具有原工程408单位/转的量化；其余导数仍为工程单位Q8。测试容差包含ROM与输出量化，不能将这些量化台阶解释为曲线发生机械振动。

仿真用300个FPGA时钟压缩代表1逻辑毫秒；真实硬件为50MHz。这是加速测试刺激，不是改变实际控制周期。验证未包含倒立摆、电机动力学与真实闭环效果。

// 50MHz -> 5MHz ADC 时钟。在 ADC 下降沿采数据，距上升沿 100ns。
// 1024 点平均，每 204.8us 发布一次结果；sum/256 对应原 C 的 12bit 数值尺度。
module equiv_base_adc_3pa1030 #(
    parameter integer HALF_DIV=5,
    parameter integer AVG_LOG2=10
)(
    input wire clk, input wire rst_n,
    input wire [9:0] adc_data_in, input wire adc_otr,
    output wire adc_clk, output wire adc_oe_n,
    output reg [11:0] angle, output reg valid, output reg overrange
);
    reg [7:0] divider;
    (* syn_keep=1, syn_preserve=1 *) reg adc_clock_r;
    assign adc_clk=adc_clock_r;
    assign adc_oe_n=1'b0; // 板上 ADC STBY 接地，不能另分配一个 FPGA 引脚。
    always @(posedge clk or negedge rst_n)
        if(!rst_n) begin divider<=0; adc_clock_r<=0; end
        else if(divider==HALF_DIV-1) begin divider<=0; adc_clock_r<=~adc_clock_r; end
        else divider<=divider+1'b1;

    // ADC 时钟域异步置复位、下降沿同步释放。
    reg [1:0] adc_reset_pipe;
    always @(negedge adc_clock_r or negedge rst_n)
        if(!rst_n) adc_reset_pipe<=0;
        else adc_reset_pipe<={adc_reset_pipe[0],1'b1};
    wire adc_rst_n=adc_reset_pipe[1];
    (* syn_preserve=1 *) reg [9:0] adc_capture;
    reg otr_capture;
    reg [4:0] warmup;
    reg [AVG_LOG2-1:0] sample_count;
    reg [AVG_LOG2+9:0] sum;
    reg otr_acc;
    // 邮箱保持到下一次发布；事件同步后再读取整条数据总线。
    (* syn_preserve=1 *) reg [11:0] result_hold;
    (* syn_preserve=1 *) reg otr_hold;
    (* syn_preserve=1 *) reg publish_toggle;
    wire [AVG_LOG2+10:0] sum_next={1'b0,sum}+adc_capture;
    always @(negedge adc_clock_r or negedge adc_rst_n) begin
        if(!adc_rst_n) begin
            adc_capture<=0; otr_capture<=0; warmup<=0; sample_count<=0; sum<=0;
            otr_acc<=0; result_hold<=0; otr_hold<=0; publish_toggle<=0;
        end else begin
            adc_capture<=adc_data_in; otr_capture<=adc_otr;
            if(warmup<16) warmup<=warmup+1'b1;
            else if(sample_count=={AVG_LOG2{1'b1}}) begin
                result_hold<=sum_next[AVG_LOG2+9:AVG_LOG2-2];
                otr_hold<=otr_acc|otr_capture; publish_toggle<=~publish_toggle;
                sample_count<=0; sum<=0; otr_acc<=0;
            end else begin
                sample_count<=sample_count+1'b1; sum<=sum_next[AVG_LOG2+9:0];
                otr_acc<=otr_acc|otr_capture;
            end
        end
    end
    (* syn_preserve=1 *) reg [1:0] publish_sync;
    reg publish_seen;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin publish_sync<=0; publish_seen<=0; angle<=0; valid<=0; overrange<=0; end
        else begin
            publish_sync<={publish_sync[0],publish_toggle}; valid<=0;
            if(publish_sync[1]!=publish_seen) begin
                publish_seen<=publish_sync[1];
                angle<=result_hold; overrange<=otr_hold; valid<=1;
            end
        end
    end
endmodule

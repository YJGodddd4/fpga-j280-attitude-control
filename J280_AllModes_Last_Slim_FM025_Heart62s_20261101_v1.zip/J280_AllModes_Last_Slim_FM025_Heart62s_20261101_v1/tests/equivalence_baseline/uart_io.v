module equiv_base_uart_tx #(parameter integer CLK_HZ=50000000, BAUD=115200)(
    input wire clk,input wire rst_n,input wire start,input wire [7:0] data,
    output reg tx,output reg busy
);
    localparam integer BIT_CLOCKS=(CLK_HZ+BAUD/2)/BAUD;
    reg [31:0] timer;
    reg [3:0] bit_index;
    reg [9:0] frame;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin tx<=1; busy<=0; timer<=0; bit_index<=0; frame<=10'h3ff; end
        else if(!busy) begin
            tx<=1;
            if(start) begin frame<={1'b1,data,1'b0}; tx<=0; busy<=1; timer<=0; bit_index<=0; end
        end else if(timer==BIT_CLOCKS-1) begin
            timer<=0;
            if(bit_index==9) begin busy<=0; tx<=1; end
            else begin frame<={1'b1,frame[9:1]}; tx<=frame[1]; bit_index<=bit_index+1'b1; end
        end else timer<=timer+1'b1;
    end
endmodule

module equiv_base_uart_rx #(parameter integer CLK_HZ=50000000, BAUD=115200)(
    input wire clk,input wire rst_n,input wire rx,
    output reg [7:0] data,output reg valid
);
    localparam integer BIT_CLOCKS=(CLK_HZ+BAUD/2)/BAUD;
    (* syn_preserve=1 *) reg [1:0] rx_sync;
    reg [31:0] timer;
    reg [3:0] bit_index;
    reg [7:0] shift;
    reg [1:0] state;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin rx_sync<=3; timer<=0; bit_index<=0; shift<=0; state<=0; valid<=0; data<=0; end
        else begin
            rx_sync<={rx_sync[0],rx}; valid<=0;
            case(state)
                0: if(!rx_sync[1]) begin timer<=0; state<=1; end
                1: if(timer==BIT_CLOCKS/2-1) begin
                    timer<=0;
                    if(!rx_sync[1]) begin state<=2; bit_index<=0; end
                    else state<=0;
                end else timer<=timer+1'b1;
                2: if(timer==BIT_CLOCKS-1) begin
                    timer<=0; shift[bit_index]<=rx_sync[1];
                    if(bit_index==7) state<=3;
                    else bit_index<=bit_index+1'b1;
                end else timer<=timer+1'b1;
                3: if(timer==BIT_CLOCKS-1) begin
                    timer<=0; state<=0;
                    if(rx_sync[1]) begin data<=shift; valid<=1; end
                end else timer<=timer+1'b1;
            endcase
        end
    end
endmodule

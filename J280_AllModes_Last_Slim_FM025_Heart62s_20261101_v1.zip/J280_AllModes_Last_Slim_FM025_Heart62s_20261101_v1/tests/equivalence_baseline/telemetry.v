// 每次请求快照为一整行 ASCII，数值采用十六进制，负数为补码。
// A=角度 C=直立标定 P=位置 T=目标 U=PWM R=运行 K=标定完成 F=故障
module equiv_base_telemetry #(parameter integer CLK_HZ=50000000, BAUD=115200)(
    input wire clk,input wire rst_n,input wire request,
    input wire [11:0] angle,center,
    input wire signed [31:0] position,target_position,
    input wire signed [7:0] command,
    input wire running,calibrated,input wire [3:0] fault,
    input wire [3:0] mode,
    input wire signed [31:0] velocity_q8,
    input wire [7:0] pulse_count,
    input wire auto_ready,motion_valid,
    input wire [1:0] pos_dip_mode,pos_step_index,
    input wire [3:0] pos_task_state,
    input wire signed [31:0] pos_edit_deci,pos_goal_deci,
    input wire signed [31:0] pos_home,pos_reference,pos_ref_velocity_q8,pos_velocity_q8,
    input wire pos_anchor_valid,pos_interrupted,
    input wire [15:0] pos_task_id,
    input wire [31:0] uptime_ms,
    input wire [63:0] pos_duration_ms,
    input wire [1:0] u_reference_owner,
    input wire signed [31:0] u_planner_reference_units,
    input wire signed [31:0] u_active_base_units,
    input wire signed [31:0] u_trajectory_endpoint_units,
    input wire signed [31:0] u_reference_velocity_q8,
    input wire [7:0] u_duty_limit_pct,
    input wire [1:0] u_active_trajectory_profile,
    input wire [3:0] u_trajectory_state,
    input wire [31:0] u_trajectory_cycle_count,
    input wire [31:0] u_trajectory_elapsed_ms,
    input wire [15:0] u_trajectory_phase,
    input wire signed [31:0] u_reference_acceleration_q8,
    input wire signed [31:0] u_reference_jerk_q8,
    input wire [15:0] u_flags,
    input wire [11:0] u_down_center_adc,
    input wire [12:0] u_peak_amplitude_adc,
    input wire [31:0] u_trajectory_cycle_ms,
    input wire [31:0] u_trajectory_config_tag,
    input wire [31:0] u_angle_kp_100,
    input wire [31:0] u_angle_ki_100,
    input wire [31:0] u_angle_kd_100,
    input wire [31:0] u_location_kp_10,
    input wire [31:0] u_location_kd_10,
    input wire [31:0] u_position_min_move_ms,
    input wire [31:0] u_position_ms_per_degree,
    input wire signed [31:0] u_trajectory_edit_deci,
    input wire signed [31:0] u_trajectory_accepted_deci,
    input wire [1:0] u_trajectory_step_index,
    input wire [15:0] u_trajectory_run_id,
    input wire [31:0] u_trajectory_time_stretch,
    input wire signed [31:0] u_trapezoid_edit_deci,
    input wire signed [31:0] u_scurve_edit_deci,
    input wire signed [31:0] u_sine_edit_deci,
    // Z=8601: independent but same-request controller/measurement diagnostics.
    input wire signed [31:0] ff_gain_q16,ff_pd10,ff_applied10,ff_loc10,ff_acceleration_q8,
    input wire signed [32:0] ff_total10,
    input wire ff_active,ff_limited,speed_valid,
    output wire tx
);
    reg [11:0] a,c;
    reg [31:0] p,t;
    reg [7:0] u;
    reg r,k;
    reg [3:0] f;
    reg [9:0] index;
    reg [3:0] m;
    reg [31:0] w;
    reg [7:0] n;
    reg q,z;
    // O=5103: signed32 E/G, unsigned64 L; H is the accepted task's actual base.
    // Self-contained atomic snapshot; legacy A/M remain compatible.
    reg [1:0] od,ok;
    reg [3:0] os;
    reg [15:0] oi;
    reg [31:0] oe,og,oh,orf,ov,ow,ot,oq,packet_sequence;
    reg [63:0] ol;
    reg oa,oz;
    // X=8002 adds one atomic all-modes snapshot after unchanged A/M/O.
    reg [1:0] xu_reference_owner;
    reg [31:0] xu_planner_reference_units;
    reg [31:0] xu_active_base_units;
    reg [31:0] xu_trajectory_endpoint_units;
    reg [31:0] xu_reference_velocity_q8;
    reg [7:0] xu_duty_limit_pct;
    reg [1:0] xu_active_trajectory_profile;
    reg [3:0] xu_trajectory_state;
    reg [31:0] xu_trajectory_cycle_count;
    reg [31:0] xu_trajectory_elapsed_ms;
    reg [15:0] xu_trajectory_phase;
    reg [31:0] xu_reference_acceleration_q8;
    reg [31:0] xu_reference_jerk_q8;
    reg [15:0] xu_flags;
    reg [11:0] xu_down_center_adc;
    reg [12:0] xu_peak_amplitude_adc;
    reg [31:0] xu_trajectory_cycle_ms;
    reg [31:0] xu_trajectory_config_tag;
    reg [31:0] xu_angle_kp_100;
    reg [31:0] xu_angle_ki_100;
    reg [31:0] xu_angle_kd_100;
    reg [31:0] xu_location_kp_10;
    reg [31:0] xu_location_kd_10;
    reg [31:0] xu_position_min_move_ms;
    reg [31:0] xu_position_ms_per_degree;
    reg [31:0] xu_trajectory_edit_deci;
    reg [31:0] xu_trajectory_accepted_deci;
    reg [1:0] xu_trajectory_step_index;
    reg [15:0] xu_trajectory_run_id;
    reg [31:0] xu_trajectory_time_stretch;
    reg [31:0] xu_trapezoid_edit_deci;
    reg [31:0] xu_scurve_edit_deci;
    reg [31:0] xu_sine_edit_deci;
    reg [31:0] zk,zpd,zff,zlo,zac;
    reg [35:0] ztt;
    reg zen,zsv,zlm;
    reg active,start;
    reg [1:0] state;
    wire busy;
    reg [7:0] byte_out;
    // Split index/hex character selection from the UART frame load path.
    // The extra select stage is one system clock per transmitted byte.
    (* syn_preserve=1 *) reg [7:0] byte_latched;
    function [7:0] hexchar;
        input [3:0] nibble;
        begin hexchar=nibble<10 ? 8'd48+nibble : 8'd65+nibble-10; end
    endfunction
    always @* begin
        byte_out=8'h20;
        case(index)
            0:byte_out="A"; 1:byte_out="=";
            2:byte_out=hexchar(0); 3:byte_out=hexchar(a[11:8]);
            4:byte_out=hexchar(a[7:4]); 5:byte_out=hexchar(a[3:0]);
            7:byte_out="C"; 8:byte_out="=";
            9:byte_out=hexchar(0); 10:byte_out=hexchar(c[11:8]);
            11:byte_out=hexchar(c[7:4]); 12:byte_out=hexchar(c[3:0]);
            14:byte_out="P";15:byte_out="=";
            16,17,18,19,20,21,22,23:byte_out=hexchar(p >> ((23-index)*4));
            25:byte_out="T";26:byte_out="=";
            27,28,29,30,31,32,33,34:byte_out=hexchar(t >> ((34-index)*4));
            36:byte_out="U";37:byte_out="=";
            38:byte_out=hexchar(u[7:4]);39:byte_out=hexchar(u[3:0]);
            41:byte_out="R";42:byte_out="=";43:byte_out=r ? "1":"0";
            45:byte_out="K";46:byte_out="=";47:byte_out=k ? "1":"0";
            49:byte_out="F";50:byte_out="=";51:byte_out=hexchar(f);
            52:byte_out=13;53:byte_out=10;
            54:byte_out="M";55:byte_out="=";56:byte_out=hexchar(m);
            58:byte_out="W";59:byte_out="=";
            60,61,62,63,64,65,66,67:byte_out=hexchar(w >> ((67-index)*4));
            69:byte_out="N";70:byte_out="=";
            71:byte_out=hexchar(n[7:4]);72:byte_out=hexchar(n[3:0]);
            74:byte_out="Q";75:byte_out="=";76:byte_out=q ? "1":"0";
            78:byte_out="Z";79:byte_out="=";80:byte_out=z ? "1":"0";
            81:byte_out=13;82:byte_out=10;
            83:byte_out="O";84:byte_out="=";
            85:byte_out="5";86:byte_out="1";87:byte_out="0";88:byte_out="3";
            90:byte_out="D";91:byte_out="=";
            92:byte_out=hexchar(od >> ((92-index)*4));
            94:byte_out="S";95:byte_out="=";
            96:byte_out=hexchar(os >> ((96-index)*4));
            98:byte_out="E";99:byte_out="=";
            100,101,102,103,104,105,106,107:byte_out=hexchar(oe >> ((107-index)*4));
            109:byte_out="G";110:byte_out="=";
            111,112,113,114,115,116,117,118:byte_out=hexchar(og >> ((118-index)*4));
            120:byte_out="H";121:byte_out="=";
            122,123,124,125,126,127,128,129:byte_out=hexchar(oh >> ((129-index)*4));
            131:byte_out="R";132:byte_out="=";
            133,134,135,136,137,138,139,140:byte_out=hexchar(orf >> ((140-index)*4));
            142:byte_out="P";143:byte_out="=";
            144,145,146,147,148,149,150,151:byte_out=hexchar(p >> ((151-index)*4));
            153:byte_out="V";154:byte_out="=";
            155,156,157,158,159,160,161,162:byte_out=hexchar(ov >> ((162-index)*4));
            164:byte_out="W";165:byte_out="=";
            166,167,168,169,170,171,172,173:byte_out=hexchar(ow >> ((173-index)*4));
            175:byte_out="K";176:byte_out="=";
            177:byte_out=hexchar(ok >> ((177-index)*4));
            179:byte_out="A";180:byte_out="=";
            181:byte_out=hexchar(oa >> ((181-index)*4));
            183:byte_out="I";184:byte_out="=";
            185,186,187,188:byte_out=hexchar(oi >> ((188-index)*4));
            190:byte_out="Z";191:byte_out="=";
            192:byte_out=hexchar(oz >> ((192-index)*4));
            194:byte_out="M";195:byte_out="=";
            196:byte_out=hexchar(m >> ((196-index)*4));
            198:byte_out="U";199:byte_out="=";
            200,201:byte_out=hexchar(u >> ((201-index)*4));
            203:byte_out="B";204:byte_out="=";
            205,206,207,208:byte_out=hexchar(a >> ((208-index)*4));
            210:byte_out="C";211:byte_out="=";
            212,213,214,215:byte_out=hexchar(c >> ((215-index)*4));
            217:byte_out="T";218:byte_out="=";
            219,220,221,222,223,224,225,226:byte_out=hexchar(ot >> ((226-index)*4));
            228:byte_out="Q";229:byte_out="=";
            230,231,232,233,234,235,236,237:byte_out=hexchar(oq >> ((237-index)*4));
            239:byte_out="L";240:byte_out="=";
            241,242,243,244,245,246,247,248,249,250,251,252,253,254,255,256:byte_out=hexchar(ol >> ((256-index)*4));
            257:byte_out=13;258:byte_out=10;
            259:byte_out="X";
            260:byte_out="=";
            261:byte_out="8";
            262:byte_out="0";
            263:byte_out="0";
            264:byte_out="2";
            266:byte_out="T";
            267:byte_out="=";
            268,269,270,271,272,273,274,275:byte_out=hexchar(ot >> ((275-index)*4));
            277:byte_out="Q";
            278:byte_out="=";
            279,280,281,282,283,284,285,286:byte_out=hexchar(oq >> ((286-index)*4));
            288:byte_out="D";
            289:byte_out="=";
            290:byte_out=hexchar(od >> ((290-index)*4));
            292:byte_out="O";
            293:byte_out="=";
            294:byte_out=hexchar(xu_reference_owner >> ((294-index)*4));
            296:byte_out="M";
            297:byte_out="=";
            298:byte_out=hexchar(m >> ((298-index)*4));
            300:byte_out="F";
            301:byte_out="=";
            302:byte_out=hexchar(f >> ((302-index)*4));
            304:byte_out="K";
            305:byte_out="=";
            306:byte_out=hexchar(k >> ((306-index)*4));
            308:byte_out="R";
            309:byte_out="=";
            310:byte_out=hexchar(r >> ((310-index)*4));
            312:byte_out="A";
            313:byte_out="=";
            314,315,316,317:byte_out=hexchar(a >> ((317-index)*4));
            319:byte_out="C";
            320:byte_out="=";
            321,322,323,324:byte_out=hexchar(c >> ((324-index)*4));
            326:byte_out="P";
            327:byte_out="=";
            328,329,330,331,332,333,334,335:byte_out=hexchar(p >> ((335-index)*4));
            337:byte_out="Y";
            338:byte_out="=";
            339,340,341,342,343,344,345,346:byte_out=hexchar(t >> ((346-index)*4));
            348:byte_out="R";
            349:byte_out="F";
            350:byte_out="=";
            351,352,353,354,355,356,357,358:byte_out=hexchar(xu_planner_reference_units >> ((358-index)*4));
            360:byte_out="H";
            361:byte_out="=";
            362,363,364,365,366,367,368,369:byte_out=hexchar(xu_active_base_units >> ((369-index)*4));
            371:byte_out="E";
            372:byte_out="P";
            373:byte_out="=";
            374,375,376,377,378,379,380,381:byte_out=hexchar(xu_trajectory_endpoint_units >> ((381-index)*4));
            383:byte_out="V";
            384:byte_out="=";
            385,386,387,388,389,390,391,392:byte_out=hexchar(xu_reference_velocity_q8 >> ((392-index)*4));
            394:byte_out="W";
            395:byte_out="=";
            396,397,398,399,400,401,402,403:byte_out=hexchar(ow >> ((403-index)*4));
            405:byte_out="U";
            406:byte_out="=";
            407,408:byte_out=hexchar(u >> ((408-index)*4));
            410:byte_out="B";
            411:byte_out="=";
            412,413:byte_out=hexchar(xu_duty_limit_pct >> ((413-index)*4));
            415:byte_out="E";
            416:byte_out="=";
            417,418,419,420,421,422,423,424:byte_out=hexchar(oe >> ((424-index)*4));
            426:byte_out="G";
            427:byte_out="=";
            428,429,430,431,432,433,434,435:byte_out=hexchar(og >> ((435-index)*4));
            437:byte_out="S";
            438:byte_out="=";
            439:byte_out=hexchar(os >> ((439-index)*4));
            441:byte_out="I";
            442:byte_out="=";
            443,444,445,446:byte_out=hexchar(oi >> ((446-index)*4));
            448:byte_out="Z";
            449:byte_out="=";
            450:byte_out=hexchar(oz >> ((450-index)*4));
            452:byte_out="L";
            453:byte_out="=";
            454,455,456,457,458,459,460,461,462,463,464,465,466,467,468,469:byte_out=hexchar(ol >> ((469-index)*4));
            471:byte_out="J";
            472:byte_out="=";
            473:byte_out=hexchar(xu_active_trajectory_profile >> ((473-index)*4));
            475:byte_out="N";
            476:byte_out="=";
            477:byte_out=hexchar(xu_trajectory_state >> ((477-index)*4));
            479:byte_out="C";
            480:byte_out="Y";
            481:byte_out="=";
            482,483,484,485,486,487,488,489:byte_out=hexchar(xu_trajectory_cycle_count >> ((489-index)*4));
            491:byte_out="E";
            492:byte_out="L";
            493:byte_out="=";
            494,495,496,497,498,499,500,501:byte_out=hexchar(xu_trajectory_elapsed_ms >> ((501-index)*4));
            503:byte_out="P";
            504:byte_out="H";
            505:byte_out="=";
            506,507,508,509:byte_out=hexchar(xu_trajectory_phase >> ((509-index)*4));
            511:byte_out="A";
            512:byte_out="C";
            513:byte_out="=";
            514,515,516,517,518,519,520,521:byte_out=hexchar(xu_reference_acceleration_q8 >> ((521-index)*4));
            523:byte_out="J";
            524:byte_out="K";
            525:byte_out="=";
            526,527,528,529,530,531,532,533:byte_out=hexchar(xu_reference_jerk_q8 >> ((533-index)*4));
            535:byte_out="F";
            536:byte_out="L";
            537:byte_out="=";
            538,539,540,541:byte_out=hexchar(xu_flags >> ((541-index)*4));
            543:byte_out="P";
            544:byte_out="V";
            545:byte_out="=";
            546,547,548,549,550,551,552,553:byte_out=hexchar(w >> ((553-index)*4));
            555:byte_out="P";
            556:byte_out="C";
            557:byte_out="=";
            558,559:byte_out=hexchar(n >> ((559-index)*4));
            561:byte_out="D";
            562:byte_out="C";
            563:byte_out="=";
            564,565,566,567:byte_out=hexchar(xu_down_center_adc >> ((567-index)*4));
            569:byte_out="P";
            570:byte_out="K";
            571:byte_out="=";
            572,573,574,575:byte_out=hexchar(xu_peak_amplitude_adc >> ((575-index)*4));
            577:byte_out="C";
            578:byte_out="L";
            579:byte_out="=";
            580,581,582,583,584,585,586,587:byte_out=hexchar(xu_trajectory_cycle_ms >> ((587-index)*4));
            589:byte_out="C";
            590:byte_out="F";
            591:byte_out="=";
            592,593,594,595,596,597,598,599:byte_out=hexchar(xu_trajectory_config_tag >> ((599-index)*4));
            601:byte_out="A";
            602:byte_out="P";
            603:byte_out="=";
            604,605,606,607,608,609,610,611:byte_out=hexchar(xu_angle_kp_100 >> ((611-index)*4));
            613:byte_out="A";
            614:byte_out="I";
            615:byte_out="=";
            616,617,618,619,620,621,622,623:byte_out=hexchar(xu_angle_ki_100 >> ((623-index)*4));
            625:byte_out="A";
            626:byte_out="D";
            627:byte_out="=";
            628,629,630,631,632,633,634,635:byte_out=hexchar(xu_angle_kd_100 >> ((635-index)*4));
            637:byte_out="L";
            638:byte_out="P";
            639:byte_out="=";
            640,641,642,643,644,645,646,647:byte_out=hexchar(xu_location_kp_10 >> ((647-index)*4));
            649:byte_out="L";
            650:byte_out="D";
            651:byte_out="=";
            652,653,654,655,656,657,658,659:byte_out=hexchar(xu_location_kd_10 >> ((659-index)*4));
            661:byte_out="P";
            662:byte_out="M";
            663:byte_out="=";
            664,665,666,667,668,669,670,671:byte_out=hexchar(xu_position_min_move_ms >> ((671-index)*4));
            673:byte_out="P";
            674:byte_out="D";
            675:byte_out="=";
            676,677,678,679,680,681,682,683:byte_out=hexchar(xu_position_ms_per_degree >> ((683-index)*4));
            
            684:byte_out=32;
            685:byte_out="T";
            686:byte_out="E";
            687:byte_out="=";
            688:byte_out=hexchar(xu_trajectory_edit_deci >> 28);
            689:byte_out=hexchar(xu_trajectory_edit_deci >> 24);
            690:byte_out=hexchar(xu_trajectory_edit_deci >> 20);
            691:byte_out=hexchar(xu_trajectory_edit_deci >> 16);
            692:byte_out=hexchar(xu_trajectory_edit_deci >> 12);
            693:byte_out=hexchar(xu_trajectory_edit_deci >> 8);
            694:byte_out=hexchar(xu_trajectory_edit_deci >> 4);
            695:byte_out=hexchar(xu_trajectory_edit_deci >> 0);
            696:byte_out=32;
            697:byte_out="T";
            698:byte_out="A";
            699:byte_out="=";
            700:byte_out=hexchar(xu_trajectory_accepted_deci >> 28);
            701:byte_out=hexchar(xu_trajectory_accepted_deci >> 24);
            702:byte_out=hexchar(xu_trajectory_accepted_deci >> 20);
            703:byte_out=hexchar(xu_trajectory_accepted_deci >> 16);
            704:byte_out=hexchar(xu_trajectory_accepted_deci >> 12);
            705:byte_out=hexchar(xu_trajectory_accepted_deci >> 8);
            706:byte_out=hexchar(xu_trajectory_accepted_deci >> 4);
            707:byte_out=hexchar(xu_trajectory_accepted_deci >> 0);
            708:byte_out=32;
            709:byte_out="T";
            710:byte_out="Z";
            711:byte_out="=";
            712:byte_out=hexchar(xu_trajectory_step_index >> 0);
            713:byte_out=32;
            714:byte_out="T";
            715:byte_out="I";
            716:byte_out="=";
            717:byte_out=hexchar(xu_trajectory_run_id >> 12);
            718:byte_out=hexchar(xu_trajectory_run_id >> 8);
            719:byte_out=hexchar(xu_trajectory_run_id >> 4);
            720:byte_out=hexchar(xu_trajectory_run_id >> 0);
            721:byte_out=32;
            722:byte_out="T";
            723:byte_out="M";
            724:byte_out="=";
            725:byte_out=hexchar(xu_trajectory_time_stretch >> 28);
            726:byte_out=hexchar(xu_trajectory_time_stretch >> 24);
            727:byte_out=hexchar(xu_trajectory_time_stretch >> 20);
            728:byte_out=hexchar(xu_trajectory_time_stretch >> 16);
            729:byte_out=hexchar(xu_trajectory_time_stretch >> 12);
            730:byte_out=hexchar(xu_trajectory_time_stretch >> 8);
            731:byte_out=hexchar(xu_trajectory_time_stretch >> 4);
            732:byte_out=hexchar(xu_trajectory_time_stretch >> 0);
            733:byte_out=32;
            734:byte_out="E";
            735:byte_out="A";
            736:byte_out="=";
            737:byte_out=hexchar(xu_trapezoid_edit_deci >> 28);
            738:byte_out=hexchar(xu_trapezoid_edit_deci >> 24);
            739:byte_out=hexchar(xu_trapezoid_edit_deci >> 20);
            740:byte_out=hexchar(xu_trapezoid_edit_deci >> 16);
            741:byte_out=hexchar(xu_trapezoid_edit_deci >> 12);
            742:byte_out=hexchar(xu_trapezoid_edit_deci >> 8);
            743:byte_out=hexchar(xu_trapezoid_edit_deci >> 4);
            744:byte_out=hexchar(xu_trapezoid_edit_deci >> 0);
            745:byte_out=32;
            746:byte_out="E";
            747:byte_out="B";
            748:byte_out="=";
            749:byte_out=hexchar(xu_scurve_edit_deci >> 28);
            750:byte_out=hexchar(xu_scurve_edit_deci >> 24);
            751:byte_out=hexchar(xu_scurve_edit_deci >> 20);
            752:byte_out=hexchar(xu_scurve_edit_deci >> 16);
            753:byte_out=hexchar(xu_scurve_edit_deci >> 12);
            754:byte_out=hexchar(xu_scurve_edit_deci >> 8);
            755:byte_out=hexchar(xu_scurve_edit_deci >> 4);
            756:byte_out=hexchar(xu_scurve_edit_deci >> 0);
            757:byte_out=32;
            758:byte_out="E";
            759:byte_out="C";
            760:byte_out="=";
            761:byte_out=hexchar(xu_sine_edit_deci >> 28);
            762:byte_out=hexchar(xu_sine_edit_deci >> 24);
            763:byte_out=hexchar(xu_sine_edit_deci >> 20);
            764:byte_out=hexchar(xu_sine_edit_deci >> 16);
            765:byte_out=hexchar(xu_sine_edit_deci >> 12);
            766:byte_out=hexchar(xu_sine_edit_deci >> 8);
            767:byte_out=hexchar(xu_sine_edit_deci >> 4);
            768:byte_out=hexchar(xu_sine_edit_deci >> 0);
            769:byte_out=13;
            770:byte_out=10;
            771:byte_out="Z";
            772:byte_out="=";
            773:byte_out="8";
            774:byte_out="6";
            775:byte_out="0";
            776:byte_out="1";
            777:byte_out=32;
            778:byte_out="T";
            779:byte_out="=";
            780:byte_out=hexchar(ot >> 28);
            781:byte_out=hexchar(ot >> 24);
            782:byte_out=hexchar(ot >> 20);
            783:byte_out=hexchar(ot >> 16);
            784:byte_out=hexchar(ot >> 12);
            785:byte_out=hexchar(ot >> 8);
            786:byte_out=hexchar(ot >> 4);
            787:byte_out=hexchar(ot >> 0);
            788:byte_out=32;
            789:byte_out="Q";
            790:byte_out="=";
            791:byte_out=hexchar(oq >> 28);
            792:byte_out=hexchar(oq >> 24);
            793:byte_out=hexchar(oq >> 20);
            794:byte_out=hexchar(oq >> 16);
            795:byte_out=hexchar(oq >> 12);
            796:byte_out=hexchar(oq >> 8);
            797:byte_out=hexchar(oq >> 4);
            798:byte_out=hexchar(oq >> 0);
            799:byte_out=32;
            800:byte_out="C";
            801:byte_out="F";
            802:byte_out="=";
            803:byte_out=hexchar(xu_trajectory_config_tag >> 28);
            804:byte_out=hexchar(xu_trajectory_config_tag >> 24);
            805:byte_out=hexchar(xu_trajectory_config_tag >> 20);
            806:byte_out=hexchar(xu_trajectory_config_tag >> 16);
            807:byte_out=hexchar(xu_trajectory_config_tag >> 12);
            808:byte_out=hexchar(xu_trajectory_config_tag >> 8);
            809:byte_out=hexchar(xu_trajectory_config_tag >> 4);
            810:byte_out=hexchar(xu_trajectory_config_tag >> 0);
            811:byte_out=32;
            812:byte_out="K";
            813:byte_out="A";
            814:byte_out="=";
            815:byte_out=hexchar(zk >> 28);
            816:byte_out=hexchar(zk >> 24);
            817:byte_out=hexchar(zk >> 20);
            818:byte_out=hexchar(zk >> 16);
            819:byte_out=hexchar(zk >> 12);
            820:byte_out=hexchar(zk >> 8);
            821:byte_out=hexchar(zk >> 4);
            822:byte_out=hexchar(zk >> 0);
            823:byte_out=32;
            824:byte_out="P";
            825:byte_out="D";
            826:byte_out="=";
            827:byte_out=hexchar(zpd >> 28);
            828:byte_out=hexchar(zpd >> 24);
            829:byte_out=hexchar(zpd >> 20);
            830:byte_out=hexchar(zpd >> 16);
            831:byte_out=hexchar(zpd >> 12);
            832:byte_out=hexchar(zpd >> 8);
            833:byte_out=hexchar(zpd >> 4);
            834:byte_out=hexchar(zpd >> 0);
            835:byte_out=32;
            836:byte_out="F";
            837:byte_out="F";
            838:byte_out="=";
            839:byte_out=hexchar(zff >> 28);
            840:byte_out=hexchar(zff >> 24);
            841:byte_out=hexchar(zff >> 20);
            842:byte_out=hexchar(zff >> 16);
            843:byte_out=hexchar(zff >> 12);
            844:byte_out=hexchar(zff >> 8);
            845:byte_out=hexchar(zff >> 4);
            846:byte_out=hexchar(zff >> 0);
            847:byte_out=32;
            848:byte_out="T";
            849:byte_out="T";
            850:byte_out="=";
            851:byte_out=hexchar(ztt >> 32);
            852:byte_out=hexchar(ztt >> 28);
            853:byte_out=hexchar(ztt >> 24);
            854:byte_out=hexchar(ztt >> 20);
            855:byte_out=hexchar(ztt >> 16);
            856:byte_out=hexchar(ztt >> 12);
            857:byte_out=hexchar(ztt >> 8);
            858:byte_out=hexchar(ztt >> 4);
            859:byte_out=hexchar(ztt >> 0);
            860:byte_out=32;
            861:byte_out="L";
            862:byte_out="O";
            863:byte_out="=";
            864:byte_out=hexchar(zlo >> 28);
            865:byte_out=hexchar(zlo >> 24);
            866:byte_out=hexchar(zlo >> 20);
            867:byte_out=hexchar(zlo >> 16);
            868:byte_out=hexchar(zlo >> 12);
            869:byte_out=hexchar(zlo >> 8);
            870:byte_out=hexchar(zlo >> 4);
            871:byte_out=hexchar(zlo >> 0);
            872:byte_out=32;
            873:byte_out="A";
            874:byte_out="C";
            875:byte_out="=";
            876:byte_out=hexchar(zac >> 28);
            877:byte_out=hexchar(zac >> 24);
            878:byte_out=hexchar(zac >> 20);
            879:byte_out=hexchar(zac >> 16);
            880:byte_out=hexchar(zac >> 12);
            881:byte_out=hexchar(zac >> 8);
            882:byte_out=hexchar(zac >> 4);
            883:byte_out=hexchar(zac >> 0);
            884:byte_out=32;
            885:byte_out="E";
            886:byte_out="N";
            887:byte_out="=";
            888:byte_out=hexchar(zen >> 0);
            889:byte_out=32;
            890:byte_out="S";
            891:byte_out="V";
            892:byte_out="=";
            893:byte_out=hexchar(zsv >> 0);
            894:byte_out=32;
            895:byte_out="L";
            896:byte_out="M";
            897:byte_out="=";
            898:byte_out=hexchar(zlm >> 0);
            899:byte_out=13;
            900:byte_out=10;
        endcase
    end
    equiv_base_uart_tx #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) u_tx(
        .clk(clk),.rst_n(rst_n),.start(start),.data(byte_latched),.tx(tx),.busy(busy)
    );
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            a<=0;c<=0;p<=0;t<=0;u<=0;r<=0;k<=0;f<=0;
            m<=0;w<=0;n<=0;q<=0;z<=0;
            od<=0;ok<=0;os<=0;oe<=0;og<=0;oi<=0;
            oh<=0;orf<=0;ov<=0;ow<=0;ot<=0;oq<=0;ol<=0;packet_sequence<=0;oa<=0;oz<=0;
            xu_reference_owner<=0;
            xu_planner_reference_units<=0;
            xu_active_base_units<=0;
            xu_trajectory_endpoint_units<=0;
            xu_reference_velocity_q8<=0;
            xu_duty_limit_pct<=0;
            xu_active_trajectory_profile<=0;
            xu_trajectory_state<=0;
            xu_trajectory_cycle_count<=0;
            xu_trajectory_elapsed_ms<=0;
            xu_trajectory_phase<=0;
            xu_reference_acceleration_q8<=0;
            xu_reference_jerk_q8<=0;
            xu_flags<=0;
            xu_down_center_adc<=0;
            xu_peak_amplitude_adc<=0;
            xu_trajectory_cycle_ms<=0;
            xu_trajectory_config_tag<=0;
            xu_angle_kp_100<=0;
            xu_angle_ki_100<=0;
            xu_angle_kd_100<=0;
            xu_location_kp_10<=0;
            xu_location_kd_10<=0;
            xu_position_min_move_ms<=0;
            xu_position_ms_per_degree<=0;
            xu_trajectory_edit_deci<=0;
            xu_trajectory_accepted_deci<=0;
            xu_trajectory_step_index<=0;
            xu_trajectory_run_id<=0;
            xu_trajectory_time_stretch<=0;
            xu_trapezoid_edit_deci<=0;
            xu_scurve_edit_deci<=0;
            xu_sine_edit_deci<=0;
            zk<=0;zpd<=0;zff<=0;zlo<=0;zac<=0;ztt<=0;zen<=0;zsv<=0;zlm<=0;
            index<=0;active<=0;start<=0;state<=0;byte_latched<=0;
        end else begin
            start<=0;
            if(request && !active) begin
                a<=angle;c<=center;p<=position;t<=target_position;u<=command;
                r<=running;k<=calibrated;f<=fault;index<=0;active<=1;state<=0;
                m<=mode;w<=velocity_q8;n<=pulse_count;q<=auto_ready;z<=motion_valid;
                od<=pos_dip_mode;os<=pos_task_state;oe<=pos_edit_deci;og<=pos_goal_deci;
                oh<=pos_home;orf<=pos_reference;ov<=pos_ref_velocity_q8;ow<=pos_velocity_q8;
                ok<=pos_step_index;oa<=pos_anchor_valid;oi<=pos_task_id;oz<=pos_interrupted;
                ot<=uptime_ms;oq<=packet_sequence+1'b1;packet_sequence<=packet_sequence+1'b1;ol<=pos_duration_ms;
                xu_reference_owner<=u_reference_owner;
                xu_planner_reference_units<=u_planner_reference_units;
                xu_active_base_units<=u_active_base_units;
                xu_trajectory_endpoint_units<=u_trajectory_endpoint_units;
                xu_reference_velocity_q8<=u_reference_velocity_q8;
                xu_duty_limit_pct<=u_duty_limit_pct;
                xu_active_trajectory_profile<=u_active_trajectory_profile;
                xu_trajectory_state<=u_trajectory_state;
                xu_trajectory_cycle_count<=u_trajectory_cycle_count;
                xu_trajectory_elapsed_ms<=u_trajectory_elapsed_ms;
                xu_trajectory_phase<=u_trajectory_phase;
                xu_reference_acceleration_q8<=u_reference_acceleration_q8;
                xu_reference_jerk_q8<=u_reference_jerk_q8;
                xu_flags<=u_flags;
                xu_down_center_adc<=u_down_center_adc;
                xu_peak_amplitude_adc<=u_peak_amplitude_adc;
                xu_trajectory_cycle_ms<=u_trajectory_cycle_ms;
                xu_trajectory_config_tag<=u_trajectory_config_tag;
                xu_angle_kp_100<=u_angle_kp_100;
                xu_angle_ki_100<=u_angle_ki_100;
                xu_angle_kd_100<=u_angle_kd_100;
                xu_location_kp_10<=u_location_kp_10;
                xu_location_kd_10<=u_location_kd_10;
                xu_position_min_move_ms<=u_position_min_move_ms;
                xu_position_ms_per_degree<=u_position_ms_per_degree;
                xu_trajectory_edit_deci<=u_trajectory_edit_deci;
                xu_trajectory_accepted_deci<=u_trajectory_accepted_deci;
                xu_trajectory_step_index<=u_trajectory_step_index;
                xu_trajectory_run_id<=u_trajectory_run_id;
                xu_trajectory_time_stretch<=u_trajectory_time_stretch;
                xu_trapezoid_edit_deci<=u_trapezoid_edit_deci;
                xu_scurve_edit_deci<=u_scurve_edit_deci;
                xu_sine_edit_deci<=u_sine_edit_deci;
                zk<=ff_gain_q16;zpd<=ff_pd10;zff<=ff_applied10;zlo<=ff_loc10;
                zac<=ff_acceleration_q8;ztt<={{3{ff_total10[32]}},ff_total10};
                zen<=ff_active;zsv<=speed_valid;zlm<=ff_limited;


            end
            if(active) begin
                case(state)
                    0: if(!busy) begin byte_latched<=byte_out;state<=1;end
                    1: if(!busy) begin start<=1;state<=2;end
                    2: if(busy) state<=3;
                    3: if(!busy) begin
                        if(index==900) active<=0;
                        else begin index<=index+1'b1;state<=0;end
                    end
                endcase
            end
        end
    end
endmodule

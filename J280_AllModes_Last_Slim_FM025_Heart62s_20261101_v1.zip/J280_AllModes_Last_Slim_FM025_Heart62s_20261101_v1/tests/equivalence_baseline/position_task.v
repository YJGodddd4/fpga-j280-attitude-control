// Position-reference task above the UNMODIFIED v5 cascade PID.
// Each confirmed increment is relative to ACTUAL position at that confirmation.
// The accepted base stays fixed throughout that task, in408 units/revolution.
// UI values are0.1 degree; this is NOT a claim of0.1 degree hardware accuracy.
// T=MIN_MOVE_MS+round(abs(delta_units)*360*MS_PER_DEG/408) milliseconds.
// The quintic is a monotone256-segment Q24 LUT with linear interpolation;
// its analytic derivative is interpolated separately for reference-speed display.
// A mode change reduces phase rate by1-quintic(t/CANCEL_MS), then holds the
// reference reached at the END of deceleration. It never resets motor PWM.
module equiv_base_position_task #(
    parameter integer MIN_MOVE_MS=2000,
    parameter integer MS_PER_DEG=100,
    parameter integer CANCEL_MS=500,
    parameter integer ARRIVE_POSITION_UNITS=2,
    parameter integer ARRIVE_SPEED_UNITS_S=2,
    parameter integer ARRIVE_ANGLE_ADC=32,
    parameter integer ARRIVE_HOLD_MS=500
)(
    input wire clk,input wire rst_n,input wire tick_ms,
    input wire capture_event,input wire signed [31:0] capture_home,
    // Return from a different reference generator without clearing encoder or
    // measured-speed history. This is a reference handoff, not calibration.
    input wire reference_adopt_event,input wire signed [31:0] reference_adopt_value,
    input wire lock_valid,input wire balance_ready,input wire stop_event,
    input wire [1:0] dip_mode,input wire dip_valid,
    input wire edit_minus,input wire edit_plus,input wire step_event,input wire confirm_event,
    input wire signed [31:0] position,input wire [11:0] angle,input wire [11:0] center,
    output reg target_update,output reg signed [31:0] target_value,
    output reg signed [31:0] edit_deci,output reg signed [31:0] goal_deci,
    output reg signed [31:0] home_position,output reg signed [31:0] reference_position,
    output reg signed [31:0] reference_speed_q8,output reg signed [31:0] actual_speed_q8,
    output reg [3:0] task_state,output reg [1:0] step_index,
    output reg anchor_valid,output reg interrupted,output reg [15:0] task_id,
    output reg [63:0] duration_ms
);
    localparam [3:0] NO_HOME=0,HOLD=1,MOVING=2,SETTLING=3,ARRIVED=4,
        DECELERATING=5,RESERVED=6,INTERRUPTED=7;
    localparam [5:0] IDLE=0,WAIT_QUANT=1,PLAN_DURATION=2,WAIT_DURATION=3,
        WAIT_CANCEL=4,LOOKUP=5,INTERPOLATE=6,SHAPE_READY=7,ADVANCE=8,
        WAIT_PHASE=9,POSITION_PRODUCT=10,SPEED_PRODUCT=11,START_SPEED_DIV=12,
        WAIT_SPEED=13,PUBLISH=14,QUANT_MULT=15,QUANT_ROUND=16,QUANT_START=17,
        GOAL_ADD=18,GOAL_STORE=19,DELTA_STORE=20,DURATION_MUL360=21,
        DURATION_SCALE=22,DURATION_ROUND=23,DURATION_START=24,
        INTERP_PRODUCTS=25,INTERP_SUM=26,POSITION_MAGNITUDE=27,POSITION_ROUND=28,
        POSITION_SIGN=29,POSITION_ADD=30,SPEED_COMBINE=31,SPEED_SCALE_A=32,
        SPEED_SCALE_B=33,SPEED_ROUND=34,SPEED_SIGN=35,ADVANCE_TEST=36,
        ADVANCE_START=37,CANCEL_START=38;
    wire position_mode=dip_valid && dip_mode==2'b00;
    wire can_edit=anchor_valid && balance_ready && position_mode;
    wire signed [32:0] edit_step=step_index==0 ? 33'sd1 :
        (step_index==1 ? 33'sd10 : 33'sd100);
    wire signed [32:0] plus_edit=$signed({edit_deci[31],edit_deci})+edit_step;
    wire signed [32:0] minus_edit=$signed({edit_deci[31],edit_deci})-edit_step;
    reg [5:0] engine_state;
    reg div_start,abort_engine;
    reg [95:0] div_numerator;
    reg [63:0] div_denominator;
    wire div_busy,div_done;
    wire accept_confirm=can_edit && confirm_event &&
        (task_state==HOLD || task_state==SETTLING || task_state==ARRIVED) &&
        engine_state==IDLE && !div_busy;
    wire [95:0] div_quotient;
    wire engine_rst_n=rst_n && anchor_valid && lock_valid && !stop_event && !capture_event && !reference_adopt_event && !abort_engine;
    wire signed [31:0] incoming_reference=capture_event ? capture_home : reference_adopt_value;
    equiv_base_position_serial_div u_reference_div(.clk(clk),.rst_n(engine_rst_n),.start(div_start),
        .numerator(div_numerator),.denominator(div_denominator),
        .busy(div_busy),.done(div_done),.quotient(div_quotient));
    reg goal_negative,duration_ready,shape_is_cancel;
    reg signed [31:0] start_position,goal_position;
    reg signed [32:0] move_delta;
    reg [31:0] edit_magnitude;
    reg [32:0] move_magnitude;
    reg [63:0] quant_product,quant_rounded;
    reg signed [63:0] quantized_offset_latched,absolute_goal_latched;
    reg [63:0] duration_degrees_product,duration_scaled_product,duration_rounded;
    reg [95:0] progress_q16;
    reg [95:0] progress_next_latched;
    reg [16:0] working_rate;
    reg [31:0] cancel_elapsed,arrive_count;
    wire [95:0] total_progress_q16={16'd0,duration_ms,16'd0};
    reg [32:0] shape_phase;
    wire [8:0] rom_index=shape_phase[32] ? 9'd256 : {1'b0,shape_phase[31:24]};
    wire [24:0] rom_f0,rom_f1;
    wire [17:0] rom_d0,rom_d1;
    equiv_base_position_quintic_rom u_quintic(.index(rom_index),.f0(rom_f0),.f1(rom_f1),.d0(rom_d0),.d1(rom_d1));
    reg [24:0] lut_f0,lut_f1,shape_value;
    reg [17:0] lut_d0,lut_d1,shape_derivative;
    reg [15:0] fraction;
    reg [24:0] f_difference;
    reg [41:0] f_interpolation_product;
    reg signed [18:0] derivative_difference;
    reg signed [35:0] d_interpolation_product;
    wire signed [35:0] d_interpolated=$signed({1'b0,lut_d0})+(d_interpolation_product>>>16);
    reg signed [63:0] position_product;
    reg [63:0] speed_product1;
    reg [95:0] speed_product2 /* synthesis syn_preserve = 1 */;
    reg position_negative;
    reg [63:0] position_magnitude,position_rounded;
    reg signed [63:0] position_offset;
    reg [48:0] speed_low_product,speed_high_product;
    reg [95:0] speed_scaled_a,speed_numerator,speed_dividend,speed_rounded;
    reg signed [31:0] pending_position,pending_speed;
    reg [1:0] pending_finish;
    function [31:0] abs32;
        input signed [31:0] value;
        begin abs32=value[31] ? (~value+1'b1) : value;end
    endfunction
    function [32:0] abs33;
        input signed [32:0] value;
        begin abs33=value[32] ? (~value+1'b1) : value;end
    endfunction

    function signed [31:0] clamp_speed;
        input [95:0] value;
        input negative;
        begin
            if(negative)clamp_speed=value>=96'd2147483648 ? 32'sh80000000 : -$signed(value[31:0]);
            else clamp_speed=value>96'd2147483647 ? 32'sh7fffffff : $signed(value[31:0]);
        end
    endfunction
    function signed [31:0] rounded_q24;
        input signed [63:0] value;
        begin rounded_q24=value<0 ? -((-value+64'sd8388608)>>>24) : ((value+64'sd8388608)>>>24);end
    endfunction
    function signed [31:0] clamp32;
        input signed [63:0] value;
        begin
            if(value>64'sd2147483647)clamp32=32'sh7fffffff;
            else if(value< -64'sd2147483648)clamp32=32'sh80000000;
            else clamp32=value[31:0];
        end
    endfunction

    // Actual speed is encoder POSITION change /50ms followed by alpha=1/2 IIR (confirmed latest running firmware).
    // This legacy estimate is kept for arrival labels; UART W uses a separate raw-encoder estimator. No PID feedback uses this estimate.
    // Capture restarts both the measurement window and the filter pipeline.
    reg [5:0] speed_count;
    reg signed [31:0] previous_position;
    reg [2:0] speed_math;
    reg signed [32:0] actual_delta_latched,actual_filter_error;
    reg signed [63:0] actual_product;
    reg signed [31:0] actual_raw,actual_filter_increment;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            speed_count<=0;previous_position<=0;actual_speed_q8<=0;speed_math<=0;
            actual_delta_latched<=0;actual_product<=0;actual_raw<=0;actual_filter_error<=0;actual_filter_increment<=0;
        end else if(capture_event)begin speed_count<=0;previous_position<=position;actual_speed_q8<=0;speed_math<=0;end
        else begin
            case(speed_math)
                1:begin actual_product<=actual_delta_latched*64'sd5120;speed_math<=2;end
                2:begin actual_raw<=clamp32(actual_product);speed_math<=3;end
                3:begin actual_filter_error<=$signed({actual_raw[31],actual_raw})-$signed({actual_speed_q8[31],actual_speed_q8});speed_math<=4;end
                4:begin actual_filter_increment<=actual_filter_error>>>1;speed_math<=5;end
                5:begin actual_speed_q8<=actual_speed_q8+actual_filter_increment;speed_math<=0;end
                default:begin end
            endcase
            if(tick_ms)begin
                if(speed_count==49)begin
                    speed_count<=0;previous_position<=position;
                    actual_delta_latched<=$signed({position[31],position})-$signed({previous_position[31],previous_position});speed_math<=1;
                end else speed_count<=speed_count+1'b1;
            end
        end
    end
    wire signed [32:0] position_error=$signed({position[31],position})-$signed({goal_position[31],goal_position});
    wire signed [12:0] angle_error=$signed({1'b0,angle})-$signed({1'b0,center});
    wire in_arrival_window=(position_error>= -ARRIVE_POSITION_UNITS && position_error<=ARRIVE_POSITION_UNITS) &&
        ($signed(actual_speed_q8)>= -(ARRIVE_SPEED_UNITS_S*256) && $signed(actual_speed_q8)<=ARRIVE_SPEED_UNITS_S*256) &&
        (angle_error>= -ARRIVE_ANGLE_ADC && angle_error<=ARRIVE_ANGLE_ADC);

    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            target_update<=0;target_value<=0;edit_deci<=0;goal_deci<=0;
            home_position<=0;reference_position<=0;reference_speed_q8<=0;
            task_state<=NO_HOME;step_index<=1;anchor_valid<=0;interrupted<=0;task_id<=0;duration_ms<=0;
            engine_state<=IDLE;div_start<=0;abort_engine<=0;div_numerator<=0;div_denominator<=1;
            goal_negative<=0;duration_ready<=0;shape_is_cancel<=0;start_position<=0;goal_position<=0;move_delta<=0;
            edit_magnitude<=0;quant_product<=0;quant_rounded<=0;move_magnitude<=0;
            quantized_offset_latched<=0;absolute_goal_latched<=0;
            duration_degrees_product<=0;duration_scaled_product<=0;duration_rounded<=0;progress_next_latched<=0;
            progress_q16<=0;working_rate<=0;cancel_elapsed<=0;arrive_count<=0;shape_phase<=0;
            lut_f0<=0;lut_f1<=0;lut_d0<=0;lut_d1<=0;fraction<=0;shape_value<=0;shape_derivative<=0;
            position_product<=0;speed_product1<=0;speed_product2<=0;pending_position<=0;pending_speed<=0;pending_finish<=0;
            f_difference<=0;f_interpolation_product<=0;derivative_difference<=0;d_interpolation_product<=0;
            position_negative<=0;position_magnitude<=0;position_rounded<=0;position_offset<=0;
            speed_low_product<=0;speed_high_product<=0;speed_scaled_a<=0;speed_numerator<=0;speed_dividend<=0;speed_rounded<=0;
        end else begin
            target_update<=0;div_start<=0;abort_engine<=0;
            // An explicit human stop always wins, even on a capture edge.
            // Capture otherwise wins over the old lock dropping during handoff.
            if(stop_event)begin
                if(anchor_valid && (task_state==MOVING || task_state==SETTLING || task_state==ARRIVED || task_state==DECELERATING))begin
                    interrupted<=1;task_state<=INTERRUPTED;
                end else task_state<=NO_HOME;
                anchor_valid<=0;reference_speed_q8<=0;engine_state<=IDLE;duration_ready<=0;
                progress_q16<=0;working_rate<=0;arrive_count<=0;
            end else if(capture_event || reference_adopt_event)begin
                anchor_valid<=1;home_position<=incoming_reference;reference_position<=incoming_reference;target_value<=incoming_reference;
                edit_deci<=0;goal_deci<=0;reference_speed_q8<=0;step_index<=1;duration_ms<=0;
                start_position<=incoming_reference;goal_position<=incoming_reference;move_delta<=0;
                engine_state<=IDLE;duration_ready<=0;progress_q16<=0;working_rate<=0;cancel_elapsed<=0;arrive_count<=0;
                task_state<=position_mode ? HOLD : RESERVED;
                // Keep an interruption visible until the next accepted NEW task.
            end else if(anchor_valid && !lock_valid)begin
                if(anchor_valid && (task_state==MOVING || task_state==SETTLING || task_state==ARRIVED || task_state==DECELERATING))begin
                    interrupted<=1;task_state<=INTERRUPTED;
                end else task_state<=NO_HOME;
                anchor_valid<=0;reference_speed_q8<=0;engine_state<=IDLE;duration_ready<=0;
                progress_q16<=0;working_rate<=0;arrive_count<=0;
            end else if(anchor_valid)begin
                if(can_edit)begin
                    if(step_event)step_index<=step_index==2 ? 0 : step_index+1'b1;
                    if(edit_plus && !edit_minus)edit_deci<=plus_edit>33'sd2147483647 ? 32'sh7fffffff : plus_edit[31:0];
                    else if(edit_minus && !edit_plus)edit_deci<=minus_edit< -33'sd2147483648 ? 32'sh80000000 : minus_edit[31:0];
                    if(accept_confirm)begin
                        goal_deci<=edit_deci;task_id<=task_id+1'b1;interrupted<=0;task_state<=MOVING;
                        // Latch the REAL new origin once. Leave the old reference
                        // and PID state alone so residual error cannot cause a
                        // sudden setpoint step at the command boundary.
                        home_position<=position;edit_deci<=0;
                        goal_negative<=edit_deci[31];edit_magnitude<=abs32(edit_deci);engine_state<=QUANT_MULT;
                        duration_ready<=0;progress_q16<=0;working_rate<=65536;cancel_elapsed<=0;arrive_count<=0;
                    end
                end

                case(engine_state)
                    QUANT_MULT:begin quant_product<=edit_magnitude*64'd408;engine_state<=QUANT_ROUND;end
                    QUANT_ROUND:begin quant_rounded<=quant_product+64'd1800;engine_state<=QUANT_START;end
                    QUANT_START:begin div_numerator<={32'd0,quant_rounded};div_denominator<=3600;div_start<=1;engine_state<=WAIT_QUANT;end
                    WAIT_QUANT:if(div_done)begin
                        quantized_offset_latched<=goal_negative ? -$signed(div_quotient[63:0]) : $signed(div_quotient[63:0]);engine_state<=GOAL_ADD;
                    end
                    GOAL_ADD:begin absolute_goal_latched<=$signed(home_position)+quantized_offset_latched;engine_state<=GOAL_STORE;end
                    GOAL_STORE:begin goal_position<=clamp32(absolute_goal_latched);start_position<=reference_position;engine_state<=DELTA_STORE;end
                    DELTA_STORE:begin move_delta<=$signed({goal_position[31],goal_position})-$signed({reference_position[31],reference_position});engine_state<=PLAN_DURATION;end
                    PLAN_DURATION:begin
                        if(move_delta==0)begin
                            duration_ms<=0;reference_speed_q8<=0;duration_ready<=0;task_state<=SETTLING;engine_state<=IDLE;
                        end else begin
                            move_magnitude<=abs33(move_delta);engine_state<=DURATION_MUL360;
                        end
                    end
                    DURATION_MUL360:begin duration_degrees_product<=move_magnitude*64'd360;engine_state<=DURATION_SCALE;end
                    DURATION_SCALE:begin duration_scaled_product<=duration_degrees_product*MS_PER_DEG;engine_state<=DURATION_ROUND;end
                    DURATION_ROUND:begin duration_rounded<=duration_scaled_product+64'd204;engine_state<=DURATION_START;end
                    DURATION_START:begin div_numerator<=duration_rounded;div_denominator<=408;div_start<=1;engine_state<=WAIT_DURATION;end
                    WAIT_DURATION:if(div_done)begin
                        duration_ms<=MIN_MOVE_MS+div_quotient[63:0];duration_ready<=1;engine_state<=IDLE;
                    end
                    WAIT_CANCEL:if(div_done)begin shape_phase<=div_quotient[32:0];shape_is_cancel<=1;engine_state<=LOOKUP;end
                    WAIT_PHASE:if(div_done)begin shape_phase<=div_quotient[32:0];shape_is_cancel<=0;engine_state<=LOOKUP;end
                    LOOKUP:begin
                        lut_f0<=rom_f0;lut_f1<=rom_f1;lut_d0<=rom_d0;lut_d1<=rom_d1;
                        fraction<=shape_phase[32] ? 16'd0 : shape_phase[23:8];engine_state<=INTERPOLATE;
                    end
                    INTERPOLATE:begin
                        f_difference<=lut_f1-lut_f0;derivative_difference<=$signed({1'b0,lut_d1})-$signed({1'b0,lut_d0});engine_state<=INTERP_PRODUCTS;
                    end
                    INTERP_PRODUCTS:begin
                        f_interpolation_product<=f_difference*fraction;d_interpolation_product<=derivative_difference*$signed({1'b0,fraction});engine_state<=INTERP_SUM;
                    end
                    INTERP_SUM:begin
                        shape_value<=lut_f0+(f_interpolation_product>>16);shape_derivative<=d_interpolated[17:0];engine_state<=SHAPE_READY;
                    end
                    SHAPE_READY:begin
                        if(shape_is_cancel)begin working_rate<=17'd65536-(shape_value>>8);engine_state<=ADVANCE;end
                        else engine_state<=POSITION_PRODUCT;
                    end
                    ADVANCE:begin
                        progress_next_latched<=progress_q16+working_rate;engine_state<=ADVANCE_TEST;
                    end
                    ADVANCE_TEST:begin
                        if(progress_next_latched>=total_progress_q16)begin
                            progress_q16<=total_progress_q16;pending_position<=goal_position;pending_speed<=0;
                            pending_finish<=task_state==DECELERATING ? 2 : 1;engine_state<=PUBLISH;
                        end else if(working_rate==0)begin
                            pending_position<=reference_position;pending_speed<=0;pending_finish<=2;engine_state<=PUBLISH;
                        end else begin
                            progress_q16<=progress_next_latched;engine_state<=ADVANCE_START;
                        end
                    end
                    ADVANCE_START:begin div_numerator<=progress_q16<<16;div_denominator<=duration_ms;div_start<=1;engine_state<=WAIT_PHASE;end
                    POSITION_PRODUCT:begin
                        position_product<=$signed(move_delta)*$signed({1'b0,shape_value});
                        speed_product1<=move_magnitude*shape_derivative;engine_state<=POSITION_MAGNITUDE;
                    end
                    POSITION_MAGNITUDE:begin position_negative<=position_product[63];position_magnitude<=position_product<0 ? -position_product : position_product;engine_state<=POSITION_ROUND;end
                    POSITION_ROUND:begin position_rounded<=position_magnitude+64'd8388608;engine_state<=POSITION_SIGN;end
                    POSITION_SIGN:begin position_offset<=position_negative ? -$signed({24'd0,position_rounded[63:24]}) : $signed({24'd0,position_rounded[63:24]});engine_state<=POSITION_ADD;end
                    POSITION_ADD:begin pending_position<=clamp32($signed(start_position)+position_offset);engine_state<=SPEED_PRODUCT;end
                    SPEED_PRODUCT:begin
                        speed_low_product<=speed_product1[31:0]*working_rate;speed_high_product<=speed_product1[63:32]*working_rate;engine_state<=SPEED_COMBINE;
                    end
                    SPEED_COMBINE:begin speed_product2<={15'd0,speed_high_product,32'd0}+{47'd0,speed_low_product};engine_state<=SPEED_SCALE_A;end
                    SPEED_SCALE_A:begin speed_scaled_a<=(speed_product2<<10)-(speed_product2<<4);engine_state<=SPEED_SCALE_B;end
                    SPEED_SCALE_B:begin speed_numerator<=speed_scaled_a-(speed_product2<<3);engine_state<=START_SPEED_DIV;end
                    START_SPEED_DIV:begin div_numerator<=speed_numerator;div_denominator<=duration_ms;div_start<=1;engine_state<=WAIT_SPEED;end
                    WAIT_SPEED:if(div_done)begin
                        speed_dividend<=div_quotient;engine_state<=SPEED_ROUND;
                    end
                    SPEED_ROUND:begin speed_rounded<=speed_dividend+64'd8388608;engine_state<=SPEED_SIGN;end
                    SPEED_SIGN:begin pending_speed<=clamp_speed(speed_rounded>>24,move_delta[32]);pending_finish<=0;engine_state<=PUBLISH;end
                    CANCEL_START:begin div_numerator<={cancel_elapsed,32'd0};div_denominator<=CANCEL_MS;div_start<=1;engine_state<=WAIT_CANCEL;end
                    PUBLISH:if(balance_ready)begin
                        reference_position<=pending_position;target_value<=pending_position;target_update<=1;
                        reference_speed_q8<=pending_speed;engine_state<=IDLE;
                        if(pending_finish==1)begin
                            task_state<=(task_state==DECELERATING || !position_mode) ?
                                (position_mode ? HOLD : RESERVED) : SETTLING;
                            duration_ready<=0;arrive_count<=0;
                        end
                        else if(pending_finish==2)begin task_state<=position_mode ? HOLD : RESERVED;duration_ready<=0;arrive_count<=0;end
                    end
                    default:begin end
                endcase

                if(tick_ms && balance_ready && engine_state==IDLE && duration_ready &&
                   (task_state==MOVING || task_state==DECELERATING))begin
                    if(task_state==DECELERATING)begin
                        cancel_elapsed<=cancel_elapsed+1'b1;
                        engine_state<=CANCEL_START;
                    end else begin working_rate<=65536;engine_state<=ADVANCE;end
                end

                if(task_state==MOVING && !position_mode)begin
                    interrupted<=1;arrive_count<=0;
                    // A completed endpoint publish has precedence over requesting
                    // deceleration: there is no remaining timed job to decelerate.
                    if(engine_state==PUBLISH && pending_finish!=0)begin
                        task_state<=RESERVED;duration_ready<=0;reference_speed_q8<=0;
                    end else if(!duration_ready || progress_q16==0)begin
                        task_state<=RESERVED;duration_ready<=0;engine_state<=IDLE;abort_engine<=1;reference_speed_q8<=0;
                    end else begin task_state<=DECELERATING;cancel_elapsed<=0;end
                end else if((task_state==HOLD || task_state==SETTLING || task_state==ARRIVED) && !position_mode)begin
                    if(task_state==SETTLING)interrupted<=1;
                    task_state<=RESERVED;arrive_count<=0;
                end else if(task_state==RESERVED && position_mode && balance_ready)task_state<=HOLD;

                // A label only: neither arrival nor leaving this window stops PID.
                if(tick_ms && balance_ready && position_mode && !accept_confirm &&
                   (task_state==SETTLING || task_state==ARRIVED))begin
                    if(in_arrival_window)begin
                        if(ARRIVE_HOLD_MS<=1 || arrive_count>=ARRIVE_HOLD_MS-1)begin task_state<=ARRIVED;arrive_count<=ARRIVE_HOLD_MS;end
                        else arrive_count<=arrive_count+1'b1;
                    end else begin arrive_count<=0;task_state<=SETTLING;end
                end
            end
        end
    end
endmodule

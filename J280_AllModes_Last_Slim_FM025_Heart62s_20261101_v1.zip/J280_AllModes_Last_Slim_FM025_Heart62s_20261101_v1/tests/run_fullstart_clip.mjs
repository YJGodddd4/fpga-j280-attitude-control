// Independent full-stroke startup tests at both signed32 coordinate boundaries.
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'..');
const {simulate}=await import('./local_verilog_runtime.mjs');
const sources=['tests/tb_fullstart_clip.sv','rtl/trajectory_task.v','rtl/trajectory_tables.v','rtl/position_serial_div.v'];
const paths=[...sources,'rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem'];
const files=await Promise.all(paths.map(async path=>({path,data:await readFile(resolve(root,path),'utf8')})));
const sourceSha256=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
let passed=true;
for(const name of ['positive_max','negative_min']){
 const r=await simulate({files,sources,top:'tb_fullstart_clip_'+name,generation:'2012',timeoutMs:180000});
 const match=r.stdout.match(new RegExp('ALL PASS fullstart clip case='+name+' assertions=(\\d+) publications=(\\d+) clipped=(\\d+) restored=(\\d+) returns=(\\d+)'));
 const success=Boolean(r.success&&match);
 const report={success,case:name,stage:r.stage,exitCode:r.exitCode,sourceSha256,stdout:r.stdout,stderr:r.stderr,
  assertions:match?Number(match[1]):null,publications:match?Number(match[2]):null,clipped:match?Number(match[3]):null,restored:match?Number(match[4]):null,returns:match?Number(match[5]):null,
  runner_sha256:createHash('sha256').update(await readFile(fileURLToPath(import.meta.url))).digest('hex'),
  scope:'Actual generated-ROM trajectory RTL. Independent seven-stage continuous integration with longint64 origin-plus-displacement sums. Origin2147483547 with+90half and origin-2147483548 with-90half; first full180stroke,clamped midpoint/endpoints,no signed wrap,zero derivatives and invalid flags during clipping,recovery and exactreturn,7secondcycle.300FPGAclocks/logicalms.No mechanical plant or hardware.'};
 await writeFile(resolve(here,'fullstart_clip_'+name+'_result.json'),JSON.stringify(report,null,2),'utf8');
 await writeFile(resolve(here,'fullstart_clip_'+name+'_test.log'),r.combinedOutput,'utf8');
 process.stdout.write(JSON.stringify({case:name,success,assertions:report.assertions,publications:report.publications,clipped:report.clipped,restored:report.restored,returns:report.returns})+'\n');
 if(!success)process.stderr.write(r.combinedOutput);passed&&=success;
}
if(!passed)process.exitCode=1;

module tb_amfm_editor;
reg clk=0;always #10 clk=~clk;
reg rst_n=0,enable=1,valid=1;
reg [1:0] mode=1;
reg minus=0,plus=0,step=0;
wire signed [31:0] request,a,b,c;wire [1:0] size;
trajectory_editor dut(.clk(clk),.rst_n(rst_n),.edit_enable(enable),
.selected_mode(mode),.selection_valid(valid),.minus_event(minus),.plus_event(plus),
.step_event(step),.requested_deci(request),.trapezoid_deci(a),.scurve_deci(b),
.sine_deci(c),.step_index(size));
integer n=0;
task check(input ok,input [511:0] message);
begin n=n+1;if(ok!==1)$fatal(1,"%0s",message);end endtask
task press(input integer which);
begin @(negedge clk);minus=which==0;plus=which==1;step=which==2;
@(negedge clk);minus=0;plus=0;step=0;repeat(2)@(negedge clk);end endtask
initial begin
repeat(4)@(negedge clk);rst_n=1;repeat(3)@(negedge clk);
check(a==300 && b==300 && c==900,"new AM/FM defaults30, ordinary sine remains90");
check(request==300 && size==2,"default editor selection and10deg step");
press(1);check(a==400 && b==300 && c==900,"AM edit only changes AM request");
mode=2;repeat(2)@(negedge clk);press(0);press(0);press(0);press(0);
check(b==-100 && a==400 && c==900,"FM can cross zero and retain independent pending request");
mode=3;repeat(2)@(negedge clk);check(request==900,"ordinary sine default preserved");
press(1);check(c==1000 && a==400 && b==-100,"ordinary sine edit semantics preserved");
mode=0;repeat(2)@(negedge clk);press(1);press(2);
check(request==0 && c==1000 && size==2,"00 neither edits trajectory requests nor step");
mode=1;valid=0;press(1);check(a==400,"invalid DIP must not edit");
valid=1;enable=0;press(0);check(a==400,"disabled editor must not edit");
enable=1;press(2);check(size==0,"10deg to0.1deg step");
press(0);check(a==399,"0.1degree pending edit retained");
press(2);press(1);check(size==1 && a==409,"1degree step");
press(2);check(size==2,"cycle back10degree");
@(negedge clk);plus=1;minus=1;
@(negedge clk);plus=0;minus=0;repeat(2)@(negedge clk);
check(a==409,"simultaneous + and - do not alter requested amplitude");
@(negedge clk);dut.trapezoid_deci=32'sh7ffffffe;press(1);
check(a==32'sh7fffffff,"signed32 positive request saturates numerically");
@(negedge clk);dut.trapezoid_deci=32'sh80000001;press(0);
check(a==32'sh80000000,"signed32 negative request saturates numerically");
rst_n=0;repeat(3)@(negedge clk);rst_n=1;repeat(2)@(negedge clk);
check(a==300 && b==300 && c==900 && size==2,"reset restores only new AM/FM defaults");
$display("ALL PASS AMFM editor: %0d checks",n);$finish;
end
endmodule

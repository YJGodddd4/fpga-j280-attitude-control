"""Offline regression for Z8601 / fast W. Never opens any serial port."""
from pathlib import Path
import sys,unittest,csv,tempfile,time,json,io
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'monitor'))
from feedforward_protocol import *
from unified_protocol import *
from unified_monitor import UnifiedMonitor
from test_unified_runtime import wire_v2
import tkinter as tk

Z='Z=8601 T=000003E8 Q=0000000A CF=B5FBC6B6 KA=00004000 PD=000002BC FF=FFFFFF00 TT=0000001BC LO=000001BC AC=FFFFFC00 EN=1 SV=1 LM=0\r\n'
def zline(**values):
    out=[]
    for token in Z.strip().split():
        key,raw=token.split('=')
        if key in values:raw=f'{values[key]&((1<<(len(raw)*4))-1):0{len(raw)}X}'
        out.append(key+'='+raw)
    return (' '.join(out)+'\r\n').encode()
class Protocol(unittest.TestCase):
    def test_literal_length_signed_fields_and_names(self):
        self.assertEqual(len(Z),130);self.assertEqual(DIAGNOSTIC_LENGTH,128)
        f=decode_feedforward(Z)
        self.assertEqual((f.gain_q16,f.gain,f.pd10,f.feedforward10,f.total10,f.location_out10,f.acceleration_q8),(16384,.25,700,-256,444,444,-1024))
        self.assertIn('最近一次50ms',diagnostic_summary(f))
        self.assertIn('当前规划输入可用',diagnostic_summary(f))
    def test_negative_extrema_and_sign_extension(self):
        f=decode_feedforward(zline(KA=-2147483648,PD=-2147483648,FF=2147483647,TT=-4294967296,LO=-1000,AC=-2147483648))
        self.assertEqual((f.gain_q16,f.pd10,f.feedforward10,f.total10,f.location_out10),(-2147483648,-2147483648,2147483647,-4294967296,-1000))
        self.assertEqual(decode_feedforward(zline(TT=4294967295)).total10,4294967295)
        self.assertIn('关闭',diagnostic_summary(decode_feedforward(zline(KA=0,EN=0))))
    def test_bad_headers_flags_bounds_and_non_ascii(self):
        bad=[zline(SV=2),zline(EN=15),zline(LM=3),zline(LO=1001),zline(LO=-1001),
             zline(TT=4294967296),zline(TT=-4294967297),zline().replace(b'8601',b'8602'),zline().replace(b'00004000',b'ZZZZZZZZ'),b'\xff']
        for item in bad:
            with self.subTest(item=item),self.assertRaises(ValueError):decode_feedforward(item)
    def test_mixed_packet_chunks_preserve_atomic_X(self):
        stream=wire_v2(CF=0xB5FBC6B6)+zline()+wire_v2(CF=0xB10F9791,Q=11)
        for size in (1,2,3,7,15,31,64,129,130,511,512,8192):
            d=UnifiedStreamDecoder();out=[]
            for i in range(0,len(stream),size):out.extend(d.feed(stream[i:i+size]))
            self.assertEqual([p.kind for p in out],['X','Z','X'])
            self.assertEqual(out[1].frame.feedforward10,-256)
            self.assertEqual((d.diagnostic_count,d.invalid_diagnostic,d.legacy_count,d.invalid_x),(1,0,0,0))
    def test_corrupt_diag_and_partial_resync_never_fakes_X(self):
        for bad in [zline(LO=1001),zline()[:35]+b'\r\n',zline().replace(b' EN=1',b' EN=F')]:
            d=UnifiedStreamDecoder();out=d.feed(bad+wire_v2()+zline())
            self.assertEqual([p.kind for p in out],['X','Z'])
            self.assertGreaterEqual(d.invalid_diagnostic,1);self.assertEqual(d.invalid_x,0)
    def test_unterminated_diag_cannot_consume_next_X(self):
        d=UnifiedStreamDecoder()
        out=d.feed(zline()[:-2]+wire_v2()+zline())
        self.assertEqual([p.kind for p in out],['X','Z']);self.assertEqual(d.invalid_diagnostic,1)
    def test_X_and_Z_match_only_exact_identity(self):
        f=decode_unified(wire_v2(CF=0xB5FBC6B6))
        # Literal wire_v2's T/Q differ; align known identity deliberately.
        d=decode_feedforward(zline(T=f.uptime_ms,Q=f.snapshot_sequence))
        self.assertTrue(d.matches(f))
        for values in ({'T':f.uptime_ms+1},{'Q':f.snapshot_sequence+1},{'CF':0}):
            self.assertFalse(decode_feedforward(zline(**({'T':f.uptime_ms,'Q':f.snapshot_sequence}|values))).matches(f))
    def test_version_specific_speed_description(self):
        self.assertIn('10ms',speed_description(0xB5FBC6B6))
        for tag in [0xB10F9791,0,0xffffffff]:
            self.assertIn('未遥测',speed_description(tag))
            self.assertNotIn('10ms',speed_description(tag))
    def test_Z_independent_CSV_and_close(self):
        with tempfile.TemporaryDirectory() as path:
            rec=UnifiedRecorder(path,'FAKE');h=UnifiedHistory()
            f=decode_unified(wire_v2());rec.append(f,1,1,h.append(f,1,1))
            self.assertFalse(rec.diagnostic_path.exists())
            rec.append_diagnostic(decode_feedforward(zline()),1.01,1);rec.close();rec.close()
            rows=list(csv.DictReader(rec.diagnostic_path.open(encoding='utf-8-sig')))
            self.assertEqual(len(rows),1);self.assertEqual(rows[0]['feedforward10'],'-256')
            self.assertEqual(rows[0]['total10'],'444');self.assertEqual(rows[0]['diagnostic_version'],'8601')
            xs=list(csv.DictReader(rec.csv_path.open(encoding='utf-8-sig')))
            self.assertEqual(len(xs),1);self.assertNotIn('gain_q16',xs[0])
            with self.assertRaises(OSError):rec.append_diagnostic(decode_feedforward(zline()),2,1)
    def test_real_RTL_fixture(self):
        path=R/'tests/ffmonitor_z_fixture.txt'
        if not path.exists():self.skipTest('RTL fixture generation pending')
        z=decode_feedforward(path.read_bytes());x=decode_unified((R/'tests/ffmonitor_x_fixture.txt').read_bytes())
        self.assertTrue(z.matches(x));self.assertEqual(z.gain_q16,16384)
        self.assertEqual((z.pd10,z.feedforward10,z.total10,z.location_out10),(700,-256,444,444))
class GUI(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw();self.app=UnifiedMonitor(self.root,mode='replay',create_worker=False);self.root.update_idletasks()
    def tearDown(self):
        for token in self.root.tk.splitlist(self.root.tk.call('after','info')):self.root.after_cancel(token)
        self.app.close()
    def test_CF_switch_and_diagnostic_independence(self):
        app=self.app;f=decode_unified(wire_v2(CF=0xB5FBC6B6))
        app.process_frame(f,1,record=False)
        self.assertIn('10ms',app.speed_plot.unit);self.assertIn('旧速度仅用于00',app.position_var.get())
        self.assertEqual(app.valid,1)
        d=decode_feedforward(zline(T=f.uptime_ms,Q=f.snapshot_sequence))
        app.process_diagnostic(d,1.01,record=False);self.assertEqual(app.valid,1)
        self.assertIn('同一发送快照',app.ff_var.get());self.assertIn('+0.250000',app.ff_var.get())
        app.process_frame(decode_unified(wire_v2(CF=0xB10F9791,Q=11)),1.1,record=False);app.refresh_diagnostic()
        self.assertIn('未遥测',app.speed_plot.unit);self.assertIn('当前未与X配对',app.ff_var.get())
        self.assertIsNone(app.worker)
    def test_no_diag_never_infers_enable_from_CF(self):
        self.app.process_frame(decode_unified(wire_v2(CF=0xB5FBC6B6)),1,record=False)
        self.app.refresh_diagnostic()
        self.assertIn('未收到独立Z=8601',self.app.ff_var.get())
    def test_replay_optional_sidecar_and_preserve_files(self):
        with tempfile.TemporaryDirectory() as path:
            rec=UnifiedRecorder(path,'FAKE');h=UnifiedHistory()
            f=decode_unified(wire_v2(CF=0xB5FBC6B6))
            rec.append(f,1,1,h.append(f,1,1));rec.append_diagnostic(decode_feedforward(zline(T=f.uptime_ms,Q=f.snapshot_sequence)),1.01,1);rec.close()
            before={p:p.read_bytes() for p in Path(path).iterdir()}
            self.app.load_replay(rec.csv_path)
            self.assertIn('+0.250000',self.app.ff_var.get())
            self.assertIsNone(self.app.worker);self.assertIsNone(self.app.recorder)
            for p,b in before.items():self.assertEqual(p.read_bytes(),b)
    def test_stale_diag_and_connection_mismatch(self):
        f=decode_unified(wire_v2(CF=0xB5FBC6B6));a=self.app
        a.process_frame(f,1,record=False);a.mode='live';a.connected=True
        a.process_diagnostic(decode_feedforward(zline(T=f.uptime_ms,Q=f.snapshot_sequence)),1,at=time.monotonic()-2,record=False)
        self.assertIn('历史',a.ff_var.get());a.connection_segment+=1;a.refresh_diagnostic()
        self.assertIn('当前未与X配对',a.ff_var.get())
    def test_real_Tk_layout_all_tabs_no_serial(self):
        a=self.app;self.root.deiconify();self.root.geometry('1280x880')
        f=decode_unified(wire_v2(CF=0xB5FBC6B6,D=2,J=2,O=1,N=2,PH=2,CL=30000,TM=1,TA=900))
        a.process_frame(f,1,record=False);a.process_diagnostic(decode_feedforward(zline(T=f.uptime_ms,Q=f.snapshot_sequence)),1,record=False)
        for page in a.pages.values():
            a.notebook.select(page);self.root.update();a.redraw();self.root.update()
        self.assertEqual(len(a.plots),8);self.assertTrue(all(p.canvas.find_all() for p in a.plots));self.assertIsNone(a.worker)
        self.assertTrue(a.ff_var.get())
if __name__=='__main__':
    buf=io.StringIO();suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result=unittest.TextTestRunner(stream=buf,verbosity=2).run(suite)
    report={'success':result.wasSuccessful(),'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'output':buf.getvalue(),'scope':'Offline parser, framing, CSV, exact T/Q/CF association, old-CF semantics, optional diagnostic replay, real Tk 8-plot layout; no serial opened'}
    (R/'tests/ffmonitor_host_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(buf.getvalue());sys.exit(0 if result.wasSuccessful() else 1)

import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';import{fileURLToPath,pathToFileURL}from'node:url';import{createHash}from'node:crypto';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const runtime=process.env.J280_VERILOG_RUNTIME||process.argv[2];
const {simulate}=runtime?await import(pathToFileURL(runtime).href):await import('./local_verilog_runtime.mjs');
const sources=['tests/amfm_limits.sv','rtl/trajectory_task.v','rtl/trajectory_tables.v','rtl/position_serial_div.v'];
const paths=[...sources,'rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem'];
const files=await Promise.all(paths.map(async p=>({path:p,data:await readFile(resolve(root,p),'utf8')})));
const source_sha256={};for(const p of [...paths,'tests/amfm_limits.mjs'])source_sha256[p]=createHash('sha256').update(await readFile(resolve(root,p))).digest('hex');
const r=await simulate({files,sources,top:'tb_amfm_limits',generation:'2012',timeoutMs:60000});
const m=r.stdout?.match(/ALL PASS amfm limits assertions=(\d+) publications=(\d+)/);
const report={success:Boolean(r.success&&r.exitCode===0&&m),assertions:m?+m[1]:null,publications:m?+m[2]:null,
source_sha256,stdout:r.stdout,stderr:r.stderr,hardware_tested:false,scope:'Actual AM/FM RTL at signed32 maximum/minimum requested degrees; declared numeric cap accepted symmetrically, fixed periods/TM1, bounded accepted amplitude with valid derivatives, every published q/v/a/j exactly odd symmetric, full sample stream and immediate explicitstop. All-phase arithmetic no-wrap bounds independently checked in amfm_numeric_check_result.json.'};
await writeFile(resolve(root,'tests/amfm_limits_result.json'),JSON.stringify(report,null,2));
await writeFile(resolve(root,'tests/amfm_limits_test.log'),r.combinedOutput||r.stdout+'\n'+r.stderr);console.log(r.combinedOutput||r.stdout);
if(!report.success)process.exitCode=1;

// [FAST_AB_10S修改] SetJ280_SIM_DEBUG_ACC=1 for full debug access; default optimized native simulation.
// Portable simulator adapter; all native child windows remain hidden.
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdir, mkdtemp, writeFile, readFile, unlink, rmdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve, basename } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
const here = dirname(fileURLToPath(import.meta.url));

function executable(name) {
  const explicit = process.env.J280_QUESTA_BIN;
  if (explicit) {
    const value = join(explicit, name + (process.platform === 'win32' ? '.exe' : ''));
    if (!existsSync(value)) throw new Error('Missing simulator executable: ' + value);
    return value;
  }
  const candidates = process.platform === 'win32' ? [
    `D:/questa/win64/${name}.exe`,
    `D:/Questa_altera/questa_fse/win64/${name}.exe`,
    `D:/intelFPGA/questa_fse/win64/${name}.exe`
  ] : [];
  for (const path of candidates) if (existsSync(path)) return path;
  return name;
}

function launch(program, args, cwd, timeoutMs) {
  return new Promise(resolveResult => {
    const started = performance.now();
    let stdout = '', stderr = '', timedOut = false, spawnError = null;
    const child = spawn(program, args, {cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe']});
    const timer = setTimeout(() => { timedOut = true; child.kill(); }, timeoutMs);
    child.stdout.on('data', chunk => { stdout += chunk.toString(); });
    child.stderr.on('data', chunk => { stderr += chunk.toString(); });
    child.on('error', error => { spawnError = error; });
    child.on('close', code => {
      clearTimeout(timer);
      if (spawnError) stderr += '\n' + String(spawnError);
      if (timedOut) stderr += '\nSimulation subprocess timeout.';
      resolveResult({exitCode: code ?? -1, stdout, stderr, timedOut, milliseconds: performance.now() - started});
    });
  });
}

async function simulateNative(options) {
  // [SINE90_10S修改] 仍支持用户指定原兼容运行时，但默认不引用他人电脑的路径。
  if (process.env.J280_VERILOG_RUNTIME) {
    const runtime = await import(pathToFileURL(resolve(process.env.J280_VERILOG_RUNTIME)).href);
    return runtime.simulate(options);
  }
  const base = resolve(process.env.J280_SIM_TEMP || join(here, '_sim_temp'));
  await mkdir(base, {recursive: true});
  const directory = await mkdtemp(join(base, options.top + '_'));
  for (const file of options.files) {
    const target = resolve(directory, file.path);
    if (!target.startsWith(directory + (process.platform === "win32" ? "\\" : "/"))) throw new Error("Unsafe simulation file path");
    await mkdir(dirname(target), {recursive:true});
    await writeFile(target, file.data, 'utf8');
  }
  const stages = [
    ['library', executable('vlib'), ['work']],
    ['compile', executable('vlog'), ['-sv', '-work', 'work', ...options.sources]],
    ['simulate', executable('vsim'), ['-c', ...(process.env.J280_SIM_DEBUG_ACC === '1' ? ['-voptargs=+acc'] : []), '-onfinish', 'exit',
       '-do', 'onerror {quit -f -code 2}; run -all; quit -f -code 0', 'work.' + options.top]]
  ];
  let stdout = '', stderr = '', stage = 'library', exitCode = -1;
  const timings = {};
  for (const [name, program, args] of stages) {
    stage = name;
    const result = await launch(program, args, directory, options.timeoutMs || 60000);
    stdout += '\n[' + name + ']\n' + result.stdout;
    stderr += result.stderr;
    exitCode = result.exitCode;
    timings[name] = result.milliseconds;
    if (exitCode !== 0 || result.timedOut || /\*\*\s+(?:Error|Fatal):/i.test(result.stdout + result.stderr)) break;
  }
  // [SINE90_10S修改] 除进程返回值外，要求测试明确完成；$fatal不能被最终quit掩盖。
  const combinedOutput = stdout + (stderr ? '\n[stderr]\n' + stderr : '');
  const success = stage === 'simulate' && exitCode === 0 && /ALL PASS/.test(stdout) &&
    !/\*\*\s+(?:Error|Fatal):/i.test(combinedOutput);
  return {success, stage, exitCode, stdout, stderr, combinedOutput, timings,
          backend: 'Questa native command-line', workDirectory: directory};
}

// [SINE90_10S修改] Questa入门许可证只允许一个仿真会话，跨运行脚本串行排队。
export async function simulate(options) {
  const lock = resolve(process.env.J280_QUESTA_LOCK || join(tmpdir(), 'j280_questa_native.lock'));
  const started = Date.now();
  while (true) {
    try {
      await mkdir(lock);
      await writeFile(join(lock, 'owner.json'), JSON.stringify({pid: process.pid, time: Date.now()}));
      break;
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      try {
        const owner = JSON.parse(await readFile(join(lock, 'owner.json'), 'utf8'));
        try { process.kill(owner.pid, 0); }
        catch (error) { if (error.code === 'ESRCH') { await unlink(join(lock, 'owner.json')).catch(() => {}); await rmdir(lock); continue; } }
      } catch (error) { if (Date.now() - started > 300000) throw new Error('Simulator lock could not be read: ' + lock); }
      if (Date.now() - started > 600000) throw new Error('Timed out waiting for the single Questa license: ' + lock);
      await new Promise(resolveDelay => setTimeout(resolveDelay, 500));
    }
  }
  try { return await simulateNative(options); }
  finally { await unlink(join(lock, 'owner.json')).catch(() => {}); await rmdir(lock); }
}

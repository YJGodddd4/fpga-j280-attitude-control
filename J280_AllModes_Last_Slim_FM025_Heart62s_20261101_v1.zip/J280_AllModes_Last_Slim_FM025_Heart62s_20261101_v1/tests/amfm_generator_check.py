"""Independent spectral-AM and finite-difference FM check; no hardware access."""
from pathlib import Path
import json,math,hashlib,importlib.util
R=Path(__file__).resolve().parents[1]
cfg=json.loads((R/'config/trajectory_profiles.json').read_text(encoding='utf-8'))
spec=importlib.util.spec_from_file_location('amfm_generated',R/'scripts/generate_trajectory_tables.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
checks=0
def ck(x,m):
 global checks
 checks+=1
 assert x,m
scale=cfg['engineering_units_per_turn']/360;dt=cfg['sample_ms']/1000
pa,pf,pc=cfg['am'],cfg['fm'],cfg['sine']
H=pa['amplitude_degrees'];wc=2*math.pi/(pa['carrier_period_ms']/1000)
wm=2*math.pi/(pa['envelope_period_ms']/1000)
def spectral_am(t,k):
 return H*2/3*wc**k*math.sin(wc*t+k*math.pi/2)+sum(H/6*w**k*math.sin(w*t+k*math.pi/2) for w in [wc+wm,wc-wm])
for i in range(pa['envelope_period_ms']//cfg['sample_ms']):
 row=g.am_at(i*dt,pa)
 for k in range(4):ck(abs(row[k]-spectral_am(i*dt,k))<1e-9,'AM spectral derivative mismatch')
ck(abs(wc*pa['envelope_period_ms']/1000-18*math.pi)<1e-10,'AM 9 cycles')
ck(abs(H*(2+math.cos(0))/3-H)<1e-10,'AM maximum envelope')
ck(abs(H*(2+math.cos(math.pi))/3-H/3)<1e-10,'AM minimum envelope')
def fm_position(t):
 f0=pf['min_frequency_hz'];d=pf['max_frequency_hz']-f0
 T=pf['modulation_period_ms']/1000
 # Integrate f=fmin+(fmax-fmin)*sin(pi*t/T)^2 independently.
 phase=2*math.pi*((f0+d/2)*t-d*T/(4*math.pi)*math.sin(2*math.pi*t/T))
 return pf['amplitude_degrees']*math.sin(phase)
max_errors=[0.,0.,0.,0.]
h=.001
for i in range(0,pf['modulation_period_ms']//cfg['sample_ms'],3):
 t=i*dt;row=g.fm_at(t,pf)
 qm2,qm,q0,qp,qp2=[fm_position(t+k*h) for k in [-2,-1,0,1,2]]
 independent=[q0,(qm2-8*qm+8*qp-qp2)/(12*h),(-qp2+16*qp-30*q0+16*qm-qm2)/(12*h*h),
              (qp2-2*qp+2*qm-qm2)/(2*h**3)]
 for k in range(4):
  err=abs(row[k]-independent[k]);max_errors[k]=max(max_errors[k],err)
  ck(err<[1e-10,1e-6,1e-5,.02][k],'FM independent finite difference derivative mismatch')
for t,f in [(0,.1),(15,.5),(30,.1)]:
 ck(abs((.3-.2*math.cos(2*math.pi*t/30))-f)<1e-12,'FM slow-fast-slow frequency')
ck(abs(fm_position(30))<1e-10,'FM full pattern closes')
# Signed integer storage and original11 compatibility.
def s32(x):return x-(1<<32) if x&(1<<31) else x
rows=(R/'rtl/trajectory_tables_ab.mem').read_text(encoding='ascii').splitlines()
ck(len(rows)==6150,'AB line count')
for ix,word in enumerate(rows):
 code=int(word,16);got=[s32((code>>s)&0xffffffff) for s in [96,64,32,0]]
 p=pa if ix<3150 else pf;t=(ix if ix<3150 else ix-3150)*dt
 expected=g.am_at(t,p) if ix<3150 else g.fm_at(t,p)
 for k in range(4):ck(got[k]==g.nearest(expected[k]*scale*(65536 if k==0 else 256)),'ROM signed fixed-point field mismatch')
orig=R/'reference_input/rtl'
oldc=(orig/'trajectory_tables_sine.mem').read_bytes();oldenv=(orig/'trajectory_tables_envelope.mem').read_bytes()
ck((R/'rtl/trajectory_tables_sine.mem').read_bytes()==oldc,'Original C ROM changed')
ck((R/'rtl/trajectory_tables_envelope.mem').read_bytes().startswith(oldenv),'Original C envelope prefix changed')
ck(cfg['sine']==json.loads((R/'reference_input/config/trajectory_profiles.json').read_text(encoding='utf-8-sig'))['sine'],'Original C configuration changed')
limit=json.loads((R/'config/trajectory_validation.json').read_text())
for name in ['am','fm']:
 proof=limit[name+'_numeric_representation_proof'];cap=proof['max_request_deci'];base=limit['runtime_base_deci'][name]
 for n in proof['product_numerator_bounds'][1:]:
  encoded=(n*cap//base+(1<<23))>>24
  ck(encoded<2147483647,'Numeric derivative representation limit unsafe')
 ck(cap>7200,'Numerical range unexpectedly small')
paths=['scripts/generate_trajectory_tables.py','config/trajectory_profiles.json','config/modulated_semantics.json',
       'config/trajectory_validation.json','rtl/trajectory_task.v','rtl/trajectory_tables.v',
       'rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem',
       'tests/amfm_generator_check.py']
report={'success':True,'checks':checks,'fm_finite_difference_max_errors':max_errors,
 'original_sine_rom_bytes_equal':True,'original_sine_envelope_prefix_bytes_equal':True,
 'am_carrier_cycles_per_envelope':9,'fm_carrier_cycles_per_modulation':9,
 'periods_ms':{'am_carrier':3500,'am_envelope':31500,'fm_modulation':30000,'original_sine':7000},
 'source_sha256':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},
 'scope':'Independent AM three-sinusoid spectral derivative identity at all3150 time points; independent FM phase integral plus 5-point finite-difference derivative checks at1000 times; all6150 ROM rows signed-format comparison; original11 byte/config checks; conservative integer numeric representation proof. Not a mechanical plant or hardware test.',
 'hardware_tested':False}
(R/'tests/amfm_generator_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'},ensure_ascii=False,indent=2))

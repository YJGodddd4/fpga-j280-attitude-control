from pathlib import Path
ROOT=Path('C:/Users/wnc06/Documents/Codex/2026-11-01/J280_AllModes_v8_6_Feedforward')
p=ROOT/'monitor/unified_protocol.py'
s=p.read_text(encoding='utf-8-sig')
s=s.replace('from autoswing_protocol import decode_diagnostic','from autoswing_protocol import decode_diagnostic\nfrom feedforward_protocol import decode_feedforward,DIAGNOSTIC_LENGTH,DIAGNOSTIC_FIELDS')
s=s.replace("_HEADER=re.compile(rb'X=800[12] |O=510[123] |A=", "_HEADER=re.compile(rb'X=800[12] |Z=8601 |O=510[123] |A=")
s=s.replace("_STRONG_HEADER=re.compile(rb'X=800[12] |O=510[123] ')", "_STRONG_HEADER=re.compile(rb'X=800[12] |Z=8601 |O=510[123] ')")
s=s.replace('self.invalid_x=0;self.invalid_legacy=0;self.legacy_count=0;self.unsupported_o=0','self.invalid_x=0;self.invalid_legacy=0;self.legacy_count=0;self.unsupported_o=0;self.diagnostic_count=0;self.invalid_diagnostic=0')
s=s.replace("'A':52,'M':27}[kind]","'A':52,'M':27,'Z':DIAGNOSTIC_LENGTH}[kind]")
s=s.replace("_STRONG_HEADER if kind=='X' else _HEADER","_STRONG_HEADER if kind in ('X','Z') else _HEADER")
s=s.replace("if kind=='X':\n                # Version", "if kind in ('X','Z'):\n                # Version")
s=s.replace("'A':decode_frame,'M':decode_diagnostic}[kind](raw)","'A':decode_frame,'M':decode_diagnostic,'Z':decode_feedforward}[kind](raw)")
s=s.replace("if kind=='X' and newline>=0:","if kind in ('X','Z') and newline>=0:")
s=s.replace("result.append(Packet(kind,f));self.legacy_count+=kind!='X';del self.buffer[:length]","result.append(Packet(kind,f));self.legacy_count+=kind not in ('X','Z');self.diagnostic_count+=kind=='Z';del self.buffer[:length]")
s=s.replace("if kind=='X':self.invalid_x+=1\n        else:self.invalid_legacy+=1","if kind=='X':self.invalid_x+=1\n        elif kind=='Z':self.invalid_diagnostic+=1\n        else:self.invalid_legacy+=1")
s=s.replace("self._data=self.csv_path.open('x',encoding='utf-8-sig',newline='')","self.diagnostic_path=self.csv_path.with_name(self.csv_path.name.replace('_unified.csv','_feedforward.csv'));self._diagnostics=None;self.diagnostic_rows=0\n        self._data=self.csv_path.open('x',encoding='utf-8-sig',newline='')")
needle="    def event(self,kind,message,elapsed):\n        if self._closed:raise OSError('Unified recording is closed')"
replace="""    def append_diagnostic(self,f,elapsed,connection_segment):
        if self._closed:raise OSError('Unified recording is closed')
        if self._diagnostics is None:
            self._diagnostics=self.diagnostic_path.open('x',encoding='utf-8-sig',newline='')
            self._diagnostic_writer=csv.writer(self._diagnostics)
            self._diagnostic_writer.writerow(('host_time','elapsed_s','connection_segment','diagnostic_version',
                *(name for _,_,name,_ in DIAGNOSTIC_FIELDS),'raw_line'))
        self._diagnostic_writer.writerow((_host_time(),f'{float(elapsed):.6f}',connection_segment,'8601',
            *(getattr(f,name) for _,_,name,_ in DIAGNOSTIC_FIELDS),f.raw))
        self._diagnostics.flush();self.diagnostic_rows+=1
    def event(self,kind,message,elapsed):
        if self._closed:raise OSError('Unified recording is closed')"""
assert needle in s;s=s.replace(needle,replace)
s=s.replace("for stream in (self._data,self._events):","for stream in (self._data,self._events,self._diagnostics):\n            if stream is None:continue")
p.write_text(s,encoding='utf-8')
p=ROOT/'monitor/unified_monitor.py';s=p.read_text(encoding='utf-8-sig')
s=s.replace("from wave_monitor import Plot,SerialWorker","from wave_monitor import Plot,SerialWorker\nfrom feedforward_protocol import decode_feedforward,speed_description,speed_summary,diagnostic_summary,FAST_SPEED_TAGS")
s=s.replace("self.last_frame=self.last_received_at=None;self.legacy={};self.connection_segment=0","self.last_frame=self.last_received_at=None;self.legacy={};self.connection_segment=0;self.last_ff=None")
s=s.replace("v8.5 AM/FM · 只读 · X8002 / 8001","v8.6 前馈 / 快速测速 · 只读 · X8002 / Z8601")
s=s.replace("self.parameter_var=tk.StringVar();self.legacy_var=tk.StringVar();self.task_var=tk.StringVar()","self.parameter_var=tk.StringVar();self.legacy_var=tk.StringVar();self.task_var=tk.StringVar()\n        self.ff_var=tk.StringVar(value='前馈诊断：等待独立Z=8601；旧版固件没有此帧。')")
s=s.replace("grid=ttk.Frame(position);grid.pack(fill='both',expand=True)","ttk.Label(position,textvariable=self.ff_var,wraplength=1200,justify='left',foreground='#52667d').pack(anchor='w',pady=(0,4))\n        grid=ttk.Frame(position);grid.pack(fill='both',expand=True)")
s=s.replace("'度/s；W含50ms差分及1/4低通的量化与延迟'","'度/s；等待板卡CF确认测速方法'")
s=s.replace("('估算W','#16846c',lambda f:f.actual_speed_degrees)],span=2)","('估算W','#16846c',lambda f:f.actual_speed_degrees)],span=2)\n        self.speed_plot=self.plots[-1]")
s=s.replace("self.finish_recording();self.mode='live';self.history.clear();self.decoder=UnifiedStreamDecoder();self.legacy.clear()","self.finish_recording();self.mode='live';self.history.clear();self.decoder=UnifiedStreamDecoder();self.legacy.clear();self.last_ff=None")
s=s.replace("self.values['balance'].set(label(BALANCE_LABELS,f.balance_mode))","self.speed_plot.unit=speed_description(f.trajectory_config_tag)\n        self.values['balance'].set(label(BALANCE_LABELS,f.balance_mode))")
old="+runtime+('\\n'+modulation_summary(f) if modulation_summary(f) else '')+'\\n00每次确认锁实际位置；轨迹中心运行中固定。W含50ms差分及1/4低通延迟；SW2/SW3编辑下次角度，SW4停止后再启动才执行。')"
new="+runtime+('\\n'+modulation_summary(f) if modulation_summary(f) else '')+'\\n00每次确认锁实际位置；轨迹中心运行中固定。'+speed_summary(f.trajectory_config_tag)+'SW2/SW3编辑下次角度，SW4停止后再启动才执行。')"
assert old in s;s=s.replace(old,new)
s=s.replace("else:self.legacy[p.kind]=(p.frame,at)","elif p.kind=='Z':self.process_diagnostic(p.frame,self.elapsed(at),at)\n        else:self.legacy[p.kind]=(p.frame,at)")
needle="    def poll_events(self):"
new="""    def process_diagnostic(self,f,elapsed,at=None,record=True):
        self.last_ff=(f,time.monotonic() if at is None else at,self.connection_segment)
        if record and self.recorder is not None:
            try:self.recorder.append_diagnostic(f,elapsed,self.connection_segment)
            except OSError as exc:self.record_error(exc)
        self.refresh_diagnostic();self.mark_dirty()
    def refresh_diagnostic(self):
        if self.last_ff is None:
            self.ff_var.set('前馈诊断：未收到独立Z=8601；不能据此判断前馈已启用。')
            return
        d,at,segment=self.last_ff
        fresh=self.mode=='live' and self.connected and time.monotonic()-at<1.2 and segment==self.connection_segment
        paired=self.last_frame is not None and d.matches(self.last_frame) and segment==self.connection_segment
        age='实时' if fresh else '历史／离线'
        pair='与当前X同一发送快照' if paired else '独立快照，当前未与X配对'
        self.ff_var.set(f'Z8601 [{age}；{pair}；Q={d.snapshot_sequence}] '+diagnostic_summary(d))
    def poll_events(self):"""
assert needle in s;s=s.replace(needle,new)
s=s.replace("        legacy=[]\n        for kind", "        self.refresh_diagnostic()\n        legacy=[]\n        for kind")
s=s.replace("' · 连接段{self.connection_segment}')","' · 连接段{self.connection_segment}')") # no-op intentional: next replacement exact
s=s.replace(" · 连接段{self.connection_segment}')"," · 连接段{self.connection_segment} · Z诊断{d.diagnostic_count} / 坏Z{d.invalid_diagnostic}')")
s=s.replace("content=self.parameter_var.get()+'\\n\\n'+self.legacy_var.get()+'\\n\\n'+self.raw_var.get()","content=self.parameter_var.get()+'\\n\\n'+self.ff_var.get()+'\\n\\n'+self.legacy_var.get()+'\\n\\n'+self.raw_var.get()")
s=s.replace("self.finish_recording();self.mode='replay';self.history.clear();self.valid=0;self.paused_at=None;self.legacy.clear()","self.finish_recording();self.mode='replay';self.history.clear();self.valid=0;self.paused_at=None;self.legacy.clear();self.last_ff=None")
s=s.replace("for f,t,segment in frames:self.connection_segment=segment;self.process_frame(f,t,record=False)","""for f,t,segment in frames:self.connection_segment=segment;self.process_frame(f,t,record=False)
        diagnostic_path=Path(path).with_name(Path(path).name.replace('_unified.csv','_feedforward.csv'))
        if diagnostic_path!=Path(path) and diagnostic_path.exists():
            with diagnostic_path.open(encoding='utf-8-sig',newline='') as stream:
                for row in csv.DictReader(stream):
                    if int(row.get('connection_segment') or 0)!=self.connection_segment:continue
                    t=float(row['elapsed_s'])
                    if math.isfinite(t) and t<=frames[-1][1]+.2:
                        self.process_diagnostic(decode_feedforward(row['raw_line']),t,record=False)""")
p.write_text(s,encoding='utf-8')
p=ROOT/'monitor/feedforward_protocol.py';s=p.read_text(encoding='utf-8')
s=s.replace("'已作用于本次外环更新' if d.active else '系数已配置，当前未作用'","'当前规划输入可用' if d.active else '系数已配置，当前规划输入未使能'")
s=s.replace("以上是控制器内部倾角修正，非实测PWM、力矩或P/I/D分项。","PD/FF/LO来自最近一次50ms外环更新；AC是发送快照时的规划量，二者不保证同一采样时刻。非实测PWM或力矩。")
p.write_text(s,encoding='utf-8')
print('host decoder/UI/CSV changes written')

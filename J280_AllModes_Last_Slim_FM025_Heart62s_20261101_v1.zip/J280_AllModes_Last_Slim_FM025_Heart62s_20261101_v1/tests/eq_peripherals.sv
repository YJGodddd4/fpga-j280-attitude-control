`timescale 1ns/1ps
module tb_eq_peripherals;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,enable=0;reg signed [7:0] command=0;
 wire a,b,p,oa,ob,op,tick,otick,tx,busy,otx,obusy,valid,ovalid;
 reg start=0;reg [7:0] data=0;wire [7:0] received,oreceived;
 reg ea=0,eb=0;wire signed [31:0] pos,opos;wire [31:0] invalid,oinvalid;
 motor_pwm dut(.clk(clk),.rst_n(rst_n),.enable(enable),.command(command),.in1(a),.in2(b),.pwm(p));
 equiv_base_motor_pwm old(.clk(clk),.rst_n(rst_n),.enable(enable),.command(command),.in1(oa),.in2(ob),.pwm(op));
 tick_gen tg(.clk(clk),.rst_n(rst_n),.tick_ms(tick));
 equiv_base_tick_gen otg(.clk(clk),.rst_n(rst_n),.tick_ms(otick));
 uart_tx ut(.clk(clk),.rst_n(rst_n),.start(start),.data(data),.tx(tx),.busy(busy));
 equiv_base_uart_tx outx(.clk(clk),.rst_n(rst_n),.start(start),.data(data),.tx(otx),.busy(obusy));
 uart_rx ur(.clk(clk),.rst_n(rst_n),.rx(tx),.data(received),.valid(valid));
 equiv_base_uart_rx our(.clk(clk),.rst_n(rst_n),.rx(tx),.data(oreceived),.valid(ovalid));
 quadrature_encoder enc(.clk(clk),.rst_n(rst_n),.enc_a(ea),.enc_b(eb),.position(pos),.invalid_count(invalid));
 equiv_base_quadrature_encoder oenc(.clk(clk),.rst_n(rst_n),.enc_a(ea),.enc_b(eb),.position(opos),.invalid_count(oinvalid));
 integer i,checks=0,bytes_seen=0,ticks_seen=0;reg [31:0] rng=32'h582109ab;
 always @(posedge clk)begin #1;if(rst_n)begin
 checks++;
 if({a,b,p,tick,tx,busy,received,valid,pos,invalid}!=={oa,ob,op,otick,otx,obusy,oreceived,ovalid,opos,oinvalid})$fatal(1,"peripheral differs clock=%0d",checks);
 if(valid)bytes_seen++;if(tick)ticks_seen++;
 end end
 initial begin
 repeat(4)@(negedge clk);rst_n=1;
 for(i=0;i<4200000;i=i+1)begin
  @(negedge clk);
  rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
  command=(i/7500)%256-128;
  enable=(i%333333)>40;
  start=(i%6000)==20;data=rng[7:0];
  if(i%37==0)begin ea=rng[3];eb=rng[4];end
  if(i%99991==0)begin ea=~ea;end
  if(i==2100200)rst_n=0;
  if(i==2100204)rst_n=1;
 end
 if(bytes_seen<100 || ticks_seen<50)$fatal(1,"insufficient test activity");
 $display("ALL PASS eq_peripherals checks=%0d uart_bytes=%0d tick_events=%0d",checks,bytes_seen,ticks_seen);$finish;
 end
endmodule

from pathlib import Path
r=Path('C:/Users/wnc06/Documents/Codex/2026-11-01/J280_AllModes_v8_6_Feedforward')
p=r/'tests/tb_unified_telemetry.sv'
s=p.read_text(encoding='utf-8-sig').replace('module tb_unified_telemetry;','module tb_ffmonitor_uart;')
s=s.replace('FRAME_BYTES=771','FRAME_BYTES=901')
s=s.replace('    wire tx;','''    reg signed [31:0] ff_gain_q16=0,ff_pd10=0,ff_applied10=0,ff_loc10=0,ff_acceleration_q8=0;
    reg signed [32:0] ff_total10=0;
    reg ff_active=0,ff_limited=0,speed_valid=0;
    wire tx;''')
s=s.replace('        angle=angle+1; center=center-1;','''        ff_gain_q16=ff_gain_q16+17;ff_pd10=ff_pd10-19;ff_applied10=ff_applied10+23;
        ff_loc10=ff_loc10-29;ff_acceleration_q8=ff_acceleration_q8+31;ff_total10=ff_total10-37;
        ff_active=~ff_active;ff_limited=~ff_limited;speed_valid=~speed_valid;
        angle=angle+1; center=center-1;''')
s=s.replace('            load_unified_case(which);','''            ff_gain_q16=0;ff_pd10=0;ff_applied10=0;ff_loc10=0;ff_acceleration_q8=0;
            ff_total10=0;ff_active=0;ff_limited=0;speed_valid=0;
            case(which)
                1:begin ff_gain_q16=-32768;ff_pd10=32'sh7fffffff;ff_applied10=-1;
                    ff_total10=-33'sd4294967296;ff_loc10=-1000;ff_acceleration_q8=32'sh80000000;ff_active=1;ff_limited=1;end
                2:begin ff_gain_q16=32'sh7fffffff;ff_pd10=32'sh80000000;ff_applied10=32'sh7fffffff;
                    ff_total10=33'sd4294967295;ff_loc10=1000;ff_acceleration_q8=32'sh7fffffff;speed_valid=1;end
                3:begin ff_gain_q16=32'sh80000000;ff_pd10=-1;ff_applied10=0;
                    ff_total10=-1;ff_loc10=-1;ff_acceleration_q8=-1;ff_active=1;speed_valid=1;end
                4:begin ff_gain_q16=16384;ff_pd10=700;ff_applied10=-256;
                    ff_total10=444;ff_loc10=444;ff_acceleration_q8=-1024;ff_active=1;speed_valid=1;end
                5:begin ff_pd10=-1100;ff_total10=-1100;ff_loc10=-1000;ff_acceleration_q8=-512;ff_limited=1;speed_valid=1;end
            endcase
            load_unified_case(which);''')
needle='    task automatic verify_frame'
func=r'''    function automatic string expected_diagnostic_case(input integer which,input integer sequence_number);
        string seq;
        begin
            case(sequence_number)
                1:seq="00000001";2:seq="00000002";3:seq="00000003";
                4:seq="00000004";5:seq="00000005";6:seq="00000006";
            endcase
            case(which)
                0:expected_diagnostic_case={"Z=8601 T=00000000 Q=",seq," CF=00000000 KA=00000000 PD=00000000 FF=00000000 TT=000000000 LO=00000000 AC=00000000 EN=0 SV=0 LM=0\015\012"};
                1:expected_diagnostic_case={"Z=8601 T=01234567 Q=",seq," CF=89ABCDEF KA=FFFF8000 PD=7FFFFFFF FF=FFFFFFFF TT=F00000000 LO=FFFFFC18 AC=80000000 EN=1 SV=0 LM=1\015\012"};
                2:expected_diagnostic_case={"Z=8601 T=FFFFFFFF Q=",seq," CF=80000000 KA=7FFFFFFF PD=80000000 FF=7FFFFFFF TT=0FFFFFFFF LO=000003E8 AC=7FFFFFFF EN=0 SV=1 LM=0\015\012"};
                3:expected_diagnostic_case={"Z=8601 T=80000000 Q=",seq," CF=7FFFFFFF KA=80000000 PD=FFFFFFFF FF=00000000 TT=FFFFFFFFF LO=FFFFFFFF AC=FFFFFFFF EN=1 SV=1 LM=0\015\012"};
                4:expected_diagnostic_case={"Z=8601 T=10203040 Q=",seq," CF=10203040 KA=00004000 PD=000002BC FF=FFFFFF00 TT=0000001BC LO=000001BC AC=FFFFFC00 EN=1 SV=1 LM=0\015\012"};
                5:expected_diagnostic_case={"Z=8601 T=F0E0D0C0 Q=",seq," CF=FFFFFFFF KA=00000000 PD=FFFFFBB4 FF=00000000 TT=FFFFFFBB4 LO=FFFFFC18 AC=FFFFFE00 EN=0 SV=1 LM=1\015\012"};
            endcase
        end
    endfunction

'''
s=s.replace(needle,func+needle)
s=s.replace('expected={expected_legacy_case(which,sequence_number),expected_unified_case(which,sequence_number)};','expected={expected_legacy_case(which,sequence_number),expected_unified_case(which,sequence_number),expected_diagnostic_case(which,sequence_number)};')
s=s.replace('771 bytes','901 bytes')
s=s.replace('if (line_count==3) ck(line_len==X_BYTES,"Unified X8002 line is512 bytes");','if (line_count==3) ck(line_len==X_BYTES,"Unified X8002 line is512 bytes");\n                    if (line_count==4) ck(line_len==130,"Independent Z diagnostic line is130 bytes");')
s=s.replace('ck(line_count==4 && line_len==0','ck(line_count==5 && line_len==0')
s=s.replace('for(offset=259;offset<FRAME_BYTES;offset=offset+1)','for(offset=259;offset<771;offset=offset+1)')
s=s.replace('$display("ACTUAL_X_FIXTURE=%s",actual_x);','$display("ACTUAL_X_FIXTURE=%s",actual_x);\n                actual_x="";for(offset=771;offset<FRAME_BYTES;offset=offset+1) actual_x={actual_x,received[start_at+offset]};\n                $display("ACTUAL_Z_FIXTURE=%s",actual_x);')
s=s.replace('ALL PASS unified telemetry UART:','ALL PASS feedforward telemetry UART:')
(r/'tests/tb_ffmonitor_uart.sv').write_text(s,encoding='utf-8')
(r/'tests/ffmonitor_uart.mjs').write_text(r"""import { readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { simulate } from './local_verilog_runtime.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),here=resolve(root,'tests');
const paths=['tests/tb_ffmonitor_uart.sv','rtl/telemetry.v','rtl/uart_io.v'];
const files=await Promise.all(paths.map(async p=>({path:basename(p),data:await readFile(resolve(root,p),'utf8')})));
const hashes=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
const r=await simulate({files,sources:files.map(f=>f.path),top:'tb_ffmonitor_uart',timeoutMs:120000});
const m=r.stdout.match(/ALL PASS feedforward telemetry UART: (\d+) assertions, (\d+) byte comparisons, (\d+) decoded bytes/);
const x=r.stdout.match(/ACTUAL_X_FIXTURE=(X=8002[^\r\n]+)/),z=r.stdout.match(/ACTUAL_Z_FIXTURE=(Z=8601[^\r\n]+)/);
const success=r.success&&!!m&&!!x&&!!z&&m[3]==6307;
if(success){await writeFile(resolve(here,'ffmonitor_x_fixture.txt'),x[1]+'\r\n');await writeFile(resolve(here,'ffmonitor_z_fixture.txt'),z[1]+'\r\n');}
await writeFile(resolve(here,'ffmonitor_uart_result.json'),JSON.stringify({success,assertions:m?+m[1]:null,byteComparisons:m?+m[2]:null,bytes:m?+m[3]:null,hashes,stdout:r.stdout,stderr:r.stderr,timings:r.timings,scope:'Actual UART TX pin bit-center decoding. Original A/M/O/X bytes unchanged, seven complete901-byte batches including independentZ8601 signed33 extrema, input mutation and busy requests, reset sequence restart.'},null,2));
process.stdout.write(r.combinedOutput);if(!success)process.exitCode=1;
""",encoding='utf-8')
print('UART test ready')

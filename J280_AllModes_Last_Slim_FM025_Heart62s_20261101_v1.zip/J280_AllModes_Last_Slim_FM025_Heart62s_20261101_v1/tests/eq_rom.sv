`timescale 1ns/1ps
module tb_eq_rom;
 reg clk=0;always #10 clk=~clk;
 reg [1:0] profile=0;reg [15:0] sample_index=0,envelope_index=0;
 wire signed [31:0] q16,v8,a8,j8,w0,w1,w2,w3;
 wire signed [31:0] oq,ov,oa,oj,ow0,ow1,ow2,ow3;
 wire [7:0] sample_phase,oph;
 wire [15:0] leg_ticks,dwell_ticks,sine_ticks,envelope_ticks,ol,od,os,oe;
 wire [31:0] profile_cycle_ms,sample_ms,config_tag,base_deci,max_request_deci,units_per_turn;
 wire [31:0] oc,osm,ot,ob,om,ou;
 wire signed [31:0] stroke_units,stroke_q16,ost,ostq;
 trajectory_tables dut(.*);
 equiv_base_trajectory_tables old(.clk(clk),.profile(profile),.sample_index(sample_index),.envelope_index(envelope_index),
 .q16(oq),.v8(ov),.a8(oa),.j8(oj),.w0(ow0),.w1(ow1),.w2(ow2),.w3(ow3),.sample_phase(oph),
 .leg_ticks(ol),.dwell_ticks(od),.sine_ticks(os),.envelope_ticks(oe),.profile_cycle_ms(oc),.sample_ms(osm),
 .config_tag(ot),.base_deci(ob),.max_request_deci(om),.units_per_turn(ou),.stroke_units(ost),.stroke_q16(ostq));
 integer i,p,checks=0;
 initial begin
 for(p=0;p<4;p=p+1)begin
  for(i=0;i<65536;i=i+1)begin
   @(negedge clk);profile=p;sample_index=i;envelope_index=i*73;
   @(posedge clk);#1;
   checks++;
   if({q16,v8,a8,j8,w0,w1,w2,w3,sample_phase,leg_ticks,dwell_ticks,sine_ticks,envelope_ticks,profile_cycle_ms,sample_ms,config_tag,base_deci,max_request_deci,units_per_turn,stroke_units,stroke_q16} !==
      {oq,ov,oa,oj,ow0,ow1,ow2,ow3,oph,ol,od,os,oe,oc,osm,ot,ob,om,ou,ost,ostq})$fatal(1,"ROM differs profile=%0d sample=%0d envelope=%0d",p,i,envelope_index);
  end
 end
 $display("ALL PASS eq_rom checks=%0d",checks);$finish;
 end
endmodule

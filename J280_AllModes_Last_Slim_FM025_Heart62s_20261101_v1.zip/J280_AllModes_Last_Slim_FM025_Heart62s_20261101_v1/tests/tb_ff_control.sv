`timescale 1ns/1ps

module tb_ff_control;
reg clk=0,rst_n=0,sample_ms=0;always #1 clk=~clk;
reg [11:0] angle=2955;reg signed[31:0] position=0;
reg toggle_event=0,stop_event=0,plus_event=0,minus_event=0,calibrate_event=0;
reg prepare_event=0,capture_start_event=0,target_update_event=0;
reg [11:0] prepare_center=2955;reg signed [31:0] prepare_target=0,target_value=0;
reg ff_valid=0;reg signed[31:0] ff_correction10=0;
wire [3:0] running,calibrated,calibrating,zero_position,angle_update,location_update;
wire [3:0] fault[0:3];wire [11:0] center[0:3];
wire signed[31:0] target_position[0:3],location_out10[0:3];wire signed[7:0] motor_command[0:3];
wire signed[31:0] pd10[1:3],aff10[1:3];wire signed[32:0] total10[1:3];wire limited[1:3];
ff_baseline_control #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(505),.ANGLE_D_FILTER_SHIFT(1),.LOCATION_KP_10(7),.LOCATION_KD_10(105),.DUTY_LIMIT(100)) old_core(.clk(clk),.rst_n(rst_n),.sample_ms(sample_ms),.angle(angle),.position(position),.toggle_event(toggle_event),.stop_event(stop_event),.plus_event(plus_event),.minus_event(minus_event),.calibrate_event(calibrate_event),.prepare_event(prepare_event),.prepare_center(prepare_center),.prepare_target(prepare_target),.capture_start_event(capture_start_event),.target_update_event(target_update_event),.target_value(target_value),.sensor_ok(1'b1),.travel_ok(1'b1),.running(running[0]),.calibrated(calibrated[0]),.calibrating(calibrating[0]),.fault(fault[0]),.center(center[0]),.target_position(target_position[0]),.location_out10(location_out10[0]),.motor_command(motor_command[0]),.zero_position(zero_position[0]),.angle_update(angle_update[0]),.location_update(location_update[0]));
cascade_control #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(505),.ANGLE_D_FILTER_SHIFT(1),.LOCATION_KP_10(7),.LOCATION_KD_10(105),.DUTY_LIMIT(100),.FF_ENABLE(0)) disabled(.clk(clk),.rst_n(rst_n),.sample_ms(sample_ms),.angle(angle),.position(position),.toggle_event(toggle_event),.stop_event(stop_event),.plus_event(plus_event),.minus_event(minus_event),.calibrate_event(calibrate_event),.prepare_event(prepare_event),.prepare_center(prepare_center),.prepare_target(prepare_target),.capture_start_event(capture_start_event),.target_update_event(target_update_event),.target_value(target_value),.sensor_ok(1'b1),.travel_ok(1'b1),.running(running[1]),.calibrated(calibrated[1]),.calibrating(calibrating[1]),.fault(fault[1]),.center(center[1]),.target_position(target_position[1]),.location_out10(location_out10[1]),.motor_command(motor_command[1]),.zero_position(zero_position[1]),.angle_update(angle_update[1]),.location_update(location_update[1]),.location_pd10(pd10[1]),.ff_applied10(aff10[1]),.location_total10(total10[1]),.location_limited(limited[1]),.ff_valid(ff_valid),.ff_correction10(ff_correction10));
cascade_control #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(505),.ANGLE_D_FILTER_SHIFT(1),.LOCATION_KP_10(7),.LOCATION_KD_10(105),.DUTY_LIMIT(100),.FF_ENABLE(1)) zero_core(.clk(clk),.rst_n(rst_n),.sample_ms(sample_ms),.angle(angle),.position(position),.toggle_event(toggle_event),.stop_event(stop_event),.plus_event(plus_event),.minus_event(minus_event),.calibrate_event(calibrate_event),.prepare_event(prepare_event),.prepare_center(prepare_center),.prepare_target(prepare_target),.capture_start_event(capture_start_event),.target_update_event(target_update_event),.target_value(target_value),.sensor_ok(1'b1),.travel_ok(1'b1),.running(running[2]),.calibrated(calibrated[2]),.calibrating(calibrating[2]),.fault(fault[2]),.center(center[2]),.target_position(target_position[2]),.location_out10(location_out10[2]),.motor_command(motor_command[2]),.zero_position(zero_position[2]),.angle_update(angle_update[2]),.location_update(location_update[2]),.location_pd10(pd10[2]),.ff_applied10(aff10[2]),.location_total10(total10[2]),.location_limited(limited[2]),.ff_valid(1'b1),.ff_correction10(32'sd0));
cascade_control #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(505),.ANGLE_D_FILTER_SHIFT(1),.LOCATION_KP_10(7),.LOCATION_KD_10(105),.DUTY_LIMIT(100),.FF_ENABLE(1)) active_core(.clk(clk),.rst_n(rst_n),.sample_ms(sample_ms),.angle(angle),.position(position),.toggle_event(toggle_event),.stop_event(stop_event),.plus_event(plus_event),.minus_event(minus_event),.calibrate_event(calibrate_event),.prepare_event(prepare_event),.prepare_center(prepare_center),.prepare_target(prepare_target),.capture_start_event(capture_start_event),.target_update_event(target_update_event),.target_value(target_value),.sensor_ok(1'b1),.travel_ok(1'b1),.running(running[3]),.calibrated(calibrated[3]),.calibrating(calibrating[3]),.fault(fault[3]),.center(center[3]),.target_position(target_position[3]),.location_out10(location_out10[3]),.motor_command(motor_command[3]),.zero_position(zero_position[3]),.angle_update(angle_update[3]),.location_update(location_update[3]),.location_pd10(pd10[3]),.ff_applied10(aff10[3]),.location_total10(total10[3]),.location_limited(limited[3]),.ff_valid(ff_valid),.ff_correction10(ff_correction10));

integer checks=0,cycles=0,published=0,positive_clamps=0,negative_clamps=0,cancelled=0,unclipped=0;
integer pending_delay=0;reg signed[31:0] expected_pd,expected_ff;
longint signed expected_total;reg pub_now;
reg signed[31:0] e_now,pd_now;integer k;
always @(posedge clk) begin
cycles++;pub_now=0;
if(!rst_n || !running[3] || stop_event || prepare_event || capture_start_event)pending_delay=0;
else begin
if(!ff_valid && pending_delay>0 && expected_ff!=0)begin
cancelled++;expected_ff=0;expected_total=expected_pd;
end
if(pending_delay>0)begin pending_delay--;if(pending_delay==0)pub_now=1;end
if(sample_ms && active_core.location_count==49)begin
e_now=target_position[3]-position;pd_now=112*e_now-105*active_core.location_previous;
expected_pd=pd_now;
expected_ff=ff_valid ? ff_correction10 : 32'sd0;
expected_total=longint'(pd_now)+longint'(expected_ff);
pending_delay=4;
end
end
#0.1;
for(integer j=1;j<=2;j++)begin
checks++;
if({running[j],calibrated[j],calibrating[j],fault[j],center[j],target_position[j],motor_command[j],zero_position[j],angle_update[j]}!==
   {running[0],calibrated[0],calibrating[0],fault[0],center[0],target_position[0],motor_command[0],zero_position[0],angle_update[0]})
$fatal(1,"Motor/inner/supervisory cycle-exact baseline mismatch core %0d cycle %0d",j,cycles);
end
if(rst_n)begin
checks++;
if(location_update[1]!==pub_now || location_update[2]!==pub_now || location_update[3]!==pub_now)
$fatal(1,"Outer publication latency/event mismatch cycle%0d expected%b got%b%b%b",cycles,pub_now,location_update[1],location_update[2],location_update[3]);
end
if(rst_n&&pub_now)begin
for(integer j=1;j<=2;j++)begin
checks++;
if(location_out10[j]!== (expected_pd>1000?32'sd1000:expected_pd< -1000?-32'sd1000:expected_pd))
$fatal(1,"Zero/disabled FF outer event arithmetic mismatch");
end
checks++;published++;
if(pd10[3]!==expected_pd || aff10[3]!==expected_ff || $signed(total10[3])!==expected_total ||
   limited[3]!== (expected_total>1000 || expected_total< -1000) ||
   location_out10[3]!== (expected_total>1000?32'sd1000:expected_total< -1000?-32'sd1000:expected_total[31:0]) ||
   location_update[3]!==1)
$fatal(1,"FF publish cycle%0d pd=%0d/%0d ff=%0d/%0d total=%0d/%0d loc=%0d lim=%b",
cycles,pd10[3],expected_pd,aff10[3],expected_ff,total10[3],expected_total,location_out10[3],limited[3]);
if(expected_total>1000)positive_clamps++;
if(expected_total< -1000)negative_clamps++;
if(expected_total>= -1000 && expected_total<=1000 && expected_ff!=0)unclipped++;
end
end
task automatic pulse_sample;
begin @(negedge clk);sample_ms=1;@(negedge clk);sample_ms=0;repeat(79)@(negedge clk);end
endtask
task automatic prepare_start;
begin
@(negedge clk);stop_event=1;@(negedge clk);stop_event=0;repeat(5)@(negedge clk);
prepare_event=1;@(negedge clk);prepare_event=0;repeat(3)@(negedge clk);
capture_start_event=1;@(negedge clk);capture_start_event=0;repeat(3)@(negedge clk);
end endtask
initial begin
repeat(3)@(negedge clk);rst_n=1;prepare_start();
for(k=0;k<1200;k++)begin
angle=2955+((k*17)%101)-50;position=(k%201)-100;target_update_event=1;target_value=((k*7)%131)-65;
ff_valid=(k%73)>4;ff_correction10=(k%4==0)?32'sh7fffffff:(k%4==1)?32'sh80000000:(k%4==2)?32'sd235:-32'sd467;
if(k%101==0)begin plus_event=1;minus_event=0;end
else if(k%101==1)begin minus_event=1;plus_event=0;end
else begin plus_event=0;minus_event=0;end
pulse_sample();target_update_event=0;
end
target_update_event=0;plus_event=0;minus_event=0;position=0;angle=2955;prepare_target=0;
prepare_start();ff_valid=1;ff_correction10=235;repeat(100)pulse_sample();
prepare_start();ff_valid=1;ff_correction10=-467;repeat(100)pulse_sample();
ff_valid=1;ff_correction10=0;
for(k=0;k<200;k++)begin position=k-100;pulse_sample();end
ff_valid=0;ff_correction10=32'sh7fffffff;
for(k=0;k<200;k++)begin position=100-k;pulse_sample();end
for(k=0;k<4;k++)begin
prepare_start();position=0;target_value=0;target_update_event=1;ff_valid=1;ff_correction10=777;
repeat(49)pulse_sample();
@(negedge clk);sample_ms=1;@(posedge clk);#0.2;
@(negedge clk);sample_ms=0;repeat(k)@(negedge clk);ff_valid=0;
repeat(7)@(negedge clk);
if(active_core.ff_math!==0)$fatal(1,"pending ownership cancellation failed");
end
for(k=0;k<4;k++)begin
prepare_start();ff_valid=1;ff_correction10=-777;repeat(49)pulse_sample();
@(negedge clk);sample_ms=1;@(posedge clk);#0.2;
@(negedge clk);sample_ms=0;repeat(k)@(negedge clk);
stop_event=1;@(negedge clk);stop_event=0;repeat(5)@(negedge clk);
if(running[3]!==0||motor_command[3]!==0||active_core.ff_math!==0)$fatal(1,"stop did not clear pending FF");
end
prepare_start();ff_valid=1;ff_correction10=32'sh7fffffff;
for(k=0;k<150;k++)begin
position=(k%2)?32'sh7fffffff:32'sh80000000;
target_value=(k%3)?32'sh80000000:32'sh7fffffff;target_update_event=1;pulse_sample();
end
@(negedge clk);rst_n=0;repeat(4)@(negedge clk);
if(published<25||positive_clamps<5||negative_clamps<5||cancelled<4||unclipped<2)
$fatal(1,"Coverage missing pubs=%0d pos=%0d neg=%0d cancel=%0d",published,positive_clamps,negative_clamps,cancelled);
$display("Coverage FF pubs=%0d positive_clamps=%0d negative_clamps=%0d cancelled=%0d unclipped=%0d",published,positive_clamps,negative_clamps,cancelled,unclipped);
$display("ALL PASS FF control: %0d assertions, %0d cycles",checks,cycles);$finish;
end
endmodule

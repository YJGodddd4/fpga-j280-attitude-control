// [EQ62修改] 使用本机Questa命令行，不依赖其他电脑绝对路径。
export {simulate} from './local_verilog_runtime.mjs';

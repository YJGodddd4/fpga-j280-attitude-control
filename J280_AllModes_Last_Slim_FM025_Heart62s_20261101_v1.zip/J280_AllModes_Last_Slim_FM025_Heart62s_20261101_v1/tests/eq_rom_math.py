from pathlib import Path
import json,sys,hashlib,math
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'tests'))
from heart_reference import at,rn
meta=json.loads((R/'config/trajectory_validation.json').read_text())
checked=0;analytic=0;maximum=[0.,0.,0.,0.];fm_values=[]
for name,desc in meta['lossless_packing'].items():
    fields=list(desc['fields']);widths=list(desc['fields'].values())
    old=[int(x,16) for x in (R/f'tests/equivalence_baseline/trajectory_tables_{name}.mem').read_text().split()]
    new=[int(x,16) for x in (R/f'rtl/trajectory_tables_{name}.mem').read_text().split()]
    assert len(old)==desc['logical_rows'] and len(new)==desc['rows']
    for i,raw in enumerate(old):
        negative=name=='ab' and desc['fm_half_ticks'] and i>=3150+desc['fm_half_ticks']
        index=i-desc['fm_half_ticks'] if negative else i
        packed=new[index];left=sum(widths);wide=0;values={}
        for key,bits in zip(fields,widths):
            left-=bits;v=(packed>>left)&((1<<bits)-1)
            if key!='phase' and v>=(1<<(bits-1)):v-=1<<bits
            if key=='phase':v+=desc.get('phase_bias',0)
            if negative and key!='phase':v=-v
            values[key]=v
            w=8 if key=='phase' else 32
            wide=(wide<<w)|(v&((1<<w)-1));checked+=1
        assert wide==raw,(name,i)
        if name=='sine':
            reference=at(i/100)
            for k,(key,f) in enumerate(zip(['q16','v8','a8','j8'],[65536,256,256,256])):
                x=reference[k]*408/360*f;maximum[k]=max(maximum[k],abs(values[key]-x))
                assert values[key]==rn(x),(i,key);analytic+=1
        if name=='ab' and i>=3150:
            t=(i-3150)/100
            # Independent closed-form FM phase and its physical-time derivatives.
            omega=2*math.pi/30
            phi=2*math.pi*.175*t-(.15*math.pi/omega)*math.sin(omega*t)
            speed=2*math.pi*(.175-.075*math.cos(omega*t))
            acceleration=.15*math.pi*omega*math.sin(omega*t)
            jerk=.15*math.pi*omega**2*math.cos(omega*t)
            sn,cs=math.sin(phi),math.cos(phi)
            ref=[30*sn,30*speed*cs,30*(acceleration*cs-speed**2*sn),30*((jerk-speed**3)*cs-3*speed*acceleration*sn)]
            for key,x,f in zip(['q16','v8','a8','j8'],ref,[65536,256,256,256]):
                assert values[key]==rn(x*408/360*f),(i,key,x,values[key]);analytic+=1
            fm_values.append(values['q16']/65536*360/408)
assert len(fm_values)==12000
max_position_step=max(abs(fm_values[(i+1)%12000]-v) for i,v in enumerate(fm_values))
assert max_position_step<.472
assert abs(fm_values[3000]-30)<.00001 and abs(fm_values[9000]+30)<.00001
source=json.loads((R/'tests/equivalence_baseline/source_hashes.json').read_text())
unchanged=['j280_pendulum_top.v','cascade_control.v','position_task.v','adc_3pa1030.v','auto_angle_state.v','acceleration_feedforward.v','encoder_speed_monitor.v','swingup_supervisor.v','position_inputs.v','motion_reference_owner.v','signed_div_const.v','position_serial_div.v']
for name in unchanged:assert hashlib.sha256((R/'rtl'/name).read_bytes()).hexdigest()==source[name]
assert meta['heart_shape_ms']==56000 and meta['heart_hold_ms']==6000 and meta['heart_cycle_ms']==62000
assert meta['config_tag']=='CB045654' and meta['fm_frequency_range_hz']==[.1,.25] and meta['fm_position_cycle_ms']==120000
result={'success':True,'restored_fields_checked':checked,'independent_analytic_values_checked':analytic,'heart_integer_max_abs_error':maximum,'fm_logical_points':12000,'fm_stored_points':6000,'fm_max_adjacent_position_step_degrees':max_position_step,'fm_modulation_ms':30000,'fm_position_cycle_ms':120000,'unchanged_core_files':unchanged,'shape_ms':56000,'hold_ms':6000,'cycle_ms':62000,'new_config_tag':'CB045654','hardware_tested':False}
(R/'tests/eq_rom_math_result.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps(result))

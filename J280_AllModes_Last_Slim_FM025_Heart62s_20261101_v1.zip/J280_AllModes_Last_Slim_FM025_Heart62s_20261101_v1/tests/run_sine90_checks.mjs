// Independent new-default sine checks. This file never runs a programmer or serial I/O.
// Usage: node run_sine90_checks.mjs --root D:/.../NEW_PROJECT --runtime D:/.../local_verilog_runtime.mjs
// The runtime's simulate API must preserve relative virtual paths (rtl/*.mem).
import {readFile,writeFile,mkdir,access} from 'node:fs/promises';
import {dirname,resolve,basename} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

const here=dirname(fileURLToPath(import.meta.url));
const args=process.argv.slice(2);
function option(name,fallback){const i=args.indexOf(name);return i>=0?args[i+1]:fallback;}
const rootArg=option('--root');
if(!rootArg)throw Error('Pass --root with the new project directory; no default/original project will be modified.');
const root=resolve(rootArg);
const runtimeOverride=option('--runtime');
const runtimePath=resolve(runtimeOverride||resolve(here,'local_verilog_runtime.mjs'));
await access(runtimePath);
// Normal project use is a direct local import; override is for an explicit adapter only.
const {simulate}=runtimeOverride ? await import(pathToFileURL(runtimePath).href) : await import('./local_verilog_runtime.mjs');
if(typeof simulate!=='function')throw Error('Runtime must export simulate(options).');
const output=resolve(option('--output-dir',resolve(root,'tests')));await mkdir(output,{recursive:true});
const configPath=resolve(root,'config/trajectory_profiles.json');
const configBytes=await readFile(configPath);
const config=JSON.parse(configBytes.toString('utf8').replace(/^\uFEFF/,''));
const expected={amplitude_degrees:90,period_ms:7000,ramp_ms:6000};
for(const [k,v]of Object.entries(expected))if(config.sine[k]!==v)throw Error(`Expected new default sine.${k}=${v}; got${config.sine[k]}.`);
if(config.sample_ms!==10||config.engineering_units_per_turn!==408)throw Error('Bench requires10ms ROM spacing and408 engineering units/revolution.');
const benchPath=resolve(option('--bench',resolve(here,'tb_sine90_fast.sv')));
const sourcePaths=['rtl/trajectory_task.v','rtl/trajectory_tables.v','rtl/position_serial_div.v','rtl/trajectory_editor.v','rtl/position_inputs.v'];
const memPaths=['rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem'];
const files=[{path:'tb_sine90_fast.sv',data:await readFile(benchPath,'utf8')}];
for(const path of [...sourcePaths,...memPaths])files.push({path,data:await readFile(resolve(root,path),'utf8')});
const sourceSha256=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
const selected=(option('--cases','pos90,neg90,small30,large180,editor_flow')).split(',');
const known=new Set(['pos90','neg90','small30','large180','editor_flow']);
for(const name of selected)if(!known.has(name))throw Error('Unknown sine90 case: '+name);
let passed=true;const compact=[];
for(const name of selected){
 const top='tb_sine90_'+name;
 const r=await simulate({files,sources:['tb_sine90_fast.sv',...sourcePaths],top,generation:'2012',timeoutMs:600000});
 const stdout=r.stdout||'',stderr=r.stderr||'';
 const m=stdout.match(new RegExp('ALL PASS sine90 case='+name+' assertions=(\\d+) publications=(\\d+) strict=(\\d+) cycles=(\\d+)'));
 const success=Boolean(r.success&&r.exitCode===0&&m&&(name==='editor_flow'||Number(m[3])>=1400));
 const report={profile:'sine90_period7_ramp6',case:name,top,success,stage:r.stage,exitCode:r.exitCode,
  assertions:m?Number(m[1]):null,publications:m?Number(m[2]):null,strictComparisons:m?Number(m[3]):null,cycles:m?Number(m[4]):null,
  stdout,stderr,sourceSha256,config_sha256:createHash('sha256').update(configBytes).digest('hex'),sine_config:config.sine,
  runner_sha256:createHash('sha256').update(await readFile(fileURLToPath(import.meta.url))).digest('hex'),
  scope:name==='editor_flow'
   ? 'Actual raw-panel,unparameterized editor and trajectory RTL with shipped ROMs. Checks new default90degrees,10degree editing,per-profile memory isolation,accepted-request freeze,SW4 queued smooth stop/no restart,fresh acceptance and stretch,balance loss while numeric pipeline is active,recapture,and reset while pipeline is active.300 FPGA clocks per accelerated logicalms. No mechanical plant,real serial port,programmer or hardware actuation.'
   : 'Actual trajectory RTL and shipped generated ROMs. Independent continuous degree-domain sine/envelope P/V/A/J for this requested amplitude,expected stretch independent of DUT outputs,at least2whole periods,both positive/negative steady extrema,actual10ms cadence/no lag accumulation,and full smooth exit.300 FPGA clocks per accelerated logicalms. No mechanical plant,real serial port,programmer or hardware actuation.'};
 await writeFile(resolve(output,'trajectory_sine90_'+name+'_result.json'),JSON.stringify(report,null,2),'utf8');
 await writeFile(resolve(output,'trajectory_sine90_'+name+'_test.log'),r.combinedOutput||stdout+'\n'+stderr,'utf8');
 compact.push({case:name,success,assertions:report.assertions,publications:report.publications,strictComparisons:report.strictComparisons,cycles:report.cycles});
 process.stdout.write((success?'PASS ':'FAIL ')+name+'\n');
 if(!success)process.stderr.write((stdout+'\n'+stderr).slice(-8000)+'\n');
 passed&&=success;
}
process.stdout.write(JSON.stringify({success:passed,root,bench:benchPath,runtime:runtimePath,results:compact},null,2)+'\n');
if(!passed)process.exitCode=1;

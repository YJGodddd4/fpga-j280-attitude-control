// [FAST_AB_10S修改] Actual top-level wiring smoke; synthetic sensor/tick signals only.
import {readFile,writeFile,readdir} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),root=resolve(here,'..');
const {simulate}=await import('./local_verilog_runtime.mjs');
const rtl=(await readdir(resolve(root,'rtl'))).filter(x=>x.endsWith('.v')).sort().map(x=>'rtl/'+x);
const sources=['tests/tb_ff_top.sv',...rtl];
const paths=[...sources,'rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem'];
const files=await Promise.all(paths.map(async path=>({path,data:await readFile(resolve(root,path),'utf8')})));
const sourceSha256=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
const r=await simulate({files,sources,top:'tb_ff_top',generation:'2012',timeoutMs:600000});
const match=r.stdout.match(/ALL PASS[^\n]*/);
const success=Boolean(r.success&&match);
await writeFile(resolve(here,'ff_top_result.json'),JSON.stringify({success,stage:r.stage,exitCode:r.exitCode,stdout:r.stdout,stderr:r.stderr,sourceSha256,
 scope:'Actual Last uploaded top,supervisor,PID,owner,editors and planners; defaultsAM30/FM30/heart56,62s heartcycle,publicationmux,loss/recapture,noautoplay,stop. Synthetic logical tick/sensors; no plant or hardware.'},null,2));
await writeFile(resolve(here,'ff_top_test.log'),r.combinedOutput);
process.stdout.write(r.combinedOutput);if(!success)process.exitCode=1;

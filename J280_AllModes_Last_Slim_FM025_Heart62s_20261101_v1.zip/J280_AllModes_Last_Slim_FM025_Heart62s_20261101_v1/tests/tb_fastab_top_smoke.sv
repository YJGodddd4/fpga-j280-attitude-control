`timescale 1ns/1ps
// [FASTAB修改] 真实顶层/原PID/三种真实规划器短集成检查；仅tick和传感器值为合成输入。
// 不含机械模型，不连接串口或硬件；本文件由主审集成后再执行仿真。
module tb_fastab_top_smoke;
  reg clk=0;always #10 clk=~clk;
  reg rst_n=0,tick=0;
  reg [3:0] keys_n=4'hf;
  reg [1:0] dips_n=2'b11;
  reg [11:0] observed_angle=859;
  reg signed [31:0] observed_position=50;
  wire AN1,AN2,PWMA,BN1,BN2,PWMB;
  wire [3:0] led;
  integer checks=0,profile,origin_saved,center_saved,run_anchor_saved,run_saved;
  integer publications=0,pubs_saved,first_publications=0,last_run=-1,previous_reference;

  j280_pendulum_top dut(
    .clk_50m(clk),.rst_n(rst_n),.key_sw(keys_n),.dip_sw_n(dips_n),
    .uart_rx(1'b1),.uart_tx(),.adc_clk(),.adc_oe_n(),.adc_data_in(10'd0),.adc_otr(1'b0),
    .enc1_a(1'b0),.enc1_b(1'b0),.enc2_a(1'b0),.enc2_b(1'b0),
    .AN1(AN1),.AN2(AN2),.PWMA(PWMA),.BN1(BN1),.BN2(BN2),.PWMB(PWMB),.led(led));

  initial begin
    force dut.tick_ms=tick;
    force dut.telemetry_request=1'b0;
    force dut.angle=observed_angle;
    force dut.angle_valid=1'b1;
    force dut.adc_overrange=1'b0;
    force dut.position=observed_position;
  end

  task ck(input bit pass,input string message);
    begin
      checks=checks+1;
      if(!pass)$fatal(1,"%s M=%0d J=%0d N=%0d owner=%0d run=%0d TA=%0d TM=%0d CL=%0d H=%0d R=%0d Y=%0d",
        message,dut.mode,dut.tr_profile,dut.tr_state,dut.reference_owner,dut.tr_running,
        dut.tr_accepted_deci,dut.tr_time_stretch,dut.tr_cycle_ms,dut.tr_center,dut.tr_reference,dut.target_position);
    end
  endtask
  task sample;
    begin
      @(negedge clk);tick=1;@(negedge clk);tick=0;
      // [FASTAB修改] 仍留足1200个50MHz周期完成真实96位除法链，不替换规划器运算。
      repeat(1198)@(negedge clk);
    end
  endtask
  task wait_ticks(input integer count);
    integer n;begin for(n=0;n<count;n=n+1)sample;end
  endtask
  task follow_ticks(input integer count);
    integer n;
    begin
      for(n=0;n<count;n=n+1)begin
        observed_position=dut.target_position;
        sample;
        if(dut.tr_running && dut.u_trajectory_task.prepared)begin
          ck(dut.target_position==dut.tr_reference,"published trajectory reaches the real PID target mux");
          ck(dut.tr_center==center_saved,"trajectory center stays locked while running");
        end
      end
    end
  endtask
  task press(input [3:0] mask);
    begin keys_n=~mask;follow_ticks(30);keys_n=4'hf;follow_ticks(30);end
  endtask
  task select_profile(input [1:0] selected);
    begin
      dips_n=~selected;follow_ticks(35);follow_ticks(80);
      ck(dut.pos_dip_valid && dut.pos_dip_mode==selected,"real DIP debounce selects requested profile");
      ck(dut.trajectory_owned && dut.tr_held_idle && !dut.tr_running,"selection adopts held reference without automatic replay");
      run_anchor_saved=dut.tr_reference;center_saved=run_anchor_saved+(selected==3 ? 0 : 102);
    end
  endtask
  task interrupt_and_recapture(input integer new_position);
    begin
      // [FASTAB修改] 通过真实角度输入触发原失衡恢复路径，不force内部模式或PID状态。
      observed_angle=859;wait_ticks(12);
      ck(dut.mode!=5 && !dut.pid_running && !dut.position_target_valid,"angle loss exits balance and invalidates old target");
      ck(!dut.tr_running && !dut.tr_base_valid && dut.tr_interrupted,"loss cancels the active trajectory and marks interruption");
      ck(!dut.motion_write && dut.reference_owner==0,"interrupted generators cannot keep writing targets");
      observed_position=new_position;observed_angle=2955;wait_ticks(110);
      ck(dut.mode==5 && dut.pid_running && dut.trajectory_owned && dut.tr_held_idle,"real supervisor captures upright and returns to READY");
      ck(!dut.tr_running && dut.tr_profile==0,"recapture does not restart the previous profile");
      ck(dut.tr_reference==new_position && dut.tr_center==new_position && dut.target_position==new_position,"fresh capture adopts actual position as new held reference");
      ck(dut.encoder_origin==origin_saved,"recapture does not reset the encoder origin");
      center_saved=new_position;follow_ticks(80);
      ck(!dut.tr_running && dut.tr_reference==new_position,"READY remains stopped until a new SW4 confirmation");
    end
  endtask

  always @(negedge clk)begin
    if(dut.reset_n)begin
      if(dut.position_write && dut.trajectory_write)$fatal(1,"simultaneous position and trajectory target writes");
      if(BN1 || BN2 || PWMB)$fatal(1,"inactive bridge B driven");
      if(dut.tr_update && dut.tr_running)begin
        publications=publications+1;
        if(last_run!=dut.tr_run_id)begin
          first_publications=first_publications+1;
          if(dut.tr_reference!==run_anchor_saved)$fatal(1,"first reference publication jumped away from captured startup anchor");
          if(dut.tr_speed!==0)$fatal(1,"first reference publication has nonzero planned speed");
          last_run=dut.tr_run_id;
        end else begin
          if(dut.tr_reference-previous_reference>2 || previous_reference-dut.tr_reference>2)
            $fatal(1,"unexpected large short-run reference jump");
        end
        previous_reference=dut.tr_reference;
      end
    end
  end

  initial begin
    repeat(5)@(negedge clk);rst_n=1;wait_ticks(60);
    ck(dut.mode==1 && dut.pos_dip_mode==0,"boot enters READY in position selection");
    press(4'b0001);observed_position=50;observed_angle=2955;wait_ticks(100);
    ck(dut.mode==5 && dut.pid_running && dut.pid_center==2955,"real SW1 and upright angle capture enter balance");
    origin_saved=dut.encoder_origin;
    ck(dut.ANGLE_KD_100==500 && dut.LOCATION_KD_10==92,"production gains preserve uploaded source500/92");
    ck(dut.ANGLE_D_FILTER_SHIFT==1 && dut.unified_flags[14] && !dut.unified_flags[15],"actual filtered core is enabled and advertised byFL14");
    ck(dut.tr_edit_a==900 && dut.tr_edit_b==900 && dut.tr_edit_c==900,"all profile defaults are signed90degree half-amplitudes");

    for(profile=1;profile<=3;profile=profile+1)begin
      select_profile(profile[1:0]);
      run_saved=dut.tr_run_id;pubs_saved=publications;
      press(4'b1000);follow_ticks(300);
      ck(dut.tr_running && dut.tr_profile==profile,"real SW4 starts the selected profile");
      ck(dut.tr_run_id==run_saved+1,"one accepted start advances the run ID exactly once");
      ck(dut.tr_accepted_deci==900 && dut.tr_time_stretch==1 && dut.tr_cycle_ms==7000,"accepted half90 uses TM1 and7second full roundtrip");
      ck(dut.tr_center==center_saved && dut.active_base==center_saved,"active base reports fixed geometric midpoint while first sample retains startup anchor");
      ck(dut.target_position==dut.tr_reference,"current planner reference is the actual PID target");
      ck(dut.tr_elapsed>=300 && dut.tr_cycles==0,"short startup advances time without claiming a completed steady cycle");
      ck(publications-pubs_saved>=25,"real arithmetic publishes multiple10ms references during the short run");
      interrupt_and_recapture(100+profile*40);
    end
    ck(first_publications==3,"all three profiles published a continuous first sample");
    press(4'b0001);wait_ticks(10);
    ck(!dut.pid_running && !dut.tr_running && !dut.motion_write,"explicit global stop cancels both control and reference ownership");
    ck(AN1==0 && AN2==0 && PWMA==0 && BN1==0 && BN2==0 && PWMB==0,"all physical driver outputs are off after global stop");
    $display("ALL PASS fast centered profiles top smoke: %0d checks, %0d trajectory publications; real top/PID/debounced panel, synthetic sensors and ideal follower only",checks,publications);
    $finish;
  end
  initial begin #1000000000;$fatal(1,"timeout");end
endmodule

from pathlib import Path
r=Path('C:/Users/wnc06/Documents/Codex/2026-11-01/J280_AllModes_v8_6_Feedforward')
p=r/'monitor/unified_monitor.py';s=p.read_text(encoding='utf-8')
s=s.replace("self.refresh_status();root.after(50,self.poll_events);root.after(120,self.redraw)","self.refresh_status();self.poll_after_id=root.after(50,self.poll_events);self.redraw_after_id=root.after(120,self.redraw)")
s=s.replace("self.refresh_status();self.root.after(50,self.poll_events)","self.refresh_status();self.poll_after_id=self.root.after(50,self.poll_events)")
s=s.replace("self.root.after(120,self.redraw)","self.redraw_after_id=self.root.after(120,self.redraw)")
s=s.replace("        self.finish_recording();self.root.destroy()","""        self.finish_recording()
        for token in (getattr(self,'poll_after_id',None),getattr(self,'redraw_after_id',None)):
            if token is not None:
                try:self.root.after_cancel(token)
                except tk.TclError:pass
        self.root.update_idletasks();self.root.destroy()""")
p.write_text(s,encoding='utf-8')
p=r/'monitor/Start_Unified_Monitor.cmd';s=p.read_text(encoding='utf-8-sig')
s=s.replace('v8.4 Read-only Monitor - X8002','v8.6 Feedforward Read-only Monitor - X8002 Z8601')
s=s.replace('if not exist "%J280_UNIFIED_ROOT%unified_protocol.py" goto missing_files','if not exist "%J280_UNIFIED_ROOT%unified_protocol.py" goto missing_files\nif not exist "%J280_UNIFIED_ROOT%feedforward_protocol.py" goto missing_files')
p.write_bytes(s.replace('\r\n','\n').replace('\r','').replace('\n','\r\n').encode('utf-8'))
(r/'monitor/使用说明_v8_6前馈监测.md').write_text("""# v8.6 前馈与快速测速监测

双击本目录“启动J280全功能监测.cmd”，选择 COM7，连接。窗口只接收数据，不发送任何启动、目标或调参命令。

- 起摆、平衡、任意位置、AM、FM和普通正弦仍在同一个窗口；按键与拨码沿用工程分配。
- 新固件 CF=B5FBC6B6 的 W 使用原始1040计数/转编码器，50ms滑动窗口、10ms更新、1/2低通。旧速度保留给00到位判断。W依然是估算，不是独立实测速度传感器；改善测速延迟不等于改善实物跟踪。
- 旧CF/旧CSV会显示旧版测速说明；旧程序没有遥测滤波权重，所以不会凭CF猜用户修改后的 >>> 值。
- 定位与轨迹页新增 Z8601 前馈诊断：KA（实际Q16系数）、PD、FF、总和、实际外环倾角修正LO、限幅和测速窗口有效标志。KA=0明确显示关闭；收到新CF但没收到Z，不会猜测前馈已启用。
- PD/FF/LO记录最近一次50ms外环更新；AC是发送快照时的规划加速度，二者不保证同一控制采样时刻。EN表示当前前馈输入可用，不保证最近一次FF非零。
- Z和X有同一发送快照的T/Q/CF；窗口同时检查连接段和数据新鲜度。Z独立显示，不把不同快照拼成一个控制采样。
- 默认前馈系数是模型估计的试验起点，方向与大小仍需实物对照。实际改善请看同条件下P对RF的跟踪误差、摆杆角度偏差以及内部命令；不能以绿色W变得平滑代替验证。

连接后 records/ 自动生成：
1. *_unified.csv：原54字段X8002及派生量，格式保留。
2. *_feedforward.csv：独立Z8601诊断，包含主机时间、连接段、板卡T/Q/CF和原始行；首次收到Z才创建。
3. *_events.csv：连接事件和本地备注。

回放统一CSV时，同目录同名 *_feedforward.csv 会一并读取。旧CSV没有诊断文件也可回放；原文件不会被修改。回放和断线后的数值会标记历史/离线，不能作为板卡当前状态。
""",encoding='utf-8')
print('lifecycle, launcher and documentation updated')

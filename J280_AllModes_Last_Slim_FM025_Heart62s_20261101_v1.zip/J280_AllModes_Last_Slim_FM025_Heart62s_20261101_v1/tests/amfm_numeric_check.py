from pathlib import Path
import math,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
cfg=json.loads((ROOT/'config/trajectory_profiles.json').read_text(encoding='utf-8'))
rows=(ROOT/'rtl/trajectory_tables_ab.mem').read_text().splitlines()
checks=0
def ck(c,m):
 global checks
 checks+=1
 if not c:raise AssertionError(m)
def signed(x):return x if x<2**31 else x-2**32
def unpack(row):
 x=int(row,16);return [signed((x>>s)&0xffffffff) for s in [96,64,32,0]]
def n(x):return math.floor(x+.5) if x>=0 else -math.floor(-x+.5)
scale=408/360
ck(len(rows)==6150,'AM3150+FM3000 ROM')
peaks={}
for mode,count,start in [(1,3150,0),(2,3000,3150)]:
 p=[0,0,0,0]
 for i in range(count):
  t=i*.01;H=30.
  if mode==1:
   w=2*math.pi/3.5;z=2*math.pi/31.5
   a=H*(2+math.cos(z*t))/3;ad=-H*z*math.sin(z*t)/3
   add=-H*z*z*math.cos(z*t)/3;addd=H*z**3*math.sin(z*t)/3
   expected=(a*math.sin(w*t),ad*math.sin(w*t)+a*w*math.cos(w*t),
     add*math.sin(w*t)+2*ad*w*math.cos(w*t)-a*w*w*math.sin(w*t),
     addd*math.sin(w*t)+3*add*w*math.cos(w*t)-3*ad*w*w*math.sin(w*t)-a*w**3*math.cos(w*t))
  else:
   z=2*math.pi/30;phi=.6*math.pi*t-6*math.sin(z*t)
   w=2*math.pi*(.3-.2*math.cos(z*t));wd=2*math.pi*.2*z*math.sin(z*t);wdd=2*math.pi*.2*z*z*math.cos(z*t)
   expected=(H*math.sin(phi),H*w*math.cos(phi),H*(wd*math.cos(phi)-w*w*math.sin(phi)),
       H*(wdd*math.cos(phi)-3*w*wd*math.sin(phi)-w**3*math.cos(phi)))
  values=unpack(rows[start+i])
  for k,(got,value) in enumerate(zip(values,expected)):
   ck(abs(got-n(value*scale*(65536 if k==0 else 256)))<=1,f'ROM mode{mode} i{i} field{k}')
   p[k]=max(p[k],abs(value))
 peaks[str(mode)]=p
ck(abs((30*(2+math.cos(0))/3)/30-1)<1e-12,'AM maximum=H')
ck(abs((30*(2+math.cos(math.pi))/3)/30-1/3)<1e-12,'AM minimum=H/3')
ck(31500/3500==9,'AM nine complete carrier cycles')
for t,expected in [(0,.1),(15,.5),(30,.1)]:
 f=.3-.2*math.cos(2*math.pi*t/30);ck(abs(f-expected)<1e-12,'FM freq extrema')
 eps=1e-5
 phi=lambda x:.6*math.pi*x-6*math.sin(2*math.pi*x/30)
 ck(abs((phi(t+eps)-phi(t-eps))/(2*eps)/(2*math.pi)-f)<1e-9,'FM frequency is phase derivative')
ck(abs((.6*math.pi*30-6*math.sin(2*math.pi))/(2*math.pi)-9)<1e-12,'FM modulation period has9cycles')
for name in ['trajectory_tables_sine.mem']:
 ck((ROOT/'rtl'/name).read_bytes()==(ROOT/'reference_input/rtl'/name).read_bytes(),'ordinary11 ROM unchanged')
orig=(ROOT/'reference_input/rtl/trajectory_tables_envelope.mem').read_bytes()
ck((ROOT/'rtl/trajectory_tables_envelope.mem').read_bytes().startswith(orig),'ordinary11 envelope bytes unchanged')
for name in ['position_task.v','position_inputs.v','motion_reference_owner.v','cascade_control.v','motor_pwm.v','quadrature_encoder.v']:
 ck((ROOT/'rtl'/name).read_bytes()==(ROOT/'reference_input/rtl'/name).read_bytes(),'retained '+name)
# Independently recompute all-phase fixed-point derivative bounds from stored
# ROM maxima (linear interpolation cannot leave endpoint range), and the
# binomial product rule for the separate smooth start/stop envelope.
validation=json.loads((ROOT/'config/trajectory_validation.json').read_text())
envlines=(ROOT/'rtl/trajectory_tables_envelope.mem').read_text().splitlines()
modenv=[unpack(x) for x in envlines[601:]]
ck(len(modenv)==201,'AMFM envelope has201points')
wm=[max(abs(row[k]) for row in modenv) for k in range(4)]
representation={}
for name,count,start in [('am',3150,0),('fm',3000,3150)]:
 raw=[unpack(x) for x in rows[start:start+count]]
 mx=[max(abs(row[k]) for row in raw) for k in range(4)]
 q,v,a,j=mx;w0,w1,w2,w3=wm
 numerators=[q*w0,(v*w0<<8)+q*w1,(a*w0<<8)+2*(v*w1<<8)+q*w2,
             (j*w0<<8)+3*(a*w1<<8)+3*(v*w2<<8)+q*w3]
 limit=validation[name+'_numeric_representation_proof']['max_request_deci']
 bounds=[((n*limit//300)+(1<<23))>>24 for n in numerators[1:]]
 ck(all(b<2**31 for b in bounds),name+' all-phase signed32 V/A/J do not wrap at accepted limit')
 ck(max(numerators)<2**63,name+' shared64bit product sums do not wrap')
 ck(limit>=7200,name+' numeric representation supports720degrees')
 representation[name]={'max_request_deci':limit,'published_abs_bound_q8':bounds,'all_enter_exit_phases':True}
paths=['tests/amfm_numeric_check.py','rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem','config/trajectory_profiles.json']
for name in ['position_task.v','position_inputs.v','motion_reference_owner.v','cascade_control.v','motor_pwm.v','quadrature_encoder.v']:
 paths += ['rtl/'+name,'reference_input/rtl/'+name]
paths += ['config/trajectory_validation.json','reference_input/rtl/trajectory_tables_sine.mem','reference_input/rtl/trajectory_tables_envelope.mem']
report={'success':True,'checks':checks,'nominal_peaks_degree_units':peaks,'rom_rows':{'AM':3150,'FM':3000},'all_phase_representation_bounds':representation,
 'source_sha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths},'hardware_tested':False,
 'scope':'Independent degree-domain analytic q/v/a/j at every stored AM/FM ROM point; AM envelope extrema/9cycle ratio, FM frequency as numerical phase derivative at extrema/period, ordinary11 ROM/envelope exact-byte preservation and original position/PID/PWM/encoder module retention.'}
(ROOT/'tests/amfm_numeric_check_result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'},indent=2))

import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {simulate} from './fastspeed_wasm_adapter.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const cases=(process.argv[2]||'pos56,neg56,pos30,neg30,pos90,neg90,exit_early,exit_mid,lifecycle,pair_am,pair_fm').split(',');
const sources=['tests/heart_numeric.sv','rtl/trajectory_task.v','rtl/trajectory_tables.v','rtl/position_serial_div.v','rtl/trajectory_editor.v','rtl/position_inputs.v'];
for(const f of ['tests/heart_exit_numeric.sv','tests/heart_lifecycle.sv','tests/heart_pairs.sv','tests/heart_baseline_task.v','tests/heart_baseline_tables.v'])try{await readFile(resolve(root,f));sources.push(f);}catch{}
const paths=[...sources,'rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem','tests/heart_expected.mem'];
for(const f of ['tests/heart_baseline_ab.mem','tests/heart_baseline_sine.mem','tests/heart_baseline_envelope.mem'])try{await readFile(resolve(root,f));paths.push(f);}catch{}
const files=await Promise.all(paths.map(async p=>({path:p,data:await readFile(resolve(root,p),'utf8')})));
const source_sha256={};for(const p of [...paths,'scripts/generate_trajectory_tables.py','config/trajectory_profiles.json'])source_sha256[p]=createHash('sha256').update(await readFile(resolve(root,p))).digest('hex');
let failed=false;
for(const c of cases){
 console.log('RUN '+c);
 const r=await simulate({files,sources,top:'tb_heart_'+c,generation:'2012',timeoutMs:600000});
 const m=r.stdout?.match(new RegExp('ALL PASS heart case='+c+' assertions=(\\d+) publications=(\\d+) strict=(\\d+) cycles=(\\d+)'));
 const report={case:c,success:!!(r.success&&r.exitCode===0&&m),assertions:m?+m[1]:0,publications:m?+m[2]:0,strict:m?+m[3]:0,cycles:m?+m[4]:0,source_sha256,stdout:r.stdout,stderr:r.stderr,timings:r.timings,hardware_tested:false};
 await writeFile(resolve(root,'tests/heart_'+c+'_result.json'),JSON.stringify(report,null,2));
 await writeFile(resolve(root,'tests/heart_'+c+'_test.log'),r.combinedOutput||r.stdout+'\n'+r.stderr);
 console.log((report.success?'PASS ':'FAIL ')+c+' assertions='+report.assertions);
 if(!report.success){console.log((r.combinedOutput||r.stdout+'\n'+r.stderr).slice(-8000));failed=true;break;}
}
if(failed)process.exitCode=1;

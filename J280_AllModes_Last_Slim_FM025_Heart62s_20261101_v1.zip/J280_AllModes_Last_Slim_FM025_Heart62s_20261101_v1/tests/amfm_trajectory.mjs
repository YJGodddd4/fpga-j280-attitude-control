import {readFile,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const runtime=process.env.J280_VERILOG_RUNTIME||process.argv[3];
const {simulate}=runtime?await import(pathToFileURL(runtime).href):await import('./local_verilog_runtime.mjs');
const cases=['am30','amneg90','fm30','fmneg720','c90','c135','lifecycle'];
const sources=['tests/amfm_numeric.sv','tests/amfm_sine_pair.sv','tests/amfm_lifecycle.sv',
 'tests/amfm_original_task.v','tests/amfm_original_tables.v',
 'rtl/trajectory_task.v','rtl/trajectory_tables.v','rtl/position_serial_div.v','rtl/trajectory_editor.v','rtl/position_inputs.v'];
const mems=['rtl/trajectory_tables_ab.mem','rtl/trajectory_tables_sine.mem','rtl/trajectory_tables_envelope.mem',
 'reference_input/rtl/trajectory_tables_ab.mem','reference_input/rtl/trajectory_tables_sine.mem','reference_input/rtl/trajectory_tables_envelope.mem'];
const paths=[...sources,...mems];
const files=await Promise.all(paths.map(async p=>({path:p,data:await readFile(resolve(root,p),'utf8')})));
const hashPaths=[...paths,'tests/amfm_trajectory.mjs','config/trajectory_profiles.json','scripts/generate_trajectory_tables.py'];
const source_sha256={};for(const p of hashPaths)source_sha256[p]=createHash('sha256').update(await readFile(resolve(root,p))).digest('hex');
const chosen=process.argv[2]?process.argv[2].split(','):cases;
for(const c of chosen)if(!cases.includes(c))throw Error('unknown '+c);
let fail=false;
for(const c of chosen){
 console.log('RUN '+c);
 const r=await simulate({files,sources,top:'tb_amfm_'+c,generation:'2012',timeoutMs:600000});
 const m=r.stdout?.match(new RegExp('ALL PASS amfm case='+c+' assertions=(\\d+) publications=(\\d+) strict=(\\d+) cycles=(\\d+)'));
 const report={case:c,success:Boolean(r.success&&r.exitCode===0&&m),exit_code:r.exitCode,
 assertions:m?+m[1]:null,publications:m?+m[2]:null,strict:m?+m[3]:null,cycles:m?+m[4]:null,
 source_sha256,stdout:r.stdout,stderr:r.stderr,timings:r.timings};
 await writeFile(resolve(root,'tests/amfm_'+c+'_result.json'),JSON.stringify(report,null,2));
 await writeFile(resolve(root,'tests/amfm_'+c+'_test.log'),r.combinedOutput||r.stdout+'\n'+r.stderr);
 console.log((report.success?'PASS ':'FAIL ')+c+' assertions='+report.assertions);
 if(!report.success){console.log((r.combinedOutput||r.stdout+'\n'+r.stderr).slice(-7000));fail=true;break;}
}
const valid=[];
for(const c of cases){try{const r=JSON.parse(await readFile(resolve(root,'tests/amfm_'+c+'_result.json'),'utf8'));
 if(r.success&&Object.entries(source_sha256).every(([p,h])=>r.source_sha256[p]===h))valid.push({case:c,assertions:r.assertions,publications:r.publications,strict:r.strict,cycles:r.cycles});
}catch{}}
const original=root+'/reference_input/rtl/';
const retained={};for(const name of ['position_task.v','position_inputs.v','motion_reference_owner.v','cascade_control.v','motor_pwm.v','quadrature_encoder.v']){
 retained[name]=createHash('sha256').update(await readFile(resolve(root,'rtl',name))).digest('hex')===createHash('sha256').update(await readFile(original+name)).digest('hex');
}
const success=valid.length===cases.length&&Object.values(retained).every(Boolean);
const summary={success,source_sha256,cases:valid,assertions:valid.reduce((a,c)=>a+c.assertions,0),publications:valid.reduce((a,c)=>a+c.publications,0),
 strict_comparisons:valid.reduce((a,c)=>a+c.strict,0),retained_input_modules:retained,hardware_tested:false,
 scope:'Actual trajectory/editor/panel RTL plus current ROMs, independent analytic AM/FM q/v/a/j including full entry/exit and every10ms publication; signed30/90/720 variable amplitude with fixedAM/FM periods. Full original ordinary11 visible-output bitwise equivalence each FPGAclock at90 and135(TM2), original ROM cloned under separate names. Raw SW2/SW3/SW4, zero/negative edits, pending vs accepted values, smooth stop during entry, DIP stop, inflight balance loss and recapture/no auto replay, reset/globalstop.300FPGAclocks per logicalms; no mechanical plant or real serial/programmer action.'};
await writeFile(resolve(root,'tests/amfm_trajectory_result.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify({success,passed:valid.length,total:cases.length,assertions:summary.assertions,publications:summary.publications}));
if(fail||(!process.argv[2]&&!success))process.exitCode=1;

"""Independent truncated-series reference for the confirmed drawn heart."""
from pathlib import Path
import math,json,hashlib
ROOT=Path(__file__).resolve().parents[1]
class S:
 def __init__(self,x): self.c=tuple(x) if isinstance(x,(list,tuple)) else (float(x),0.,0.,0.)
 def __add__(self,y):
  y=y if isinstance(y,S) else S(y)
  return S([a+b for a,b in zip(self.c,y.c)])
 __radd__=__add__
 def __neg__(self):return S([-a for a in self.c])
 def __sub__(self,y):return self+(-y if isinstance(y,S) else -S(y))
 def __rsub__(self,y):return S(y)+(-self)
 def __mul__(self,y):
  y=y if isinstance(y,S) else S(y)
  return S([sum(self.c[k]*y.c[n-k] for k in range(n+1)) for n in range(4)])
 __rmul__=__mul__
 def __truediv__(self,y):return self*(y**-1 if isinstance(y,S) else 1/y)
 def __pow__(self,p):
  a=self.c[0];d=(self-a)/a
  return a**p*(1+p*d+p*(p-1)/2*d*d+p*(p-1)*(p-2)/6*d*d*d)
 def cos(self):
  a=self.c[0];d=self-a
  return math.cos(a)*(1-d*d/2)-math.sin(a)*(d-d*d*d/6)

def step(x):
 if x.c[0]<=0:return S(0)
 if x.c[0]>=1:return S(1)
 return x*x*x*x*(35+x*(-84+x*(70-20*x)))
# Root of 19 -4c -24c^2 -32c^3 =0 found independently by bisection.
lo,hi=0.,1.
for _ in range(80):
 m=(lo+hi)/2
 if 19-4*m-24*m*m-32*m*m*m>0:lo=m
 else:hi=m
cp=(lo+hi)/2;peak=19*cp-2*cp**2-8*cp**3-8*cp**4
def at(t):
 if t<=0 or t>=56:return (0.,)*6
 x=S((t,1.,0.,0.));s=x/28-1;eps=.045
 rho=((s*s+eps*eps)**(1/3)-eps**(2/3))/((1+eps*eps)**(1/3)-eps**(2/3))
 c=(1-rho)**.5
 u=(19*c-2*c*c-8*c*c*c-8*c*c*c*c)*(19.5/peak)
 r=((s*s+.0004)**.5-.02)/(math.sqrt(1.0004)-.02)
 l=-56*(1-r)**.65
 g=step(x/2)*step((56-x)/2);u=u*g;l=l*g
 q=(u+l)/2-(u-l)/2*(2*math.pi/4*(x-28)).cos()
 return(q.c[0],q.c[1],q.c[2]*2,q.c[3]*6,u.c[0],l.c[0])
def rn(x):return int(math.floor(x+.5)) if x>=0 else -int(math.floor(-x+.5))
def main():
 rows=[at(i/100) for i in range(5600)]
 assert all(l-1e-8<=q<=u+1e-8 for q,v,a,j,u,l in rows)
 assert max(abs(rows[i][0]-at(56-i/100)[0]) for i in range(5600))<1e-8
 assert abs(at(28)[0]+56)<1e-10
 errs=[0.,0.,0.];h=1e-4
 for i in range(151):
  t=.13+(56-.26)*i/150;c=at(t);p=at(t+h);m=at(t-h)
  for k in range(3):errs[k]=max(errs[k],abs((p[k]-m[k])/(2*h)-c[k+1]))
 assert max(errs)<.01,errs
 lines=[]
 for row in rows:
  values=[rn(x*408/360*(65536 if k in (0,4,5) else 256)) for k,x in enumerate(row)]
  lines.append(''.join(f'{v&0xffffffff:08X}' for v in values))
 (ROOT/'tests/heart_expected.mem').write_text('\n'.join(lines)+'\n',encoding='ascii')
 result={'reference':'independent order-three Taylor series; no production-generator import',
  'T_s':56,'carrier_cycles':14,'carrier_period_s':4,'sampling_ms':10,'sample_count':len(rows),
  'q_range_degrees':[min(r[0] for r in rows),max(r[0] for r in rows)],
  'peak_derivative_degrees':[max(abs(r[k]) for r in rows) for k in (1,2,3)],
  'finite_difference_max_errors':errs,'endpoint_q_v_a_j':[at(0)[:4],at(56)[:4]],'hardware_tested':False}
 (ROOT/'tests/heart_math_result.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()

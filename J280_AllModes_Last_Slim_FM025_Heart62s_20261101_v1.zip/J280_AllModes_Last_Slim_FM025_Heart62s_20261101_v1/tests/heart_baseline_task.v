// Editable analytic references. Original PID still consumes only integer R.
// Real10ms cadence; exact rational phase and Q24 ROM interpolation.
// One shared32x32 multiplier;96-bit scaling uses two products and serial divide.
// [AMFM_V85] Centered AM/FM periodic references; original sine behavior retained.
// AM/FM amplitude editing leaves their time periods unchanged.
module heart_baseline_task(
 input wire clk,input wire rst_n,input wire tick_ms,
 input wire owned,input wire balance_ready,input wire stop_event,
 input wire adopt_event,input wire signed [31:0] adopt_reference,
 input wire [1:0] selected_mode,input wire selection_valid,input wire confirm_event,
 input wire signed [31:0] requested_deci,
 output reg signed [31:0] accepted_deci,output reg [31:0] time_stretch,output reg [15:0] run_id,
 output reg target_update,output reg signed [31:0] target_value,
 output reg signed [31:0] reference_position,reference_speed_q8,
 output reg signed [31:0] reference_acceleration_q8,reference_jerk_q8,
 output reg signed [31:0] center_position,endpoint_position,
 output reg [1:0] active_profile,output reg [3:0] trajectory_state,
 output reg [15:0] phase,output reg [31:0] cycle_count,elapsed_ms,
 output wire [31:0] cycle_ms,config_tag,
 output reg base_valid,running,stop_pending,interrupted,
 output wire jerk_valid,acceleration_valid,held_idle
);
 localparam [3:0] DISABLED=0,READY=1,PLAYING=2,DWELL=3,STOPPING=4,INTERRUPTED=5,PREPARING=6;
 localparam [6:0] IDLE=0,FRAC_START=1,FRAC_WAIT=2,ENV_FRAC_WAIT=3,ROM0_WAIT=4,ROM0_LATCH=5,
  ROM1_WAIT=6,ROM1_LATCH=7,INTERP_START=8,INTERP_MUL=9,INTERP_STORE=10,PREP_ENV=11,
  ENV_MUL=12,ENV_STORE=13,CORE0=14,CORE1=15,CORE2=16,CORE3=17,SCALE_SELECT=18,
  SCALE_LOW_MUL=19,SCALE_LOW_STORE=20,SCALE_HIGH_MUL=21,SCALE_HIGH_STORE=22,SCALE_JOIN=23,
  SCALE_DIV_WAIT=24,SCALE_STORE=26,POSITION_SUM=27,PUBLISH=28,
  PREP_STRETCH=40,PREP_STRETCH_WAIT=41,PREP_CYCLE_MUL=42,PREP_CYCLE_STORE=43,
  PREP_ENDPOINT_MUL=44,PREP_ENDPOINT_STORE=45,PREP_ENDPOINT_WAIT=46,PREP_FINISH=47,
  PREP_CLIP=48,PREP_ACCEPT=49,PREP_NUMERATOR=50,PREP_ENDPOINT_ROUND=51,PREP_ENDPOINT_DIV=52,
  PREP_ENDPOINT_SUM=53,INTERP_ROUND=54,INTERP_SIGN=55,INTERP_ADD=56,
  SCALE_ROUND_MID=57,SCALE_ROUND_HIGH=58,SCALE_ROUND_JOIN=59,SCALE_ABS=60,MULTIPLY_WAIT=61,
  PREP_CENTER_DIV=62,PREP_CENTER_WAIT=63,PREP_CENTER_SUM=64;
 reg [6:0] math_state;
 reg [31:0] sample_count,phase_remainder,envelope_remainder,clock_elapsed_ms,sample_elapsed_ms;
 reg [15:0] sample_index,envelope_index,dwell_count;
  reg leg_reverse,dwelling,prepared,read_second;
 // Locked center: all periodic references are relative to this held origin.
 reg signed [31:0] run_origin_position;
 reg [1:0] envelope_stage;
 wire signed [31:0] table_q16,table_v8,table_a8,table_j8,table_w0,table_w1,table_w2,table_w3;
 wire [7:0] table_phase;
 wire [15:0] leg_ticks,dwell_ticks,sine_ticks,envelope_ticks;
 wire [31:0] table_cycle_ms,sample_ms,base_deci,max_request_deci,units_per_turn;
 wire signed [31:0] stroke_units,stroke_q16;
 wire [15:0] next_sample_index=sample_index>=sine_ticks-1 ? 16'd0 : sample_index+1'b1;
 wire [15:0] next_envelope_index=envelope_index>=envelope_ticks ? envelope_ticks : envelope_index+1'b1;
 heart_baseline_tables u_tables(.clk(clk),.profile(active_profile),
  .sample_index(read_second ? next_sample_index : sample_index),.envelope_index(read_second ? next_envelope_index : envelope_index),
  .q16(table_q16),.v8(table_v8),.a8(table_a8),.j8(table_j8),.w0(table_w0),.w1(table_w1),.w2(table_w2),.w3(table_w3),
  .sample_phase(table_phase),.leg_ticks(leg_ticks),.dwell_ticks(dwell_ticks),.sine_ticks(sine_ticks),.envelope_ticks(envelope_ticks),
  .profile_cycle_ms(table_cycle_ms),.sample_ms(sample_ms),.config_tag(config_tag),.stroke_units(stroke_units),.stroke_q16(stroke_q16),
  .base_deci(base_deci),.max_request_deci(max_request_deci),.units_per_turn(units_per_turn));
 reg [31:0] scaled_cycle_ms;
 assign cycle_ms=active_profile==0 ? 32'd0 : scaled_cycle_ms;
 assign held_idle=base_valid && !running && math_state==IDLE && trajectory_state==READY;
 reg numeric_clipped;
 assign jerk_valid=base_valid && running && prepared && !numeric_clipped && active_profile!=0;
 assign acceleration_valid=base_valid && running && prepared && !numeric_clipped && active_profile!=0;
 wire request_stop=confirm_event || !selection_valid || selected_mode!=active_profile;
 wire advance_sample=tick_ms && prepared && sample_count>=sample_ms-1 && math_state==IDLE;
 wire advance_base=phase_remainder+32'd1>=time_stretch;
 wire finish_dwell=advance_base && dwell_count+16'd1>=dwell_ticks;
 reg [32:0] request_abs;
 reg request_negative,scale_negative;
 reg [31:0] accepted_abs;
 reg [31:0] base_deci_latched,max_request_latched,cycle_ms_latched,units_per_turn_latched;
 reg [32:0] prep_stretch_sum;
 reg [63:0] endpoint_product,endpoint_rounded;
  reg signed [63:0] endpoint_sum;
  reg signed [63:0] center_offset,center_sum;
  reg signed [31:0] far_endpoint_position,near_endpoint_position;
 wire [32:0] incoming_abs=requested_deci[31] ? {1'b0,~requested_deci}+33'd1 : {1'b0,requested_deci};
 wire [31:0] clipped_request=request_abs>{1'b0,max_request_latched} ? max_request_latched : request_abs[31:0];
 reg div_start;wire div_busy,div_done;reg [95:0] div_numerator;reg [31:0] div_denominator;wire [95:0] div_quotient;
 wire div_rst_n=rst_n && owned && balance_ready && !stop_event && !adopt_event;
 position_serial_div #(.NUM_WIDTH(96),.DEN_WIDTH(32)) u_div(.clk(clk),.rst_n(div_rst_n),.start(div_start),
  .numerator(div_numerator),.denominator(div_denominator),.busy(div_busy),.done(div_done),.quotient(div_quotient));
 reg [24:0] phase_fraction,envelope_fraction;
 reg signed [31:0] row0[0:7],row1[0:7],interpolated[0:7];
 reg [3:0] interpolation_index,product_index;
 reg [7:0] phase_latched,rom_phase;
 reg last_leg_sample,last_exit_sample,last_entry_sample;
 reg signed [31:0] q16_latched,v8_latched,a8_latched,j8_latched,w0_latched,w1_latched,w2_latched,w3_latched;
 reg signed [31:0] multiply_left,multiply_right;
 reg signed [31:0] multiply_left_reg,multiply_right_reg;
 reg [6:0] multiply_return;
 reg signed [63:0] multiply_result,products[0:9],q_num,v_num,a_num,j_num,a_pair,j_pair1,j_pair2,p7triple,p8triple;
 reg [1:0] scale_index,divisions_left;
 reg [63:0] scale_magnitude,scale_low,scale_high;
 reg [32:0] scale_middle;
 reg signed [63:0] scale_raw;
 reg [32:0] round_low,round_middle;
 reg [63:0] round_upper;
 reg [31:0] round_high;
 wire [31:0] scale_upper=scale_high[63:32]+{32{scale_low[63]}}+{31'd0,scale_middle[32]};
 reg result_negative;reg [95:0] rounded_result;
 reg signed [63:0] q_offset,position_sum,endpoint_offset;
 reg signed [31:0] pending_v,pending_a,pending_j;
 wire [24:0] interpolation_fraction=interpolation_index<4 ? phase_fraction : envelope_fraction;
 wire signed [31:0] interpolation_delta=row1[interpolation_index]-row0[interpolation_index];
 reg interpolation_negative;
 reg [63:0] interpolation_magnitude,interpolation_rounded_magnitude;
 reg signed [31:0] interpolation_base,interpolation_signed_delta;
 integer k;
 function signed [31:0] clamp32;
  input signed [63:0] x;
  begin clamp32=x>64'sd2147483647 ? 32'sh7fffffff : (x< -64'sd2147483648 ? 32'sh80000000 : x[31:0]);end
 endfunction
 always @*begin
  multiply_left=0;multiply_right=0;
  if(math_state==INTERP_MUL || math_state==INTERP_STORE)begin multiply_left=interpolation_delta;multiply_right=$signed({7'd0,interpolation_fraction});end
  else if(math_state==SCALE_LOW_MUL || math_state==SCALE_LOW_STORE)begin multiply_left=$signed(scale_magnitude[31:0]);multiply_right=$signed(accepted_abs);end
  else if(math_state==SCALE_HIGH_MUL || math_state==SCALE_HIGH_STORE)begin multiply_left=$signed(scale_magnitude[63:32]+{31'd0,scale_magnitude[31]});multiply_right=$signed(accepted_abs);end
  else if(math_state==PREP_CYCLE_MUL || math_state==PREP_CYCLE_STORE)begin multiply_left=$signed(cycle_ms_latched);multiply_right=$signed(time_stretch);end
  else if(math_state==PREP_ENDPOINT_MUL || math_state==PREP_ENDPOINT_STORE)begin multiply_left=$signed(accepted_abs);multiply_right=$signed(units_per_turn_latched);end
  else case(product_index)
   0:begin multiply_left=q16_latched;multiply_right=w0_latched;end
   1:begin multiply_left=v8_latched;multiply_right=w0_latched;end
   2:begin multiply_left=q16_latched;multiply_right=w1_latched;end
   3:begin multiply_left=a8_latched;multiply_right=w0_latched;end
   4:begin multiply_left=v8_latched;multiply_right=w1_latched;end
   5:begin multiply_left=q16_latched;multiply_right=w2_latched;end
   6:begin multiply_left=j8_latched;multiply_right=w0_latched;end
   7:begin multiply_left=a8_latched;multiply_right=w1_latched;end
   8:begin multiply_left=v8_latched;multiply_right=w2_latched;end
   9:begin multiply_left=q16_latched;multiply_right=w3_latched;end
   default:begin end
  endcase
 end
 // Operand mux/subtract and the single multiplier occupy separate clocks.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin multiply_left_reg<=0;multiply_right_reg<=0;multiply_result<=0;end
  else begin
   if(math_state==INTERP_MUL || math_state==SCALE_LOW_MUL || math_state==SCALE_HIGH_MUL || math_state==ENV_MUL || math_state==PREP_CYCLE_MUL || math_state==PREP_ENDPOINT_MUL)begin
    multiply_left_reg<=multiply_left;multiply_right_reg<=multiply_right;
   end
   if(math_state==MULTIPLY_WAIT)multiply_result<=multiply_left_reg*multiply_right_reg;
  end
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   target_update<=0;target_value<=0;reference_position<=0;reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;
   center_position<=0;endpoint_position<=0;active_profile<=0;trajectory_state<=DISABLED;phase<=0;cycle_count<=0;elapsed_ms<=0;clock_elapsed_ms<=0;sample_elapsed_ms<=0;
   base_valid<=0;running<=0;stop_pending<=0;interrupted<=0;numeric_clipped<=0;prepared<=0;read_second<=0;
   accepted_deci<=0;time_stretch<=1;run_id<=0;request_abs<=0;request_negative<=0;scale_negative<=0;accepted_abs<=0;scaled_cycle_ms<=0;
   base_deci_latched<=1;max_request_latched<=0;cycle_ms_latched<=0;units_per_turn_latched<=0;prep_stretch_sum<=0;
    endpoint_product<=0;endpoint_rounded<=0;endpoint_sum<=0;far_endpoint_position<=0;multiply_return<=0;
    center_offset<=0;center_sum<=0;near_endpoint_position<=0;run_origin_position<=0;
   math_state<=IDLE;sample_count<=0;sample_index<=0;envelope_index<=0;dwell_count<=0;phase_remainder<=0;envelope_remainder<=0;
   leg_reverse<=0;dwelling<=0;envelope_stage<=0;product_index<=0;interpolation_index<=0;phase_fraction<=0;envelope_fraction<=0;
   q16_latched<=0;v8_latched<=0;a8_latched<=0;j8_latched<=0;w0_latched<=0;w1_latched<=0;w2_latched<=0;w3_latched<=0;
   phase_latched<=0;rom_phase<=0;last_leg_sample<=0;last_exit_sample<=0;last_entry_sample<=0;
   q_num<=0;v_num<=0;a_num<=0;j_num<=0;a_pair<=0;j_pair1<=0;j_pair2<=0;p7triple<=0;p8triple<=0;
   scale_index<=0;divisions_left<=0;scale_magnitude<=0;scale_low<=0;scale_high<=0;scale_middle<=0;result_negative<=0;rounded_result<=0;
   scale_raw<=0;round_low<=0;round_middle<=0;round_upper<=0;round_high<=0;
   interpolation_negative<=0;interpolation_magnitude<=0;interpolation_rounded_magnitude<=0;interpolation_base<=0;interpolation_signed_delta<=0;
   q_offset<=0;pending_v<=0;pending_a<=0;pending_j<=0;position_sum<=0;endpoint_offset<=0;
   div_start<=0;div_numerator<=0;div_denominator<=1;
   for(k=0;k<10;k=k+1)products[k]<=0;
   for(k=0;k<8;k=k+1)begin row0[k]<=0;row1[k]<=0;interpolated[k]<=0;end
  end else begin
   target_update<=0;div_start<=0;
   // Explicit stop/loss wins over adoption, editing, and pending arithmetic.
   if(stop_event || !balance_ready)begin
    if(running)interrupted<=1;
     running<=0;base_valid<=0;stop_pending<=0;math_state<=IDLE;sample_count<=0;prepared<=0;
    trajectory_state<=running ? INTERRUPTED : DISABLED;reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;
   end else if(adopt_event)begin
     target_value<=adopt_reference;reference_position<=adopt_reference;center_position<=adopt_reference;endpoint_position<=adopt_reference;far_endpoint_position<=adopt_reference;
     near_endpoint_position<=adopt_reference;run_origin_position<=adopt_reference;
    reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;
    base_valid<=1;running<=0;stop_pending<=0;math_state<=IDLE;sample_count<=0;prepared<=0;
    active_profile<=0;trajectory_state<=READY;phase<=0;cycle_count<=0;elapsed_ms<=0;clock_elapsed_ms<=0;sample_elapsed_ms<=0;numeric_clipped<=0;scaled_cycle_ms<=0;
   end else if(!owned)begin
    if(running)interrupted<=1;
     running<=0;base_valid<=0;stop_pending<=0;math_state<=IDLE;trajectory_state<=DISABLED;prepared<=0;
    reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;
   end else if(base_valid)begin
    if(!running)begin
     if(confirm_event && selection_valid && selected_mode!=0 && math_state==IDLE)begin
      if(requested_deci==0)begin accepted_deci<=0;time_stretch<=1;scaled_cycle_ms<=0;end
      else begin
       center_position<=reference_position;run_origin_position<=reference_position;active_profile<=selected_mode;request_abs<=incoming_abs;request_negative<=requested_deci[31];
       running<=1;stop_pending<=0;interrupted<=0;trajectory_state<=PREPARING;prepared<=0;run_id<=run_id+1'b1;
       phase<=0;cycle_count<=0;elapsed_ms<=0;clock_elapsed_ms<=0;sample_elapsed_ms<=0;sample_count<=0;sample_index<=0;envelope_index<=0;phase_remainder<=0;envelope_remainder<=0;
        // Every periodic profile has its own smooth entry/exit envelope.
        leg_reverse<=0;dwelling<=0;dwell_count<=0;envelope_stage<=1;numeric_clipped<=0;math_state<=PREP_STRETCH;
      end
     end
    end else begin
     if(request_stop)begin stop_pending<=1;trajectory_state<=STOPPING;end
     if(tick_ms && prepared)begin
      clock_elapsed_ms<=clock_elapsed_ms+1'b1;
      if(sample_count<sample_ms-1)sample_count<=sample_count+1'b1;
     end
     if(advance_sample)begin
      sample_count<=0;
      if(advance_base)phase_remainder<=0;else phase_remainder<=phase_remainder+1'b1;
      if(active_profile!=0)begin
       if(advance_base)begin
        if(sample_index>=sine_ticks-1)begin sample_index<=0;cycle_count<=cycle_count+1'b1;end else sample_index<=sample_index+1'b1;
       end
       if(envelope_stage==1 || envelope_stage==3)begin
        if(envelope_remainder+1'b1>=time_stretch)begin envelope_remainder<=0;if(envelope_index<envelope_ticks)envelope_index<=envelope_index+1'b1;end
        else envelope_remainder<=envelope_remainder+1'b1;
       end else if(stop_pending || request_stop)begin
        envelope_stage<=3;envelope_index<=time_stretch==1 ? 16'd1 : 16'd0;envelope_remainder<=time_stretch==1 ? 32'd0 : 32'd1;
       end
       math_state<=FRAC_START;
      end else if(dwelling && (stop_pending || request_stop))begin
       running<=0;stop_pending<=0;trajectory_state<=READY;reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;
      end else if(dwelling && finish_dwell)begin
       dwell_count<=0;dwelling<=0;sample_index<=0;leg_reverse<=!leg_reverse;trajectory_state<=PLAYING;
        // [FULL_START_7S修改] 端点为origin与origin+2H，负TA反转首程方向。
        endpoint_position<=leg_reverse ? far_endpoint_position : near_endpoint_position;
        // 首程和反程及两端驻留均完成后记为一个完整往返。
        if(leg_reverse)cycle_count<=cycle_count+1'b1;
       math_state<=FRAC_START;
      end else if(dwelling)begin
       if(advance_base)dwell_count<=dwell_count+1'b1;
       math_state<=FRAC_START;
      end else begin
       if(advance_base && sample_index<leg_ticks)sample_index<=sample_index+1'b1;
       math_state<=FRAC_START;
      end
     end
     case(math_state)
      PREP_STRETCH:begin
       base_deci_latched<=base_deci;max_request_latched<=max_request_deci;cycle_ms_latched<=table_cycle_ms;units_per_turn_latched<=units_per_turn;
       math_state<=PREP_CLIP;
      end
      PREP_CLIP:begin accepted_abs<=clipped_request;math_state<=PREP_ACCEPT;end
      PREP_ACCEPT:begin
       accepted_deci<=request_negative ? -$signed(accepted_abs) : $signed(accepted_abs);scale_negative<=request_negative;
       prep_stretch_sum<={1'b0,accepted_abs}+{1'b0,base_deci_latched};math_state<=PREP_NUMERATOR;
      end
      // AM/FM keep time independent of amplitude. Preserve the original C divider sequence.
      PREP_NUMERATOR:begin div_numerator<=active_profile==3 ? {63'd0,(prep_stretch_sum-33'd1)} : {64'd0,base_deci_latched};div_denominator<=base_deci_latched;div_start<=1;math_state<=PREP_STRETCH_WAIT;end
      PREP_STRETCH_WAIT:if(div_done)begin time_stretch<=div_quotient[31:0]==0 ? 32'd1 : div_quotient[31:0];math_state<=PREP_CYCLE_MUL;end
      PREP_CYCLE_MUL:begin multiply_return<=PREP_CYCLE_STORE;math_state<=MULTIPLY_WAIT;end
      PREP_CYCLE_STORE:begin scaled_cycle_ms<=multiply_result[31:0];math_state<=PREP_ENDPOINT_MUL;end
      PREP_ENDPOINT_MUL:begin multiply_return<=PREP_ENDPOINT_STORE;math_state<=MULTIPLY_WAIT;end
      PREP_ENDPOINT_STORE:begin endpoint_product<=multiply_result;math_state<=PREP_ENDPOINT_ROUND;end
      PREP_ENDPOINT_ROUND:begin endpoint_rounded<=endpoint_product+64'd1800;math_state<=PREP_ENDPOINT_DIV;end
      PREP_ENDPOINT_DIV:begin div_numerator<={32'd0,endpoint_rounded};div_denominator<=32'd3600;div_start<=1;math_state<=PREP_ENDPOINT_WAIT;end
      PREP_ENDPOINT_WAIT:if(div_done)begin endpoint_offset<=scale_negative ? -$signed(div_quotient[63:0]) : $signed(div_quotient[63:0]);math_state<=PREP_ENDPOINT_SUM;end
       PREP_ENDPOINT_SUM:begin
        // 完整位移只舍入一次；不以已取整中点加减半幅拼接端点。
        endpoint_sum<=$signed({{32{run_origin_position[31]}},run_origin_position})+endpoint_offset;
        math_state<=PREP_CENTER_DIV;
       end
      PREP_CENTER_DIV:begin
       div_numerator<={32'd0,endpoint_product}+96'd1800;div_denominator<=3600;div_start<=1;math_state<=PREP_CENTER_WAIT;
      end
      PREP_CENTER_WAIT:if(div_done)begin center_offset<=scale_negative ? -$signed(div_quotient[63:0]) : $signed(div_quotient[63:0]);math_state<=PREP_CENTER_SUM;end
      PREP_CENTER_SUM:begin center_sum<=$signed({{32{run_origin_position[31]}},run_origin_position})+center_offset;math_state<=PREP_FINISH;end
      PREP_FINISH:begin
       center_position<=run_origin_position;
       far_endpoint_position<=run_origin_position;
       near_endpoint_position<=run_origin_position;
       endpoint_position<=run_origin_position;
       prepared<=1;trajectory_state<=(stop_pending || request_stop) ? STOPPING : PLAYING;math_state<=FRAC_START;
      end
      FRAC_START:begin
       read_second<=0;sample_elapsed_ms<=clock_elapsed_ms;
       if(time_stretch==1)begin phase_fraction<=0;envelope_fraction<=0;math_state<=ROM0_WAIT;end
       else begin div_numerator<={40'd0,phase_remainder,24'd0};div_denominator<=time_stretch;div_start<=1;math_state<=FRAC_WAIT;end
      end
      FRAC_WAIT:if(div_done)begin
       phase_fraction<=div_quotient[24:0];
       if(active_profile!=0 && envelope_stage!=2)begin div_numerator<={40'd0,envelope_remainder,24'd0};div_denominator<=time_stretch;div_start<=1;math_state<=ENV_FRAC_WAIT;end
       else begin envelope_fraction<=0;math_state<=ROM0_WAIT;end
      end
      ENV_FRAC_WAIT:if(div_done)begin envelope_fraction<=div_quotient[24:0];math_state<=ROM0_WAIT;end
      ROM0_WAIT:math_state<=ROM0_LATCH;
      ROM0_LATCH:begin
       row0[0]<=table_q16;row0[1]<=table_v8;row0[2]<=table_a8;row0[3]<=table_j8;
       row0[4]<=table_w0;row0[5]<=table_w1;row0[6]<=table_w2;row0[7]<=table_w3;rom_phase<=table_phase;
       read_second<=1;math_state<=ROM1_WAIT;
      end
      ROM1_WAIT:math_state<=ROM1_LATCH;
      ROM1_LATCH:begin
       row1[0]<=table_q16;row1[1]<=table_v8;row1[2]<=table_a8;row1[3]<=table_j8;
       row1[4]<=table_w0;row1[5]<=table_w1;row1[6]<=table_w2;row1[7]<=table_w3;
       read_second<=0;interpolation_index<=0;math_state<=INTERP_START;
      end
      INTERP_START:begin
       if(interpolation_fraction==0)begin
        interpolated[interpolation_index]<=row0[interpolation_index];
        if(interpolation_index==7)math_state<=PREP_ENV;else interpolation_index<=interpolation_index+1'b1;
       end else begin interpolation_base<=row0[interpolation_index];math_state<=INTERP_MUL;end
      end
      INTERP_MUL:begin multiply_return<=INTERP_STORE;math_state<=MULTIPLY_WAIT;end
      INTERP_STORE:begin
       interpolation_negative<=multiply_result[63];interpolation_magnitude<=multiply_result[63] ? -multiply_result : multiply_result;
       math_state<=INTERP_ROUND;
      end
      INTERP_ROUND:begin interpolation_rounded_magnitude<=interpolation_magnitude+64'd8388608;math_state<=INTERP_SIGN;end
      INTERP_SIGN:begin
       interpolation_signed_delta<=interpolation_negative ? -$signed(interpolation_rounded_magnitude[55:24]) : $signed(interpolation_rounded_magnitude[55:24]);
       math_state<=INTERP_ADD;
      end
      INTERP_ADD:begin
       interpolated[interpolation_index]<=interpolation_base+interpolation_signed_delta;
       if(interpolation_index==7)math_state<=PREP_ENV;else begin interpolation_index<=interpolation_index+1'b1;math_state<=INTERP_START;end
      end
       PREP_ENV:begin
        // [AMFM_V85] ROM q is signed displacement around the locked center.
        q16_latched<=interpolated[0];
        v8_latched<=interpolated[1];a8_latched<=interpolated[2];j8_latched<=interpolated[3];
       if(active_profile!=0 && envelope_stage!=2)begin
        w0_latched<=envelope_stage==1 ? interpolated[4] : 32'sd65536-interpolated[4];
        w1_latched<=envelope_stage==1 ? interpolated[5] : -interpolated[5];
        w2_latched<=envelope_stage==1 ? interpolated[6] : -interpolated[6];w3_latched<=envelope_stage==1 ? interpolated[7] : -interpolated[7];
       end else begin w0_latched<=65536;w1_latched<=0;w2_latched<=0;w3_latched<=0;end
       phase_latched<={6'd0,envelope_stage};
       last_leg_sample<=1'b0;
       last_exit_sample<=active_profile!=0 && envelope_stage==3 && envelope_index>=envelope_ticks;
       last_entry_sample<=active_profile!=0 && envelope_stage==1 && envelope_index>=envelope_ticks;
       product_index<=0;math_state<=ENV_MUL;
      end
      ENV_MUL:begin multiply_return<=ENV_STORE;math_state<=MULTIPLY_WAIT;end
      ENV_STORE:begin products[product_index]<=multiply_result;if(product_index==9)math_state<=CORE0;else begin product_index<=product_index+1'b1;math_state<=ENV_MUL;end end
      CORE0:begin p7triple<=products[7]+(products[7]<<<1);p8triple<=products[8]+(products[8]<<<1);q_num<=products[0];math_state<=CORE1;end
      CORE1:begin v_num<=(products[1]<<<8)+products[2];a_pair<=(products[3]<<<8)+(products[4]<<<9);math_state<=CORE2;end
      CORE2:begin a_num<=a_pair+products[5];j_pair1<=(products[6]<<<8)+(p7triple<<<8);j_pair2<=(p8triple<<<8)+products[9];math_state<=CORE3;end
      CORE3:begin j_num<=j_pair1+j_pair2;scale_index<=0;math_state<=SCALE_SELECT;end
      SCALE_SELECT:begin
        // 首程及所有后续行程共用完整缩放，保留原96位算术及TM幂次。
       case(scale_index)
         0:scale_raw<=q_num;
         1:scale_raw<=v_num;
         2:scale_raw<=a_num;
         3:scale_raw<=j_num;
       endcase
       math_state<=SCALE_ABS;
      end
      SCALE_ABS:begin scale_magnitude<=scale_raw[63] ? -scale_raw : scale_raw;result_negative<=scale_raw[63]^scale_negative;math_state<=SCALE_LOW_MUL;end
      SCALE_LOW_MUL:begin multiply_return<=SCALE_LOW_STORE;math_state<=MULTIPLY_WAIT;end
      SCALE_LOW_STORE:begin scale_low<=multiply_result;math_state<=SCALE_HIGH_MUL;end
      SCALE_HIGH_MUL:begin multiply_return<=SCALE_HIGH_STORE;math_state<=MULTIPLY_WAIT;end
      SCALE_HIGH_STORE:begin scale_high<=multiply_result;scale_middle<={1'b0,scale_low[63:32]}+{1'b0,multiply_result[31:0]};math_state<=SCALE_JOIN;end
      SCALE_JOIN:begin div_numerator<={scale_upper,scale_middle[31:0],scale_low[31:0]};div_denominator<=base_deci_latched;div_start<=1;divisions_left<=scale_index;math_state<=SCALE_DIV_WAIT;end
      SCALE_DIV_WAIT:if(div_done)begin
       if(divisions_left!=0)begin div_numerator<=div_quotient;div_denominator<=time_stretch;div_start<=1;divisions_left<=divisions_left-1'b1;end
       else begin
        round_low<={1'b0,div_quotient[31:0]}+(scale_index==0 ? 33'd2147483648 : 33'd8388608);
        round_upper<=div_quotient[95:32];math_state<=SCALE_ROUND_MID;
       end
      end
      SCALE_ROUND_MID:begin round_middle<={1'b0,round_upper[31:0]}+{32'd0,round_low[32]};math_state<=SCALE_ROUND_HIGH;end
      SCALE_ROUND_HIGH:begin round_high<=round_upper[63:32]+{31'd0,round_middle[32]};math_state<=SCALE_ROUND_JOIN;end
      SCALE_ROUND_JOIN:begin rounded_result<={round_high,round_middle[31:0],round_low[31:0]};math_state<=SCALE_STORE;end
      SCALE_STORE:begin
       case(scale_index)
        0:q_offset<=result_negative ? -$signed(rounded_result[95:32]) : $signed(rounded_result[95:32]);
        1:pending_v<=result_negative ? -$signed(rounded_result[55:24]) : $signed(rounded_result[55:24]);
        2:pending_a<=result_negative ? -$signed(rounded_result[55:24]) : $signed(rounded_result[55:24]);
        3:pending_j<=result_negative ? -$signed(rounded_result[55:24]) : $signed(rounded_result[55:24]);
       endcase
       if(scale_index==3)math_state<=POSITION_SUM;else begin scale_index<=scale_index+1'b1;math_state<=SCALE_SELECT;end
      end
      POSITION_SUM:begin position_sum<=$signed({{32{run_origin_position[31]}},run_origin_position})+q_offset;math_state<=PUBLISH;end
      PUBLISH:begin
       reference_position<=clamp32(position_sum);target_value<=clamp32(position_sum);target_update<=1;elapsed_ms<=sample_elapsed_ms;
       numeric_clipped<=position_sum>64'sd2147483647 || position_sum< -64'sd2147483648;
       if(position_sum>64'sd2147483647 || position_sum< -64'sd2147483648)begin reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;end
       else begin reference_speed_q8<=pending_v;reference_acceleration_q8<=pending_a;reference_jerk_q8<=pending_j;end
       phase<={8'd0,phase_latched};math_state<=IDLE;
       if(last_exit_sample)begin running<=0;stop_pending<=0;trajectory_state<=READY;reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;end
       else if(last_entry_sample)begin
        if(stop_pending || request_stop)begin envelope_stage<=3;envelope_index<=0;envelope_remainder<=0;trajectory_state<=STOPPING;end
        else begin envelope_stage<=2;trajectory_state<=PLAYING;end
       end else if(last_leg_sample)begin
        reference_speed_q8<=0;reference_acceleration_q8<=0;reference_jerk_q8<=0;
        if(stop_pending || request_stop)begin running<=0;stop_pending<=0;trajectory_state<=READY;end
        else begin dwelling<=1;dwell_count<=0;phase_remainder<=0;trajectory_state<=DWELL;phase<=leg_reverse ? 16'd16 : 16'd8;end
       end
      end
      MULTIPLY_WAIT:math_state<=multiply_return;
      default:begin end
     endcase
    end
   end
  end
 end
endmodule



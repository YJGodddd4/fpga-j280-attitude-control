// Copy this file and tb_dfilter_control.sv into NEW_PROJECT/tests,then:
// node tests/run_dfilter_checks.mjs --root .
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';import {fileURLToPath} from 'node:url';import {createHash} from 'node:crypto';
const here=dirname(fileURLToPath(import.meta.url)),args=process.argv.slice(2);
function option(name,fallback){const i=args.indexOf(name);return i>=0?args[i+1]:fallback;}
const rootArg=option('--root');if(!rootArg)throw Error('Pass --root with the NEW project directory.');
const root=resolve(rootArg),output=resolve(option('--output-dir',resolve(root,'tests')));await mkdir(output,{recursive:true});
const {simulate}=await import('./local_verilog_runtime.mjs');
const sources=['tests/tb_dfilter_control.sv','rtl/cascade_control.v','rtl/signed_div_const.v','tests/cascade_control_legacy.v'];
const files=[];for(const path of sources)files.push({path,data:await readFile(resolve(root,path),'utf8')});
if(!/module\s+cascade_control_legacy\b/.test(files[3].data))throw Error('Frozen baseline must be named module cascade_control_legacy.');
if(!/ANGLE_D_FILTER_SHIFT/.test(files[1].data))throw Error('Current control source does not have the requested Dfilter parameter.');
const sourceSha256=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
const selected=option('--cases','arithmetic,capture_lifecycle,legacy_compat').split(',');
const allowed=new Set(['arithmetic','capture_lifecycle','legacy_compat']);for(const name of selected)if(!allowed.has(name))throw Error('Unknown Dfilter case: '+name);
let passed=true;const compact=[];
for(const name of selected){
 const r=await simulate({files,sources,top:'tb_dfilter_'+name,generation:'2012',timeoutMs:180000});
 const stdout=r.stdout||'',stderr=r.stderr||'';
 const signature=name==='legacy_compat'?/ALL PASS dfilter legacy_compat: (\d+) assertions, (\d+) samples, (\d+) FPGAcycles, (\d+) angle_updates, (\d+) location_updates/:
  new RegExp('ALL PASS dfilter scenario'+(name==='arithmetic'?0:1)+': (\\d+) assertions, (\\d+) samples, (\\d+) angle_updates, (\\d+) location_updates');
 const m=stdout.match(signature),success=Boolean(r.success&&r.exitCode===0&&m);
 const report={profile:'Dlowpass_fullerror_alpha_half_5ms',case:name,success,stage:r.stage,exitCode:r.exitCode,stdout,stderr,sourceSha256,
  assertions:m?Number(m[1]):null,samples:m?Number(m[2]):null,
  angle_updates:m?Number(m[name==='legacy_compat'?4:3]):null,location_updates:m?Number(m[name==='legacy_compat'?5:4]):null,
  fpga_cycles:name==='legacy_compat'&&m?Number(m[3]):null,
  parameters:{ANGLE:[40,1,500],LOCATION:[7,87],DUTY_LIMIT:100,INTEGRAL_LIMIT:10000000,ANGLE_D_FILTER_SHIFT:name==='legacy_compat'?0:1},
  runner_sha256:createHash('sha256').update(await readFile(fileURLToPath(import.meta.url))).digest('hex'),
  scope:name==='legacy_compat'
   ? 'Current SHIFT0core versus frozen prefilter baseline on EVERY FPGAcycle,including output pulses and internal P/I/D/outer history,pipeline and numerator. Explicit production40/1/500and7/87,stimulation of target/position/ADC boundaries,auto/manual start,stop in divider,manual calibration and reset.200FPGAclocks/accelerated1ms sample.No plant,serial,programmer or hardware.'
   : 'Current SHIFT1core versus independent signedlongint oracle with explicit signed32 wrap,5ms full-error rawD,Q8alpha1/2recurrence,symmetric nearest rounding,unchanged P/I,50ms outer7/87and same-tick oldLordering,40/1/500modular numerator,saturation and truncation toward zero. Checks eachangle_update and exact41clock latency. Arithmetic includes alternating/ramp ADC,both half ties,signed32 location extremes and both original integral clamps; lifecycle includes auto/manual seeds,stop during eachnew filter stage,reset during work and clean recapture.200FPGAclocks/accelerated1ms sample.No plant,serial,programmer or hardware.'};
 await writeFile(resolve(output,'dfilter_'+name+'_result.json'),JSON.stringify(report,null,2),'utf8');
 await writeFile(resolve(output,'dfilter_'+name+'_test.log'),r.combinedOutput||stdout+'\n'+stderr,'utf8');
 compact.push({case:name,success,assertions:report.assertions,samples:report.samples,angle_updates:report.angle_updates,location_updates:report.location_updates});
 process.stdout.write((success?'PASS ':'FAIL ')+name+'\n');if(!success)process.stderr.write((stdout+'\n'+stderr).slice(-10000)+'\n');passed&&=success;
}
process.stdout.write(JSON.stringify({success:passed,root,results:compact},null,2)+'\n');if(!passed)process.exitCode=1;

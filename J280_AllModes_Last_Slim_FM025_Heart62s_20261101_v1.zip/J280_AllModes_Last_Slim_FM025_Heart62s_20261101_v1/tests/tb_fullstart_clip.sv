`timescale 1ns/1ps
// Independent wide-coordinate oracle for the new full-stroke startup geometry.
module fullstart_clip_test #(
 parameter integer MODE=1, REQUEST_DECI=900,
 parameter longint signed ORIGIN=64'sd2147483547,
 parameter real VMAX=85.71428571428572, AMAX=87.46355685131196, JMAX=1249.4793835901708,
 parameter CASE_NAME="positive_max"
);
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=ORIGIN,requested_deci=REQUEST_DECI;
 reg [1:0] selected_mode=MODE;reg selection_valid=1,confirm_event=0;
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,clipped_points=0,restored_points=0,return_points=0,i,k;
 real durations[0:6],controls[0:6],tj,ta,tv,vp,t,remaining,dt,q,v,a,j,local_t;
 longint signed raw_position,full_offset,half_offset,expected_endpoint;
 bit found,clipped,check_math=0;
 function automatic longint signed round_near(input real x);
  round_near=x<0?-$rtoi(-x+0.5):$rtoi(x+0.5);
 endfunction
 function automatic signed [31:0] clamp32(input longint signed x);
  clamp32=x>64'sd2147483647 ? 32'sh7fffffff : (x< -64'sd2147483648 ? 32'sh80000000 : x[31:0]);
 endfunction
 task ck(input bit pass,input string msg);
  begin assertions=assertions+1;
   if(!pass)$fatal(1,"%s clipcase=%s elapsed=%0d P=%0d expectedwide=%0d midpoint=%0d EP=%0d clip=%0b flag=%0b V=%0d A=%0d J=%0d cycles=%0d",msg,CASE_NAME,elapsed_ms,reference_position,raw_position,center_position,endpoint_position,clipped,dut.numeric_clipped,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,cycle_count);
  end
 endtask
 task integrate_leg(input real seconds);
  begin
   q=0;v=0;a=0;j=0;remaining=seconds;found=0;
   if(seconds>=3.15-1e-9)q=180;
   else for(k=0;k<7;k=k+1)begin
    dt=durations[k];
    if(!found)begin
     if(remaining<dt-1e-9)begin
      q=q+v*remaining+a*remaining*remaining/2+controls[k]*remaining*remaining*remaining/6;
      v=v+a*remaining+controls[k]*remaining*remaining/2;
      a=a+controls[k]*remaining;j=controls[k];found=1;
     end else begin
      q=q+v*dt+a*dt*dt/2+controls[k]*dt*dt*dt/6;
      v=v+a*dt+controls[k]*dt*dt/2;a=a+controls[k]*dt;remaining=remaining-dt;
     end
    end
   end
  end
 endtask
 always @(posedge clk)begin #1;
  if(target_update&&check_math)begin
   publications=publications+1;
   t=(elapsed_ms%7000)/1000.0;
   if(t<3.15-1e-9)begin integrate_leg(t);expected_endpoint=ORIGIN+full_offset;end
   else if(t<3.50-1e-9)begin q=180;expected_endpoint=ORIGIN+full_offset;end
   else if(t<6.65-1e-9)begin integrate_leg(t-3.50);q=180-q;expected_endpoint=ORIGIN;end
   else begin q=0;expected_endpoint=ORIGIN;end
   raw_position=ORIGIN+round_near(q*(REQUEST_DECI/900.0)*408/360.0);
   clipped=raw_position>64'sd2147483647||raw_position< -64'sd2147483648;
   ck(reference_position===clamp32(raw_position),"published position equals independently clamped wide-coordinate reference without wrap");
   ck(target_value===reference_position,"target mux sees the clamped reference");
   ck(center_position===clamp32(ORIGIN+half_offset),"midpoint telemetry clamps its independent wide-coordinate sum");
   ck(endpoint_position===clamp32(expected_endpoint),"both full-stroke endpoints clamp independently");
   ck(dut.numeric_clipped===clipped,"numeric clip status follows the published position sum");
   ck(cycle_ms==7000&&time_stretch==1&&cycle_count===elapsed_ms/7000,"first full round trip completes exactly at7seconds");
   if(elapsed_ms==0)ck(reference_position===ORIGIN[31:0]&&reference_speed_q8==0,"first sample preserves the startup endpoint with zero velocity");
   if(clipped)begin
    clipped_points=clipped_points+1;
    ck(reference_speed_q8==0&&reference_acceleration_q8==0&&reference_jerk_q8==0,"clipped position has zero published derivatives");
    ck(!acceleration_valid&&!jerk_valid,"clipped arithmetic clears derivative validity");
   end else begin
    ck(acceleration_valid&&jerk_valid,"leaving saturation restores derivative validity");
    if(t>3.5&&clipped_points>0)restored_points=restored_points+1;
   end
   if(t>=6.65&&t<7.0)begin
    return_points=return_points+1;
    ck(reference_position===ORIGIN[31:0]&&reference_speed_q8==0&&reference_acceleration_q8==0&&reference_jerk_q8==0,"reverse leg returns exactly to unsaturated original endpoint and rests");
   end
  end
 end
 task ms(input integer count);integer n;begin for(n=0;n<count;n=n+1)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
 end end endtask
 initial begin
  tj=AMAX/JMAX;ta=VMAX/AMAX-tj;vp=AMAX*(tj+ta);tv=180/vp-(2*tj+ta);
  durations[0]=tj;durations[1]=ta;durations[2]=tj;durations[3]=tv;durations[4]=tj;durations[5]=ta;durations[6]=tj;
  controls[0]=JMAX;controls[1]=0;controls[2]=-JMAX;controls[3]=0;controls[4]=-JMAX;controls[5]=0;controls[6]=JMAX;
  half_offset=round_near(REQUEST_DECI*408/3600.0);full_offset=round_near(2.0*REQUEST_DECI*408/3600.0);
  repeat(5)@(negedge clk);rst_n=1;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);
  ck(held_idle&&!running,"adoption requires explicit start");
  @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;check_math=1;
  ms(7110);
  ck(cycle_count==1,"complete first round trip has no half-amplitude startup delay");
  ck(publications>=710&&clipped_points>10&&restored_points>10&&return_points>=30,"checks include saturation,exit from saturation,and exact full-stroke return");
  $display("ALL PASS fullstart clip case=%s assertions=%0d publications=%0d clipped=%0d restored=%0d returns=%0d",CASE_NAME,assertions,publications,clipped_points,restored_points,return_points);$finish;
 end
 initial begin #(64'd1000000000);$fatal(1,"full-start clip timeout");end
endmodule
module tb_fullstart_clip_positive_max;fullstart_clip_test t();endmodule
module tb_fullstart_clip_negative_min;
 fullstart_clip_test #(.MODE(2),.REQUEST_DECI(-900),.ORIGIN(-64'sd2147483548),.AMAX(122.44897959183675),.JMAX(349.8542274052479),.CASE_NAME("negative_min")) t();
endmodule

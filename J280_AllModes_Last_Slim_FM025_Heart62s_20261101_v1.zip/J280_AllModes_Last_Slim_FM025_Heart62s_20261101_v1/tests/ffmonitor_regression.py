import sys,unittest,io,json,hashlib,subprocess,os
from pathlib import Path
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'monitor'))
suite=unittest.TestSuite()
for name in ['test_unified_monitor','test_unified_runtime','test_amfm_monitor','test_derivative_filter_status']:
 suite.addTests(unittest.defaultTestLoader.loadTestsFromName(name))
buf=io.StringIO();result=unittest.TextTestRunner(stream=buf,verbosity=1).run(suite)
# Start the exact user's Chinese CMD wrapper with a no-serial UI validation flag.
si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
wrapper=str(r/'monitor/启动J280全功能监测.cmd')
p=subprocess.run([str(Path('C:/Windows/System32/cmd.exe')),'/d','/c','call','启动J280全功能监测.cmd','--ui-check'],
    cwd=r/'monitor',capture_output=True,timeout=60,startupinfo=si)
out=p.stdout.decode('utf-8',errors='replace');err=p.stderr.decode('utf-8',errors='replace')
files=['rtl/telemetry.v','monitor/unified_protocol.py','monitor/unified_monitor.py','monitor/feedforward_protocol.py','monitor/Start_Unified_Monitor.cmd']
report={'success':result.wasSuccessful() and p.returncode==0 and 'PASS:' in out,'tests':result.testsRun,
    'failures':len(result.failures),'errors':len(result.errors),'output':buf.getvalue(),
    'launcher':{'path':wrapper,'exit_code':p.returncode,'stdout':out,'stderr':err,'no_serial':True},
    'source_sha256':{f:hashlib.sha256((r/f).read_bytes()).hexdigest() for f in files}}
(r/'tests/ffmonitor_regression_result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ('output','source_sha256')},ensure_ascii=False,indent=2))
sys.exit(0 if report['success'] else 1)

// Independent full-width oracle and pipeline ownership tests.
`timescale 1ns/1ps

module tb_ff_arithmetic;
reg clk=0,rst_n=0,enable=0;always #1 clk=~clk;
reg signed [31:0] acceleration=0;
wire signed [31:0] correction[0:3];wire [3:0] valid;
acceleration_feedforward #(.LOCATION_AFF_Q16(16384)) p(clk,rst_n,enable,acceleration,correction[0],valid[0]);
acceleration_feedforward #(.LOCATION_AFF_Q16(-16384)) n(clk,rst_n,enable,acceleration,correction[1],valid[1]);
acceleration_feedforward #(.LOCATION_AFF_Q16(2147483647)) big(clk,rst_n,enable,acceleration,correction[2],valid[2]);
acceleration_feedforward #(.LOCATION_AFF_Q16(0)) zero(clk,rst_n,enable,acceleration,correction[3],valid[3]);
reg q_valid[0:3];reg signed [31:0] q_value[0:3][0:3];
integer checks=0,steps=0,i,j,g;integer gains[0:3];
function automatic signed [31:0] oracle(input signed [31:0] a,input signed[31:0] gain);
longint signed prod,val;longint unsigned mag;
begin
prod=longint'(a)*longint'(gain);
mag=prod<0 ? -prod : prod;
val=(mag+64'd8388608)>>24;
if(prod<0) val=-val;
if(val>2147483647) oracle=32'sh7fffffff;
else if(val< -64'sd2147483648) oracle=32'sh80000000;
else oracle=val;
end endfunction
task automatic clear_model;
begin for(i=0;i<4;i=i+1)begin q_valid[i]=0;for(j=0;j<4;j=j+1)q_value[j][i]=0;end end
endtask
task automatic step(input bit en,input signed [31:0] a);
begin
@(negedge clk);enable=en;acceleration=a;
if(!en)clear_model();
else begin
for(i=3;i>0;i=i-1)begin q_valid[i]=q_valid[i-1];for(j=0;j<4;j=j+1)q_value[j][i]=q_value[j][i-1];end
q_valid[0]=1;for(j=0;j<4;j=j+1)q_value[j][0]=oracle(a,gains[j]);
end
@(posedge clk);#0.1;
for(g=0;g<4;g=g+1)begin
checks++;
if(valid[g]!==q_valid[3] || correction[g]!== (q_valid[3]?q_value[g][3]:32'sd0))
$fatal(1,"FF arithmetic step=%0d instance=%0d input=%0d valid=%b expectedvalid=%b got=%0d exp=%0d",steps,g,a,valid[g],q_valid[3],correction[g],q_valid[3]?q_value[g][3]:0);
end
steps++;
end endtask
initial begin
gains[0]=16384;gains[1]=-16384;gains[2]=2147483647;gains[3]=0;clear_model();
repeat(3)@(posedge clk);@(negedge clk);rst_n=1;
step(1,0);step(1,511);step(1,512);step(1,513);step(1,-511);step(1,-512);step(1,-513);
step(1,32'sh7fffffff);step(1,32'sh80000000);step(1,8388608);step(1,-8388608);
for(integer k=0;k<4096;k++)step(k%31!=0,$urandom);
for(integer k=0;k<4;k++)begin
step(1,32'sh7fffffff);repeat(k)step(1,12345);
step(0,32'sh80000000);step(1,-17);step(1,-19);step(0,15);
end
for(integer k=0;k<8;k++)step(1,0);
@(negedge clk);rst_n=0;#0.1;
for(g=0;g<4;g++)begin checks++;if(valid[g]!==0||correction[g]!==0)$fatal(1,"async reset not clear");end
$display("ALL PASS FF arithmetic: %0d assertions, %0d cycles",checks,steps);$finish;
end
endmodule

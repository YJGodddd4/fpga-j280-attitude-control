"""Independent configuration/representation checks; no hardware or serial I/O."""
from pathlib import Path
import contextlib,copy,hashlib,importlib.util,io,json,math,tempfile,zlib

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('trajectory_generator',ROOT/'scripts/generate_trajectory_tables.py')
gen=importlib.util.module_from_spec(spec);spec.loader.exec_module(gen)
baseline=json.loads((ROOT/'config/trajectory_profiles.json').read_text(encoding='utf-8'))
checks=[]

def generate(cfg,old_tags=None):
    with tempfile.TemporaryDirectory(prefix='.trajectory-generation-',dir=ROOT/'tests') as folder:
        p=Path(folder)
        assert p.resolve().parent==(ROOT/'tests').resolve()
        (p/'config').mkdir();(p/'rtl').mkdir()
        (p/'config/trajectory_profiles.json').write_text(json.dumps(cfg),encoding='utf-8')
        if old_tags is not None:(p/'config/trajectory_semantics.json').write_text(json.dumps({'centered_half_amplitude_tags':old_tags}),encoding='utf-8')
        gen.ROOT=p
        with contextlib.redirect_stdout(io.StringIO()):gen.main()
        report=json.loads((p/'config/trajectory_validation.json').read_text())
        metadata=json.loads((p/'config/trajectory_semantics.json').read_text())
        files={f'rtl/{f.name}':f.read_bytes() for f in (p/'rtl').iterdir()}
        return report,files,metadata

def signed32(x):
    x=x&0xffffffff
    return x-0x100000000 if x&0x80000000 else x

r,files,metadata=generate(baseline)
expected_tag=f'{zlib.crc32(json.dumps(baseline,sort_keys=True,separators=(",",":")).encode())&0xffffffff:08X}'
assert r['config_tag']==expected_tag
assert r['trapezoid_cycle_ms']==r['s_curve_cycle_ms']==r['sine_cycle_ms']==7000
assert r['trapezoid_leg_ms']==r['s_curve_leg_ms']==3150
for path,content in files.items():assert content==(ROOT/path).read_bytes(),path
assert metadata['centered_half_amplitude_tags']==[expected_tag]
checks.append('Default full-stroke startup90/7s regeneration is byte-identical; all three periods7s; A/B full leg3.15s')
assert 'base_deci=profile==3 ? 32\'d900 : (profile==2 ? 32\'d900 : 32\'d900)' in files['rtl/trajectory_tables.v'].decode('utf-8')
checks.append('All runtime bases use90degree half amplitudes; ROM full A/B displacement remains180degrees')

# Independent sampled-calculus checks on the emitted fixed-point tables.
# They verify physical consistency, not only agreement with the generator's
# own plan or evaluator. Rounded A must have zero acceleration at both ends
# and constant-acceleration ramps separated from cruise by finite jerk.
rows=[int(line,16) for line in files['rtl/trajectory_tables_ab.mem'].decode('ascii').splitlines()]
n=r['trapezoid_leg_ms']//baseline['sample_ms']+1
scale=360/408;dt=baseline['sample_ms']/1000
for name,block in [('trapezoid',rows[:n]),('s_curve',rows[n:])]:
    vals=[(signed32(x>>96)/65536*scale,signed32(x>>64)/256*scale,signed32(x>>32)/256*scale,signed32(x)/256*scale) for x in block]
    pp=baseline[name]
    assert abs(vals[-1][0]-180)<1e-5
    assert vals[0][:3]==(0,0,0) and vals[-1][1:]==(0,0,0)
    # Trapezoidal integration on grid-aligned constant-jerk stages is exact
    # for acceleration->velocity apart from Q8 quantization.
    iv=sum((x[1]+y[1])*dt/2 for x,y in zip(vals,vals[1:]))
    ia=sum((x[2]+y[2])*dt/2 for x,y in zip(vals,vals[1:]))
    assert abs(iv-180)<.01,(name,iv)
    assert abs(ia)<.01,(name,ia)
    assert max(abs((y[2]-x[2])/dt) for x,y in zip(vals,vals[1:]))<=pp['jerk_degrees_s3']+1
    assert max(abs((y[1]-x[1])/dt-(x[2]+y[2])/2) for x,y in zip(vals,vals[1:]))<.4
    assert max(abs((y[0]-x[0])/dt-(x[1]+y[1])/2) for x,y in zip(vals,vals[1:]))<.015
    assert len([x for x in vals if abs(x[1]-pp['velocity_degrees_s'])<.01 and abs(x[2])<.01])>=100
assert r['ab_stage_durations_seconds']['trapezoid'][0] < r['ab_stage_durations_seconds']['s_curve'][0]
assert r['ab_startup']=='full_stroke_from_current_endpoint'
assert metadata['full_stroke_start_tags']==[expected_tag]
checks.append('Rounded trapezoid and seven-S: complete180degree full stroke,zero endpoint speed/acceleration,finite-jerk acceleration changes,independent sampled calculus and distinct corner widths')
checks.append('Full-stroke startup is separately registered; all cycles including dwell exactly30percent shorter than10000ms')

short=copy.deepcopy(baseline)
short['trapezoid']['stroke_degrees']=1.4
short['s_curve']['stroke_degrees']=1.4
sr,sf,sm=generate(short)
# Independent closed-form solution for the short rounded-trapezoid A:
# acceleration limit is reached, velocity limit is not.
pa=baseline['trapezoid'];tj=pa['acceleration_degrees_s2']/pa['jerk_degrees_s3']
flat=(-3*tj+math.sqrt(tj*tj+4*1.4/pa['acceleration_degrees_s2']))/2
assert flat>0
ta=4*tj+2*flat
ts=4*(1.4/(2*baseline['s_curve']['jerk_degrees_s3']))**(1/3)
assert sr['trapezoid_leg_ms']==math.ceil(ta/0.01-1e-9)*10
assert sr['s_curve_leg_ms']==math.ceil(ts/0.01-1e-9)*10
rows=sf['rtl/trajectory_tables_ab.mem'].decode('ascii').splitlines()
for idx in (sr['trapezoid_leg_ms']//10,len(rows)-1):
    x=int(rows[idx],16);q=signed32(x>>96)/65536
    assert abs(q-1.4*408/360)<1/65536
    assert signed32(x>>64)==signed32(x>>32)==signed32(x)==0
checks.append('Short1.4degree full strokes preserve Q16 endpoints and zero endpoint derivatives; reduced trapezoid/S timings independently checked')

low=copy.deepcopy(baseline)
low['s_curve'].update(stroke_degrees=0.8,velocity_degrees_s=0.5,acceleration_degrees_s2=10,jerk_degrees_s3=20)
lr,lf,lm=generate(low)
arows=lr['trapezoid_leg_ms']//baseline['sample_ms']+1
vmax=max(abs(signed32(int(line,16)>>64)/256*360/408) for line in lf['rtl/trajectory_tables_ab.mem'].decode('ascii').splitlines()[arows:])
assert vmax<=0.5+360/408/512
checks.append('Velocity-limited short S remains within0.5deg/s plus half a Q8 LSB')

_,_,registered=generate(baseline,['89abcdef',expected_tag])
assert registered['centered_half_amplitude_tags']==sorted({'89ABCDEF',expected_tag})
checks.append('Semantic registry preserves old centered tags,normalizes case,sorts and deduplicates')

for label,change in [
 ('reject missing half-amplitude scale contract',lambda c:c.update(centered_ab=False)),
 ('reject missing full-stroke startup contract',lambda c:c.update(ab_startup='half_stroke_entry')),
 ('reject half amplitude outside0.1degree editor grid',lambda c:c['trapezoid'].update(stroke_degrees=1.3)),
 ('reject underestimated full-envelope acceleration',lambda c:c['sine'].update(acceleration_limit_degrees_s2=1)),
 ('reject fixed-point overflow instead of wrapping',lambda c:c['trapezoid'].update(stroke_degrees=40000,velocity_degrees_s=10000,acceleration_degrees_s2=10000)),
 ('reject zero dwell unsupported by sampled state machine',lambda c:c['trapezoid'].update(dwell_ms=0)),
]:
    c=copy.deepcopy(baseline);change(c)
    try:generate(c)
    except ValueError:checks.append(label)
    else:raise AssertionError(label)

print(json.dumps({'success':True,'checks':checks,'default_config_tag':r['config_tag'],'short_config_tag':sr['config_tag'],
 'short_trapezoid_leg_ms':sr['trapezoid_leg_ms'],'short_s_curve_leg_ms':sr['s_curve_leg_ms'],
 'sourceSha256':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in ['scripts/generate_trajectory_tables.py','config/trajectory_profiles.json','tests/test_trajectory_generator.py']},
 'sine_full_envelope_bounds':r['sine_full_envelope_bounds_degrees']},indent=2))

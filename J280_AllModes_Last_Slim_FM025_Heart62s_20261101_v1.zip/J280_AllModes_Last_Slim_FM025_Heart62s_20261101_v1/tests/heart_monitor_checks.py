"""Heart v8.7 monitor verification: offline generated ROM, real Tk, no COM."""
from pathlib import Path
import sys,os,json,math,copy,unittest,tempfile
from types import SimpleNamespace
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'monitor'),str(ROOT/'monitor/lib')]
import amfm_semantics as am
import unified_monitor as mon
from unified_protocol import decode_unified,UnifiedHistory,UnifiedRecorder
from feedforward_protocol import diagnostic_summary,speed_description,speed_summary
TAG=int(json.loads((ROOT/'config/trajectory_validation.json').read_text())['config_tag'],16)
H=am.heart_config(TAG)
assert H is not None
def frame(**kw):
    d=dict(CF=TAG,D=3,J=3,CL=56000,EL=0,PH=2,TM=1,TA=560,TE=560,EC=560,H=123,P=123,RF=123,EP=123)
    d.update(kw)
    return decode_unified(mon.demo_line(0,**d))
class HeartMath(unittest.TestCase):
    def test_62_second_hold_and_legacy_56(self):
        for ms in (56000,57000,60000,61990,118000,123990):
            f=frame(CL=62000,EL=ms)
            self.assertEqual(am.upper_envelope_degrees(f),0)
            self.assertEqual(am.lower_envelope_degrees(f),0)
            self.assertEqual(am.heart_data(f)['period_s'],62)
            self.assertIn('6s间隔保持',am.modulation_summary(f))
        self.assertAlmostEqual(am.lower_envelope_degrees(frame(CL=62000,EL=90000)),-56)
        self.assertAlmostEqual(am.lower_envelope_degrees(frame(CL=56000,EL=84000)),-56)

    def test_current_and_old_tags(self):
        self.assertIn('心形',mon.active_profile_label(frame()))
        self.assertIn('11 心形',mon.selected_mode_label(frame()))
        for tag in (0xB5FBC6B6,0x12345678):
            self.assertIsNone(am.heart_config(tag))
            f=frame(CF=tag,CL=7000)
            self.assertIn('正弦',mon.active_profile_label(f))
            self.assertIn('正弦',mon.selected_mode_label(f))
            self.assertIsNone(am.heart_data(f))
            self.assertIsNone(am.upper_envelope_degrees(f))
        self.assertIn('最大绝对偏移',mon.trajectory_semantics(frame())[0])
    def test_envelope_full_cycle_endpoints_and_sign(self):
        for ms in (0,56000,112000):
            self.assertEqual(am.heart_bounds_at(ms,560,H),(0.,0.))
        self.assertAlmostEqual(am.lower_envelope_degrees(frame(EL=28000)),-56)
        self.assertGreater(am.upper_envelope_degrees(frame(EL=28000)),0)
        for ms in range(0,112001,137):
            u,l=am.heart_bounds_at(ms,560,H)
            um,lm=am.heart_bounds_at(ms,-560,H)
            self.assertAlmostEqual(um,-l)
            self.assertAlmostEqual(lm,-u)
            self.assertGreaterEqual(u,l)
            self.assertAlmostEqual(am.heart_bounds_at(ms,1120,H)[0],2*u)
    def test_overlay_matches_all_generated_rom_positions(self):
        rows=(ROOT/'rtl/trajectory_tables_sine.mem').read_text().splitlines()
        self.assertEqual(len(rows),5600)
        self.assertEqual(H['period_ms']/H['carrier_cycles'],4000)
        maxerror=0.
        for i,row in enumerate(rows):
            bits=json.loads((ROOT/'config/trajectory_validation.json').read_text())['lossless_packing']['sine']['fields']
            shift=bits['v8']+bits['a8']+bits['j8'];width=bits['q16']
            raw=(int(row,16)>>shift)&((1<<width)-1)
            if raw&(1<<(width-1)):raw-=1<<width
            raw &= 0xffffffff
            if raw&(1<<31):raw-=1<<32
            actual=raw/65536*360/408
            t=i*10
            u,l=am.heart_bounds_at(t,560,H)
            expected=(u+l)/2-(u-l)/2*math.cos(2*math.pi*14*(t/56000-.5))
            maxerror=max(maxerror,abs(expected-actual))
            self.assertLessEqual(abs(expected-actual),.5/65536*360/408+1e-8)
            self.assertGreaterEqual(actual,l-.00001);self.assertLessEqual(actual,u+.00001)
        self.assertLess(maxerror,.00001)
    def test_phase_is_board_elapsed_not_host_time_or_edit(self):
        f=frame(EL=28000,TE=9999,EC=9999)
        self.assertAlmostEqual(am.lower_envelope_degrees(f),-56)
        self.assertEqual(am.heart_data(f)['board_elapsed_s'],28)
        self.assertEqual(am.heart_data(f)['maximum_absolute_degrees'],56)
        self.assertEqual(am.lower_envelope_degrees(frame(EL=84000)),-56)
        self.assertEqual(am.lower_envelope_degrees(frame(EL=28000,H=-50000)),-56)
    def test_exit_or_wrong_owner_not_fabricated(self):
        f=frame(PH=3)
        self.assertIsNotNone(am.heart_data(f))
        self.assertIsNone(am.upper_envelope_degrees(f));self.assertIsNone(am.lower_envelope_degrees(f))
        self.assertIn('暂不画',am.modulation_summary(f))
        for kw in ({'TM':2},{'CL':4000},{'O':0},{'FL':0},{'J':1,'CL':56000}):
            self.assertIsNone(am.heart_data(frame(**kw)))
    def test_legacy_am_fm_still_asymmetric_independent(self):
        for tag in (TAG,0xB5FBC6B6):
            f=frame(CF=tag,J=1,D=1,EL=15750,CL=31500,TA=300)
            self.assertAlmostEqual(am.upper_envelope_degrees(f),10)
            self.assertAlmostEqual(am.lower_envelope_degrees(f),-10)
            p=am.config_for_tag(tag)['fm']
            f=frame(CF=tag,J=2,D=2,EL=15000,CL=p.get('position_cycle_ms',30000),TA=300)
            self.assertAlmostEqual(am.modulated_data(f)['instant_period_s'],1/p['max_frequency_hz'])
            self.assertEqual(am.upper_envelope_degrees(f),30)
    def test_continuous_new_fm_keeps_30s_frequency_cycle(self):
        for ms in range(0,240001,15000):
            f=frame(J=2,D=2,CL=120000,EL=ms,TA=300)
            d=am.modulated_data(f)
            self.assertIsNotNone(d)
            self.assertEqual(d['modulation_period_s'],30)
            self.assertEqual(d['position_cycle_s'],120)
            self.assertAlmostEqual(d['frequency_hz'],.1 if ms%30000==0 else .25)
            self.assertEqual(am.upper_envelope_degrees(f),30)
        self.assertIsNone(am.modulated_data(frame(J=2,D=2,CL=30000,TA=300)))
    def test_unknown_malformed_heart_is_not_guessed(self):
        for update in ({'period_ms':0},{'lower_epsilon':float('nan')},{'upper_max_degrees':100},{'carrier_cycles':13},{'endpoint_gate_ms':56000}):
            cfg=copy.deepcopy(am.config_for_tag(TAG));cfg['heart'].update(update)
            with patch.object(am,'config_for_tag',return_value=cfg):self.assertIsNone(am.heart_config(TAG))
    def test_wire_and_csv_remain_atomic(self):
        with tempfile.TemporaryDirectory() as folder:
            f=frame(EL=28000);self.assertEqual(len(f.raw),510)
            rec=UnifiedRecorder(folder,'OFFLINE');history=UnifiedHistory()
            rec.append(f,9999,1,history.append(f,9999,1));rec.close()
            self.assertIn(f.raw,rec.csv_path.read_text(encoding='utf-8-sig'))
    def test_config_and_new_run_segment_history(self):
        history=UnifiedHistory()
        history.append(frame(T=100,Q=1,TI=1),1,1)
        c=history.append(frame(T=200,Q=2,TI=2),1.1,1)
        self.assertIn('轨迹运行ID变化',c.reason)
    def test_ff_speed_and_integral_contract(self):
        self.assertIn('原始编码器50ms',speed_description(TAG))
        self.assertIn('10ms更新',speed_summary(TAG))
        d=SimpleNamespace(trajectory_config_tag=TAG,gain_q16=81920,gain=1.25,active=1,
             pd10=17,feedforward10=13,total10=35,location_out10=35,limited=0,speed_valid=1)
        self.assertIn('TT−PD−FF',diagnostic_summary(d))
        self.assertIn('+0.5',diagnostic_summary(d))
class HeartGUI(unittest.TestCase):
    def setUp(self):
        self.root=mon.tk.Tk();self.root.withdraw()
        self.app=mon.UnifiedMonitor(self.root,mode='replay',create_worker=False)
    def tearDown(self):self.app.close()
    def test_120_second_default_and_full_shape_render(self):
        self.assertEqual(self.app.span_var.get(),'120')
        for i in range(561):
            t=i*100
            u,l=am.heart_bounds_at(t,560,H)
            q=(u+l)/2-(u-l)/2*math.cos(2*math.pi*14*(t/56000-.5))
            self.app.process_frame(frame(T=t,Q=i,EL=t,RF=123+round(q*408/360),P=123+round(q*408/360)),i*.1,False)
        for size in ('1280x680','1366x768'):
            self.root.geometry(size);self.root.update()
            self.app.notebook.select(self.app.pages['position']);self.root.update()
            self.app.mark_dirty();self.app.redraw()
            self.assertTrue(self.app.plots[4].canvas.find_all())
        text=self.app.position_var.get()
        self.assertIn('完整心形周期CL=56.000s',text)
        self.assertIn('最大绝对偏移',text)
        self.assertIn('14个载波',text)
        self.assertEqual(len(self.app.notebook.tabs()),5)
        self.assertEqual(len(self.app.plots),8)
        self.assertIsNone(self.app.worker);self.assertIsNone(self.app.recorder)
    def test_new62_second_hold_gui(self):
        self.app.process_frame(frame(CL=62000,EL=58000,RF=123,P=123),58,False)
        text=self.app.position_var.get()
        self.assertIn('CL=62.000s',text)
        self.assertIn('6s间隔保持',text)
        self.assertEqual(am.upper_envelope_degrees(frame(CL=62000,EL=58000)),0)
    def test_negative_bounds_and_requested_not_accepted(self):
        f=frame(EL=28000,TA=-560,TE=1200,EC=1200)
        self.app.process_frame(f,1000,False)
        self.assertIn('TE=+120.0',self.app.position_var.get())
        self.assertIn('TA=-56.0',self.app.position_var.get())
        series=self.app.plots[4].series
        self.assertAlmostEqual(series[-2][2](f),56)
        self.assertLess(series[-1][2](f),0)
        self.assertIn('2秒平滑',self.app.sw4_var.get())
    def test_actual_and_selected_profiles_remain_separate(self):
        self.app.process_frame(frame(D=2,EL=28000),1,False)
        self.assertIn('心形',self.app.values['mode'].get())
        self.assertIn('FM',self.app.details['mode'].get())
        self.assertIn('停止旧轨迹',self.app.details['mode'].get())
if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    r=unittest.TextTestRunner(verbosity=2).run(suite)
    report={'success':r.wasSuccessful(),'tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),
            'tag':f'{TAG:08X}','complete_rom_samples_compared':5600,
            'gui_checks':'real Tk, 120-second window, 5 tabs/8 plots at1280x680 and1366x768',
            'serial_port_opened':False,'serial_bytes_transmitted':False}
    (ROOT/'tests/heart_monitor_result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report));raise SystemExit(not r.wasSuccessful())

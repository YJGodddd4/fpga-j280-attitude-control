`timescale 1ns/1ps

module heart_numeric #(
 parameter integer MODE=3,REQUEST_DECI=560,
 parameter CASE_NAME="pos56"
);
 localparam integer IS_C=(MODE==3);
 localparam integer MAG=REQUEST_DECI<0?-REQUEST_DECI:REQUEST_DECI;
 localparam integer BASE=560;
 localparam integer STRETCH=1,PERIOD=56000,RAMP=2000,CYCLE=62000;
 reg [191:0] expected[0:5599];
 reg [191:0] golden;
 reg signed [31:0] gq,gv,ga,gj,gu,gl;
 initial $readmemh("tests/heart_expected.mem",expected);
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123,requested_deci=REQUEST_DECI;
 reg [1:0] selected_mode=MODE;reg selection_valid=1,confirm_event=0;
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,strict=0,logical_ms=0,last_elapsed=-1,last_pub=-1,last_phase=-1;
 integer entry_points=0,steady_points=0,exit_points=0,waited=0,saved_id,saved_pubs,expect_r;
 real amp,t,om,modom,modphase,carrier,A0,A1,A2,A3,wave_phase,om1,om2,om3;
 real bq,bv,ba,bj,q,v,a,j,s,w,wd,wdd,wddd,ramp,exit_start=-1,scale;
 real vmax=0,steady_vmax=0,steady_min=1e9,steady_max=-1e9;
 bit checking=0;
 function real ab(input real x);ab=x<0?-x:x;endfunction
 function integer rn(input real x);rn=x<0?-$rtoi(-x+0.5):$rtoi(x+0.5);endfunction
 task ck(input bit yes,input string message);
  begin assertions++;if(!yes)$fatal(1,"%s case=%s elapsed=%0d ms=%0d phase=%0d st=%0d R=%0d V=%0d A=%0d J=%0d TM=%0d TA=%0d",message,CASE_NAME,elapsed_ms,logical_ms,phase,trajectory_state,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,time_stretch,accepted_deci);end
 endtask
 task independent;
  begin
   golden=(elapsed_ms%62000>=56000) ? 192'd0 : expected[(elapsed_ms%62000)/10];
   {gq,gv,ga,gj,gu,gl}=golden;
   bq=$itor(gq)/65536*REQUEST_DECI/560.0;
   bv=$itor(gv)/256*REQUEST_DECI/560.0;
   ba=$itor(ga)/256*REQUEST_DECI/560.0;
   bj=$itor(gj)/256*REQUEST_DECI/560.0;
   if(phase==3&&exit_start<0)exit_start=elapsed_ms-10.0;
   ramp=2;
   if(phase==3)begin
    s=(elapsed_ms-exit_start)/2000.0;
    if(s<0)s=0;if(s>1)s=1;
    w=35*s**4-84*s**5+70*s**6-20*s**7;
    wd=(140*s**3-420*s**4+420*s**5-140*s**6)/ramp;
    wdd=(420*s**2-1680*s**3+2100*s**4-840*s**5)/(ramp*ramp);
    wddd=(840*s-5040*s**2+8400*s**3-4200*s**4)/(ramp*ramp*ramp);
    w=1-w;wd=-wd;wdd=-wdd;wddd=-wddd;
   end else begin w=1;wd=0;wdd=0;wddd=0;end
   q=bq*w;v=bv*w+bq*wd;a=ba*w+2*bv*wd+bq*wdd;
   j=bj*w+3*ba*wd+3*bv*wdd+bq*wddd;
  end
 endtask
 always @(posedge tick_ms)if(rst_n)logical_ms++;
 always @(posedge target_update)begin
  #1;
  if(target_update)begin
   publications++;
   ck(owned&&balance_ready&&!stop_event,"publication only while current owner and balanced");
   ck(target_value===reference_position,"target/display atomic");
   if(checking)begin
    strict++;
    ck(accepted_deci==REQUEST_DECI,"accepted request frozen while next edit changes");
    ck(time_stretch==STRETCH,"expected per-profile stretch");
    ck(cycle_ms==CYCLE,"full modulation/reference period is correct");
    ck(center_position==123&&endpoint_position==123,"fixed center and endpoint for periodic profiles");
    ck(dut.base_deci_latched==BASE,"ROM amplitude base scale correct");
    independent;expect_r=123+rn(q);
    scale=ab(REQUEST_DECI/560.0);if(scale<1)scale=1;
    ck(ab(reference_position-expect_r)<=1,"position independent heart formula");
    if(running)begin
     ck(jerk_valid&&acceleration_valid,"analytic derivatives reported valid");
     ck(ab(reference_speed_q8-v*256)<16*scale,"velocity independent derivative");
     ck(ab(reference_acceleration_q8-a*256)<28*scale,"acceleration independent derivative");
     ck(ab(reference_jerk_q8-j*256)<80*scale,"jerk independent derivative");
    end
    if(last_elapsed>=0)ck(elapsed_ms==last_elapsed+10,"every publication advances exactly10ms");
    if(last_elapsed>=10&&phase==last_phase)ck(logical_ms-last_pub>=9&&logical_ms-last_pub<=11,"publication inside10ms slot without accumulating lag");
    ck($itor(dut.clock_elapsed_ms)-$itor(elapsed_ms)>=0&&$itor(dut.clock_elapsed_ms)-$itor(elapsed_ms)<10,"pipeline completes in10ms slot");
    last_elapsed=elapsed_ms;last_pub=logical_ms;last_phase=phase;
    ck(phase!=1,"intrinsic smooth heart start has no extra entry gate");
    if(phase==2)begin
     steady_points++;
     if(q<steady_min)steady_min=q;if(q>steady_max)steady_max=q;
     if(ab(reference_speed_q8)>steady_vmax)steady_vmax=ab(reference_speed_q8);
    end
    if(phase==3)exit_points++;
    if(ab(reference_speed_q8)>vmax)vmax=ab(reference_speed_q8);
   end
  end
 end
 task ms(input integer n);integer i;begin for(i=0;i<n;i++)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;#5960;
 end end endtask
 task confirm;begin @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;
  adopt_reference=123;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;
  repeat(4)@(negedge clk);ck(held_idle&&!running&&run_id==0,"adopt does not auto run");
  confirm;checking=1;ms(100);requested_deci=-222222;
  ms(CYCLE*2+100);
  ck(running&&cycle_count>=2,"two full hearts completed");
  ck(strict>=11200&&steady_points>=11200,"every10ms in two cycles independently checked");
  ck(entry_points==0,"heart uses native C3 endpoint not an extra amplitude ramp");
  if(REQUEST_DECI>0)begin
   ck(steady_min<-MAG/10.0*0.9*408/360,"negative heart tip reached");
   ck(steady_max>MAG/10.0*0.30*408/360,"upper heart lobes reached");
  end else begin
   ck(steady_max>MAG/10.0*0.9*408/360,"mirrored positive heart tip reached");
   ck(steady_min<-MAG/10.0*0.30*408/360,"mirrored lower lobes reached");
  end
  saved_id=run_id;confirm;waited=0;
  while(!held_idle&&waited<RAMP+1000)begin ms(1);waited++;end
  ck(held_idle&&!running&&reference_position==123,"C3 smooth stop returns exactly to same origin");
  ck(exit_points>=RAMP/10-2,"all exit samples independently checked");
  saved_pubs=publications;ms(50);ck(publications==saved_pubs&&run_id==saved_id,"no automatic replay");
  $display("ALL PASS heart case=%s assertions=%0d publications=%0d strict=%0d cycles=%0d",CASE_NAME,assertions,publications,strict,cycle_count);$finish;
 end
 initial begin #(64'd8000000000);$fatal(1,"heart numeric timeout");end
endmodule
module tb_heart_pos56;heart_numeric #(.REQUEST_DECI(560),.CASE_NAME("pos56")) t();endmodule
module tb_heart_neg56;heart_numeric #(.REQUEST_DECI(-560),.CASE_NAME("neg56")) t();endmodule
module tb_heart_pos30;heart_numeric #(.REQUEST_DECI(300),.CASE_NAME("pos30")) t();endmodule
module tb_heart_neg30;heart_numeric #(.REQUEST_DECI(-300),.CASE_NAME("neg30")) t();endmodule
module tb_heart_pos90;heart_numeric #(.REQUEST_DECI(900),.CASE_NAME("pos90")) t();endmodule
module tb_heart_neg90;heart_numeric #(.REQUEST_DECI(-900),.CASE_NAME("neg90")) t();endmodule

`timescale 1ns/1ps
module tb_heart_lifecycle;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123;reg [3:0] keys_n=15;reg [1:0] dip_n=0;reg edit_enable=1;
 wire minus_event,plus_event,step_event,confirm_event,selection_valid;
 wire [1:0] selected_mode,step_index;
 wire signed [31:0] requested_deci,trapezoid_deci,scurve_deci,sine_deci;
 position_inputs panel(.clk(clk),.rst_n(rst_n),.tick_ms(tick_ms),.keys_n(keys_n),.dip_n(dip_n),
 .edit_enable(edit_enable),.minus_event(minus_event),.plus_event(plus_event),.step_event(step_event),
 .confirm_event(confirm_event),.dip_mode(selected_mode),.dip_valid(selection_valid));
 trajectory_editor editor(.clk(clk),.rst_n(rst_n),.edit_enable(edit_enable),.selected_mode(selected_mode),.selection_valid(selection_valid),
 .minus_event(minus_event),.plus_event(plus_event),.step_event(step_event),.requested_deci(requested_deci),
 .trapezoid_deci(trapezoid_deci),.scurve_deci(scurve_deci),.sine_deci(sine_deci),.step_index(step_index));
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,waited=0,id,oldpubs;
 task ck(input bit x,input string s);begin assertions++;if(!x)$fatal(1,"%s TE%0d TA%0d mode%0d st%0d ph%0d",s,requested_deci,accepted_deci,selected_mode,trajectory_state,phase);end endtask
 always @(posedge target_update)begin #1;if(target_update)begin publications++;ck(owned&&balance_ready&&!stop_event,"no stale publication after loss/stop");end end
 task ms(input integer n);integer i;begin for(i=0;i<n;i++)begin @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;#5960;end end endtask
 task keys(input [3:0] mask);begin @(negedge clk);keys_n=~mask;ms(30);@(negedge clk);keys_n=15;ms(30);end endtask
 task adopt(input integer p);begin owned=0;adopt_reference=p;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);end endtask
 task wait_stop;begin waited=0;while(!held_idle&&waited<5000)begin ms(1);waited++;end ck(held_idle&&!running,"smooth stop within entry+exit duration");end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;ms(60);adopt(123);
  ck(selection_valid&&selected_mode==3&&requested_deci==560,"DIP11 heart default maximum56");
  ck(trapezoid_deci==300&&scurve_deci==300&&sine_deci==560&&step_index==2,"per-profile default editing values");
  id=run_id;keys(8);ck(running&&accepted_deci==560&&cycle_ms==56000&&time_stretch==1&&run_id==id+1,"raw SW4 starts heart56 without time stretch");
  keys(4);ck(requested_deci==660&&accepted_deci==560&&center_position==123,"RUN raw SW3 edit changes next heart only");
  keys(8);ck(stop_pending&&running,"SW4 in first second starts C3 smooth stop");wait_stop;
  ck(reference_position==123&&reference_speed_q8==0&&reference_acceleration_q8==0&&reference_jerk_q8==0,"early heart stop returns all derivatives zero");
  id=run_id;oldpubs=publications;ms(40);ck(run_id==id&&publications==oldpubs,"no automatic restart");
  keys(8);ck(running&&accepted_deci==660&&time_stretch==1&&cycle_ms==56000,"larger edited heart keeps56-second period");
  ms(500);@(negedge clk);dip_n=2;ms(60);ck(selected_mode==1&&stop_pending,"DIP11 to01 requests smooth exit");wait_stop;
  adopt(250);@(negedge clk);dip_n=0;ms(60);
  repeat(6)keys(2);ck(requested_deci==60,"SW2 decrement56-to6 after pending66");
  keys(6);keys(6);ck(step_index==1,"raw SW2+SW3 cycles to1degree editing");
  repeat(6)keys(2);ck(requested_deci==0,"raw panel can set zero heart amplitude");
  id=run_id;keys(8);ck(!running&&run_id==id&&accepted_deci==0,"zero request never starts");
  keys(2);keys(8);ck(running&&accepted_deci==-10&&cycle_ms==56000&&time_stretch==1,"raw signed editor starts mirrored fixed-period heart");
  ms(20);waited=0;while(dut.math_state==0&&waited<20)begin ms(1);waited++;end ck(dut.math_state!=0,"inflight numeric pipeline reached");
  @(negedge clk);balance_ready=0;@(posedge clk);#2;
  ck(!running&&!base_valid&&!target_update&&interrupted,"balance loss cancels pending publication immediately");
  ms(10);balance_ready=1;adopt(400);ms(20);ck(held_idle&&!running&&center_position==400,"recapture adopts new origin without auto replay");
  keys(8);ck(running,"explicit restart after recapture");
  @(negedge clk);stop_event=1;@(posedge clk);#2;ck(!running&&!base_valid&&!target_update,"globalstop wins");@(negedge clk);stop_event=0;
  @(negedge clk);rst_n=0;repeat(3)@(negedge clk);
  ck(!running&&!base_valid&&run_id==0&&trapezoid_deci==300&&scurve_deci==300&&sine_deci==560,"reset restores defaults and clears execution");
  $display("ALL PASS heart case=lifecycle assertions=%0d publications=%0d strict=0 cycles=0",assertions,publications);$finish;
 end
 initial begin #(64'd4000000000);$fatal(1,"lifecycle timeout");end
endmodule

`timescale 1ns/1ps
module tb_ff_normalizer;
 reg clk=0;always #10 clk=~clk;
 reg rst=0,tick=0;reg signed[31:0] raw=0,origin=0,numer,expected;
 integer n,k,checks=0;reg[31:0] seed=32'h19abcde1;
 j280_pendulum_top dut(.clk_50m(clk),.rst_n(rst),.key_sw(4'hf),.dip_sw_n(2'b11),
 .uart_rx(1'b1),.adc_data_in(10'd0),.adc_otr(1'b0),.enc1_a(1'b0),.enc1_b(1'b0),.enc2_a(1'b0),.enc2_b(1'b0));
 initial begin force dut.tick_ms=tick;force dut.encoder_raw=raw;force dut.encoder_origin=origin;force dut.telemetry_request=1'b0;end
 initial begin
 repeat(8)@(negedge clk);rst=1;repeat(10)@(negedge clk);
 for(n=0;n<350;n=n+1)begin
  @(negedge clk);seed=seed*32'd1664525+32'd1013904223;raw=seed;origin=seed^32'hcae22317;
  numer=(origin-raw)*408;expected=numer/1040;tick=1;
  @(negedge clk);tick=0;
  // Keep changing raw/origin after the capture: delayed logic must not use these.
  raw=raw+32'sd777;origin=origin-32'sd333;
  k=0;
  while(!dut.norm_done && k<100)begin @(negedge clk);k=k+1;end
  checks=checks+1;
  if(!dut.norm_done || dut.position!==expected)$fatal(1,"normalizer data/tick mismatch n%0d actual%0d expected%0d",n,dut.position,expected);
  repeat(5)@(negedge clk);
 end
 $display("ALL PASS normalizer exact tick snapshot and signed32 arithmetic: %0d checks",checks);$finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule

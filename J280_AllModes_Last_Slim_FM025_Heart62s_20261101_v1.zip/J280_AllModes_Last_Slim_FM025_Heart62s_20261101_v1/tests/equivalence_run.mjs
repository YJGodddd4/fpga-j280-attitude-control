import {readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {simulate} from './local_verilog_runtime.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const cases=(process.argv[2]||'rom,peripherals,am,fm,heart_pos,heart_neg').split(',');
const result=[];
for(const name of cases){
 let modules=name==='rom'?['trajectory_tables']:name==='peripherals'?['input_helpers','uart_io','motor_pwm','quadrature_encoder']:['trajectory_task','trajectory_tables','position_serial_div'];
 const sources=['tests/eq_'+(name==='rom'?'rom':name==='peripherals'?'peripherals':'trajectory')+'.sv',...modules.map(x=>'rtl/'+x+'.v'),...modules.map(x=>'tests/equivalence_baseline/'+x+'.v')];
 const paths=[...sources,...['ab','sine','envelope'].flatMap(x=>['rtl/trajectory_tables_'+x+'.mem','tests/equivalence_baseline/trajectory_tables_'+x+'.mem'])];
 const files=await Promise.all(paths.map(async path=>({path,data:await readFile(resolve(root,path),'utf8')})));
 console.log('RUN eq_'+name);
 const r=await simulate({files,sources,top:'tb_eq_'+name,timeoutMs:600000});
 const success=Boolean(r.success&&/ALL PASS/.test(r.stdout));
 const sourceSha256=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
 await writeFile(resolve(root,'tests/eq_'+name+'_result.json'),JSON.stringify({success,case:name,sourceSha256,stdout:r.stdout,stderr:r.stderr,timings:r.timings,hardware_tested:false},null,2));
 await writeFile(resolve(root,'tests/eq_'+name+'_test.log'),r.combinedOutput);
 console.log((success?'PASS ':'FAIL ')+name+' '+(r.stdout.match(/ALL PASS[^\n]*/)?.[0]||r.combinedOutput.slice(-4000)));
 result.push({case:name,success});if(!success){process.exitCode=1;break;}
}
await writeFile(resolve(root,'tests/equivalence_results.json'),JSON.stringify(result,null,2));

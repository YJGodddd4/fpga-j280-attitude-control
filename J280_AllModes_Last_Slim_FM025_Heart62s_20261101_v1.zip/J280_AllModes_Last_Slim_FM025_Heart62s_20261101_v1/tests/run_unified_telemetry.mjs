import { readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';

const here=dirname(fileURLToPath(import.meta.url));
const root=resolve(here,'..');
const runtime=process.env.J280_VERILOG_RUNTIME ||
  fileURLToPath(new URL('./local_verilog_runtime.mjs',import.meta.url));
const { simulate }=await import(pathToFileURL(runtime).href);
const paths=[resolve(here,'tb_unified_telemetry.sv'),resolve(root,'rtl/telemetry.v'),resolve(root,'rtl/uart_io.v')];
const files=await Promise.all(paths.map(async path=>({path:basename(path),data:await readFile(path,'utf8')})));
const sourceSha256=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
const result=await simulate({files,sources:files.map(f=>f.path),top:'tb_unified_telemetry',generation:'2012',timeoutMs:120000});
const match=result.stdout.match(/ALL PASS unified telemetry UART: (\d+) assertions, (\d+) byte comparisons, (\d+) decoded bytes/);
const fixture=result.stdout.match(/ACTUAL_X_FIXTURE=(X=8002[^\r\n]+)/);
const fixtureText=fixture ? fixture[1]+'\r\n' : '';
const fixtureBytes=Buffer.byteLength(fixtureText,'ascii');
const success=result.success && Boolean(match) && fixtureBytes===512 && Number(match[3])===5397;
if(success)await writeFile(resolve(here,'unified_uart_fixture.txt'),fixtureText,'ascii');
await writeFile(resolve(here,'unified_telemetry_result.json'),JSON.stringify({
  success,stage:result.stage,exitCode:result.exitCode,stdout:result.stdout,stderr:result.stderr,
  timings:result.timings,assertions:match?Number(match[1]):null,
  byteComparisons:match?Number(match[2]):null,decodedBytes:match?Number(match[3]):null,sourceSha256,
  frameBytes:{legacyA:54,legacyM:29,positionO:176,unifiedX:512,unifiedPayload:510,total:771,lastIndex:770},
  unifiedVersion:'8002',unifiedFields:54,fixtureBytes,fixtureSha256:success?createHash('sha256').update(fixtureText,'ascii').digest('hex'):null,
  scope:'Actual all-modes telemetry and UART RTL, independent TX bit-center decoding at115200baud/16clocks per bit. Seven independently spelled-out771byte expected frames verify unchanged first259bytes A/M/O5103 plus512byte X8002. All54 X fields include editable/accepted signed deci-degrees, step, run ID, unsigned time stretch and independently retained A/B/C edits. Signed32 and unsigned32 extrema,32/64bit values,flags,profile/owner,positive/negative command and720/4000degree requests. Every source mutates throughout all lines; busy requests in A/M/O/X, appended trajectory metadata and final bytes are rejected. Q1..6 and reset Q1 remain atomic across O/X. No hierarchical byte/index/active reads, reused RTL receiver, real serial port or mechanical validation.'
},null,2));
await writeFile(resolve(here,'unified_telemetry_test.log'),result.combinedOutput);
process.stdout.write(result.combinedOutput);
if (!success) process.exitCode=1;

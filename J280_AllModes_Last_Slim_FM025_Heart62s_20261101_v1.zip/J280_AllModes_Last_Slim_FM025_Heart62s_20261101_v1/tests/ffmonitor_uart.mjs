import { readFile, writeFile } from 'node:fs/promises';
import { basename, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { simulate } from './local_verilog_runtime.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..'),here=resolve(root,'tests');
const paths=['tests/tb_ffmonitor_uart.sv','rtl/telemetry.v','rtl/uart_io.v'];
const files=await Promise.all(paths.map(async p=>({path:basename(p),data:await readFile(resolve(root,p),'utf8')})));
const hashes=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
const r=await simulate({files,sources:files.map(f=>f.path),top:'tb_ffmonitor_uart',timeoutMs:120000});
const m=r.stdout.match(/ALL PASS feedforward telemetry UART: (\d+) assertions, (\d+) byte comparisons, (\d+) decoded bytes/);
const x=r.stdout.match(/ACTUAL_X_FIXTURE=(X=8002[^\r\n]+)/),z=r.stdout.match(/ACTUAL_Z_FIXTURE=(Z=8601[^\r\n]+)/);
const success=r.success&&!!m&&!!x&&!!z&&m[3]==6307;
if(success){await writeFile(resolve(here,'ffmonitor_x_fixture.txt'),x[1]+'\r\n');await writeFile(resolve(here,'ffmonitor_z_fixture.txt'),z[1]+'\r\n');}
await writeFile(resolve(here,'ffmonitor_uart_result.json'),JSON.stringify({success,assertions:m?+m[1]:null,byteComparisons:m?+m[2]:null,bytes:m?+m[3]:null,hashes,stdout:r.stdout,stderr:r.stderr,timings:r.timings,scope:'Actual UART TX pin bit-center decoding. Original A/M/O/X bytes unchanged, seven complete901-byte batches including independentZ8601 signed33 extrema, input mutation and busy requests, reset sequence restart.'},null,2));
process.stdout.write(r.combinedOutput);if(!success)process.exitCode=1;

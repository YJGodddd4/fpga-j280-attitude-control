`timescale 1ns/1ps
module tb_amfm_limits;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0,selection_valid=1,confirm_event=0;
 reg signed [31:0] adopt_reference=0,requested_deci=0;reg [1:0] selected_mode=1;
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,pass=0,index=0,k,n,lim;
 reg signed [31:0] saved_q[0:20],saved_v[0:20],saved_a[0:20],saved_j[0:20];
 task ck(input bit x,input string s);begin assertions++;if(!x)$fatal(1,"%s pass%0d TA%0d EL%0d",s,pass,accepted_deci,elapsed_ms);end endtask
 task ms(input integer count);integer i;begin for(i=0;i<count;i++)begin @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);end end endtask
 always @(posedge clk)begin #1;if(target_update)begin
  publications++;ck(running&&base_valid,"published only during active clip test");
  ck(time_stretch==1,"numeric clip does not change cycle timing");
  ck(accepted_deci==((pass%2)?-lim:lim),"max/min signed input clipped symmetrically to declared numeric bound");
  ck(!dut.numeric_clipped&&jerk_valid&&acceleration_valid,"accepted bounded amplitude keeps correct derivatives without final position clipping");
  if(pass%2==0)begin saved_q[index]=reference_position;saved_v[index]=reference_speed_q8;saved_a[index]=reference_acceleration_q8;saved_j[index]=reference_jerk_q8;end
  else begin
   ck(reference_position==-saved_q[index],"position odd symmetry after positive/negative clip");
   ck(reference_speed_q8==-saved_v[index],"speed odd symmetry after positive/negative clip");
   ck(reference_acceleration_q8==-saved_a[index],"acceleration odd symmetry after positive/negative clip");
   ck(reference_jerk_q8==-saved_j[index],"jerk odd symmetry after positive/negative clip");
  end
  index++;
 end end
 initial begin
  for(pass=0;pass<4;pass++)begin
   rst_n=0;owned=0;repeat(5)@(negedge clk);rst_n=1;index=0;
   selected_mode=(pass<2)?1:2;lim=(pass<2)?2406000:908970;
   requested_deci=(pass%2)?32'sh80000000:32'sh7fffffff;
   @(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);
   @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;ms(120);
   ck(index>=12,"numeric limit produces complete publication stream");
   ck(cycle_ms==((pass<2)?31500:30000),"CL stays fixed at representational edge");
   @(negedge clk);stop_event=1;@(posedge clk);#2;ck(!running&&!target_update&&!base_valid,"stop still wins at max/min input");@(negedge clk);stop_event=0;
  end
  $display("ALL PASS amfm limits assertions=%0d publications=%0d",assertions,publications);$finish;
 end
 initial begin #(64'd100000000);$fatal(1,"numeric limits timeout");end
endmodule

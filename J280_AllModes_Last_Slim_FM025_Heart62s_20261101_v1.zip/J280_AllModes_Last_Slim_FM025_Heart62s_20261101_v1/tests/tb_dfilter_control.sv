`timescale 1ns/1ps
// Independent integer oracle for5ms full-error-D low-pass. No plant/hardware.
module dfilter_oracle_test #(parameter integer SCENARIO=0);
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,sample_ms=0,sensor_ok=1,travel_ok=1,toggle_event=0,stop_event=0;
 reg plus_event=0,minus_event=0,calibrate_event=0,prepare_event=0,capture_start_event=0,target_update_event=0;
 reg [11:0] angle=2955,prepare_center=2955;
 reg signed [31:0] position=0,prepare_target=0,target_value=0;
 wire running,calibrated,calibrating,zero_position,angle_update,location_update;
 wire [3:0] fault;wire [11:0] center;
 wire signed [31:0] target_position,location_out10;wire signed [7:0] motor_command;
 cascade_control #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(500),.ANGLE_D_FILTER_SHIFT(1),
  .LOCATION_KP_10(7),.LOCATION_KD_10(87)) dut(.*);
 integer assertions=0,clock_cycle=0,samples=0,angle_pulses=0,location_pulses=0;
 integer ac=0,lc=0,expected_sample_cycle=0,i,k,positive_half_ties=0,negative_half_ties=0;
 integer saturated_outputs=0,positive_integral_clamps=0,negative_integral_clamps=0,noise_samples=0;
 bit model_running=0,model_calibrated=0,pending_inner=0,pending_location=0,collect_noise=0;
 longint signed mc=2010,mt=0,ml=0,mlprev=0,mi=0,meprev=0,mf=0;
 longint signed ee=0,raw=0,filtered=0,rounded_d=0,num=0,cmd=0,le=0,lraw=0;
 longint signed expected_error=0,expected_raw=0,expected_filter=0,expected_d=0,expected_num=0,expected_cmd=0;
 longint signed expected_integral=0,noise_raw_square=0,noise_filtered_square=0;
 function automatic signed [31:0] wrap32(input longint signed x);wrap32=x[31:0];endfunction
 function automatic longint signed abs64(input longint signed x);abs64=x<0?-x:x;endfunction
 function automatic longint signed sym_round_q8(input longint signed x);
  sym_round_q8=x<0?-(((-x)+64'sd128)>>>8):((x+64'sd128)>>>8);
 endfunction
 task ck(input bit pass,input string message);begin assertions=assertions+1;
  if(!pass)$fatal(1,"%s scenario=%0d sample=%0d clk=%0d running=%0b ac/lc=%0d/%0d E=%0d/%0d I=%0d/%0d rawD=%0d/%0d Q8=%0d/%0d D=%0d/%0d L=%0d/%0d U=%0d/%0d math=%0d",message,SCENARIO,samples,clock_cycle,running,ac,lc,dut.error_latched,expected_error,dut.integral,expected_integral,dut.d_raw_latched,expected_raw,dut.d_filter_q8,expected_filter,dut.delta_latched,expected_d,location_out10,ml,motor_command,expected_cmd,dut.math_state);
 end endtask
 always @(posedge clk)begin
  clock_cycle=clock_cycle+1;#1;
  if(rst_n&&angle_update)begin
   angle_pulses=angle_pulses+1;ck(pending_inner,"every angle_update has one pending5ms oracle sample");
   ck(clock_cycle-expected_sample_cycle==41,"filtered output latency is original36clocks plus five filter clocks");
   ck(dut.error_latched===expected_error[31:0],"full error latched before same-tick outer update");
   ck(dut.integral===expected_integral[31:0]&&dut.integral_latched===expected_integral[31:0],"original integral and integral snapshot unchanged");
   ck(dut.d_raw_latched===expected_raw[31:0],"raw D is complete error difference at5ms");
   ck(dut.d_filter_q8===expected_filter[31:0],"Q8alpha1/2history matches independent signed integer recurrence");
   ck(dut.delta_latched===expected_d[31:0],"D rounding is symmetric nearest,including negative half ties");
   ck(dut.numerator===expected_num[31:0],"original signed32 modular40/1/500 numerator retained");
   ck(motor_command===expected_cmd[7:0],"original saturation and signed division toward zero retained");
   ck(dut.angle_previous===expected_error[31:0],"unfiltered full error history is retained for next raw difference");
   pending_inner=0;if(abs64(expected_cmd)==100)saturated_outputs=saturated_outputs+1;
   if(expected_integral==10000000)positive_integral_clamps=positive_integral_clamps+1;
   if(expected_integral==-10000000)negative_integral_clamps=negative_integral_clamps+1;
   if(expected_filter>0&&(expected_filter&255)==128)positive_half_ties=positive_half_ties+1;
   if(expected_filter<0&&((-expected_filter)&255)==128)negative_half_ties=negative_half_ties+1;
   if(collect_noise)begin noise_samples=noise_samples+1;noise_raw_square=noise_raw_square+expected_raw*expected_raw;noise_filtered_square=noise_filtered_square+expected_d*expected_d;end
  end
  if(rst_n&&location_update)begin
   location_pulses=location_pulses+1;ck(pending_location,"every outer publication has one pending50ms sample");
   ck(location_out10===ml[31:0]&&dut.location_previous===mlprev[31:0],"7/87outer PD preserves original signed32 arithmetic and50ms cadence");pending_location=0;
  end
 end
 task clear_history;
  begin ac=0;lc=0;ml=0;mlprev=0;mi=0;meprev=0;mf=0;pending_inner=0;pending_location=0;expected_integral=0;end
 endtask
 task predict_sample;
  begin
   samples=samples+1;
   if(model_running)begin
    // Deliberately compute inner BEFORE outer when5/50ms boundaries coincide.
    if(ac==4)begin
     ac=0;ck(!pending_inner,"previous inner sample finished before next5ms sample");
     ee=wrap32((mc-$signed({1'b0,angle}))*64'sd10-ml);
     mi=wrap32(mi+ee);if(mi>10000000)mi=10000000;if(mi< -10000000)mi=-10000000;
     raw=wrap32(ee-meprev);meprev=ee;
     filtered=wrap32(mf+((raw*64'sd256-mf)>>>1));mf=filtered;rounded_d=sym_round_q8(filtered);
     num=wrap32(64'sd40*ee+mi+64'sd500*rounded_d);
     cmd=num;if(cmd>100000)cmd=100000;if(cmd< -100000)cmd=-100000;cmd=cmd/64'sd1000;
     expected_error=ee;expected_raw=raw;expected_filter=filtered;expected_d=rounded_d;
     expected_num=num;expected_cmd=cmd;expected_integral=mi;expected_sample_cycle=clock_cycle+1;pending_inner=1;
    end else ac=ac+1;
    if(lc==49)begin
     lc=0;ck(!pending_location,"previous outer sample finished before next50ms sample");
     le=wrap32(mt-$signed(position));lraw=wrap32(64'sd94*le-64'sd87*mlprev);mlprev=le;
     ml=lraw;if(ml>1000)ml=1000;if(ml< -1000)ml=-1000;pending_location=1;
    end else lc=lc+1;
   end
  end
 endtask
 task sample_one;
  begin
   @(negedge clk);predict_sample();sample_ms=1;
   @(negedge clk);sample_ms=0;repeat(198)@(negedge clk);
   ck(!pending_inner&&!pending_location,"all outputs publish within a200clock accelerated1ms slot");
   ck(running==model_running&&center==mc[11:0]&&target_position===mt[31:0],"run/reference state matches independently controlled lifecycle");
   ck(location_out10===ml[31:0]&&dut.integral===mi[31:0],"P/I and outer state remain correct between inner publications");
  end
 endtask
 task pulse_target(input reg signed [31:0] value);begin
  @(negedge clk);target_value=value;target_update_event=1;if(model_running)mt=value;
  @(negedge clk);target_update_event=0;repeat(2)@(negedge clk);
 end endtask
 task reset_all;begin
  @(negedge clk);rst_n=0;sample_ms=0;toggle_event=0;stop_event=0;prepare_event=0;capture_start_event=0;target_update_event=0;
  model_running=0;model_calibrated=0;mc=2010;mt=0;clear_history();repeat(4)@(negedge clk);
  ck(!running&&!calibrated&&!calibrating&&motor_command==0&&dut.d_filter_q8==0&&dut.d_raw_latched==0,"reset clears control state and all filter history");
  rst_n=1;repeat(4)@(negedge clk);
 end endtask
 task prepare(input integer value_c,input reg signed [31:0] value_t);begin
  ck(!model_running,"prepare helper only loads a stopped controller");
  @(negedge clk);prepare_center=value_c;prepare_target=value_t;prepare_event=1;mc=value_c;mt=value_t;model_calibrated=1;clear_history();
  @(negedge clk);prepare_event=0;repeat(4)@(negedge clk);
  ck(calibrated&&!running&&center==value_c&&target_position===value_t&&dut.d_filter_q8==0,"stopped prepare loads reference without inheriting filter tail");
 end endtask
 task start_run(input bit manual_toggle);begin
  ck(model_calibrated&&!model_running,"valid stopped calibration precedes start");
  @(negedge clk);if(manual_toggle)toggle_event=1;else capture_start_event=1;
  model_running=1;clear_history();meprev=wrap32((mc-$signed({1'b0,angle}))*64'sd10);
  @(negedge clk);toggle_event=0;capture_start_event=0;repeat(4)@(negedge clk);
  ck(running&&dut.angle_previous===meprev[31:0]&&dut.d_filter_q8==0,"manual/automatic filtered start seeds current full error and zero filter history");
 end endtask
 task stop_assert_now;begin
  stop_event=1;model_running=0;clear_history();
  @(negedge clk);stop_event=0;repeat(80)@(negedge clk);
  ck(!running&&motor_command==0&&location_out10==0&&dut.d_filter_q8==0&&dut.d_raw_latched==0&&dut.d_next_q8==0&&dut.d_correction_q8==0&&dut.d_magnitude_q8==0&&dut.d_round_magnitude_q8==0,"stop/idle clears every filter pipeline register and pending result");
 end endtask
 task stop_run;begin @(negedge clk);stop_assert_now();end endtask
 task short_fifth_sample;
  begin @(negedge clk);predict_sample();sample_ms=1;@(negedge clk);sample_ms=0;end
 endtask
 initial begin
  repeat(5)@(negedge clk);reset_all();
  if(SCENARIO==0)begin
   // Deliberate positive and negative .5ties in Q8 rounding,through real ADC input.
   angle=2955;position=0;prepare(2955,0);start_run(0);angle=2954;repeat(20)sample_one();stop_run();
   angle=2955;prepare(2955,0);start_run(0);angle=2956;repeat(20)sample_one();stop_run();
   angle=2955;prepare(2955,0);start_run(0);collect_noise=1;
   for(i=0;i<600;i=i+1)begin angle=2955+((i%2)?1:-1);position=0;sample_one();end
   collect_noise=0;ck(noise_samples>=100&&noise_filtered_square*100<noise_raw_square*36,"alternating5ms raw-D energy is attenuated without changing P/I arithmetic");
   for(i=0;i<400;i=i+1)begin angle=2860+(i%191);sample_one();end
   for(i=0;i<900;i=i+1)begin
    if(i==100)pulse_target(100);if(i==300)pulse_target(-100);if(i==650)pulse_target(32'sh7fffffff);if(i==750)pulse_target(32'sh80000000);
    angle=2940+((i*7)%31);position=((i/50)%9-4)*15;
    if(i>=650&&i<750)position=32'sh80000000;if(i>=750)position=32'sh7fffffff;
    sample_one();
   end
   stop_run();position=0;angle=0;prepare(4095,0);start_run(0);repeat(1300)sample_one();
   ck(positive_integral_clamps>0,"production positive integral limit is exercised");
   stop_run();angle=4095;prepare(0,0);start_run(0);repeat(1300)sample_one();
   ck(negative_integral_clamps>0&&saturated_outputs>100,"production negative integral and motor saturation are exercised");
   ck(positive_half_ties>0&&negative_half_ties>0,"both signs of symmetric half-way rounding are observed");
   stop_run();
  end else begin
   // An uncalibrated automatic start is rejected and cannot seed stale history.
   @(negedge clk);capture_start_event=1;@(negedge clk);capture_start_event=0;repeat(4)@(negedge clk);
   ck(!running&&fault==1&&dut.d_filter_q8==0,"uncalibrated capture is rejected");
   angle=2940;position=50;prepare(2955,50);start_run(0);repeat(20)sample_one();
   ck(dut.d_raw_latched==0&&dut.delta_latched==0,"automatic capture seeds a constant nonzero error without a D kick");
   angle=2956;repeat(25)sample_one();stop_run();
   angle=2900;position=0;prepare(2955,0);start_run(1);repeat(5)sample_one();
   ck(dut.d_raw_latched==0&&dut.delta_latched==0&&motor_command==22,"filtered manual toggle seeds error but retains original P/I contribution");
   repeat(45)sample_one();pulse_target(20);repeat(60)sample_one();
   ck(location_pulses>0,"target/outer changes are fed into the full-error D oracle");stop_run();
   // Stop in EACH of the five new pipeline stages,then restart cleanly.
   for(k=3;k<=7;k=k+1)begin
    angle=2955;position=0;prepare(2955,0);start_run(0);repeat(4)sample_one();angle=2944;short_fifth_sample();
    while(dut.math_state!=k)@(negedge clk);
    ck(pending_inner&&dut.math_state==k,"stop case reaches the requested in-flight filter stage");stop_assert_now();
    ck(!angle_update&&dut.d_filter_q8==0,"canceled filter stage cannot publish after stop");
   end
   angle=2955;prepare(2955,0);start_run(0);repeat(4)sample_one();angle=2966;short_fifth_sample();
   while(dut.math_state!=6)@(negedge clk);reset_all();
   angle=2955;position=0;prepare(2955,0);start_run(0);repeat(50)sample_one();
   ck(dut.d_filter_q8==0&&dut.delta_latched==0&&motor_command==0,"reset/restart cannot inherit a canceled filter or divider result");stop_run();
  end
  ck(angle_pulses>0&&location_pulses>0,"actual5ms and50ms loops both ran");
  $display("ALL PASS dfilter scenario%0d: %0d assertions, %0d samples, %0d angle_updates, %0d location_updates; half_ties=%0d/%0d noise_outputs=%0d raw_square=%0d filtered_square=%0d",SCENARIO,assertions,samples,angle_pulses,location_pulses,positive_half_ties,negative_half_ties,noise_samples,noise_raw_square,noise_filtered_square);$finish;
 end
 initial begin #(64'd1000000000);$fatal(1,"Dfilter oracle timeout");end
endmodule
module tb_dfilter_arithmetic;dfilter_oracle_test #(.SCENARIO(0)) t();endmodule
module tb_dfilter_capture_lifecycle;dfilter_oracle_test #(.SCENARIO(1)) t();endmodule

// SHIFT0 must match the frozen baseline on EVERY FPGA clock,not merely after
// its result settles. All production gain parameters are overridden explicitly.
module tb_dfilter_legacy_compat;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,sample_ms=0,sensor_ok=1,travel_ok=1,toggle_event=0,stop_event=0;
 reg plus_event=0,minus_event=0,calibrate_event=0,prepare_event=0,capture_start_event=0,target_update_event=0;
 reg [11:0] angle=2955,prepare_center=2955;reg signed[31:0] position=0,prepare_target=0,target_value=0;
 wire running_n,calibrated_n,calibrating_n,zero_position_n,angle_update_n,location_update_n;
 wire running_l,calibrated_l,calibrating_l,zero_position_l,angle_update_l,location_update_l;
 wire[3:0]fault_n,fault_l;wire[11:0]center_n,center_l;
 wire signed[31:0]target_position_n,target_position_l,location_out10_n,location_out10_l;
 wire signed[7:0]motor_command_n,motor_command_l;
 cascade_control #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(500),.ANGLE_D_FILTER_SHIFT(0),.LOCATION_KP_10(7),.LOCATION_KD_10(87)) dut(
  .clk(clk),.rst_n(rst_n),.sample_ms(sample_ms),.angle(angle),.position(position),.sensor_ok(sensor_ok),.travel_ok(travel_ok),
  .toggle_event(toggle_event),.stop_event(stop_event),.plus_event(plus_event),.minus_event(minus_event),.calibrate_event(calibrate_event),
  .prepare_event(prepare_event),.prepare_center(prepare_center),.prepare_target(prepare_target),.capture_start_event(capture_start_event),
  .target_update_event(target_update_event),.target_value(target_value),.running(running_n),.calibrated(calibrated_n),.calibrating(calibrating_n),
  .fault(fault_n),.center(center_n),.target_position(target_position_n),.location_out10(location_out10_n),.motor_command(motor_command_n),
  .zero_position(zero_position_n),.angle_update(angle_update_n),.location_update(location_update_n));
 cascade_control_legacy #(.ANGLE_KP_100(40),.ANGLE_KI_100(1),.ANGLE_KD_100(500),.LOCATION_KP_10(7),.LOCATION_KD_10(87)) frozen(
  .clk(clk),.rst_n(rst_n),.sample_ms(sample_ms),.angle(angle),.position(position),.sensor_ok(sensor_ok),.travel_ok(travel_ok),
  .toggle_event(toggle_event),.stop_event(stop_event),.plus_event(plus_event),.minus_event(minus_event),.calibrate_event(calibrate_event),
  .prepare_event(prepare_event),.prepare_center(prepare_center),.prepare_target(prepare_target),.capture_start_event(capture_start_event),
  .target_update_event(target_update_event),.target_value(target_value),.running(running_l),.calibrated(calibrated_l),.calibrating(calibrating_l),
  .fault(fault_l),.center(center_l),.target_position(target_position_l),.location_out10(location_out10_l),.motor_command(motor_command_l),
  .zero_position(zero_position_l),.angle_update(angle_update_l),.location_update(location_update_l));
 integer assertions=0,cycles=0,samples=0,angle_pulses=0,location_pulses=0,i;bit armed=0;
 task ck(input bit pass,input string message);begin assertions=assertions+1;
  if(!pass)$fatal(1,"%s legacycompat cycle=%0d sample=%0d U=%0d/%0d L=%0d/%0d math=%0d/%0d",message,cycles,samples,motor_command_n,motor_command_l,location_out10_n,location_out10_l,dut.math_state,frozen.math_state);
 end endtask
 always @(posedge clk)begin cycles=cycles+1;#1;if(armed)begin
  ck(!$isunknown({running_n,calibrated_n,calibrating_n,fault_n,center_n,target_position_n,location_out10_n,motor_command_n,zero_position_n,angle_update_n,location_update_n}),"public outputs are initialized,not matching X values");
  ck({running_n,calibrated_n,calibrating_n,fault_n,center_n,target_position_n,location_out10_n,motor_command_n,zero_position_n,angle_update_n,location_update_n}===
     {running_l,calibrated_l,calibrating_l,fault_l,center_l,target_position_l,location_out10_l,motor_command_l,zero_position_l,angle_update_l,location_update_l},"SHIFT0public outputs/pulses match frozen core on every FPGA cycle");
  ck(dut.math_state==frozen.math_state&&{dut.angle_count,dut.location_count,dut.angle_previous,dut.location_previous,dut.integral,dut.error_latched,dut.delta_latched,dut.integral_latched,dut.numerator,dut.div_input,dut.div_start}===
    {frozen.angle_count,frozen.location_count,frozen.angle_previous,frozen.location_previous,frozen.integral,frozen.error_latched,frozen.delta_latched,frozen.integral_latched,frozen.numerator,frozen.div_input,frozen.div_start},"SHIFT0history,arithmetic and exact pipeline cadence match frozen core");
  if(angle_update_n)angle_pulses=angle_pulses+1;if(location_update_n)location_pulses=location_pulses+1;
 end end
 task sample_one;begin @(negedge clk);sample_ms=1;samples=samples+1;@(negedge clk);sample_ms=0;repeat(198)@(negedge clk);end endtask
 task set_target(input reg signed[31:0] value);begin @(negedge clk);target_value=value;target_update_event=1;@(negedge clk);target_update_event=0;end endtask
 task prepare;begin @(negedge clk);prepare_event=1;@(negedge clk);prepare_event=0;repeat(4)@(negedge clk);end endtask
 task capture;begin @(negedge clk);capture_start_event=1;@(negedge clk);capture_start_event=0;repeat(4)@(negedge clk);end endtask
 task toggle;begin @(negedge clk);toggle_event=1;@(negedge clk);toggle_event=0;repeat(4)@(negedge clk);end endtask
 task stop;begin @(negedge clk);stop_event=1;@(negedge clk);stop_event=0;repeat(60)@(negedge clk);end endtask
 initial begin
  repeat(5)@(negedge clk);armed=1;rst_n=1;capture();ck(!running_n&&fault_n==1,"uncalibrated start actually exercised");
  prepare_target=42;prepare();position=42;capture();
  for(i=0;i<1200;i=i+1)begin
   if(i==100)set_target(520);if(i==300)set_target(-520);if(i==800)set_target(32'sh7fffffff);if(i==1000)set_target(32'sh80000000);
   angle=(i%17==0)?0:((i%19==0)?4095:2955+((i*13)%101)-50);position=((i*37)%901)-450;
   if(i>=800&&i<1000)position=32'sh80000000;if(i>=1000)position=32'sh7fffffff;
   sample_one();
  end
  toggle();ck(!running_n,"manual stop exercised");angle=2900;toggle();repeat(100)sample_one();
  // Stop while the old divider is active. Both implementations must cancel it.
  repeat(4)sample_one();@(negedge clk);sample_ms=1;@(negedge clk);sample_ms=0;repeat(6)@(negedge clk);stop();
  prepare_center=2955;prepare_target=-31;prepare();position=-31;capture();repeat(100)sample_one();stop();
  @(negedge clk);plus_event=1;@(negedge clk);plus_event=0;
  @(negedge clk);minus_event=1;@(negedge clk);minus_event=0;
  @(negedge clk);calibrate_event=1;@(negedge clk);calibrate_event=0;
  angle=3000;repeat(40)sample_one();ck(calibrated_n&&!calibrating_n&&center_n==3000,"manual32sample calibration remained active in comparison");
  toggle();repeat(50)sample_one();
  @(negedge clk);rst_n=0;repeat(5)@(negedge clk);rst_n=1;repeat(5)@(negedge clk);
  ck(angle_pulses>200&&location_pulses>20,"comparison exercises real inner and outer updates,not idle zeros");
  $display("ALL PASS dfilter legacy_compat: %0d assertions, %0d samples, %0d FPGAcycles, %0d angle_updates, %0d location_updates",assertions,samples,cycles,angle_pulses,location_pulses);$finish;
 end
 initial begin #(64'd1000000000);$fatal(1,"SHIFT0legacy compatibility timeout");end
endmodule

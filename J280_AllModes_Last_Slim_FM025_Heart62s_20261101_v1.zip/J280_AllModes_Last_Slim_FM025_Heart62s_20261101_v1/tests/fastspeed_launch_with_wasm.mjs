import {pathToFileURL,fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
const here=dirname(fileURLToPath(import.meta.url));
process.env.J280_VERILOG_RUNTIME=resolve(here,'fastspeed_wasm_adapter.mjs');
const target=process.argv[2] ? resolve(process.argv[2]) : resolve(here,'fastspeed_checks.mjs');
await import(pathToFileURL(target).href);

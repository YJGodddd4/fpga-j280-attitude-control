`timescale 1ns/1ps
// Sample only the actual TX pin at UART bit centers. No hierarchical reads of
// byte_out/index/active, and no reused RTL UART receiver or physical device.
module tb_ffmonitor_uart;
    localparam integer BAUD=115200;
    localparam integer CLK_HZ=BAUD*16;
    localparam real CLOCK_NS=1000000000.0/CLK_HZ;
    localparam real BIT_NS=16.0*CLOCK_NS;
    localparam integer A_BYTES=54, M_BYTES=29, O_BYTES=176, X_BYTES=512, FRAME_BYTES=901;
    reg clk=0;
    always #(CLOCK_NS/2.0) clk=~clk;
    reg rst_n=0, request=0, noise=0;
    reg [11:0] angle=0, center=0;
    reg signed [31:0] position=0, target_position=0, velocity_q8=0;
    reg signed [7:0] command=0;
    reg running=0, calibrated=0, auto_ready=0, motion_valid=0;
    reg [3:0] fault=0, mode=0;
    reg [7:0] pulse_count=0;
    reg [1:0] pos_dip_mode=0, pos_step_index=0;
    reg [3:0] pos_task_state=0;
    reg signed [31:0] pos_edit_deci=0, pos_goal_deci=0;
    reg signed [31:0] pos_home=0, pos_reference=0;
    reg signed [31:0] pos_ref_velocity_q8=0, pos_velocity_q8=0;
    reg pos_anchor_valid=0, pos_interrupted=0;
    reg [15:0] pos_task_id=0;
    reg [31:0] uptime_ms=0;
    reg [63:0] pos_duration_ms=0;
    reg [1:0] u_reference_owner=0;
    reg signed [31:0] u_planner_reference_units=0;
    reg signed [31:0] u_active_base_units=0;
    reg signed [31:0] u_trajectory_endpoint_units=0;
    reg signed [31:0] u_reference_velocity_q8=0;
    reg [7:0] u_duty_limit_pct=0;
    reg [1:0] u_active_trajectory_profile=0;
    reg [3:0] u_trajectory_state=0;
    reg [31:0] u_trajectory_cycle_count=0;
    reg [31:0] u_trajectory_elapsed_ms=0;
    reg [15:0] u_trajectory_phase=0;
    reg signed [31:0] u_reference_acceleration_q8=0;
    reg signed [31:0] u_reference_jerk_q8=0;
    reg [15:0] u_flags=0;
    reg [11:0] u_down_center_adc=0;
    reg [12:0] u_peak_amplitude_adc=0;
    reg [31:0] u_trajectory_cycle_ms=0;
    reg [31:0] u_trajectory_config_tag=0;
    reg [31:0] u_angle_kp_100=0;
    reg [31:0] u_angle_ki_100=0;
    reg [31:0] u_angle_kd_100=0;
    reg [31:0] u_location_kp_10=0;
    reg [31:0] u_location_kd_10=0;
    reg [31:0] u_position_min_move_ms=0;
    reg [31:0] u_position_ms_per_degree=0;
    reg signed [31:0] u_trajectory_edit_deci=0, u_trajectory_accepted_deci=0;
    reg [1:0] u_trajectory_step_index=0;
    reg [15:0] u_trajectory_run_id=0;
    reg [31:0] u_trajectory_time_stretch=0;
    reg signed [31:0] u_trapezoid_edit_deci=0, u_scurve_edit_deci=0, u_sine_edit_deci=0;
    reg signed [31:0] ff_gain_q16=0,ff_pd10=0,ff_applied10=0,ff_loc10=0,ff_acceleration_q8=0;
    reg signed [32:0] ff_total10=0;
    reg ff_active=0,ff_limited=0,speed_valid=0;
    wire tx;
    telemetry #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) dut(.*);

    reg [7:0] received [0:8191];
    reg [7:0] rx_byte;
    integer rx_count=0, bit_no, assertions=0, byte_comparisons=0;
    initial forever begin
        @(negedge tx);
        if (rst_n) begin
            #(BIT_NS/2.0);
            if (tx!==1'b0) $fatal(1,"UART start bit not low");
            rx_byte=0;
            for (bit_no=0;bit_no<8;bit_no=bit_no+1) begin
                #(BIT_NS);
                if (tx!==1'b0 && tx!==1'b1) $fatal(1,"Unknown UART data bit");
                rx_byte[bit_no]=tx;
            end
            #(BIT_NS);
            if (tx!==1'b1) $fatal(1,"UART stop bit not high");
            if (rx_count>=8192) $fatal(1,"Unexpected continuous UART transmission");
            received[rx_count]=rx_byte;
            rx_count=rx_count+1;
        end
    end

    // Mutate every source field during transmission, after the request edge.
    // All four lines, including their repeated fields, must remain atomic.
    always @(negedge clk) if (noise) begin
        ff_gain_q16=ff_gain_q16+17;ff_pd10=ff_pd10-19;ff_applied10=ff_applied10+23;
        ff_loc10=ff_loc10-29;ff_acceleration_q8=ff_acceleration_q8+31;ff_total10=ff_total10-37;
        ff_active=~ff_active;ff_limited=~ff_limited;speed_valid=~speed_valid;
        angle=angle+1; center=center-1;
        position=position+3; target_position=target_position-5;
        command=command+1; running=~running; calibrated=~calibrated;
        fault=fault+1; mode=mode+1; velocity_q8=velocity_q8+7;
        pulse_count=pulse_count+1; auto_ready=~auto_ready; motion_valid=~motion_valid;
        pos_dip_mode=pos_dip_mode+1; pos_step_index=pos_step_index+1;
        pos_task_state=pos_task_state+1; pos_edit_deci=pos_edit_deci-11;
        pos_goal_deci=pos_goal_deci+13; pos_home=pos_home-17;
        pos_reference=pos_reference+19; pos_ref_velocity_q8=pos_ref_velocity_q8-23;
        pos_velocity_q8=pos_velocity_q8+29; pos_anchor_valid=~pos_anchor_valid;
        pos_interrupted=~pos_interrupted; pos_task_id=pos_task_id+31;
        uptime_ms=uptime_ms+37; pos_duration_ms=pos_duration_ms+41;
        u_reference_owner=u_reference_owner+43;
        u_planner_reference_units=u_planner_reference_units+45;
        u_active_base_units=u_active_base_units+47;
        u_trajectory_endpoint_units=u_trajectory_endpoint_units+49;
        u_reference_velocity_q8=u_reference_velocity_q8+51;
        u_duty_limit_pct=u_duty_limit_pct+53;
        u_active_trajectory_profile=u_active_trajectory_profile+55;
        u_trajectory_state=u_trajectory_state+57;
        u_trajectory_cycle_count=u_trajectory_cycle_count+59;
        u_trajectory_elapsed_ms=u_trajectory_elapsed_ms+61;
        u_trajectory_phase=u_trajectory_phase+63;
        u_reference_acceleration_q8=u_reference_acceleration_q8+65;
        u_reference_jerk_q8=u_reference_jerk_q8+67;
        u_flags=u_flags+69;
        u_down_center_adc=u_down_center_adc+71;
        u_peak_amplitude_adc=u_peak_amplitude_adc+73;
        u_trajectory_cycle_ms=u_trajectory_cycle_ms+75;
        u_trajectory_config_tag=u_trajectory_config_tag+77;
        u_angle_kp_100=u_angle_kp_100+79;
        u_angle_ki_100=u_angle_ki_100+81;
        u_angle_kd_100=u_angle_kd_100+83;
        u_location_kp_10=u_location_kp_10+85;
        u_location_kd_10=u_location_kd_10+87;
        u_position_min_move_ms=u_position_min_move_ms+89;
        u_position_ms_per_degree=u_position_ms_per_degree+91;
        u_trajectory_edit_deci=u_trajectory_edit_deci+97;
        u_trajectory_accepted_deci=u_trajectory_accepted_deci-101;
        u_trajectory_step_index=u_trajectory_step_index+103;
        u_trajectory_run_id=u_trajectory_run_id+107;
        u_trajectory_time_stretch=u_trajectory_time_stretch+109;
        u_trapezoid_edit_deci=u_trapezoid_edit_deci-113;
        u_scurve_edit_deci=u_scurve_edit_deci+127;
        u_sine_edit_deci=u_sine_edit_deci-131;

    end

    task automatic ck(input bit ok, input string message);
        begin
            assertions=assertions+1;
            if (!ok) $fatal(1,"%s; received=%0d",message,rx_count);
        end
    endtask
    task automatic pulse_request;
        begin
            @(negedge clk); request=1;
            @(negedge clk); request=0;
        end
    endtask
    // New input cases are independent of the serializer's field/nibble code.
    task automatic load_unified_case(input integer which);
        begin
            u_reference_owner=0;
            u_planner_reference_units=0;
            u_active_base_units=0;
            u_trajectory_endpoint_units=0;
            u_reference_velocity_q8=0;
            u_duty_limit_pct=0;
            u_active_trajectory_profile=0;
            u_trajectory_state=0;
            u_trajectory_cycle_count=0;
            u_trajectory_elapsed_ms=0;
            u_trajectory_phase=0;
            u_reference_acceleration_q8=0;
            u_reference_jerk_q8=0;
            u_flags=0;
            u_down_center_adc=0;
            u_peak_amplitude_adc=0;
            u_trajectory_cycle_ms=0;
            u_trajectory_config_tag=0;
            u_angle_kp_100=0;
            u_angle_ki_100=0;
            u_angle_kd_100=0;
            u_location_kp_10=0;
            u_location_kd_10=0;
            u_position_min_move_ms=0;
            u_position_ms_per_degree=0;
            u_trajectory_edit_deci=0;u_trajectory_accepted_deci=0;u_trajectory_step_index=0;u_trajectory_run_id=0;
            u_trajectory_time_stretch=0;u_trapezoid_edit_deci=0;u_scurve_edit_deci=0;u_sine_edit_deci=0;
            case(which)
                0: begin end
                1: begin
                    u_reference_owner=1;u_planner_reference_units=-120;u_active_base_units=16;u_trajectory_endpoint_units=50;u_reference_velocity_q8=-512;u_duty_limit_pct=100;
                    u_active_trajectory_profile=1;u_trajectory_state=4;u_trajectory_cycle_count=32'h12345678;u_trajectory_elapsed_ms=32'h55667788;u_trajectory_phase=16'h1357;
                    u_reference_acceleration_q8=-256;u_reference_jerk_q8=32'sh80000000;u_flags=16'hffff;u_down_center_adc=12'h321;u_peak_amplitude_adc=13'h1234;
                    u_trajectory_cycle_ms=32'h01020304;u_trajectory_config_tag=32'h89abcdef;u_angle_kp_100=120;u_angle_ki_100=1;u_angle_kd_100=55;u_location_kp_10=7;u_location_kd_10=40;u_position_min_move_ms=300;u_position_ms_per_degree=15;
                    u_trajectory_edit_deci=-123;u_trajectory_accepted_deci=7200;u_trajectory_step_index=1;u_trajectory_run_id=16'h1234;
                    u_trajectory_time_stretch=24;u_trapezoid_edit_deci=7200;u_scurve_edit_deci=-600;u_sine_edit_deci=200;
                end
                2: begin
                    u_reference_owner=2;u_planner_reference_units=32'sh80000000;u_active_base_units=32'sh7fffffff;u_trajectory_endpoint_units=32'sh80000000;u_reference_velocity_q8=32'sh80000000;u_duty_limit_pct=255;
                    u_active_trajectory_profile=2;u_trajectory_state=15;u_trajectory_cycle_count=32'hffffffff;u_trajectory_elapsed_ms=32'h80000000;u_trajectory_phase=16'hffff;
                    u_reference_acceleration_q8=32'sh7fffffff;u_reference_jerk_q8=-1;u_flags=16'h8000;u_down_center_adc=12'hfff;u_peak_amplitude_adc=13'h1fff;
                    u_trajectory_cycle_ms=32'hffffffff;u_trajectory_config_tag=32'h80000000;u_angle_kp_100=32'hffffffff;u_angle_ki_100=32'h80000000;u_angle_kd_100=0;u_location_kp_10=32'hffffffff;u_location_kd_10=32'h80000000;u_position_min_move_ms=32'hffffffff;u_position_ms_per_degree=32'h80000000;
                    u_trajectory_edit_deci=32'sh80000000;u_trajectory_accepted_deci=32'sh7fffffff;u_trajectory_step_index=3;u_trajectory_run_id=16'hffff;
                    u_trajectory_time_stretch=32'hffffffff;u_trapezoid_edit_deci=32'sh80000000;u_scurve_edit_deci=32'sh7fffffff;u_sine_edit_deci=-1;
                end
                3: begin
                    u_reference_owner=3;u_planner_reference_units=32'sh7fffffff;u_active_base_units=32'sh80000000;u_trajectory_endpoint_units=32'sh7fffffff;u_reference_velocity_q8=32'sh7fffffff;u_duty_limit_pct=0;
                    u_active_trajectory_profile=3;u_trajectory_state=10;u_trajectory_cycle_count=0;u_trajectory_elapsed_ms=32'hffffffff;u_trajectory_phase=16'h8000;
                    u_reference_acceleration_q8=32'sh80000000;u_reference_jerk_q8=32'sh7fffffff;u_flags=0;u_down_center_adc=0;u_peak_amplitude_adc=0;
                    u_trajectory_cycle_ms=0;u_trajectory_config_tag=32'h7fffffff;u_angle_kp_100=0;u_angle_ki_100=32'hffffffff;u_angle_kd_100=32'h80000000;u_location_kp_10=32'h7fffffff;u_location_kd_10=1;u_position_min_move_ms=0;u_position_ms_per_degree=32'hffffffff;
                    u_trajectory_edit_deci=32'sh7fffffff;u_trajectory_accepted_deci=32'sh80000000;u_trajectory_step_index=0;u_trajectory_run_id=0;
                    u_trajectory_time_stretch=32'h80000000;u_trapezoid_edit_deci=32'sh7fffffff;u_scurve_edit_deci=32'sh80000000;u_sine_edit_deci=0;
                end
                4: begin
                    u_reference_owner=1;u_planner_reference_units=1010;u_active_base_units=1000;u_trajectory_endpoint_units=1816;u_reference_velocity_q8=256;u_duty_limit_pct=100;
                    u_active_trajectory_profile=2;u_trajectory_state=2;u_trajectory_cycle_count=12;u_trajectory_elapsed_ms=100000;u_trajectory_phase=7;
                    u_reference_acceleration_q8=512;u_reference_jerk_q8=768;u_flags=16'h3fff;u_down_center_adc=859;u_peak_amplitude_adc=4095;
                    u_trajectory_cycle_ms=11000;u_trajectory_config_tag=32'h10203040;u_angle_kp_100=40;u_angle_ki_100=1;u_angle_kd_100=55;u_location_kp_10=4;u_location_kd_10=40;u_position_min_move_ms=300;u_position_ms_per_degree=15;
                    u_trajectory_edit_deci=7200;u_trajectory_accepted_deci=7200;u_trajectory_step_index=2;u_trajectory_run_id=42;
                    u_trajectory_time_stretch=24;u_trapezoid_edit_deci=7200;u_scurve_edit_deci=-600;u_sine_edit_deci=200;
                end
                5: begin
                    u_reference_owner=0;u_planner_reference_units=-1010;u_active_base_units=-1000;u_trajectory_endpoint_units=-1816;u_reference_velocity_q8=-256;u_duty_limit_pct=100;
                    u_reference_acceleration_q8=-512;u_reference_jerk_q8=-768;u_flags=16'h4000;u_down_center_adc=859;u_peak_amplitude_adc=100;
                    u_trajectory_config_tag=32'hffffffff;u_angle_kp_100=40;u_angle_ki_100=1;u_angle_kd_100=55;u_location_kp_10=4;u_location_kd_10=40;u_position_min_move_ms=300;u_position_ms_per_degree=15;
                    u_trajectory_edit_deci=-7200;u_trajectory_accepted_deci=-40000;u_trajectory_step_index=3;u_trajectory_run_id=16'h8000;
                    u_trajectory_time_stretch=65536;u_trapezoid_edit_deci=-40000;u_scurve_edit_deci=-7200;u_sine_edit_deci=-200;
                end
                default:$fatal(1,"Bad unified case");
            endcase
        end
    endtask

    task automatic load_case(input integer which);
        begin
            @(negedge clk);
            case (which)
                0: begin
                    angle=0; center=0; position=0; target_position=0;
                    command=0; running=0; calibrated=0; fault=0; mode=0;
                    velocity_q8=0; pulse_count=0; auto_ready=0; motion_valid=0;
                    pos_dip_mode=0; pos_task_state=0; pos_edit_deci=0; pos_goal_deci=0;
                    pos_home=0; pos_reference=0; pos_ref_velocity_q8=0; pos_velocity_q8=0;
                    pos_step_index=0; pos_anchor_valid=0; pos_task_id=0; pos_interrupted=0;
                    uptime_ms=0; pos_duration_ms=0;
                end
                1: begin
                    angle=12'h123; center=12'habc; position=-1; target_position=32'sh80000000;
                    command=-100; running=1; calibrated=0; fault=4'ha; mode=5;
                    velocity_q8=-256; pulse_count=8'hfe; auto_ready=1; motion_valid=0;
                    pos_dip_mode=1; pos_task_state=5; pos_edit_deci=-1; pos_goal_deci=-1800;
                    pos_home=32'sh12345678; pos_reference=-123456789;
                    pos_ref_velocity_q8=-256; pos_velocity_q8=256;
                    pos_step_index=1; pos_anchor_valid=1; pos_task_id=16'hffff; pos_interrupted=1;
                    uptime_ms=32'h01234567; pos_duration_ms=64'hffffffffffffffff;
                end
                2: begin
                    angle=12'hfff; center=0; position=32'sh80000000; target_position=32'sh7fffffff;
                    command=-128; running=0; calibrated=1; fault=4'hf; mode=4'hf;
                    velocity_q8=32'sh80000000; pulse_count=8'hff; auto_ready=0; motion_valid=1;
                    pos_dip_mode=2; pos_task_state=4'ha; pos_edit_deci=32'sh80000000; pos_goal_deci=32'sh7fffffff;
                    pos_home=32'sh80000000; pos_reference=32'sh7fffffff;
                    pos_ref_velocity_q8=32'sh80000000; pos_velocity_q8=32'sh7fffffff;
                    pos_step_index=2; pos_anchor_valid=0; pos_task_id=16'h8000; pos_interrupted=0;
                    uptime_ms=32'hffffffff; pos_duration_ms=64'h8000000000000000;
                end
                3: begin
                    angle=0; center=12'hfff; position=32'sh7fffffff; target_position=-1;
                    command=127; running=1; calibrated=1; fault=0; mode=4'ha;
                    velocity_q8=32'sh7fffffff; pulse_count=0; auto_ready=1; motion_valid=1;
                    pos_dip_mode=3; pos_task_state=4'hf; pos_edit_deci=32'sh7fffffff; pos_goal_deci=32'sh80000000;
                    pos_home=32'sh7fffffff; pos_reference=32'sh80000000;
                    pos_ref_velocity_q8=32'sh7fffffff; pos_velocity_q8=32'sh80000000;
                    pos_step_index=3; pos_anchor_valid=1; pos_task_id=0; pos_interrupted=1;
                    uptime_ms=32'h80000000; pos_duration_ms=0;
                end
                4: begin
                    angle=12'hb8b; center=12'hb8b; position=1000; target_position=1816;
                    command=25; running=1; calibrated=1; fault=0; mode=5;
                    velocity_q8=257; pulse_count=12; auto_ready=1; motion_valid=1;
                    pos_dip_mode=0; pos_task_state=2; pos_edit_deci=7200; pos_goal_deci=40000;
                    pos_home=1000; pos_reference=1010; pos_ref_velocity_q8=256; pos_velocity_q8=512;
                    pos_step_index=1; pos_anchor_valid=1; pos_task_id=6; pos_interrupted=0;
                    uptime_ms=32'h10203040; pos_duration_ms=64'h0123456789abcdef;
                end
                5: begin
                    angle=12'hb8b; center=12'hb8b; position=-1000; target_position=-1816;
                    command=-25; running=1; calibrated=1; fault=0; mode=5;
                    velocity_q8=-257; pulse_count=12; auto_ready=1; motion_valid=1;
                    pos_dip_mode=0; pos_task_state=2; pos_edit_deci=-40000; pos_goal_deci=-7200;
                    pos_home=-1000; pos_reference=-1010; pos_ref_velocity_q8=-256; pos_velocity_q8=-512;
                    pos_step_index=1; pos_anchor_valid=1; pos_task_id=7; pos_interrupted=0;
                    uptime_ms=32'hf0e0d0c0; pos_duration_ms=64'h0000000100000000;
                end
                default: $fatal(1,"Bad test case");
            endcase
            ff_gain_q16=0;ff_pd10=0;ff_applied10=0;ff_loc10=0;ff_acceleration_q8=0;
            ff_total10=0;ff_active=0;ff_limited=0;speed_valid=0;
            case(which)
                1:begin ff_gain_q16=-32768;ff_pd10=32'sh7fffffff;ff_applied10=-1;
                    ff_total10=-33'sd4294967296;ff_loc10=-1000;ff_acceleration_q8=32'sh80000000;ff_active=1;ff_limited=1;end
                2:begin ff_gain_q16=32'sh7fffffff;ff_pd10=32'sh80000000;ff_applied10=32'sh7fffffff;
                    ff_total10=33'sd4294967295;ff_loc10=1000;ff_acceleration_q8=32'sh7fffffff;speed_valid=1;end
                3:begin ff_gain_q16=32'sh80000000;ff_pd10=-1;ff_applied10=0;
                    ff_total10=-1;ff_loc10=-1;ff_acceleration_q8=-1;ff_active=1;speed_valid=1;end
                4:begin ff_gain_q16=16384;ff_pd10=700;ff_applied10=-256;
                    ff_total10=444;ff_loc10=444;ff_acceleration_q8=-1024;ff_active=1;speed_valid=1;end
                5:begin ff_pd10=-1100;ff_total10=-1100;ff_loc10=-1000;ff_acceleration_q8=-512;ff_limited=1;speed_valid=1;end
            endcase
            load_unified_case(which);
        end
    endtask

    function automatic string expected_legacy_case(input integer which, input integer sequence_number);
        string seq;
        begin
            // Explicit strings avoid sharing the serializer's nibble logic.
            case (sequence_number)
                1:seq="00000001";
                2:seq="00000002";
                3:seq="00000003";
                4:seq="00000004";
                5:seq="00000005";
                6:seq="00000006";
                default:$fatal(1,"Bad expected sequence");
            endcase
            case (which)
                0: expected_legacy_case={
                    "A=0000 C=0000 P=00000000 T=00000000 U=00 R=0 K=0 F=0\015\012",
                    "M=0 W=00000000 N=00 Q=0 Z=0\015\012",
                    "O=5103 D=0 S=0 E=00000000 G=00000000 H=00000000 R=00000000 P=00000000 V=00000000 W=00000000 K=0 A=0 I=0000 Z=0 M=0 U=00 B=0000 C=0000 T=00000000 Q=",seq," L=0000000000000000\015\012"};
                1: expected_legacy_case={
                    "A=0123 C=0ABC P=FFFFFFFF T=80000000 U=9C R=1 K=0 F=A\015\012",
                    "M=5 W=FFFFFF00 N=FE Q=1 Z=0\015\012",
                    "O=5103 D=1 S=5 E=FFFFFFFF G=FFFFF8F8 H=12345678 R=F8A432EB P=FFFFFFFF V=FFFFFF00 W=00000100 K=1 A=1 I=FFFF Z=1 M=5 U=9C B=0123 C=0ABC T=01234567 Q=",seq," L=FFFFFFFFFFFFFFFF\015\012"};
                2: expected_legacy_case={
                    "A=0FFF C=0000 P=80000000 T=7FFFFFFF U=80 R=0 K=1 F=F\015\012",
                    "M=F W=80000000 N=FF Q=0 Z=1\015\012",
                    "O=5103 D=2 S=A E=80000000 G=7FFFFFFF H=80000000 R=7FFFFFFF P=80000000 V=80000000 W=7FFFFFFF K=2 A=0 I=8000 Z=0 M=F U=80 B=0FFF C=0000 T=FFFFFFFF Q=",seq," L=8000000000000000\015\012"};
                3: expected_legacy_case={
                    "A=0000 C=0FFF P=7FFFFFFF T=FFFFFFFF U=7F R=1 K=1 F=0\015\012",
                    "M=A W=7FFFFFFF N=00 Q=1 Z=1\015\012",
                    "O=5103 D=3 S=F E=7FFFFFFF G=80000000 H=7FFFFFFF R=80000000 P=7FFFFFFF V=7FFFFFFF W=80000000 K=3 A=1 I=0000 Z=1 M=A U=7F B=0000 C=0FFF T=80000000 Q=",seq," L=0000000000000000\015\012"};
                4: expected_legacy_case={
                    "A=0B8B C=0B8B P=000003E8 T=00000718 U=19 R=1 K=1 F=0\015\012",
                    "M=5 W=00000101 N=0C Q=1 Z=1\015\012",
                    "O=5103 D=0 S=2 E=00001C20 G=00009C40 H=000003E8 R=000003F2 P=000003E8 V=00000100 W=00000200 K=1 A=1 I=0006 Z=0 M=5 U=19 B=0B8B C=0B8B T=10203040 Q=",seq," L=0123456789ABCDEF\015\012"};
                5: expected_legacy_case={
                    "A=0B8B C=0B8B P=FFFFFC18 T=FFFFF8E8 U=E7 R=1 K=1 F=0\015\012",
                    "M=5 W=FFFFFEFF N=0C Q=1 Z=1\015\012",
                    "O=5103 D=0 S=2 E=FFFF63C0 G=FFFFE3E0 H=FFFFFC18 R=FFFFFC0E P=FFFFFC18 V=FFFFFF00 W=FFFFFE00 K=1 A=1 I=0007 Z=0 M=5 U=E7 B=0B8B C=0B8B T=F0E0D0C0 Q=",seq," L=0000000100000000\015\012"};
                default:expected_legacy_case="";
            endcase
        end
    endfunction

    // Fully written expected X strings do not use the schema JSON, a field map,
    // dynamic hex formatter or RTL hierarchy. This also fixes every field's order.
    function automatic string expected_unified_case(input integer which,input integer sequence_number);
        string seq;
        begin
            case(sequence_number)
                1:seq="00000001";2:seq="00000002";3:seq="00000003";
                4:seq="00000004";5:seq="00000005";6:seq="00000006";
                default:$fatal(1,"Bad unified sequence");
            endcase
            case(which)
                0:expected_unified_case={"X=8002 T=00000000 Q=",seq," D=0 O=0 M=0 F=0 K=0 R=0 A=0000 C=0000 P=00000000 Y=00000000 RF=00000000 H=00000000 EP=00000000 V=00000000 W=00000000 U=00 B=00 E=00000000 G=00000000 S=0 I=0000 Z=0 L=0000000000000000 J=0 N=0 CY=00000000 EL=00000000 PH=0000 AC=00000000 JK=00000000 FL=0000 PV=00000000 PC=00 DC=0000 PK=0000 CL=00000000 CF=00000000 AP=00000000 AI=00000000 AD=00000000 LP=00000000 LD=00000000 PM=00000000 PD=00000000 TE=00000000 TA=00000000 TZ=0 TI=0000 TM=00000000 EA=00000000 EB=00000000 EC=00000000\015\012"};
                1:expected_unified_case={"X=8002 T=01234567 Q=",seq," D=1 O=1 M=5 F=A K=0 R=1 A=0123 C=0ABC P=FFFFFFFF Y=80000000 RF=FFFFFF88 H=00000010 EP=00000032 V=FFFFFE00 W=00000100 U=9C B=64 E=FFFFFFFF G=FFFFF8F8 S=5 I=FFFF Z=1 L=FFFFFFFFFFFFFFFF J=1 N=4 CY=12345678 EL=55667788 PH=1357 AC=FFFFFF00 JK=80000000 FL=FFFF PV=FFFFFF00 PC=FE DC=0321 PK=1234 CL=01020304 CF=89ABCDEF AP=00000078 AI=00000001 AD=00000037 LP=00000007 LD=00000028 PM=0000012C PD=0000000F TE=FFFFFF85 TA=00001C20 TZ=1 TI=1234 TM=00000018 EA=00001C20 EB=FFFFFDA8 EC=000000C8\015\012"};
                2:expected_unified_case={"X=8002 T=FFFFFFFF Q=",seq," D=2 O=2 M=F F=F K=1 R=0 A=0FFF C=0000 P=80000000 Y=7FFFFFFF RF=80000000 H=7FFFFFFF EP=80000000 V=80000000 W=7FFFFFFF U=80 B=FF E=80000000 G=7FFFFFFF S=A I=8000 Z=0 L=8000000000000000 J=2 N=F CY=FFFFFFFF EL=80000000 PH=FFFF AC=7FFFFFFF JK=FFFFFFFF FL=8000 PV=80000000 PC=FF DC=0FFF PK=1FFF CL=FFFFFFFF CF=80000000 AP=FFFFFFFF AI=80000000 AD=00000000 LP=FFFFFFFF LD=80000000 PM=FFFFFFFF PD=80000000 TE=80000000 TA=7FFFFFFF TZ=3 TI=FFFF TM=FFFFFFFF EA=80000000 EB=7FFFFFFF EC=FFFFFFFF\015\012"};
                3:expected_unified_case={"X=8002 T=80000000 Q=",seq," D=3 O=3 M=A F=0 K=1 R=1 A=0000 C=0FFF P=7FFFFFFF Y=FFFFFFFF RF=7FFFFFFF H=80000000 EP=7FFFFFFF V=7FFFFFFF W=80000000 U=7F B=00 E=7FFFFFFF G=80000000 S=F I=0000 Z=1 L=0000000000000000 J=3 N=A CY=00000000 EL=FFFFFFFF PH=8000 AC=80000000 JK=7FFFFFFF FL=0000 PV=7FFFFFFF PC=00 DC=0000 PK=0000 CL=00000000 CF=7FFFFFFF AP=00000000 AI=FFFFFFFF AD=80000000 LP=7FFFFFFF LD=00000001 PM=00000000 PD=FFFFFFFF TE=7FFFFFFF TA=80000000 TZ=0 TI=0000 TM=80000000 EA=7FFFFFFF EB=80000000 EC=00000000\015\012"};
                4:expected_unified_case={"X=8002 T=10203040 Q=",seq," D=0 O=1 M=5 F=0 K=1 R=1 A=0B8B C=0B8B P=000003E8 Y=00000718 RF=000003F2 H=000003E8 EP=00000718 V=00000100 W=00000200 U=19 B=64 E=00001C20 G=00009C40 S=2 I=0006 Z=0 L=0123456789ABCDEF J=2 N=2 CY=0000000C EL=000186A0 PH=0007 AC=00000200 JK=00000300 FL=3FFF PV=00000101 PC=0C DC=035B PK=0FFF CL=00002AF8 CF=10203040 AP=00000028 AI=00000001 AD=00000037 LP=00000004 LD=00000028 PM=0000012C PD=0000000F TE=00001C20 TA=00001C20 TZ=2 TI=002A TM=00000018 EA=00001C20 EB=FFFFFDA8 EC=000000C8\015\012"};
                5:expected_unified_case={"X=8002 T=F0E0D0C0 Q=",seq," D=0 O=0 M=5 F=0 K=1 R=1 A=0B8B C=0B8B P=FFFFFC18 Y=FFFFF8E8 RF=FFFFFC0E H=FFFFFC18 EP=FFFFF8E8 V=FFFFFF00 W=FFFFFE00 U=E7 B=64 E=FFFF63C0 G=FFFFE3E0 S=2 I=0007 Z=0 L=0000000100000000 J=0 N=0 CY=00000000 EL=00000000 PH=0000 AC=FFFFFE00 JK=FFFFFD00 FL=4000 PV=FFFFFEFF PC=0C DC=035B PK=0064 CL=00000000 CF=FFFFFFFF AP=00000028 AI=00000001 AD=00000037 LP=00000004 LD=00000028 PM=0000012C PD=0000000F TE=FFFFE3E0 TA=FFFF63C0 TZ=3 TI=8000 TM=00010000 EA=FFFF63C0 EB=FFFFE3E0 EC=FFFFFF38\015\012"};
                default:expected_unified_case="";
            endcase
        end
    endfunction

    function automatic string expected_diagnostic_case(input integer which,input integer sequence_number);
        string seq;
        begin
            case(sequence_number)
                1:seq="00000001";2:seq="00000002";3:seq="00000003";
                4:seq="00000004";5:seq="00000005";6:seq="00000006";
            endcase
            case(which)
                0:expected_diagnostic_case={"Z=8601 T=00000000 Q=",seq," CF=00000000 KA=00000000 PD=00000000 FF=00000000 TT=000000000 LO=00000000 AC=00000000 EN=0 SV=0 LM=0\015\012"};
                1:expected_diagnostic_case={"Z=8601 T=01234567 Q=",seq," CF=89ABCDEF KA=FFFF8000 PD=7FFFFFFF FF=FFFFFFFF TT=F00000000 LO=FFFFFC18 AC=80000000 EN=1 SV=0 LM=1\015\012"};
                2:expected_diagnostic_case={"Z=8601 T=FFFFFFFF Q=",seq," CF=80000000 KA=7FFFFFFF PD=80000000 FF=7FFFFFFF TT=0FFFFFFFF LO=000003E8 AC=7FFFFFFF EN=0 SV=1 LM=0\015\012"};
                3:expected_diagnostic_case={"Z=8601 T=80000000 Q=",seq," CF=7FFFFFFF KA=80000000 PD=FFFFFFFF FF=00000000 TT=FFFFFFFFF LO=FFFFFFFF AC=FFFFFFFF EN=1 SV=1 LM=0\015\012"};
                4:expected_diagnostic_case={"Z=8601 T=10203040 Q=",seq," CF=10203040 KA=00004000 PD=000002BC FF=FFFFFF00 TT=0000001BC LO=000001BC AC=FFFFFC00 EN=1 SV=1 LM=0\015\012"};
                5:expected_diagnostic_case={"Z=8601 T=F0E0D0C0 Q=",seq," CF=FFFFFFFF KA=00000000 PD=FFFFFBB4 FF=00000000 TT=FFFFFFBB4 LO=FFFFFC18 AC=FFFFFE00 EN=0 SV=1 LM=1\015\012"};
            endcase
        end
    endfunction

    task automatic verify_frame(input integer which, input integer sequence_number, input integer start_at);
        string expected,actual_x;
        integer offset, line_len, line_count;
        begin
            expected={expected_legacy_case(which,sequence_number),expected_unified_case(which,sequence_number),expected_diagnostic_case(which,sequence_number)};
            ck(expected.len()==FRAME_BYTES,"Independent expected A/M/O/X length is901 bytes");
            line_len=0; line_count=0;
            for (offset=0;offset<FRAME_BYTES;offset=offset+1) begin
                byte_comparisons=byte_comparisons+1;
                ck(received[start_at+offset]===expected[offset],
                   $sformatf("Case%0d Q%0d byte%0d expected 0x%02h got 0x%02h",
                     which,sequence_number,offset,expected[offset],received[start_at+offset]));
                line_len=line_len+1;
                if (received[start_at+offset]==10) begin
                    ck(offset>0 && received[start_at+offset-1]==13,"Each line ends with CRLF");
                    if (line_count==0) ck(line_len==A_BYTES,"Legacy A line remains 54 bytes");
                    if (line_count==1) ck(line_len==M_BYTES,"Legacy M line remains 29 bytes");
                    if (line_count==2) ck(line_len==O_BYTES,"Position O line is 176 bytes");
                    if (line_count==3) ck(line_len==X_BYTES,"Unified X8002 line is512 bytes");
                    if (line_count==4) ck(line_len==130,"Independent Z diagnostic line is130 bytes");
                    line_count=line_count+1; line_len=0;
                end
            end
            ck(line_count==5 && line_len==0,"Exactly unchanged A/M/O then self-contained X");
            if(which==4)begin
                actual_x="";
                for(offset=259;offset<771;offset=offset+1)
                    actual_x={actual_x,received[start_at+offset]};
                $display("ACTUAL_X_FIXTURE=%s",actual_x);
                actual_x="";for(offset=771;offset<FRAME_BYTES;offset=offset+1) actual_x={actual_x,received[start_at+offset]};
                $display("ACTUAL_Z_FIXTURE=%s",actual_x);
            end
            $display("PASS waveform case%0d Q%0d: compatible A54/M29 plus atomic O176/X8002-512",which,sequence_number);
        end
    endtask

    task automatic send_and_verify(input integer which, input integer sequence_number);
        integer start_at;
        begin
            noise=0; load_case(which); start_at=rx_count; pulse_request();
            @(negedge clk); noise=1;
            // Busy requests in each line must neither replace the snapshot nor
            // increment Q or queue a later frame.
            wait(rx_count==start_at+5); pulse_request();
            wait(rx_count==start_at+A_BYTES); pulse_request();
            wait(rx_count==start_at+A_BYTES+M_BYTES); pulse_request();
            wait(rx_count==start_at+259); pulse_request();
            wait(rx_count==start_at+400); pulse_request();
            wait(rx_count==start_at+698); pulse_request();
            wait(rx_count==start_at+FRAME_BYTES-4); pulse_request();
            wait(rx_count==start_at+FRAME_BYTES);
            verify_frame(which,sequence_number,start_at);
            #(BIT_NS*40.0);
            ck(rx_count==start_at+FRAME_BYTES && tx===1,"Busy requests rejected without queued replay");
            noise=0;
        end
    endtask

    integer which, before_reset;
    initial begin
        repeat(4) @(negedge clk); rst_n=1;
        repeat(20) @(negedge clk);
        ck(tx===1 && rx_count==0,"Idle/reset emits no unsolicited frame");
        for (which=0;which<6;which=which+1) send_and_verify(which,which+1);
        ck(rx_count==6*FRAME_BYTES,"Six accepted requests produce exactly six frames");
        before_reset=rx_count;
        @(negedge clk); rst_n=0;
        repeat(8) @(negedge clk);
        ck(tx===1 && rx_count==before_reset,"Reset returns idle without additional bytes");
        rst_n=1; repeat(20) @(negedge clk);
        send_and_verify(0,1);
        ck(rx_count==7*FRAME_BYTES,"Reset sequence restarts at Q1; exactly seven frames total");
        $display("ALL PASS feedforward telemetry UART: %0d assertions, %0d byte comparisons, %0d decoded bytes",assertions,byte_comparisons,rx_count);
        $finish;
    end
    initial begin
        #650000000;
        $fatal(1,"Unified telemetry timed out after %0d bytes",rx_count);
    end
endmodule

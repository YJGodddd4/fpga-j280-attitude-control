`timescale 1ns/1ps

module amfm_numeric #(
 parameter integer MODE=1,REQUEST_DECI=300,
 parameter CASE_NAME="am30"
);
 localparam integer IS_C=(MODE==3);
 localparam integer MAG=REQUEST_DECI<0?-REQUEST_DECI:REQUEST_DECI;
 localparam integer BASE=IS_C?900:300;
 localparam integer STRETCH=IS_C?(MAG<=900?1:(MAG+899)/900):1;
 localparam integer PERIOD=MODE==1?31500:(MODE==2?30000:7000);
 localparam integer RAMP=IS_C?6000:2000;
 localparam integer CYCLE=PERIOD*STRETCH;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123,requested_deci=REQUEST_DECI;
 reg [1:0] selected_mode=MODE;reg selection_valid=1,confirm_event=0;
 wire target_update;wire signed [31:0] target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci;
 wire [1:0] active_profile;wire [3:0] trajectory_state;wire [15:0] phase,run_id;
 wire [31:0] cycle_count,elapsed_ms,cycle_ms,config_tag,time_stretch;
 wire base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle;
 trajectory_task dut(.*);
 integer assertions=0,publications=0,strict=0,logical_ms=0,last_elapsed=-1,last_pub=-1,last_phase=-1;
 integer entry_points=0,steady_points=0,exit_points=0,waited=0,saved_id,saved_pubs,expect_r;
 real amp,t,om,modom,modphase,carrier,A0,A1,A2,A3,wave_phase,om1,om2,om3;
 real bq,bv,ba,bj,q,v,a,j,s,w,wd,wdd,wddd,ramp,exit_start=-1,scale;
 real vmax=0,steady_vmax=0,steady_min=1e9,steady_max=-1e9;
 bit checking=0;
 function real ab(input real x);ab=x<0?-x:x;endfunction
 function integer rn(input real x);rn=x<0?-$rtoi(-x+0.5):$rtoi(x+0.5);endfunction
 task ck(input bit yes,input string message);
  begin assertions++;if(!yes)$fatal(1,"%s case=%s elapsed=%0d ms=%0d phase=%0d st=%0d R=%0d V=%0d A=%0d J=%0d TM=%0d TA=%0d",message,CASE_NAME,elapsed_ms,logical_ms,phase,trajectory_state,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,time_stretch,accepted_deci);end
 endtask
 task independent;
  begin
   amp=REQUEST_DECI/10.0;t=elapsed_ms/1000.0/STRETCH;
   if(MODE==1)begin
    om=2*3.14159265358979323846/3.5;modom=2*3.14159265358979323846/31.5;
    A0=amp*(2+$cos(modom*t))/3;A1=-amp*modom*$sin(modom*t)/3;
    A2=-amp*modom*modom*$cos(modom*t)/3;A3=amp*modom*modom*modom*$sin(modom*t)/3;
    bq=A0*$sin(om*t);bv=A1*$sin(om*t)+A0*om*$cos(om*t);
    ba=A2*$sin(om*t)+2*A1*om*$cos(om*t)-A0*om*om*$sin(om*t);
    bj=A3*$sin(om*t)+3*A2*om*$cos(om*t)-3*A1*om*om*$sin(om*t)-A0*om*om*om*$cos(om*t);
   end else if(MODE==2)begin
    modom=2*3.14159265358979323846/30.0;
    wave_phase=2*3.14159265358979323846*0.3*t-6*$sin(modom*t);
    om1=2*3.14159265358979323846*(0.3-0.2*$cos(modom*t));
    om2=2*3.14159265358979323846*0.2*modom*$sin(modom*t);
    om3=2*3.14159265358979323846*0.2*modom*modom*$cos(modom*t);
    bq=amp*$sin(wave_phase);bv=amp*om1*$cos(wave_phase);
    ba=amp*(om2*$cos(wave_phase)-om1*om1*$sin(wave_phase));
    bj=amp*(om3*$cos(wave_phase)-3*om1*om2*$sin(wave_phase)-om1*om1*om1*$cos(wave_phase));
   end else begin
    om=2*3.14159265358979323846/7.0;
    bq=amp*$sin(om*t);bv=amp*om*$cos(om*t);
    ba=-amp*om*om*$sin(om*t);bj=-amp*om*om*om*$cos(om*t);
   end
   if(phase==3&&exit_start<0)exit_start=elapsed_ms-10.0;
   ramp=RAMP/1000.0;
   if(phase==1||phase==3)begin
    s=phase==1?t/ramp:(elapsed_ms-exit_start)/1000.0/STRETCH/ramp;
    if(s<0)s=0;if(s>1)s=1;
    w=10*s*s*s-15*s*s*s*s+6*s*s*s*s*s;
    wd=(30*s*s-60*s*s*s+30*s*s*s*s)/ramp;
    wdd=(60*s-180*s*s+120*s*s*s)/(ramp*ramp);
    wddd=(60-360*s+360*s*s)/(ramp*ramp*ramp);
    if(phase==3)begin w=1-w;wd=-wd;wdd=-wdd;wddd=-wddd;end
   end else begin w=1;wd=0;wdd=0;wddd=0;end
   q=bq*w;v=(bv*w+bq*wd)/STRETCH;
   a=(ba*w+2*bv*wd+bq*wdd)/(STRETCH*STRETCH);
   j=(bj*w+3*ba*wd+3*bv*wdd+bq*wddd)/(STRETCH*STRETCH*STRETCH);
  end
 endtask
 always @(posedge clk)begin
  if(rst_n&&tick_ms)logical_ms++;
  #1;
  if(target_update)begin
   publications++;
   ck(owned&&balance_ready&&!stop_event,"publication only while current owner and balanced");
   ck(target_value===reference_position,"target/display atomic");
   if(checking)begin
    strict++;
    ck(accepted_deci==REQUEST_DECI,"accepted request frozen while next edit changes");
    ck(time_stretch==STRETCH,"expected per-profile stretch");
    ck(cycle_ms==CYCLE,"full modulation/reference period is correct");
    ck(center_position==123&&endpoint_position==123,"fixed center and endpoint for periodic profiles");
    ck(dut.base_deci_latched==BASE,"ROM amplitude base scale correct");
    independent;expect_r=123+rn(q*408/360.0);
    scale=ab(REQUEST_DECI/300.0);if(scale<1)scale=1;
    ck(ab(reference_position-expect_r)<=1,"position independent AM/FM phase-and-envelope formula");
    if(running)begin
     ck(jerk_valid&&acceleration_valid,"analytic derivatives reported valid");
     ck(ab(reference_speed_q8-v*408/360*256)<16*scale,"velocity independent derivative");
     ck(ab(reference_acceleration_q8-a*408/360*256)<28*scale,"acceleration independent derivative");
     ck(ab(reference_jerk_q8-j*408/360*256)<80*scale,"jerk independent derivative");
    end
    if(last_elapsed>=0)ck(elapsed_ms==last_elapsed+10,"every publication advances exactly10ms");
    if(last_elapsed>=10&&phase==last_phase)ck(logical_ms-last_pub>=9&&logical_ms-last_pub<=11,"publication inside10ms slot without accumulating lag");
    ck($itor(dut.clock_elapsed_ms)-$itor(elapsed_ms)>=0&&$itor(dut.clock_elapsed_ms)-$itor(elapsed_ms)<10,"pipeline completes in10ms slot");
    last_elapsed=elapsed_ms;last_pub=logical_ms;last_phase=phase;
    if(phase==1)entry_points++;
    if(phase==2)begin
     steady_points++;
     if(q<steady_min)steady_min=q;if(q>steady_max)steady_max=q;
     if(ab(reference_speed_q8)>steady_vmax)steady_vmax=ab(reference_speed_q8);
    end
    if(phase==3)exit_points++;
    if(ab(reference_speed_q8)>vmax)vmax=ab(reference_speed_q8);
   end
  end
 end
 task ms(input integer n);integer i;begin for(i=0;i<n;i++)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
 end end endtask
 task confirm;begin @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;
  adopt_reference=123;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;
  repeat(4)@(negedge clk);ck(held_idle&&!running&&run_id==0,"adopt does not auto run");
  confirm;checking=1;ms(RAMP*STRETCH+100);requested_deci=-222222;
  ms(CYCLE+100);
  ck(running&&cycle_count>=1,"one full modulation/reference period completed");
  ck(strict>=(RAMP*STRETCH+CYCLE)/10,"full publication stream exercised");
  ck(entry_points>=RAMP*STRETCH/10-2&&steady_points>=CYCLE/10,"entry plus full steady period covered");
  ck(steady_max>ab(REQUEST_DECI/10.0)*0.90&&steady_min<-ab(REQUEST_DECI/10.0)*0.90,"both extrema of signed waveform exercised");
  saved_id=run_id;confirm;waited=0;
  while(!held_idle&&waited<RAMP*STRETCH+1000)begin ms(1);waited++;end
  ck(held_idle&&!running&&reference_position==123,"smooth stop returns exactly to same center");
  ck(exit_points>=RAMP*STRETCH/10-2,"full exit envelope independently checked");
  saved_pubs=publications;ms(50);ck(publications==saved_pubs&&run_id==saved_id,"no automatic replay");
  $display("ALL PASS amfm case=%s assertions=%0d publications=%0d strict=%0d cycles=%0d peak_v_q8=%0.0f",CASE_NAME,assertions,publications,strict,cycle_count,vmax);$finish;
 end
 initial begin #(64'd8000000000);$fatal(1,"AMFM numeric timeout");end
endmodule
module tb_amfm_am30;amfm_numeric #(.MODE(1),.REQUEST_DECI(300),.CASE_NAME("am30")) t();endmodule
module tb_amfm_amneg90;amfm_numeric #(.MODE(1),.REQUEST_DECI(-900),.CASE_NAME("amneg90")) t();endmodule
module tb_amfm_fm30;amfm_numeric #(.MODE(2),.REQUEST_DECI(300),.CASE_NAME("fm30")) t();endmodule
module tb_amfm_fmneg720;amfm_numeric #(.MODE(2),.REQUEST_DECI(-7200),.CASE_NAME("fmneg720")) t();endmodule

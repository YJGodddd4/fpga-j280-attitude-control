from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
cases=['pos56','neg56','pos30','neg30','pos90','neg90','exit_early','exit_mid','lifecycle','pair_am','pair_fm']
reports=[]
for case in cases:
 p=ROOT/f'tests/heart_{case}_result.json'
 report=json.loads(p.read_text())
 assert report['success'],case
 for name,digest in report['source_sha256'].items():
  assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,(case,'stale',name)
 reports.append({k:report[k] for k in ('case','assertions','publications','strict','cycles')})
math=json.loads((ROOT/'tests/heart_math_result.json').read_text())
rom=json.loads((ROOT/'tests/heart_rom_check_result.json').read_text())
assert rom['success']
summary={'success':True,'cases':reports,'total_assertions':sum(r['assertions'] for r in reports),
 'publications':sum(r['publications'] for r in reports),'strict_numeric_publications':sum(r['strict'] for r in reports),
 'independent_rom_values':rom['independent_bit_exact_rounded_values'],
 'finite_difference_errors':math['finite_difference_max_errors'],
 'retained_baseline_modules':rom['retained_baseline_modules'],
 'final_source_hash_matches_all_case_snapshots':True,
 'scope':'Six signed30/56/90 degree references each over two complete56s cycles, every10ms q/v/a/j, first-second/nonzero-position septic exits, rawSW2/SW3/SW4 editing andDIP lifecycle, zero/signed/pending requests, loss/inflight cancel/recapture/no replay/reset/globalstop. AM/FM visible outputs bitwise compared against bundled v8.6 baseline every simulatedFPGAclock over full modulation plus entry/exit.',
 'simulation_ms_clock_ratio':300,'hardware_tested':False}
(ROOT/'tests/heart_verification_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))

# [EQ62修改] 无损存储与独立解析验证。
import runpy
from pathlib import Path
runpy.run_path(str(Path(__file__).with_name('eq_rom_math.py')),run_name='__main__')

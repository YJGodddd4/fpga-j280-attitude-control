import {readFile,writeFile} from 'node:fs/promises';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {simulate} from './local_verilog_runtime.mjs';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const selected=process.argv.slice(2).filter(x=>x==='arithmetic'||x==='control');const cases=selected.length?selected:['arithmetic','control'];
let success=true;
for(const name of cases){
 const paths=name==='arithmetic'?['tests/tb_ff_arithmetic.sv','rtl/acceleration_feedforward.v']:
 ['tests/tb_ff_control.sv','rtl/cascade_control.v','rtl/signed_div_const.v','tests/ff_baseline_control.v'];
 const files=await Promise.all(paths.map(async path=>({path,data:await readFile(resolve(root,path),'utf8')})));
 const hashes=Object.fromEntries(files.map(f=>[f.path,createHash('sha256').update(f.data).digest('hex')]));
 const result=await simulate({files,sources:paths,top:'tb_ff_'+name,timeoutMs:180000});
 const signature=result.stdout.match(new RegExp('ALL PASS FF '+name+': (\\d+) assertions, (\\d+) cycles'));
 const ok=Boolean(result.success&&signature);
 await writeFile(resolve(root,'tests','ff_'+name+'_result.json'),JSON.stringify({success:ok,sourceSha256:hashes,assertions:signature?Number(signature[1]):null,cycles:signature?Number(signature[2]):null,scope:name==='arithmetic'?'Actual helper RTL; independent longint oracle, signed extremes, half ties, positive/negative/zero gains, pipeline reset and enable interruptions. No mechanical plant.':'Current outer arithmetic snapshot matches independent signed32 oracle on every 50ms event and publishes at fixed four FPGA clocks (80ns at50MHz), including FF=0 and invalid/mode00. At accelerated 81-clock spacing per 1ms sample, all motor commands, inner angle-update pulses and supervisory outputs match frozen working v8.5 controller on every FPGA clock when FF disabled or zero; outer location/update pulses intentionally differ by four clocks. Nonzero signed33 sum/clamp oracle, ownership loss falls back to PD, stop/capture/reset pending cancellation, signed extrema. No mechanical plant.',...result},null,2),'utf8');
 process.stdout.write((ok?'PASS ':'FAIL ')+name+'\n');
 if(!ok)process.stderr.write(result.combinedOutput.slice(-12000)+'\n');
 success&&=ok;
}
if(!success)process.exitCode=1;

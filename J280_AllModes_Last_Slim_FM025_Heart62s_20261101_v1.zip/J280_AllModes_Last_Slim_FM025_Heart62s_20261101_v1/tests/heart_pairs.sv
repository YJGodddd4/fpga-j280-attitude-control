`timescale 1ns/1ps
module heart_pairs #(parameter integer MODE=1,REQUEST=300,parameter CASE_NAME="pair_am");
 localparam integer STRETCH=1;
 reg clk=0;always #10 clk=~clk;
 reg rst_n=0,tick_ms=0,owned=0,balance_ready=1,stop_event=0,adopt_event=0;
 reg signed [31:0] adopt_reference=123,requested_deci=REQUEST;
 reg [1:0] selected_mode=MODE;reg selection_valid=1,confirm_event=0;
 wire  target_update,old_target_update;
 wire signed [31:0] target_value,old_target_value;
 wire signed [31:0] reference_position,old_reference_position;
 wire signed [31:0] reference_speed_q8,old_reference_speed_q8;
 wire signed [31:0] reference_acceleration_q8,old_reference_acceleration_q8;
 wire signed [31:0] reference_jerk_q8,old_reference_jerk_q8;
 wire signed [31:0] center_position,old_center_position;
 wire signed [31:0] endpoint_position,old_endpoint_position;
 wire signed [31:0] accepted_deci,old_accepted_deci;
 wire [1:0] active_profile,old_active_profile;
 wire [3:0] trajectory_state,old_trajectory_state;
 wire [15:0] phase,old_phase;
 wire [15:0] run_id,old_run_id;
 wire [31:0] cycle_count,old_cycle_count;
 wire [31:0] elapsed_ms,old_elapsed_ms;
 wire [31:0] cycle_ms,old_cycle_ms;
 wire [31:0] config_tag,old_config_tag;
 wire [31:0] time_stretch,old_time_stretch;
 wire  base_valid,old_base_valid;
 wire  running,old_running;
 wire  stop_pending,old_stop_pending;
 wire  interrupted,old_interrupted;
 wire  jerk_valid,old_jerk_valid;
 wire  acceleration_valid,old_acceleration_valid;
 wire  held_idle,old_held_idle;
 trajectory_task dut(.*);
 heart_baseline_task olddut(.clk(clk),.rst_n(rst_n),.tick_ms(tick_ms),.owned(owned),.balance_ready(balance_ready),.stop_event(stop_event),.adopt_event(adopt_event),.adopt_reference(adopt_reference),.selected_mode(selected_mode),.selection_valid(selection_valid),.confirm_event(confirm_event),.requested_deci(requested_deci),.target_update(old_target_update),.target_value(old_target_value),.reference_position(old_reference_position),.reference_speed_q8(old_reference_speed_q8),.reference_acceleration_q8(old_reference_acceleration_q8),.reference_jerk_q8(old_reference_jerk_q8),.center_position(old_center_position),.endpoint_position(old_endpoint_position),.accepted_deci(old_accepted_deci),.active_profile(old_active_profile),.trajectory_state(old_trajectory_state),.phase(old_phase),.run_id(old_run_id),.cycle_count(old_cycle_count),.elapsed_ms(old_elapsed_ms),.cycle_ms(old_cycle_ms),.config_tag(old_config_tag),.time_stretch(old_time_stretch),.base_valid(old_base_valid),.running(old_running),.stop_pending(old_stop_pending),.interrupted(old_interrupted),.jerk_valid(old_jerk_valid),.acceleration_valid(old_acceleration_valid),.held_idle(old_held_idle));
 integer assertions=0,publications=0,cycles=0,waited=0,prevpubs;
 task ck(input bit pass,input string msg);begin assertions++;if(!pass)$fatal(1,"%s case=%s state%0d phase%0d EL%0d",msg,CASE_NAME,trajectory_state,phase,elapsed_ms);end endtask
 always @(posedge clk)begin #1;if(rst_n)begin
 ck({target_update,target_value,reference_position,reference_speed_q8,reference_acceleration_q8,reference_jerk_q8,center_position,endpoint_position,accepted_deci,active_profile,trajectory_state,phase,run_id,cycle_count,elapsed_ms,cycle_ms,time_stretch,base_valid,running,stop_pending,interrupted,jerk_valid,acceleration_valid,held_idle}==={old_target_update,old_target_value,old_reference_position,old_reference_speed_q8,old_reference_acceleration_q8,old_reference_jerk_q8,old_center_position,old_endpoint_position,old_accepted_deci,old_active_profile,old_trajectory_state,old_phase,old_run_id,old_cycle_count,old_elapsed_ms,old_cycle_ms,old_time_stretch,old_base_valid,old_running,old_stop_pending,old_interrupted,old_jerk_valid,old_acceleration_valid,old_held_idle},"AMFM retained bit-exact visible bundle everyclock");
 if(target_update)publications++;
 end end

 task ms(input integer n);integer i;begin for(i=0;i<n;i++)begin
  @(negedge clk);tick_ms=1;@(negedge clk);tick_ms=0;repeat(298)@(negedge clk);
 end end endtask
 task confirm;begin @(negedge clk);confirm_event=1;@(negedge clk);confirm_event=0;end endtask
 task adopt(input integer p);begin
  owned=0;adopt_reference=p;@(negedge clk);adopt_event=1;@(negedge clk);adopt_event=0;owned=1;repeat(4)@(negedge clk);
 end endtask
 initial begin
  repeat(5)@(negedge clk);rst_n=1;adopt(123);
  confirm;ms(34000);ck(running&&cycle_count>=1,"at least one full AMFM period");
  confirm;waited=0;while(!held_idle&&waited<6000*STRETCH+100)begin ms(1);waited++;end
  ck(held_idle&&reference_position==123,"ordinary11 complete exit");
  prevpubs=publications;ms(20);ck(publications==prevpubs,"no stopped publications");
  confirm;ms(51);balance_ready=0;ms(2);ck(!running&&!base_valid&&!target_update,"loss cancels");
  balance_ready=1;adopt(250);ms(5);ck(held_idle&&run_id==2,"new center without replay");
  confirm;ms(21);stop_event=1;ms(2);stop_event=0;ms(2);ck(!running&&!base_valid,"explicit stop cancels");
  $display("ALL PASS heart case=%s assertions=%0d publications=%0d strict=0 cycles=%0d",CASE_NAME,assertions,publications,cycle_count);$finish;
 end
 initial begin #(64'd8000000000);$fatal(1,"legacy sine pair timeout");end
endmodule
module tb_heart_pair_am;heart_pairs #(.MODE(1),.REQUEST(300),.CASE_NAME("pair_am")) t();endmodule
module tb_heart_pair_fm;heart_pairs #(.MODE(2),.REQUEST(-900),.CASE_NAME("pair_fm")) t();endmodule

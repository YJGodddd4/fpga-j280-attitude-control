create_clock -name sys_clk -period 20.000 [get_ports {clk_50m}]
# adc_clock_r toggles every 5 system clocks: 5MHz, 100ns half-cycle.
create_generated_clock -name adc_sample_clk -source [get_ports {clk_50m}] -divide_by 10 [get_pins {u_adc/adc_clock_r_s1/Q}]
# ADC tOD=25ns (datasheet); allow 15ns extra for board/clock/output delay.
# Capture is at ADC falling edge, rather than close to its data launch edge.
set_input_delay -clock adc_sample_clk -max 40.000 [get_ports {adc_data_in[*] adc_otr}]
set_input_delay -clock adc_sample_clk -min 0.000 [get_ports {adc_data_in[*] adc_otr}]
set_clock_uncertainty -setup 0.500 -from [get_clocks {sys_clk adc_sample_clk}] -to [get_clocks {sys_clk adc_sample_clk}]
set_clock_uncertainty -hold 0.200 -from [get_clocks {sys_clk adc_sample_clk}] -to [get_clocks {sys_clk adc_sample_clk}]
# Bundled-data mailbox: the toggle passes two synchronizer stages before capture.
# Data are stable for 204.8us; enforce a 20ns transfer, well before capture >=40ns.
# The same-edge hold check is inapplicable because capture enable is then false.
set_max_delay 20.000 -from [get_regs {u_adc/result_hold* u_adc/otr_hold*}] -to [get_regs {u_adc/angle* u_adc/overrange*}]
set_false_path -hold -from [get_regs {u_adc/result_hold* u_adc/otr_hold*}] -to [get_regs {u_adc/angle* u_adc/overrange*}]
# Only the first toggle synchronizer stage is asynchronous.
set_false_path -from [get_regs {u_adc/publish_toggle*}] -to [get_regs {u_adc/publish_sync_0*}]
# Exclude the virtual generated-clock interpretation of its own divider feedback;
# the divider itself is launched/captured by the 50MHz system clock.
set_false_path -from [get_clocks {adc_sample_clk}] -to [get_pins {u_adc/adc_clock_r_s1/D}]
# Asynchronous controls enter two-stage synchronizers.
set_false_path -from [get_ports {rst_n key_sw[*] dip_sw_n[*] enc1_a enc1_b enc2_a enc2_b uart_rx}]
# These are slow human/driver outputs, not a synchronous receiver interface.
set_false_path -to [get_ports {led[*] AN1 AN2 PWMA BN1 BN2 PWMB uart_tx adc_oe_n}]

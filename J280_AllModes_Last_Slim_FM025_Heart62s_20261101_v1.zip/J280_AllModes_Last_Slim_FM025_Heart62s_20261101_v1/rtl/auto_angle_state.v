// Fixed confirmed reference + apex observer for the unguarded experiment.
// This observer never gates the controller or stops a running motor.
// theta uses calibrated ADC-count equivalents; 2*(2955-859)=4192 per turn.
module auto_angle_state #(
    parameter integer MAP_CONFIRMED=1,
    parameter integer UP_REF=2955,
    parameter integer DOWN_REF=859,
    parameter integer V_HYST_Q8=64,
    parameter integer MIN_PEAK_ADC=8
)(
    input wire clk, input wire rst_n, input wire tick_ms,
    input wire sensor_ok, input wire active, input wire reference_reset,
    input wire [11:0] angle,
    output reg reference_ready,
    output reg [11:0] reference_center, down_center,
    output wire signed [15:0] theta_up, theta_down,
    output reg signed [31:0] velocity_q8,
    output reg motion_valid, jump_event, turn_event, turn_positive,
    output reg [12:0] peak_amplitude,
    output reg motion_seen
);
    localparam integer HALF_TURN=UP_REF-DOWN_REF;
    localparam integer FULL_TURN=2*HALF_TURN;
    wire signed [31:0] angle32={20'd0,angle};
    wire signed [31:0] up_difference=angle32-$signed({20'd0,reference_center});
    wire signed [31:0] down_difference=angle32-$signed({20'd0,down_center});
    wire signed [31:0] up_normalized=(up_difference>HALF_TURN) ?
        up_difference-FULL_TURN : ((up_difference< -HALF_TURN) ?
        up_difference+FULL_TURN : up_difference);
    wire signed [31:0] down_normalized=(down_difference>HALF_TURN) ?
        down_difference-FULL_TURN : ((down_difference< -HALF_TURN) ?
        down_difference+FULL_TURN : down_difference);
    assign theta_up=up_normalized[15:0];
    assign theta_down=down_normalized[15:0];
    wire [12:0] down_amplitude=down_normalized[31] ? -down_normalized : down_normalized;
    reg sample_seen;
    reg [11:0] previous_angle;
    reg signed [1:0] last_direction;
    reg signed [31:0] previous_phi;
    reg [12:0] leg_peak;
    wire signed [31:0] raw_step=angle32-$signed({20'd0,previous_angle});
    wire signed [31:0] step_delta=raw_step>HALF_TURN ? raw_step-FULL_TURN :
        (raw_step< -HALF_TURN ? raw_step+FULL_TURN : raw_step);
    wire signed [31:0] instantaneous_q8=step_delta*256;
    wire signed [31:0] filtered_velocity=velocity_q8+
        ((instantaneous_q8-velocity_q8) >>> 2);
    wire signed [1:0] next_direction=filtered_velocity>=V_HYST_Q8 ? 2'sd1 :
        (filtered_velocity<= -V_HYST_Q8 ? -2'sd1 : 2'sd0);
    wire [31:0] previous_phi_abs=previous_phi[31] ? -previous_phi : previous_phi;
    wire down_crossed=(down_normalized[31]!=previous_phi[31]) &&
        (down_amplitude<HALF_TURN/2) && (previous_phi_abs<HALF_TURN/2);
    wire [12:0] leg_peak_next=down_crossed ? down_amplitude :
        ((down_amplitude>leg_peak) ? down_amplitude : leg_peak);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            reference_ready<=MAP_CONFIRMED!=0;
            reference_center<=UP_REF; down_center<=DOWN_REF;
            sample_seen<=0; previous_angle<=0;
            velocity_q8<=0; motion_valid<=0; jump_event<=0;
            turn_event<=0; turn_positive<=0; peak_amplitude<=0;
            motion_seen<=0; last_direction<=0; leg_peak<=0; previous_phi<=0;
        end else begin
            // Confirmed constants never follow an average of the moving rod.
            reference_ready<=MAP_CONFIRMED!=0;
            reference_center<=UP_REF; down_center<=DOWN_REF;
            jump_event<=0; turn_event<=0;
            if(reference_reset) begin
                sample_seen<=0; previous_angle<=angle;
                velocity_q8<=0; motion_valid<=0; motion_seen<=0;
                last_direction<=0; leg_peak<=0; peak_amplitude<=0;
                previous_phi<=down_normalized; turn_positive<=0;
            end else if(tick_ms) begin
                previous_angle<=angle; previous_phi<=down_normalized;
                if(!sample_seen) begin
                    sample_seen<=1; velocity_q8<=0; motion_valid<=0;
                end else begin
                    motion_valid<=1; velocity_q8<=filtered_velocity;
                    if(!active) begin
                        motion_seen<=0; last_direction<=0; leg_peak<=0;
                    end else begin
                        leg_peak<=leg_peak_next;
                        if(next_direction!=0) begin
                            if(down_amplitude>=MIN_PEAK_ADC) motion_seen<=1;
                            if(motion_seen && last_direction!=0 &&
                               next_direction!=last_direction &&
                               down_amplitude>=MIN_PEAK_ADC && leg_peak_next>=MIN_PEAK_ADC) begin
                                turn_event<=1; turn_positive<=next_direction>0;
                                peak_amplitude<=leg_peak_next;
                            end
                            last_direction<=next_direction;
                        end
                    end
                end
            end
        end
    end
endmodule

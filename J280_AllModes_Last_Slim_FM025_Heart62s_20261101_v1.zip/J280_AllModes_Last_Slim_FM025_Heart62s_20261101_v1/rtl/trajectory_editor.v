// Independent requests per profile; editing cannot change the active run.
// v8.7: C=心形最大绝对位移，默认56度；周期固定56秒。
// A=AM最大包络半幅、B=FM固定半幅，默认各30度；C正值心尖向负，负值镜像。
// sine_deci等旧端口名保留，只为兼容原串口字段；11模式已改为心形。
module trajectory_editor #(
 parameter integer DEFAULT_A_DECI=300,DEFAULT_B_DECI=300,DEFAULT_C_DECI=560
)(
 input wire clk,input wire rst_n,input wire edit_enable,
 input wire [1:0] selected_mode,input wire selection_valid,
 input wire minus_event,input wire plus_event,input wire step_event,
 output wire signed [31:0] requested_deci,
 output reg signed [31:0] trapezoid_deci,scurve_deci,sine_deci,
 output reg [1:0] step_index
);
 wire signed [31:0] step_deci=step_index==0 ? 32'sd1 : (step_index==1 ? 32'sd10 : 32'sd100);
 wire signed [63:0] delta=(plus_event && !minus_event) ? $signed({{32{step_deci[31]}},step_deci}) :
                         ((minus_event && !plus_event) ? -$signed({{32{step_deci[31]}},step_deci}) : 64'sd0);
 assign requested_deci=selected_mode==1 ? trapezoid_deci :
                       (selected_mode==2 ? scurve_deci : (selected_mode==3 ? sine_deci : 32'sd0));
 wire signed [63:0] edited=$signed({{32{requested_deci[31]}},requested_deci})+delta;
 wire signed [31:0] bounded=edited>64'sd2147483647 ? 32'sh7fffffff :
                           (edited< -64'sd2147483648 ? 32'sh80000000 : edited[31:0]);
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n)begin trapezoid_deci<=DEFAULT_A_DECI;scurve_deci<=DEFAULT_B_DECI;sine_deci<=DEFAULT_C_DECI;step_index<=2;end
  else if(edit_enable && selection_valid && selected_mode!=0)begin
   if(step_event)step_index<=step_index==2 ? 2'd0 : step_index+1'b1;
   else if(plus_event ^ minus_event)begin
    case(selected_mode)
     1:trapezoid_deci<=bounded;
     2:scurve_deci<=bounded;
     3:sine_deci<=bounded;
     default:begin end
    endcase
   end
  end
 end
endmodule

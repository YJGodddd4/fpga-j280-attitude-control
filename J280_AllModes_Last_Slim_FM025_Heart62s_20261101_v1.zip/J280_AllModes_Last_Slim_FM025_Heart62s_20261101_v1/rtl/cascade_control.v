// 对应 main.c + PID.c 的串级位置式 PID。
// 位置单位沿用 C：408/输出轴转；角度以原 C 的 0..4095 数值表示。
// 内部角度和外环输出保留 1/10 ADC count；系数用整数精确表示。
module cascade_control #(
    parameter integer CENTER_DEFAULT=2010,
    parameter integer CENTER_RANGE=500,
    parameter integer ANGLE_KP_100=30,
    parameter integer ANGLE_KI_100=1,
    parameter integer ANGLE_KD_100=40,
    // [D_LPF修改] 1=每5ms以alpha=1/2滤角度D；0=保留原始差分。P/I及D输入来源不变。
    parameter integer ANGLE_D_FILTER_SHIFT=1,
    parameter integer LOCATION_KP_10=4,
    parameter integer LOCATION_KD_10=40,
    parameter integer LOCATION_KI_1000=0, // 默认关闭，由顶层传入350
    parameter integer LOCATION_I_LIMIT_10=100,
    parameter integer DUTY_LIMIT=100,
    parameter integer INTEGRAL_LIMIT=10000000,
    parameter integer CAL_SPAN=40,
    parameter integer FF_ENABLE=0
)(
    input wire clk, input wire rst_n, input wire sample_ms,
    input wire [11:0] angle,
    input wire signed [31:0] position,
    input wire sensor_ok, input wire travel_ok,
    input wire toggle_event, input wire stop_event,
    input wire plus_event, input wire minus_event, input wire calibrate_event,
    // Supervisory interfaces do not fake sensor samples or reset encoder origin.
    input wire prepare_event,
    input wire [11:0] prepare_center,
    input wire signed [31:0] prepare_target,
    input wire capture_start_event,
    input wire target_update_event,
    input wire signed [31:0] target_value,
    input wire ff_valid,input wire signed [31:0] ff_correction10,
    output reg signed [31:0] ff_applied10,location_pd10,
    output reg signed [32:0] location_total10,output reg location_limited,
    output reg running, output reg calibrated, output reg calibrating,
    output reg [3:0] fault,
    output reg [11:0] center,
    output reg signed [31:0] target_position,
    output reg signed [31:0] location_out10,
    output reg signed [7:0] motor_command,
    output reg zero_position, output reg angle_update, output reg location_update
);
    localparam integer CAL_SAMPLES=32;
    reg [2:0] angle_count;
    reg [5:0] location_count;
    reg signed [31:0] location_previous;
    reg signed [31:0] angle_previous, integral;
    reg signed [31:0] error_latched, delta_latched, integral_latched;
    reg signed [31:0] numerator;
    // [D_LPF修改] Q8保留小数，逐级流水避免把额外组合运算放进原采样路径。
    reg signed [31:0] d_filter_q8,d_raw_latched,d_correction_q8,d_next_q8;
    reg [31:0] d_magnitude_q8,d_round_magnitude_q8;
    reg [2:0] math_state;
    reg div_start;
    reg signed [31:0] div_input;
    wire div_busy, div_done;
    wire signed [31:0] div_result;
    // 停机同时取消尚未完成的运算，避免重启后写入过期命令。
    wire math_rst_n=rst_n && running;
    signed_div_const #(.WIDTH(32),.DENOM(1000)) u_duty_div(
        .clk(clk),.rst_n(math_rst_n),.start(div_start),.dividend(div_input),
        .busy(div_busy),.done(div_done),.quotient(div_result)
    );
    wire signed [31:0] angle32={20'd0,angle};
    wire signed [31:0] center32={20'd0,center};
    wire signed [31:0] error_now=(center32-angle32)*10-location_out10;
    wire signed [31:0] integral_sum=integral+error_now;
    wire signed [31:0] integral_next=(ANGLE_KI_100==0) ? 32'sd0 :
        (integral_sum>INTEGRAL_LIMIT ? INTEGRAL_LIMIT :
        (integral_sum< -INTEGRAL_LIMIT ? -INTEGRAL_LIMIT : integral_sum));
    wire signed [31:0] loc_error=target_position-position;
    // 外环50ms更新一次，Q16保留积分小数。
    // I_LIMIT_10先保持100，仅限制积分项为±10 ADC。
    localparam signed [63:0] LOC_KI_STEP_Q16=
        (64'sd65536*LOCATION_KI_1000+64'sd10000)/64'sd20000;

    localparam signed [63:0] LOC_I_LIMIT_Q16=
        64'sd65536*LOCATION_I_LIMIT_10;

    reg signed [31:0] loc_i_acc_q16,loc_i_error_latched;
    reg signed [63:0] loc_i_delta_q16,loc_i_sum_q16;
    reg [1:0] loc_i_state;

    wire loc_i_clear=!running || stop_event || prepare_event ||
        capture_start_event || calibrate_event || toggle_event ||
        LOCATION_KI_1000<=0;

    wire loc_i_tick=sample_ms && location_count==49;

    // 已限幅时，冻结继续推向饱和方向的积分；允许反向回退。
    wire loc_i_hold=location_limited &&
        ((location_total10>0 && loc_error>0) ||
        (location_total10<0 && loc_error<0));

    // 输出时才对称四舍五入，累加器仍保留小数。
    wire signed [31:0] loc_i_term10=loc_i_acc_q16[31] ?
        -(((-loc_i_acc_q16)+32'sd32768)>>>16) :
        ((loc_i_acc_q16+32'sd32768)>>>16);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            loc_i_acc_q16<=0;loc_i_error_latched<=0;
            loc_i_delta_q16<=0;loc_i_sum_q16<=0;loc_i_state<=0;
        end else if(loc_i_clear) begin
            loc_i_acc_q16<=0;loc_i_error_latched<=0;
            loc_i_delta_q16<=0;loc_i_sum_q16<=0;loc_i_state<=0;
        end else case(loc_i_state)
            0:if(loc_i_tick && !loc_i_hold)begin
                loc_i_error_latched<=loc_error;
                loc_i_state<=1;
            end
            1:begin
                loc_i_delta_q16<=
                    $signed(loc_i_error_latched)*LOC_KI_STEP_Q16;
                loc_i_state<=2;
            end
            2:begin
                loc_i_sum_q16<=
                    $signed({{32{loc_i_acc_q16[31]}},loc_i_acc_q16})+
                    loc_i_delta_q16;
                loc_i_state<=3;
            end
            3:begin
                if(loc_i_sum_q16>LOC_I_LIMIT_Q16)
                    loc_i_acc_q16<=LOC_I_LIMIT_Q16[31:0];
                else if(loc_i_sum_q16< -LOC_I_LIMIT_Q16)
                    loc_i_acc_q16<= -$signed(LOC_I_LIMIT_Q16[31:0]);
                else loc_i_acc_q16<=loc_i_sum_q16[31:0];

                loc_i_state<=0;
            end
        endcase
    end
    // Snapshot at the original 50 ms event. Arithmetic is pipelined by four
    // FPGA clocks (80 ns @50 MHz); the next 5 ms inner-loop sample is unchanged.
    // Each constant product and subtract retains the former signed32 modulo law.
    reg [2:0] ff_math;
    reg signed [31:0] ff_error_latched,ff_previous_latched;
    reg signed [31:0] ff_error_product,ff_previous_product;
    reg signed [31:0] ff_pd_latched,ff_value_latched,ff_i_latched;
    reg signed [32:0] ff_pi_latched;
    reg signed [33:0] ff_total_latched;
    reg ff_eligible;
    // Losing trajectory ownership discards FF from this transaction, while PD
    // must still complete (including mode00, whose ff_valid is normally low).
    wire use_pending_ff=FF_ENABLE && ff_eligible && ff_valid;
    wire signed [33:0] publish_total10=use_pending_ff ? ff_total_latched :
        $signed({ff_pi_latched[32],ff_pi_latched});

    // 控制求和使用34位，原33位监测字段单独处理表示范围。
    wire signed [32:0] publish_diag10=
        publish_total10>34'sd4294967295 ? 33'sh0FFFFFFFF :
        publish_total10< -34'sd4294967296 ? 33'sh100000000 :
        publish_total10[32:0];
    reg [5:0] cal_count;
    reg [17:0] cal_sum;
    reg [11:0] cal_min,cal_max;
    wire [11:0] cal_min_next=angle<cal_min ? angle : cal_min;
    wire [11:0] cal_max_next=angle>cal_max ? angle : cal_max;
    wire [18:0] cal_sum_next={1'b0,cal_sum}+angle;
    // CAL_SAMPLES 固定为 32：避免在综合路径中引入可变除法。
    wire [11:0] cal_average=cal_sum_next[16:5];

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            running<=0; calibrated<=0; calibrating<=0; fault<=0;
            center<=CENTER_DEFAULT; target_position<=0; location_out10<=0;
            motor_command<=0; zero_position<=0; angle_update<=0; location_update<=0;
            angle_count<=0; location_count<=0; location_previous<=0;
            angle_previous<=0; integral<=0; error_latched<=0; delta_latched<=0;
            integral_latched<=0; numerator<=0; math_state<=0; div_start<=0; div_input<=0;
            cal_count<=0; cal_sum<=0; cal_min<=4095; cal_max<=0;
            d_filter_q8<=0;d_raw_latched<=0;d_correction_q8<=0;d_next_q8<=0;
            d_magnitude_q8<=0;d_round_magnitude_q8<=0;
            ff_math<=0;ff_error_latched<=0;ff_previous_latched<=0;
            ff_error_product<=0;ff_previous_product<=0;ff_eligible<=0;
            ff_pd_latched<=0;ff_value_latched<=0;ff_total_latched<=0;
            ff_i_latched<=0;ff_pi_latched<=0;
            ff_applied10<=0;location_pd10<=0;location_total10<=0;location_limited<=0;
        end else begin
            zero_position<=0; angle_update<=0; location_update<=0; div_start<=0;

            if(plus_event && !minus_event) begin
                target_position<=target_position+408;
            end else if(minus_event && !plus_event) begin
                target_position<=target_position-408;
            end
            if(target_update_event && running)
                target_position<=target_value;

            if(!running) begin
                motor_command<=0; angle_count<=0; location_count<=0;
                integral<=0; angle_previous<=0; location_previous<=0;
                location_out10<=0; math_state<=0;
                d_filter_q8<=0;d_raw_latched<=0;d_correction_q8<=0;d_next_q8<=0;
                d_magnitude_q8<=0;d_round_magnitude_q8<=0;
            ff_math<=0;ff_error_latched<=0;ff_previous_latched<=0;
            ff_error_product<=0;ff_previous_product<=0;ff_eligible<=0;
            ff_pd_latched<=0;ff_value_latched<=0;ff_total_latched<=0;
            ff_i_latched<=0;ff_pi_latched<=0;
            ff_applied10<=0;location_pd10<=0;location_total10<=0;location_limited<=0;
            end else begin
                if(!ff_valid)ff_eligible<=0;
                if(!stop_event)case(ff_math)
                    1:begin
                        ff_error_product<=
                            (LOCATION_KP_10+LOCATION_KD_10)*ff_error_latched;
                        ff_previous_product<=LOCATION_KD_10*ff_previous_latched;
                        ff_math<=2;
                    end

                    2:begin
                        ff_pd_latched<=ff_error_product-ff_previous_product;
                        ff_math<=3;
                    end

                    3:begin
                        ff_pi_latched<=
                            $signed({ff_pd_latched[31],ff_pd_latched})+
                            $signed({ff_i_latched[31],ff_i_latched});
                        ff_math<=4;
                    end

                    4:begin
                        ff_total_latched<=
                            $signed({ff_pi_latched[32],ff_pi_latched})+
                            (use_pending_ff ?
                            $signed({{2{ff_value_latched[31]}},ff_value_latched}) :
                            34'sd0);
                        ff_math<=5;
                    end

                    5:begin
                        location_pd10<=ff_pd_latched;
                        ff_applied10<=use_pending_ff ? ff_value_latched : 32'sd0;
                        location_total10<=publish_diag10;

                        location_limited<=publish_total10>34'sd1000 ||
                                          publish_total10< -34'sd1000;

                        if(publish_total10>34'sd1000)
                            location_out10<=1000;
                        else if(publish_total10< -34'sd1000)
                            location_out10<= -1000;
                        else
                            location_out10<=publish_total10[31:0];

                        location_update<=1;
                        ff_math<=0;
                        ff_eligible<=0;
                    end

                    default:begin end
                endcase
                case(math_state)
                    1: begin
                        numerator<=ANGLE_KP_100*error_latched+
                                   ANGLE_KI_100*integral_latched+
                                   ANGLE_KD_100*delta_latched;
                        math_state<=2;
                    end
                    2: begin
                        if(numerator>DUTY_LIMIT*1000) div_input<=DUTY_LIMIT*1000;
                        else if(numerator< -DUTY_LIMIT*1000) div_input<= -DUTY_LIMIT*1000;
                        else div_input<=numerator;
                        div_start<=1; math_state<=0;
                    end
                    // [D_LPF修改] f[k]=f[k-1]+(raw[k]-f[k-1])/2^SHIFT。
                    // 原始delta以0.1ADC计数为单位；Q8只改善数值精度，不改变ADC硬件。
                    3: begin
                        d_correction_q8<=((d_raw_latched<<<8)-d_filter_q8)>>>ANGLE_D_FILTER_SHIFT;
                        math_state<=4;
                    end
                    4: begin d_next_q8<=d_filter_q8+d_correction_q8;math_state<=5;end
                    5: begin d_magnitude_q8<=d_next_q8[31] ? -d_next_q8 : d_next_q8;math_state<=6;end
                    6: begin d_round_magnitude_q8<=d_magnitude_q8+32'd128;math_state<=7;end
                    7: begin
                        // [D_LPF修改] 对称四舍五入，避免负数直接算术右移导致偏置。
                        delta_latched<=d_next_q8[31] ? -$signed({8'd0,d_round_magnitude_q8[31:8]}) :
                                                                $signed({8'd0,d_round_magnitude_q8[31:8]});
                        d_filter_q8<=d_next_q8;math_state<=1;
                    end
                    default: math_state<=0;
                endcase
                if(div_done) begin motor_command<=div_result[7:0]; angle_update<=1; end
                if(sample_ms) begin
                    if(angle_count==4) begin
                        angle_count<=0; error_latched<=error_now;
                        delta_latched<=error_now-angle_previous;
                        d_raw_latched<=error_now-angle_previous;
                        integral_latched<=integral_next; integral<=integral_next;
                        angle_previous<=error_now;
                        // [D_LPF修改] SHIFT=0完全走旧乘加路径；启用时先滤D再执行原乘加。
                        math_state<=(ANGLE_D_FILTER_SHIFT>0) ? 3 : 1;
                    end else angle_count<=angle_count+1'b1;
                    // 同一时刻先算内环：内环使用上次外环的输出，与 C 一致。
                    if(location_count==49) begin
                        location_count<=0; location_previous<=loc_error;
                        ff_error_latched<=loc_error;
                        ff_previous_latched<=location_previous;
                        ff_value_latched<=ff_correction10;
                        ff_i_latched<=loc_i_term10;
                        ff_eligible<=FF_ENABLE && ff_valid && ff_correction10!=0;
                        ff_math<=1;
                    end else location_count<=location_count+1'b1;
                end
            end

            if(calibrate_event && !running && !calibrating) begin
                calibrating<=1; calibrated<=0; cal_count<=0;
                cal_sum<=0; cal_min<=4095; cal_max<=0; fault<=0;
            end
            if(calibrating && sample_ms) begin
                cal_sum<=cal_sum_next[17:0]; cal_min<=cal_min_next; cal_max<=cal_max_next;
                if(cal_count==CAL_SAMPLES-1) begin
                    calibrating<=0; center<=cal_average; calibrated<=1; fault<=0;
                    zero_position<=1; target_position<=0;
                end else cal_count<=cal_count+1'b1;
            end

            if(toggle_event && !calibrating) begin
                if(running) begin running<=0; motor_command<=0; end
                else if(!calibrated) fault<=1;
                else begin
                    running<=1; fault<=0;
                    // [D_LPF修改] 手动启动从当前误差播种；关闭滤波时保留旧版行为供对照。
                    if(ANGLE_D_FILTER_SHIFT>0)angle_previous<=error_now;
                    d_filter_q8<=0;d_raw_latched<=0;d_correction_q8<=0;d_next_q8<=0;
                    d_magnitude_q8<=0;d_round_magnitude_q8<=0;
            ff_math<=0;ff_error_latched<=0;ff_previous_latched<=0;
            ff_error_product<=0;ff_previous_product<=0;ff_eligible<=0;
            ff_pd_latched<=0;ff_value_latched<=0;ff_total_latched<=0;
            ff_i_latched<=0;ff_pi_latched<=0;
            ff_applied10<=0;location_pd10<=0;location_total10<=0;location_limited<=0;
                end
            end
            // Load the caller's reference while PID is stopped. Unlike
            // manual calibration this must not assert zero_position.
            if(prepare_event && !running && !calibrating) begin
                center<=prepare_center; target_position<=prepare_target;
                calibrated<=1; fault<=0; integral<=0; location_previous<=0;
                location_out10<=0; motor_command<=0; math_state<=0;
                d_filter_q8<=0;d_raw_latched<=0;d_correction_q8<=0;d_next_q8<=0;
                d_magnitude_q8<=0;d_round_magnitude_q8<=0;
            ff_math<=0;ff_error_latched<=0;ff_previous_latched<=0;
            ff_error_product<=0;ff_previous_product<=0;ff_eligible<=0;
            ff_pd_latched<=0;ff_value_latched<=0;ff_total_latched<=0;
            ff_i_latched<=0;ff_pi_latched<=0;
            ff_applied10<=0;location_pd10<=0;location_total10<=0;location_limited<=0;
            end
            if(capture_start_event && !running && !calibrating) begin
                if(!calibrated) fault<=1;
                else begin
                    running<=1; fault<=0;
                    // This retained PID uses D on complete error, not D on A.
                    angle_previous<=error_now;
                    // [D_LPF修改] 自动捕获/恢复不继承上一次运行的滤波尾巴。
                    d_filter_q8<=0;d_raw_latched<=0;d_correction_q8<=0;d_next_q8<=0;
                    d_magnitude_q8<=0;d_round_magnitude_q8<=0;
            ff_math<=0;ff_error_latched<=0;ff_previous_latched<=0;
            ff_error_product<=0;ff_previous_product<=0;ff_eligible<=0;
            ff_pd_latched<=0;ff_value_latched<=0;ff_total_latched<=0;
            ff_i_latched<=0;ff_pi_latched<=0;
            ff_applied10<=0;location_pd10<=0;location_total10<=0;location_limited<=0;
                end
            end
            if(stop_event) begin
                running<=0; motor_command<=0; calibrating<=0;
                d_filter_q8<=0;d_raw_latched<=0;d_correction_q8<=0;d_next_q8<=0;
                d_magnitude_q8<=0;d_round_magnitude_q8<=0;
            ff_math<=0;ff_error_latched<=0;ff_previous_latched<=0;
            ff_error_product<=0;ff_previous_product<=0;ff_eligible<=0;
            ff_pd_latched<=0;ff_value_latched<=0;ff_total_latched<=0;
            ff_i_latched<=0;ff_pi_latched<=0;
            ff_applied10<=0;location_pd10<=0;location_total10<=0;location_limited<=0;
            end
        end
    end
endmodule

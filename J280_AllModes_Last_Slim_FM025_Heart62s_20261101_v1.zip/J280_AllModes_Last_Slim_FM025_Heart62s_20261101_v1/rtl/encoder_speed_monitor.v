// Low-delay MONITOR speed only; the original position-task arrival speed remains separate.
// Units: Q8 of 408 engineering counts / second; encoder_count is the original
// signed 32-bit encoder count after direction selection (not rounded to 408/rev).
// At 10 ms spacing, six samples contain a complete 50 ms backwards window.
// A half-weight IIR is updated every 10 ms. Rounding is odd-symmetric and the
// rounded correction (rather than rounded average) decays exactly to zero at rest.
module encoder_speed_monitor #(
    parameter integer ENCODER_COUNTS_REV=1040
)(
    input wire clk,input wire rst_n,input wire tick_ms,input wire capture_event,
    input wire signed [31:0] encoder_count,
    output reg signed [31:0] speed_q8,
    output reg speed_valid,output reg speed_update
);
    localparam integer SAFE_DENOM=(ENCODER_COUNTS_REV>0) ? ENCODER_COUNTS_REV : 1;
    localparam signed [63:0] HALF_DENOM=SAFE_DENOM/2;
    reg initialized;
    reg [3:0] millisecond_count;
    reg [2:0] write_index,filled_intervals;
    reg signed [31:0] history [0:5];
    wire [2:0] old_index=(write_index==5) ? 3'd0 : write_index+1'b1;
    reg signed [31:0] delta_latched,raw_q8;
    wire signed [63:0] delta64={{32{delta_latched[31]}},delta_latched};
    reg signed [63:0] product,dividend;
    reg div_start;
    wire div_busy,div_done;
    wire signed [63:0] quotient;
    wire div_rst_n=rst_n && !capture_event;
    signed_div_const #(.WIDTH(64),.DENOM(SAFE_DENOM)) u_speed_div(
        .clk(clk),.rst_n(div_rst_n),.start(div_start),.dividend(dividend),
        .busy(div_busy),.done(div_done),.quotient(quotient));
    reg [3:0] math_state;
    reg signed [32:0] filter_error,filter_increment;
    reg [32:0] error_magnitude;
    reg [33:0] rounded_magnitude;
    wire signed [32:0] next_speed=$signed({speed_q8[31],speed_q8})+filter_increment;
    integer i;
    function signed [31:0] clamp32;
        input signed [63:0] value;
        begin
            if(value>64'sd2147483647)clamp32=32'sh7fffffff;
            else if(value< -64'sd2147483648)clamp32=32'sh80000000;
            else clamp32=value[31:0];
        end
    endfunction
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            initialized<=0;millisecond_count<=0;write_index<=1;filled_intervals<=0;
            speed_q8<=0;speed_valid<=0;speed_update<=0;math_state<=0;
            delta_latched<=0;raw_q8<=0;product<=0;dividend<=0;div_start<=0;
            filter_error<=0;filter_increment<=0;error_magnitude<=0;rounded_magnitude<=0;
            for(i=0;i<6;i=i+1)history[i]<=0;
        end else if(capture_event || !initialized)begin
            initialized<=1;millisecond_count<=0;write_index<=1;filled_intervals<=0;
            // Re-seed the timeline at this capture edge; obsolete math is discarded.
            history[0]<=encoder_count;
            speed_q8<=0;speed_valid<=0;speed_update<=0;math_state<=0;
            delta_latched<=0;raw_q8<=0;product<=0;dividend<=0;div_start<=0;
            filter_error<=0;filter_increment<=0;error_magnitude<=0;rounded_magnitude<=0;
        end else begin
            speed_update<=0;div_start<=0;
            case(math_state)
                // 408*20*256 = 2^21-2^13: one fixed subtract, no variable multiply.
                1:begin product<=(delta64<<<21)-(delta64<<<13);math_state<=2;end
                // signed_div_const truncates toward zero; bias by half the divisor
                // first to obtain an odd-symmetric nearest integer (ties away).
                2:begin dividend<=product[63] ? product-HALF_DENOM : product+HALF_DENOM;math_state<=3;end
                3:begin div_start<=1;math_state<=4;end
                4:if(div_done)begin raw_q8<=clamp32(quotient);math_state<=5;end
                5:begin filter_error<=$signed({raw_q8[31],raw_q8})-$signed({speed_q8[31],speed_q8});math_state<=6;end
                6:begin error_magnitude<=filter_error[32] ? -filter_error : filter_error;math_state<=7;end
                7:begin rounded_magnitude<={1'b0,error_magnitude}+34'd1;math_state<=8;end
                8:begin filter_increment<=filter_error[32] ? -$signed({1'b0,rounded_magnitude[32:1]}) :
                                                                     $signed({1'b0,rounded_magnitude[32:1]});math_state<=9;end
                9:begin speed_q8<=next_speed[31:0];speed_valid<=1;speed_update<=1;math_state<=0;end
                default:begin end
            endcase
            if(tick_ms)begin
                if(millisecond_count==9)begin
                    millisecond_count<=0;
                    history[write_index]<=encoder_count;
                    write_index<=(write_index==5) ? 3'd0 : write_index+1'b1;
                    if(filled_intervals<5)filled_intervals<=filled_intervals+1'b1;
                    if(filled_intervals>=4)begin
                        // Intentional 32-bit modular subtraction handles encoder
                        // wrap. Motion must be <2^31 raw counts in one 50 ms window.
                        delta_latched<=encoder_count-history[old_index];
                        math_state<=1;
                    end
                end else millisecond_count<=millisecond_count+1'b1;
            end
        end
    end
endmodule

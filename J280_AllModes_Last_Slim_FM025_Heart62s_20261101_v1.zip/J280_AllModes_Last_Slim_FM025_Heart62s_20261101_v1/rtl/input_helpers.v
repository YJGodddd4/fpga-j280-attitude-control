module reset_sync(input wire clk, input wire raw_rst_n, output wire rst_n);
    (* syn_preserve=1 *) reg [1:0] sync;
    always @(posedge clk or negedge raw_rst_n)
        if (!raw_rst_n) sync<=0;
        else sync<={sync[0],1'b1};
    assign rst_n=sync[1];
endmodule

module tick_gen #(parameter integer CLK_HZ=50000000)(
    input wire clk, input wire rst_n, output wire tick_ms
);
    localparam integer COUNT_WIDTH=(CLK_HZ/1000<=1)?1:$clog2(CLK_HZ/1000); // [EQ62修改]
    reg [COUNT_WIDTH-1:0] count;
    assign tick_ms=(count==CLK_HZ/1000-1);
    always @(posedge clk or negedge rst_n)
        if(!rst_n) count<=0;
        else if(tick_ms) count<=0;
        else count<=count+1'b1;
endmodule

// 每 1ms 采样；连续稳定 20ms 后改变状态；松手产生单周期事件。
module key_release #(parameter integer DEBOUNCE_MS=20)(
    input wire clk, input wire rst_n, input wire tick_ms,
    input wire key_n, output reg release_pulse
);
    (* syn_preserve=1 *) reg [1:0] sync;
    reg stable;
    reg [7:0] count;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin sync<=2'b11; stable<=1; count<=0; release_pulse<=0; end
        else begin
            sync<={sync[0],key_n}; release_pulse<=0;
            if(tick_ms) begin
                if(sync[1]==stable) count<=0;
                else if(count==DEBOUNCE_MS-1) begin
                    stable<=sync[1]; count<=0;
                    if(sync[1]) release_pulse<=1;
                end else count<=count+1'b1;
            end
        end
    end
endmodule

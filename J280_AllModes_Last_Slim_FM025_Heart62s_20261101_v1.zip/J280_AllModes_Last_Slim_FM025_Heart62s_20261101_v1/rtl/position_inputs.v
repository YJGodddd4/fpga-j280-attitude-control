// Position-mode panel input events. SW1 remains owned by the v5 run/stop path.
// All event outputs last one FPGA clock; tick_ms is a one-clock 1 ms enable.
// Parameters are milliseconds and must be >= 1.
module position_inputs #(
    parameter integer DEBOUNCE_MS = 20,
    parameter integer REPEAT_DELAY_MS = 500,
    parameter integer REPEAT_PERIOD_MS = 100
)(
    input wire clk,
    input wire rst_n,
    input wire tick_ms,
    input wire [3:0] keys_n,
    input wire [1:0] dip_n,
    input wire edit_enable,
    output reg minus_event,
    output reg plus_event,
    output reg step_event,
    output reg confirm_event,
    output reg [1:0] dip_mode,
    output reg dip_valid
);
    // keys_n[0..3] = SW1..SW4, active low. Only SW2..SW4 are decoded here.
    (* syn_preserve=1 *) reg [3:0] keys_meta, keys_sync;
    (* syn_preserve=1 *) reg [1:0] dip_meta, dip_sync;
    reg [2:0] stable_n;
    reg [31:0] key_count [0:2];
    reg [2:0] press_pulse, release_pulse;
    reg [1:0] dip_candidate;
    reg [31:0] dip_count;
    integer i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            keys_meta <= 4'b1111;
            keys_sync <= 4'b1111;
            dip_meta <= 2'b11;
            dip_sync <= 2'b11;
            stable_n <= 3'b111;
            press_pulse <= 0;
            release_pulse <= 0;
            for (i=0; i<3; i=i+1) key_count[i] <= 0;
            dip_candidate <= 2'b11;
            dip_count <= 0;
            dip_mode <= 2'b00;
            dip_valid <= 0;
        end else begin
            keys_meta <= keys_n;
            keys_sync <= keys_meta;
            dip_meta <= dip_n;
            dip_sync <= dip_meta;
            press_pulse <= 0;
            release_pulse <= 0;
            if (tick_ms) begin
                for (i=0; i<3; i=i+1) begin
                    if (keys_sync[i+1] == stable_n[i]) key_count[i] <= 0;
                    else if (key_count[i] >= DEBOUNCE_MS-1) begin
                        stable_n[i] <= keys_sync[i+1];
                        key_count[i] <= 0;
                        if (keys_sync[i+1]) release_pulse[i] <= 1;
                        else press_pulse[i] <= 1;
                    end else key_count[i] <= key_count[i] + 1'b1;
                end

                // Publish a whole DIP combination only after it stays stable.
                // OFF/OFF raw11 -> mode00; ON/OFF raw10 -> mode01;
                // OFF/ON raw01 -> mode10; ON/ON raw00 -> mode11.
                // dip_n[0] = W20 / B3_SW1; dip_n[1] = V20 / B3_SW2.
                if (dip_sync != dip_candidate) begin
                    dip_candidate <= dip_sync;
                    dip_count <= 1;
                    if (DEBOUNCE_MS == 1) begin
                        dip_mode <= ~dip_sync;
                        dip_valid <= 1;
                    end
                end else if (dip_count < DEBOUNCE_MS) begin
                    dip_count <= dip_count + 1'b1;
                    if (dip_count == DEBOUNCE_MS-1) begin
                        dip_mode <= ~dip_candidate;
                        dip_valid <= 1;
                    end
                end
            end
        end
    end

    reg armed;
    reg [31:0] arm_count;
    reg combo_active;
    reg minus_held, plus_held;
    reg minus_repeated, plus_repeated;
    reg [31:0] minus_count, plus_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            minus_event <= 0;
            plus_event <= 0;
            step_event <= 0;
            confirm_event <= 0;
            armed <= 0;
            arm_count <= 0;
            combo_active <= 0;
            minus_held <= 0;
            plus_held <= 0;
            minus_repeated <= 0;
            plus_repeated <= 0;
            minus_count <= 0;
            plus_count <= 0;
        end else begin
            minus_event <= 0;
            plus_event <= 0;
            step_event <= 0;
            confirm_event <= 0;
            if (!edit_enable) begin
                armed <= 0;
                arm_count <= 0;
                combo_active <= 0;
                minus_held <= 0;
                plus_held <= 0;
                minus_repeated <= 0;
                plus_repeated <= 0;
                minus_count <= 0;
                plus_count <= 0;
            end else if (!armed) begin
                // Look at synchronized physical levels as well as debounced
                // levels: a pre-enable press must not arm during debounce lag.
                if (tick_ms) begin
                    if (keys_sync[3:1] == 3'b111 && stable_n == 3'b111) begin
                        if (arm_count >= DEBOUNCE_MS-1) begin
                            armed <= 1;
                            arm_count <= 0;
                        end else arm_count <= arm_count + 1'b1;
                    end else arm_count <= 0;
                end
            end else begin
                if (combo_active) begin
                    minus_held <= 0;
                    plus_held <= 0;
                    minus_repeated <= 0;
                    plus_repeated <= 0;
                    minus_count <= 0;
                    plus_count <= 0;
                    // Both keys must be released before exactly one step event.
                    if (stable_n[1:0] == 2'b11) begin
                        step_event <= 1;
                        combo_active <= 0;
                    end
                end else if (stable_n[1:0] == 2'b00) begin
                    combo_active <= 1;
                    minus_held <= 0;
                    plus_held <= 0;
                    minus_repeated <= 0;
                    plus_repeated <= 0;
                    minus_count <= 0;
                    plus_count <= 0;
                end else begin
                    if (press_pulse[0]) begin
                        minus_held <= 1;
                        minus_repeated <= 0;
                        minus_count <= 0;
                    end
                    if (press_pulse[1]) begin
                        plus_held <= 1;
                        plus_repeated <= 0;
                        plus_count <= 0;
                    end
                    if (tick_ms && minus_held && !stable_n[0]) begin
                        if ((!minus_repeated && minus_count >= REPEAT_DELAY_MS-1) ||
                            (minus_repeated && minus_count >= REPEAT_PERIOD_MS-1)) begin
                            minus_event <= 1;
                            minus_repeated <= 1;
                            minus_count <= 0;
                        end else minus_count <= minus_count + 1'b1;
                    end
                    if (tick_ms && plus_held && !stable_n[1]) begin
                        if ((!plus_repeated && plus_count >= REPEAT_DELAY_MS-1) ||
                            (plus_repeated && plus_count >= REPEAT_PERIOD_MS-1)) begin
                            plus_event <= 1;
                            plus_repeated <= 1;
                            plus_count <= 0;
                        end else plus_count <= plus_count + 1'b1;
                    end
                    if (release_pulse[0]) begin
                        if (minus_held && !minus_repeated) minus_event <= 1;
                        minus_held <= 0;
                        minus_repeated <= 0;
                        minus_count <= 0;
                    end
                    if (release_pulse[1]) begin
                        if (plus_held && !plus_repeated) plus_event <= 1;
                        plus_held <= 0;
                        plus_repeated <= 0;
                        plus_count <= 0;
                    end
                end
                // Start a ready task on debounced press, without waiting for
                // the user's hold/release time. Stopped calibration is separate.
                if (press_pulse[2]) confirm_event <= 1;
            end
        end
    end
endmodule

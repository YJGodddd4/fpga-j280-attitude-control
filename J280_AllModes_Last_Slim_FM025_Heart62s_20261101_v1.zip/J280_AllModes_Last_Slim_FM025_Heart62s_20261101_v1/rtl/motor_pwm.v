// 20kHz，百分比命令；只在周期边界更新方向和占空比。
// 换向时插入一个完整 PWM 周期的停机间隔。
module motor_pwm #(
    parameter integer CLK_HZ=50000000,
    parameter integer PWM_HZ=20000,
    parameter integer REVERSE=0
)(
    input wire clk, input wire rst_n, input wire enable,
    input wire signed [7:0] command,
    output wire in1, output wire in2, output wire pwm
);
    localparam integer PERIOD=CLK_HZ/PWM_HZ;
    // [EQ62修改] 最大计数2499，比较值可到2500；保留100%占空比。
    localparam integer COUNT_WIDTH=(PERIOD<=1)?1:$clog2(PERIOD);
    localparam integer COMPARE_WIDTH=(PERIOD<=1)?1:$clog2(PERIOD+1);
    reg [COUNT_WIDTH-1:0] counter;
    reg [COMPARE_WIDTH-1:0] compare;
    reg negative;
    reg [7:0] active_mag;
    wire [7:0] magnitude=command[7] ? -command : command;
    wire [7:0] limited=magnitude>100 ? 8'd100 : magnitude;
    wire requested_negative=command[7] ^ (REVERSE!=0);
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin counter<=0; compare<=0; negative<=0; active_mag<=0; end
        else if(!enable) begin counter<=0; compare<=0; active_mag<=0; end
        else if(counter==PERIOD-1) begin
            counter<=0;
            if(limited!=0 && active_mag!=0 && requested_negative!=negative) begin
                compare<=0; active_mag<=0;
            end else begin
                negative<=requested_negative; active_mag<=limited;
                compare<=(PERIOD/100)*limited;
            end
        end else counter<=counter+1'b1;
    end
    wire driving=enable && rst_n && active_mag!=0;
    // 与原 C 正命令的引脚电平一致：IN1=0, IN2=1。
    assign in1=driving && negative;
    assign in2=driving && !negative;
    assign pwm=driving && counter<compare;
endmodule

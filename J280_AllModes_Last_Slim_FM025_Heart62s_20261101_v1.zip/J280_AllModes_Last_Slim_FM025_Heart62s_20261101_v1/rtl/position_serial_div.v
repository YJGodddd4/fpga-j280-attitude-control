// Unsigned restoring divider. Two clocks/quotient bit split the65-bit
// subtract from result selection for the50MHz reference generator.
module position_serial_div #(
    parameter integer NUM_WIDTH=96,
    parameter integer DEN_WIDTH=64
)(
    input wire clk,input wire rst_n,input wire start,
    input wire [NUM_WIDTH-1:0] numerator,input wire [DEN_WIDTH-1:0] denominator,
    output reg busy,output reg done,output reg [NUM_WIDTH-1:0] quotient
);
    reg [NUM_WIDTH-1:0] dividend_shift,quotient_shift;
    reg [DEN_WIDTH-1:0] divisor;
    reg [DEN_WIDTH:0] remainder,trial_remainder,shifted_latched;
    reg [15:0] bits_left;
    reg subtract_phase;
    wire [DEN_WIDTH:0] shifted_remainder={remainder[DEN_WIDTH-1:0],dividend_shift[NUM_WIDTH-1]};
    wire subtract_now=!trial_remainder[DEN_WIDTH];
    wire [DEN_WIDTH:0] next_remainder=subtract_now ? trial_remainder : shifted_latched;
    wire [NUM_WIDTH-1:0] next_quotient={quotient_shift[NUM_WIDTH-2:0],subtract_now};
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin busy<=0;done<=0;quotient<=0;dividend_shift<=0;quotient_shift<=0;divisor<=0;remainder<=0;bits_left<=0;subtract_phase<=0;trial_remainder<=0;shifted_latched<=0;end
        else begin
            done<=0;
            if(start && !busy)begin
                if(denominator==0)begin quotient<=0;done<=1;end
                else begin busy<=1;dividend_shift<=numerator;divisor<=denominator;quotient_shift<=0;remainder<=0;bits_left<=NUM_WIDTH;subtract_phase<=0;end
            end else if(busy)begin
                if(!subtract_phase)begin
                    shifted_latched<=shifted_remainder;
                    trial_remainder<=shifted_remainder-{1'b0,divisor};
                    subtract_phase<=1;
                end else begin
                    dividend_shift<={dividend_shift[NUM_WIDTH-2:0],1'b0};
                    quotient_shift<=next_quotient;remainder<=next_remainder;
                    bits_left<=bits_left-1'b1;subtract_phase<=0;
                    if(bits_left==1)begin busy<=0;done<=1;quotient<=next_quotient;end
                end
            end
        end
    end
endmodule

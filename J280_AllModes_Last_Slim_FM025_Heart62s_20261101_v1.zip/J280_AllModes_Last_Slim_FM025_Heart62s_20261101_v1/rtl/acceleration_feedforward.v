// Planning acceleration feedforward. Gain unit: 0.1 ADC / (408-units/s^2).
// Q16 gain * Q8 acceleration -> Q24; symmetric rounding, no DC bias.
module acceleration_feedforward #(parameter integer LOCATION_AFF_Q16=16384)(
 input wire clk,input wire rst_n,input wire enable,
 input wire signed [31:0] reference_acceleration_q8,
 output reg signed [31:0] correction10,output reg valid
);
 reg signed [63:0] product;
 reg [63:0] magnitude,rounded;
 reg negative,rounded_negative;
 reg [2:0] pipe_valid;
 always @(posedge clk or negedge rst_n) begin
  if(!rst_n)begin product<=0;magnitude<=0;rounded<=0;negative<=0;rounded_negative<=0;pipe_valid<=0;correction10<=0;valid<=0;end
  else if(!enable)begin product<=0;magnitude<=0;rounded<=0;negative<=0;rounded_negative<=0;pipe_valid<=0;correction10<=0;valid<=0;end
  else begin
   product<=$signed(reference_acceleration_q8)*$signed(LOCATION_AFF_Q16);
   magnitude<=product[63] ? -product : product;
   negative<=product[63];
   // magnitude is from the previous cycle; the corresponding sign is negative.
   rounded<=magnitude+64'd8388608;
   rounded_negative<=negative;
   pipe_valid<={pipe_valid[1:0],1'b1};
   valid<=pipe_valid[2];
   // Sign and rounded magnitude share a pipeline age.
   if(pipe_valid[2])begin
    if(rounded >= (rounded_negative ? 64'd36028797035741184 : 64'd36028797018963968))
      correction10<=rounded_negative ? 32'sh80000000 : 32'sh7fffffff;
    else correction10<=rounded_negative ? -$signed(rounded>>24) : $signed(rounded>>24);
   end else correction10<=0;
  end
 end
endmodule

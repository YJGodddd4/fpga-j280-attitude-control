// 有符号常数除法，逐位计算，结果向零截断。start 只在 busy=0 时有效。
module signed_div_const #(
    parameter integer WIDTH = 32,
    parameter integer DENOM = 1000
) (
    input wire clk, input wire rst_n, input wire start,
    input wire signed [WIDTH-1:0] dividend,
    output reg busy, output reg done,
    output reg signed [WIDTH-1:0] quotient
);
    function integer bits_needed;
        input integer value;
        integer n;
        begin
            n=value-1; bits_needed=0;
            while(n>0) begin bits_needed=bits_needed+1; n=n>>1; end
        end
    endfunction
    localparam integer REM_BITS=(DENOM<=1) ? 1 : bits_needed(DENOM);
    reg negative;
    reg [WIDTH-1:0] bits_in, result;
    reg [REM_BITS-1:0] remainder;
    reg [7:0] left;
    wire [REM_BITS:0] trial = {remainder, bits_in[WIDTH-1]};
    wire take = trial >= DENOM;
    wire [WIDTH-1:0] next_result = {result[WIDTH-2:0], take};
    localparam [REM_BITS:0] DIVISOR=DENOM;
    wire [REM_BITS:0] next_remainder=take ? trial-DIVISOR : trial;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy<=0; done<=0; quotient<=0; negative<=0;
            bits_in<=0; result<=0; remainder<=0; left<=0;
        end else begin
            done<=0;
            if (start && !busy) begin
                busy<=1; negative<=dividend[WIDTH-1];
                bits_in<=dividend[WIDTH-1] ? -dividend : dividend;
                result<=0; remainder<=0; left<=WIDTH;
            end else if (busy) begin
                bits_in<=bits_in << 1;
                remainder<=next_remainder[REM_BITS-1:0];
                result<=next_result;
                left<=left-1'b1;
                if (left==1) begin
                    quotient<=negative ? -$signed(next_result) : $signed(next_result);
                    busy<=0; done<=1;
                end
            end
        end
    end
endmodule

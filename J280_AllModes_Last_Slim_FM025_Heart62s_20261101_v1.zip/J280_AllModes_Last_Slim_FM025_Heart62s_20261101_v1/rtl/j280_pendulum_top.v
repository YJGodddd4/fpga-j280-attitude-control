// v8.7: mode11 heart reference; current user PID/I/feedforward gains retained.
module j280_pendulum_top #(
    parameter integer CLK_HZ=50000000,
    parameter integer MOTOR_CHANNEL=0,       // 0=bridge A, 1=bridge B; keep tested wiring.
    parameter integer MOTOR_REVERSE=0,       // 角度反馈方向不对时修改
    parameter integer ENCODER_REVERSE=1,     // 电机位置反馈方向不对时修改
    parameter integer ENCODER_COUNTS_REV=1040, // 13线 * 20减速比 * 4倍频
    parameter integer DUTY_LIMIT=100,
    parameter integer ANGLE_KP_100=40, ANGLE_KI_100=1, ANGLE_KD_100=293, // Current recorded inner gains.
    parameter integer ANGLE_D_FILTER_SHIFT=1, // [D_LPF修改] alpha=1/2，5ms更新；0关闭。
    parameter integer LOCATION_KP_10=7, LOCATION_KD_10=68, // Current recorded outer gains.
    parameter integer LOCATION_KI_1000=350,    // 实际Ki约0.35
    parameter integer LOCATION_I_LIMIT_10=100, // 积分项最大修正±10 ADC
    // Current user feedforward gain: 98920/65536 = 1.25 loc10/(engineering-unit/s^2).
    // 0 disables only feedforward; PD gains and the trajectory periods are retained.
    parameter integer LOCATION_AFF_Q16=81920,
    parameter integer POSITION_MIN_MOVE_MS=300,
    parameter integer POSITION_MS_PER_DEG=15,
    parameter integer AUTO_MAP_CONFIRMED=1,
    parameter integer AUTO_UP_REF=2955, AUTO_DOWN_REF=859,
    parameter integer SWING_DUTY_START=70,
    parameter integer SWING_KICK_MS=70,
    parameter integer SWING_PULSE_MS=101,
    parameter integer CAPTURE_HALF_WIDTH=64,
    parameter integer SWING_POLARITY=1,
    parameter integer BALANCE_EXIT_ADC=388,
    parameter integer RECOVERY_DOWN_ADC=500,
    parameter integer RECOVERY_SPEED_Q8=158
)(
    input wire clk_50m,input wire rst_n,input wire [3:0] key_sw,
    input wire [1:0] dip_sw_n,
    input wire uart_rx,output wire uart_tx,
    output wire adc_clk,output wire adc_oe_n,
    input wire [9:0] adc_data_in,input wire adc_otr,
    input wire enc1_a,input wire enc1_b,input wire enc2_a,input wire enc2_b,
    output wire AN1,output wire AN2,output wire PWMA,
    output wire BN1,output wire BN2,output wire PWMB,
    output wire [3:0] led
);
    wire reset_n,tick_ms;
    reset_sync u_reset(.clk(clk_50m),.raw_rst_n(rst_n),.rst_n(reset_n));
    tick_gen #(.CLK_HZ(CLK_HZ)) u_tick(.clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms));
    wire [3:0] key_event;
    genvar k;
    generate for(k=0;k<4;k=k+1) begin: keys
        key_release u_key(.clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),
                          .key_n(key_sw[k]),.release_pulse(key_event[k]));
    end endgenerate

    wire [11:0] angle;
    wire angle_valid,adc_overrange;
    adc_3pa1030 u_adc(.clk(clk_50m),.rst_n(reset_n),.adc_data_in(adc_data_in),
        .adc_otr(adc_otr),.adc_clk(adc_clk),.adc_oe_n(adc_oe_n),
        .angle(angle),.valid(angle_valid),.overrange(adc_overrange));
    reg sensor_seen;
    reg [3:0] sensor_age;
    always @(posedge clk_50m or negedge reset_n) begin
        if(!reset_n) begin sensor_seen<=0;sensor_age<=15;end
        else if(angle_valid) begin sensor_seen<=1;sensor_age<=0;end
        else if(tick_ms && sensor_age<15) sensor_age<=sensor_age+1'b1;
    end
    wire sensor_ok=sensor_seen && sensor_age<10 && !adc_overrange && angle>4 && angle<4088;

    wire signed [31:0] encoder_raw;
    wire [31:0] encoder_invalid;
    quadrature_encoder u_encoder(.clk(clk_50m),.rst_n(reset_n),
        .enc_a(enc2_a),
        .enc_b(enc2_b),
        .position(encoder_raw),.invalid_count(encoder_invalid));
    reg signed [31:0] encoder_origin;
    wire signed [31:0] encoder_relative=ENCODER_REVERSE ?
        encoder_origin-encoder_raw : encoder_raw-encoder_origin;
    // 把实物的 1040 count/转换算为原 C 的 408 count/转，再运行原 PID 参数。
    // Capture exactly the original tick's relative count, but separate the
    // 32-bit subtract, constant product and divider sign conversion for timing.
    // Both product and valid are delayed2clocks; sample spacing stays1ms.
    reg signed [31:0] normalizer_relative_r,normalizer_input;
    reg [1:0] normalizer_tick_r;
    always @(posedge clk_50m or negedge reset_n)
        if(!reset_n)begin normalizer_relative_r<=0;normalizer_input<=0;normalizer_tick_r<=0;end
        else begin
            normalizer_relative_r<=encoder_relative;
            normalizer_input<=normalizer_relative_r*408;
            normalizer_tick_r<={normalizer_tick_r[0],tick_ms};
        end
    wire norm_busy,norm_done;
    wire signed [31:0] position;
    signed_div_const #(.WIDTH(32),.DENOM(ENCODER_COUNTS_REV)) u_position_div(
        .clk(clk_50m),.rst_n(reset_n),.start(normalizer_tick_r[1]),.dividend(normalizer_input),
        .busy(norm_busy),.done(norm_done),.quotient(position));

    wire [7:0] rx_data;
    wire rx_valid;
    uart_rx #(.CLK_HZ(CLK_HZ),.BAUD(115200)) u_rx(
        .clk(clk_50m),.rst_n(reset_n),.rx(uart_rx),.data(rx_data),.valid(rx_valid));
    wire cmd_start=rx_valid && rx_data=="s";
    wire cmd_stop=rx_valid && rx_data=="x";
    wire cmd_cal=rx_valid && rx_data=="c";
    // Legacy +/- no longer bypass the motion planner with full-turn steps.
    wire pid_running,pid_calibrated,pid_calibrating,zero_position,angle_update,location_update;
    wire [3:0] pid_fault,mode,super_fault;
    wire [11:0] pid_center;
    wire signed [31:0] target_position,location_out10;
    wire signed [7:0] pid_command,motor_command;
    wire motor_enable,pid_prepare,pid_start,pid_stop,target_update,position_target_valid;
    wire [11:0] prepare_center;
    wire signed [31:0] prepare_target,target_value,home_target;
    wire [7:0] pulse_count;
    wire auto_reference_ready,motion_valid,jump_event,turn_event,turn_positive,motion_seen;
    wire [11:0] auto_center,down_center;
    wire signed [15:0] theta_up,theta_down;
    wire signed [31:0] velocity_q8;
    wire [12:0] peak_amplitude;
    wire system_active=(mode==2 || mode==3 || mode==4 || mode==5 || mode==6);
    wire raw_cal_request=key_event[3] | cmd_cal;
    wire signed [31:0] angle32={20'd0,angle};
    wire near_saved_down=(angle32>AUTO_DOWN_REF-80 && angle32<AUTO_DOWN_REF+80);
    wire near_saved_up=(angle32>AUTO_UP_REF-500 && angle32<AUTO_UP_REF+500);
    wire down_recal=raw_cal_request && !system_active && near_saved_down;
    wire raw_manual_cal=raw_cal_request && !system_active && near_saved_up;
    reg manual_cal_pending;
    wire manual_cal_request=manual_cal_pending && !system_active && super_fault==0 && !pid_stop && !cmd_stop;
    reg manual_mode,auto_ready_seen;
    wire manual_ready=manual_mode && pid_calibrated && !pid_calibrating;
    always @(posedge clk_50m or negedge reset_n) begin
        if(!reset_n) begin manual_mode<=0;auto_ready_seen<=0;manual_cal_pending<=0;end
        else begin
            auto_ready_seen<=auto_reference_ready;
            if(system_active || cmd_stop || down_recal) manual_cal_pending<=0;
            else if(raw_manual_cal) manual_cal_pending<=1;
            else if(manual_cal_request) manual_cal_pending<=0;
            if(down_recal) manual_mode<=0;
            else if(raw_manual_cal) manual_mode<=1;
        end
    end
    auto_angle_state #(
        .MAP_CONFIRMED(AUTO_MAP_CONFIRMED),.UP_REF(AUTO_UP_REF),.DOWN_REF(AUTO_DOWN_REF)
    ) u_auto_angle(
        .clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),.sensor_ok(sensor_ok),
        .active(system_active),.reference_reset(down_recal),.angle(angle),
        .reference_ready(auto_reference_ready),.reference_center(auto_center),.down_center(down_center),
        .theta_up(theta_up),.theta_down(theta_down),.velocity_q8(velocity_q8),
        .motion_valid(motion_valid),.jump_event(jump_event),.turn_event(turn_event),
        .turn_positive(turn_positive),.peak_amplitude(peak_amplitude),.motion_seen(motion_seen));
    swingup_supervisor #(
        .SWING_DUTY_START(SWING_DUTY_START),.KICK_MS(SWING_KICK_MS),
        .PULSE_MS(SWING_PULSE_MS),.CAPTURE_ANGLE_ADC(CAPTURE_HALF_WIDTH),
        .SWING_POLARITY(SWING_POLARITY),.HALF_TURN_ADC(AUTO_UP_REF-AUTO_DOWN_REF),
        .BALANCE_EXIT_ADC(BALANCE_EXIT_ADC),.RECOVERY_DOWN_ADC(RECOVERY_DOWN_ADC),
        .RECOVERY_SPEED_Q8(RECOVERY_SPEED_Q8)
    ) u_supervisor(
        .clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),
        .start_event((key_event[0]|cmd_start) && (system_active || !manual_mode || manual_ready)),.stop_event(cmd_stop),
        .clear_event((raw_manual_cal|down_recal) && !system_active),
        .reference_ready(auto_reference_ready),.reference_center(auto_center),.angle_adc(angle),
        .sensor_ok(sensor_ok),.motion_valid(motion_valid),.jump_event(jump_event),
        .turn_event(turn_event),.turn_positive(turn_positive),.motion_seen(motion_seen),
        .theta_up(theta_up),.theta_down(theta_down),.velocity_q8(velocity_q8),
        .position(position),.peak_amplitude(peak_amplitude),
        .manual_mode(manual_mode),.manual_ready(manual_ready),.manual_center(pid_center),
        .pid_running(pid_running),.pid_angle_update(angle_update),.pid_command(pid_command),.pid_fault(pid_fault),
        .mode(mode),.fault(super_fault),.motor_command(motor_command),.motor_enable(motor_enable),
        .pid_prepare(pid_prepare),.pid_start(pid_start),.pid_stop(pid_stop),
        .prepare_center(prepare_center),.prepare_target(prepare_target),.home_target(home_target),
        .target_update(target_update),.target_value(target_value),
        .position_target_valid(position_target_valid),.pulse_count(pulse_count));

    wire position_ready=(mode==5 && pid_running && position_target_valid);
    wire position_stop=pid_stop || cmd_stop || (key_event[0] && system_active);
    wire pos_minus,pos_plus,pos_step,pos_confirm,pos_dip_valid;
    wire [1:0] pos_dip_mode,pos_step_index;
    wire [3:0] pos_task_state;
    wire pos_anchor_valid,pos_interrupted,pos_target_update;
    wire signed [31:0] pos_edit_deci,pos_goal_deci;
    wire signed [31:0] pos_home,pos_reference,pos_ref_velocity_q8,pos_velocity_q8,pos_target_value;
    wire [15:0] pos_task_id;
    wire [63:0] pos_duration_ms;
    wire trajectory_owned,position_accepting,tr_adopt,pos_adopt;
    wire signed [31:0] tr_adopt_value,pos_adopt_value;
    wire [1:0] reference_owner,handoff_state;
    wire tr_update,tr_base_valid,tr_running,tr_stop_pending,tr_interrupted;
    wire tr_jerk_valid,tr_accel_valid,tr_held_idle;
    wire signed [31:0] tr_target,tr_reference,tr_speed,tr_accel,tr_jerk,tr_center,tr_endpoint;
    wire [1:0] tr_profile;
    wire [3:0] tr_state;
    wire [15:0] tr_phase;
    wire [31:0] tr_cycles,tr_elapsed,tr_cycle_ms,tr_config_tag;
    wire signed [31:0] tr_edit_deci,tr_accepted_deci,tr_edit_a,tr_edit_b,tr_edit_c;
    wire [1:0] tr_step_index;
    wire [15:0] tr_run_id;
    wire [31:0] tr_time_stretch;
    position_inputs u_position_inputs(
        .clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),.keys_n(key_sw),.dip_n(dip_sw_n),
        .edit_enable(position_ready),.minus_event(pos_minus),.plus_event(pos_plus),
        .step_event(pos_step),.confirm_event(pos_confirm),.dip_mode(pos_dip_mode),.dip_valid(pos_dip_valid));
    position_task #(.MIN_MOVE_MS(POSITION_MIN_MOVE_MS),
        .MS_PER_DEG(POSITION_MS_PER_DEG)) u_position_task(
        .clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),
        .capture_event(pid_prepare),.capture_home(prepare_target),.lock_valid(position_target_valid),
        .reference_adopt_event(pos_adopt),.reference_adopt_value(pos_adopt_value),
        .balance_ready(position_ready),.stop_event(position_stop),
        .dip_mode(pos_dip_mode),.dip_valid(pos_dip_valid),
        .edit_minus(pos_minus && position_accepting),.edit_plus(pos_plus && position_accepting),
        .step_event(pos_step && position_accepting),.confirm_event(pos_confirm && position_accepting),
        .position(position),.angle(angle),.center(pid_center),
        .target_update(pos_target_update),.target_value(pos_target_value),
        .edit_deci(pos_edit_deci),.goal_deci(pos_goal_deci),.home_position(pos_home),
        .reference_position(pos_reference),.reference_speed_q8(pos_ref_velocity_q8),
        .actual_speed_q8(pos_velocity_q8),.task_state(pos_task_state),.step_index(pos_step_index),
        .anchor_valid(pos_anchor_valid),.interrupted(pos_interrupted),.task_id(pos_task_id),
        .duration_ms(pos_duration_ms));
    trajectory_editor u_trajectory_editor(
        .clk(clk_50m),.rst_n(reset_n),.edit_enable(position_ready),
        .selected_mode(pos_dip_mode),.selection_valid(pos_dip_valid),
        .minus_event(pos_minus),.plus_event(pos_plus),.step_event(pos_step),
        .requested_deci(tr_edit_deci),.trapezoid_deci(tr_edit_a),
        .scurve_deci(tr_edit_b),.sine_deci(tr_edit_c),.step_index(tr_step_index));
    trajectory_task u_trajectory_task(
        .clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),.owned(trajectory_owned),
        .balance_ready(position_ready),.stop_event(position_stop),
        .adopt_event(tr_adopt),.adopt_reference(tr_adopt_value),
        .selected_mode(pos_dip_mode),.selection_valid(pos_dip_valid),
        .confirm_event(pos_confirm && trajectory_owned),
        .requested_deci(tr_edit_deci),.accepted_deci(tr_accepted_deci),
        .time_stretch(tr_time_stretch),.run_id(tr_run_id),
        .target_update(tr_update),.target_value(tr_target),.reference_position(tr_reference),
        .reference_speed_q8(tr_speed),.reference_acceleration_q8(tr_accel),.reference_jerk_q8(tr_jerk),
        .center_position(tr_center),.endpoint_position(tr_endpoint),.active_profile(tr_profile),
        .trajectory_state(tr_state),.phase(tr_phase),.cycle_count(tr_cycles),.elapsed_ms(tr_elapsed),
        .cycle_ms(tr_cycle_ms),.config_tag(tr_config_tag),.base_valid(tr_base_valid),
        .running(tr_running),.stop_pending(tr_stop_pending),.interrupted(tr_interrupted),
        .jerk_valid(tr_jerk_valid),.acceleration_valid(tr_accel_valid),.held_idle(tr_held_idle));
    motion_reference_owner u_reference_owner(
        .clk(clk_50m),.rst_n(reset_n),.balance_ready(position_ready),.stop_event(position_stop),
        .capture_event(pid_prepare),.selected_mode(pos_dip_mode),.selection_valid(pos_dip_valid),
        .position_state(pos_task_state),.position_update(pos_target_update),.position_reference(pos_reference),
        .trajectory_held_idle(tr_held_idle),.trajectory_update(tr_update),.trajectory_reference(tr_reference),
        .trajectory_owned(trajectory_owned),.position_accepting(position_accepting),
        .trajectory_adopt_event(tr_adopt),.trajectory_adopt_value(tr_adopt_value),
        .position_adopt_event(pos_adopt),.position_adopt_value(pos_adopt_value),
        .reference_owner(reference_owner),.handoff_state(handoff_state));
    wire signed [31:0] fast_speed_q8,ff_correction10,ff_applied10,location_pd10;
    wire signed [32:0] location_total10;
    wire fast_speed_valid,fast_speed_update,ff_valid,location_limited;
    // Absolute raw count avoids a calibration-origin jump contaminating speed.
    wire signed [31:0] encoder_speed_count=ENCODER_REVERSE ? -encoder_raw : encoder_raw;
    encoder_speed_monitor #(.ENCODER_COUNTS_REV(ENCODER_COUNTS_REV)) u_fast_speed(
        .clk(clk_50m),.rst_n(reset_n),.tick_ms(tick_ms),.capture_event(pid_prepare),
        .encoder_count(encoder_speed_count),.speed_q8(fast_speed_q8),
        .speed_valid(fast_speed_valid),.speed_update(fast_speed_update));
    wire ff_enable=LOCATION_AFF_Q16!=0 && trajectory_owned && tr_running && tr_accel_valid &&
                   position_ready && !position_stop;
    acceleration_feedforward #(.LOCATION_AFF_Q16(LOCATION_AFF_Q16)) u_accel_ff(
        .clk(clk_50m),.rst_n(reset_n),.enable(ff_enable),
        .reference_acceleration_q8(tr_accel),.correction10(ff_correction10),.valid(ff_valid));
    wire position_write=pos_target_update && !trajectory_owned && position_ready && !position_stop;
    wire trajectory_write=tr_update && trajectory_owned && position_ready && !position_stop;
    wire motion_write=position_write || trajectory_write;
    wire signed [31:0] motion_target_value=trajectory_owned ? tr_target : pos_target_value;
    wire signed [31:0] active_reference=trajectory_owned ? tr_reference : pos_reference;
    wire signed [31:0] active_base=trajectory_owned ? tr_center : pos_home;
    wire signed [31:0] active_endpoint=trajectory_owned ? tr_endpoint : target_position;
    wire signed [31:0] active_reference_speed=trajectory_owned ? tr_speed : pos_ref_velocity_q8;
    wire active_base_valid=trajectory_owned ? tr_base_valid : pos_anchor_valid;
    cascade_control #(
        .ANGLE_KP_100(ANGLE_KP_100),.ANGLE_KI_100(ANGLE_KI_100),.ANGLE_KD_100(ANGLE_KD_100),
        .ANGLE_D_FILTER_SHIFT(ANGLE_D_FILTER_SHIFT), // [D_LPF修改] 只滤角度D。
        .LOCATION_KP_10(LOCATION_KP_10),.LOCATION_KD_10(LOCATION_KD_10),.DUTY_LIMIT(DUTY_LIMIT),
        .LOCATION_KI_1000(LOCATION_KI_1000),
        .LOCATION_I_LIMIT_10(LOCATION_I_LIMIT_10),
        .FF_ENABLE(LOCATION_AFF_Q16!=0)
    ) u_control(
        .clk(clk_50m),.rst_n(reset_n),.sample_ms(norm_done),.angle(angle),.position(position),
        .sensor_ok(sensor_ok),.travel_ok(1'b1),
        .toggle_event(1'b0),.stop_event(pid_stop|cmd_stop),
        .plus_event(1'b0),.minus_event(1'b0),
        .calibrate_event(manual_cal_request),
        .ff_valid(ff_valid && ff_enable),.ff_correction10(ff_correction10),
        .ff_applied10(ff_applied10),.location_pd10(location_pd10),
        .location_total10(location_total10),.location_limited(location_limited),
        .prepare_event(pid_prepare),.prepare_center(prepare_center),.prepare_target(prepare_target),
        .capture_start_event(pid_start),.target_update_event(target_update|motion_write),
        .target_value(motion_write ? motion_target_value : target_value),
        .running(pid_running),.calibrated(pid_calibrated),
        .calibrating(pid_calibrating),.fault(pid_fault),.center(pid_center),.target_position(target_position),
        .location_out10(location_out10),.motor_command(pid_command),
        .zero_position(zero_position),.angle_update(angle_update),.location_update(location_update));
    always @(posedge clk_50m or negedge reset_n)
        if(!reset_n) encoder_origin<=0;
        else if(zero_position || (auto_reference_ready && !auto_ready_seen && !system_active && !manual_mode))
            encoder_origin<=encoder_raw;

    wire motor_in1,motor_in2,motor_pwm_out;
    // 原始复位直接参与输出门控，按 SW5 无需等待同步器即可关断。
    // A 20ns pipeline breaks the long observer/mode/percent-to-PWM data path.
    // Raw SW5 and explicit user stop remain immediate after the pipeline.
    reg signed [7:0] motor_command_r;
    reg motor_enable_r;
    always @(posedge clk_50m or negedge reset_n)
        if(!reset_n) begin motor_command_r<=0; motor_enable_r<=0; end
        else begin motor_command_r<=motor_command; motor_enable_r<=motor_enable; end
    wire user_stop_now=cmd_stop || (key_event[0] && system_active);
    wire drive_enable=motor_enable_r && rst_n && reset_n && !user_stop_now;
    motor_pwm #(.CLK_HZ(CLK_HZ),.REVERSE(MOTOR_REVERSE)) u_motor(
        .clk(clk_50m),.rst_n(reset_n),.enable(drive_enable),.command(motor_command_r),
        .in1(motor_in1),.in2(motor_in2),.pwm(motor_pwm_out));
    assign AN1=MOTOR_CHANNEL==0 ? motor_in1 : 1'b0;
    assign AN2=MOTOR_CHANNEL==0 ? motor_in2 : 1'b0;
    assign PWMA=MOTOR_CHANNEL==0 ? motor_pwm_out : 1'b0;
    assign BN1=MOTOR_CHANNEL==1 ? motor_in1 : 1'b0;
    assign BN2=MOTOR_CHANNEL==1 ? motor_in2 : 1'b0;
    assign PWMB=MOTOR_CHANNEL==1 ? motor_pwm_out : 1'b0;
    // An explicitly cleared automatic attempt must not inherit an old PID fault
    // while the PID is idle. Prepare clears that history before the next handoff.
    wire [3:0] display_fault=(super_fault!=0) ? super_fault :
        ((manual_mode || mode==4 || mode==5) ? pid_fault : 4'd0);
    wire display_calibrated=manual_mode ? pid_calibrated : auto_reference_ready;
    wire [11:0] display_center=manual_mode ? pid_center : auto_center;
    // Zero means no locked target in swing/recovery; the stopped PID does not chase it.
    wire signed [31:0] display_target=position_target_valid ? target_position : 32'sd0;
    assign led={sensor_ok,(display_fault!=0),display_calibrated,system_active};
    wire command_at_limit=DUTY_LIMIT>0 &&
        ($signed(motor_command)>=DUTY_LIMIT || $signed(motor_command)<= -DUTY_LIMIT);
    // [D_LPF修改] FL14上传D滤波启用状态，FL15保留；X8002字段/位宽不变。
    wire [15:0] unified_flags={1'b0,(ANGLE_D_FILTER_SHIFT>0),sensor_ok,(encoder_invalid!=0),command_at_limit,pos_anchor_valid,
        (trajectory_owned && tr_accel_valid),(trajectory_owned && tr_jerk_valid),tr_interrupted,
        tr_stop_pending,tr_running,drive_enable,active_base_valid,motion_valid,auto_reference_ready,pos_dip_valid};

    reg [6:0] telemetry_ms;
    reg [31:0] uptime_ms;
    wire telemetry_request=tick_ms && telemetry_ms==99;
    always @(posedge clk_50m or negedge reset_n)
        if(!reset_n) begin telemetry_ms<=0;uptime_ms<=0;end
        else if(tick_ms) begin
            telemetry_ms<=telemetry_request ? 7'd0 : telemetry_ms+7'd1;
            uptime_ms<=uptime_ms+1'b1;
        end
    telemetry #(.CLK_HZ(CLK_HZ)) u_telemetry(
        .clk(clk_50m),.rst_n(reset_n),.request(telemetry_request),
        .angle(angle),.center(display_center),.position(position),.target_position(display_target),
        .command(motor_command),.running(system_active),.calibrated(display_calibrated),.fault(display_fault),
        .mode(mode),.velocity_q8(velocity_q8),.pulse_count(pulse_count),
        .auto_ready(auto_reference_ready),.motion_valid(motion_valid),
        .pos_dip_mode(pos_dip_mode),.pos_task_state(pos_task_state),
        .pos_edit_deci(pos_edit_deci),.pos_goal_deci(pos_goal_deci),
        .pos_home(pos_home),.pos_reference(pos_reference),
        .pos_ref_velocity_q8(pos_ref_velocity_q8),.pos_velocity_q8(fast_speed_q8),
        .pos_step_index(pos_step_index),.pos_anchor_valid(pos_anchor_valid),
        .pos_task_id(pos_task_id),.pos_interrupted(pos_interrupted),
        .uptime_ms(uptime_ms),.pos_duration_ms(pos_duration_ms),
        .u_reference_owner(reference_owner),.u_planner_reference_units(active_reference),
        .u_active_base_units(active_base),.u_trajectory_endpoint_units(active_endpoint),
        .u_reference_velocity_q8(active_reference_speed),.u_reference_acceleration_q8(tr_accel),
        .u_reference_jerk_q8(tr_jerk),.u_duty_limit_pct(DUTY_LIMIT[7:0]),
        .u_active_trajectory_profile(tr_profile),.u_trajectory_state(tr_state),
        .u_trajectory_cycle_count(tr_cycles),.u_trajectory_elapsed_ms(tr_elapsed),
        .u_trajectory_cycle_ms(tr_cycle_ms),.u_trajectory_config_tag(tr_config_tag),
        .u_trajectory_phase(tr_phase),.u_flags(unified_flags),
        .u_down_center_adc(down_center),.u_peak_amplitude_adc(peak_amplitude),
        .u_angle_kp_100(ANGLE_KP_100),.u_angle_ki_100(ANGLE_KI_100),.u_angle_kd_100(ANGLE_KD_100),
        .u_location_kp_10(LOCATION_KP_10),.u_location_kd_10(LOCATION_KD_10),
        .u_position_min_move_ms(POSITION_MIN_MOVE_MS),.u_position_ms_per_degree(POSITION_MS_PER_DEG),
        .u_trajectory_edit_deci(tr_edit_deci),.u_trajectory_accepted_deci(tr_accepted_deci),
        .u_trajectory_step_index(tr_step_index),.u_trajectory_run_id(tr_run_id),
        .u_trajectory_time_stretch(tr_time_stretch),
        .u_trapezoid_edit_deci(tr_edit_a),.u_scurve_edit_deci(tr_edit_b),.u_sine_edit_deci(tr_edit_c),
        .ff_gain_q16(LOCATION_AFF_Q16),.ff_pd10(location_pd10),.ff_applied10(ff_applied10),
        .ff_total10(location_total10),.ff_loc10(location_out10),.ff_acceleration_q8(tr_accel),
        .ff_active(ff_valid && ff_enable),.ff_limited(location_limited),.speed_valid(fast_speed_valid),
        .tx(uart_tx));
endmodule

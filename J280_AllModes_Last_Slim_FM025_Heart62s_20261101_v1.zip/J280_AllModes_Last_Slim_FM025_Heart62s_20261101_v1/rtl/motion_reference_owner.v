// Ordered ownership handoff. Source generators adopt the old HELD reference
// one FPGA clock before the mux changes, so no stale target can be published.
module motion_reference_owner(
    input wire clk,input wire rst_n,input wire balance_ready,input wire stop_event,
    input wire capture_event,input wire [1:0] selected_mode,input wire selection_valid,
    input wire [3:0] position_state,input wire position_update,
    input wire signed [31:0] position_reference,
    input wire trajectory_held_idle,input wire trajectory_update,
    input wire signed [31:0] trajectory_reference,
    output wire trajectory_owned,output wire position_accepting,
    output reg trajectory_adopt_event,output reg signed [31:0] trajectory_adopt_value,
    output reg position_adopt_event,output reg signed [31:0] position_adopt_value,
    output wire [1:0] reference_owner,output wire [1:0] handoff_state
);
    localparam [1:0] POSITION=0,PRIME_TRAJECTORY=1,TRAJECTORY=2,PRIME_POSITION=3;
    reg [1:0] state;
    assign trajectory_owned=state==TRAJECTORY || state==PRIME_POSITION;
    assign position_accepting=state==POSITION;
    assign reference_owner=trajectory_owned ? 2'd1 : 2'd0;
    assign handoff_state=state;
    always @(posedge clk or negedge rst_n)begin
        if(!rst_n)begin
            state<=POSITION;trajectory_adopt_event<=0;position_adopt_event<=0;
            trajectory_adopt_value<=0;position_adopt_value<=0;
        end else begin
            trajectory_adopt_event<=0;position_adopt_event<=0;
            if(stop_event || capture_event || !balance_ready)begin state<=POSITION;end
            else case(state)
                POSITION:if(selection_valid && selected_mode!=0 && position_state==6 && !position_update)begin
                    trajectory_adopt_value<=position_reference;trajectory_adopt_event<=1;state<=PRIME_TRAJECTORY;
                end
                PRIME_TRAJECTORY:state<=TRAJECTORY;
                TRAJECTORY:if(selection_valid && selected_mode==0 && trajectory_held_idle && !trajectory_update)begin
                    position_adopt_value<=trajectory_reference;position_adopt_event<=1;state<=PRIME_POSITION;
                end
                PRIME_POSITION:state<=POSITION;
                default:state<=POSITION;
            endcase
        end
    end
endmodule

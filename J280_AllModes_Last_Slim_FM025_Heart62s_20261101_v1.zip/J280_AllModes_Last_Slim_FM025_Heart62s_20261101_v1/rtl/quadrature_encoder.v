// 四倍频；A 超前 B 时正计数。同步后要求 A/B 整体稳定 FILTER_CYCLES。
module quadrature_encoder #(parameter integer FILTER_CYCLES=8)(
    input wire clk, input wire rst_n, input wire enc_a, input wire enc_b,
    output reg signed [31:0] position,
    output reg [31:0] invalid_count
);
    (* syn_preserve=1 *) reg [1:0] sync_a, sync_b;
    reg [1:0] candidate, previous;
    localparam integer STABLE_WIDTH=(FILTER_CYCLES<1)?1:$clog2(FILTER_CYCLES+1); // [EQ62修改]
    reg [STABLE_WIDTH-1:0] stable_count;
    reg initialized;
    wire [1:0] current={sync_a[1],sync_b[1]};
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            sync_a<=0; sync_b<=0; candidate<=0; previous<=0;
            stable_count<=0; initialized<=0; position<=0; invalid_count<=0;
        end else begin
            sync_a<={sync_a[0],enc_a}; sync_b<={sync_b[0],enc_b};
            if(current!=candidate) begin candidate<=current; stable_count<=0; end
            else if(stable_count<FILTER_CYCLES) stable_count<=stable_count+1'b1;
            else if(!initialized) begin initialized<=1; previous<=candidate; end
            else if(candidate!=previous) begin
                previous<=candidate;
                case({previous,candidate})
                    4'b0010,4'b1011,4'b1101,4'b0100: position<=position+1'b1;
                    4'b0001,4'b0111,4'b1110,4'b1000: position<=position-1'b1;
                    default: invalid_count<=invalid_count+1'b1;
                endcase
            end
        end
    end
endmodule

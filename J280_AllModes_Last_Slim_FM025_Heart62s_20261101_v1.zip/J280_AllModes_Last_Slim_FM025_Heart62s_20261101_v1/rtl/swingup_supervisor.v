// Picture-aligned swing-up with loss-of-balance recovery.
// Left apex -> right pulse; right apex -> left pulse; center -> existing PID.
// Each capture latches a new arm target; recovery resumes a moving swing in phase.
// User stop/reset cancel the whole flow. No range/time/pulse-count fault latch.
module swingup_supervisor #(
    parameter integer SWING_DUTY_START=32,
    parameter integer KICK_MS=70,
    parameter integer PULSE_MS=40,
    parameter integer CAPTURE_ANGLE_ADC=64,
    parameter integer SWING_POLARITY=1,
    parameter integer HALF_TURN_ADC=2096,
    parameter integer BALANCE_EXIT_ADC=256,
    parameter integer RECOVERY_DOWN_ADC=80,
    parameter integer RECOVERY_SPEED_Q8=128
)(
    input wire clk, input wire rst_n, input wire tick_ms,
    input wire start_event, input wire stop_event, input wire clear_event,
    input wire reference_ready,
    input wire [11:0] reference_center,
    input wire [11:0] angle_adc,
    input wire sensor_ok, input wire motion_valid, input wire jump_event,
    input wire turn_event, input wire turn_positive, input wire motion_seen,
    input wire signed [15:0] theta_up, input wire signed [15:0] theta_down,
    input wire signed [31:0] velocity_q8, input wire signed [31:0] position,
    input wire [12:0] peak_amplitude,
    input wire manual_mode, input wire manual_ready,
    input wire [11:0] manual_center,
    input wire pid_running, input wire pid_angle_update,
    input wire signed [7:0] pid_command,
    input wire [3:0] pid_fault,
    output reg [3:0] mode, output reg [3:0] fault,
    output wire signed [7:0] motor_command,
    output wire motor_enable,
    output reg pid_prepare, output reg pid_start, output reg pid_stop,
    output reg [11:0] prepare_center,
    output reg signed [31:0] prepare_target,
    output reg signed [31:0] home_target,
    output reg target_update,
    output reg signed [31:0] target_value,
    output reg position_target_valid,
    output wire [7:0] pulse_count
);
    localparam [3:0] IDLE=0, READY=1, KICK=2, SWING=3, HANDOFF=4, BALANCE=5, RECOVER=6;
    localparam signed [13:0] HALF_C=HALF_TURN_ADC;
    localparam signed [13:0] FULL_C=2*HALF_TURN_ADC;
    // Percent representation only: no separate run-time maximum/adaptation.
    localparam integer DUTY_C=SWING_DUTY_START>100 ? 100 :
                              (SWING_DUTY_START<0 ? 0 : SWING_DUTY_START);
    reg [31:0] kick_ms, pulse_left_ms;
    reg signed [7:0] pulse_command;
    reg [7:0] pulses;
    reg [1:0] handoff_stage;
    reg [11:0] control_center;
    reg turn_event_previous;
    reg resume_turn_pending, resume_turn_negative;
    wire active=(mode==KICK || mode==SWING || mode==HANDOFF || mode==BALANCE || mode==RECOVER);
    wire stop_now=stop_event || (start_event && active);
    // Keep the exact reference selected at the FIRST start, including manual C.
    // A raw12 difference fits signed14; normalize using the calibrated turn.
    wire signed [13:0] raw_error=$signed({2'b0,angle_adc})-$signed({2'b0,control_center});
    wire signed [13:0] control_error=(raw_error>HALF_C) ? raw_error-FULL_C :
        ((raw_error< -HALF_C) ? raw_error+FULL_C : raw_error);
    wire in_center=(control_error>= -CAPTURE_ANGLE_ADC && control_error<=CAPTURE_ANGLE_ADC);
    wire loss_of_balance=(mode==BALANCE || mode==HANDOFF) &&
        (control_error>BALANCE_EXIT_ADC || control_error< -BALANCE_EXIT_ADC);
    wire near_down=(control_error>=HALF_TURN_ADC-RECOVERY_DOWN_ADC ||
                    control_error<= -HALF_TURN_ADC+RECOVERY_DOWN_ADC);
    wire slow_down=($signed(velocity_q8)>= -RECOVERY_SPEED_Q8 &&
                    $signed(velocity_q8)<=RECOVERY_SPEED_Q8);
    wire pulse_negative=(control_error>0) ^ (SWING_POLARITY<0);
    wire fresh_turn=turn_event && !turn_event_previous;
    function signed [7:0] signed_duty;
        input negative;
        begin signed_duty=negative ? -DUTY_C : DUTY_C; end
    endfunction
    assign motor_enable=rst_n && !stop_now && !loss_of_balance &&
        (mode==KICK || mode==SWING || mode==BALANCE);
    assign motor_command=!motor_enable ? 8'sd0 :
        (mode==KICK && !in_center) ? signed_duty(SWING_POLARITY<0) :
        (mode==SWING && pulse_left_ms!=0 && !in_center) ? pulse_command :
        (mode==BALANCE) ? pid_command : 8'sd0;
    assign pulse_count=pulses;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            mode<=IDLE; fault<=0; kick_ms<=0; pulse_left_ms<=0; pulse_command<=0;
            pulses<=0; handoff_stage<=0; turn_event_previous<=0;
            control_center<=0;
            resume_turn_pending<=0; resume_turn_negative<=0;
            pid_prepare<=0; pid_start<=0; pid_stop<=0;
            prepare_center<=0; prepare_target<=0; home_target<=0;
            target_update<=0; target_value<=0;
            position_target_valid<=0;
        end else begin
            fault<=0; pid_prepare<=0; pid_start<=0; pid_stop<=0; target_update<=0;
            turn_event_previous<=turn_event;
            // An apex may arrive between millisecond ticks or while PID is
            // acknowledging stop. Preserve it once instead of losing its phase.
            if(mode==RECOVER && fresh_turn) begin
                resume_turn_pending<=1; resume_turn_negative<=pulse_negative;
            end
            if(stop_now) begin
                resume_turn_pending<=0;
                pid_stop<=1; pulse_left_ms<=0; pulse_command<=0;
                position_target_valid<=0; home_target<=0; prepare_target<=0; target_value<=0;
                mode<=(reference_ready || manual_ready) ? READY : IDLE;
            end else if(clear_event && !active) begin
                resume_turn_pending<=0;
                pid_stop<=1; mode<=(reference_ready || manual_ready) ? READY : IDLE;
                position_target_valid<=0; home_target<=0; prepare_target<=0; target_value<=0;
            end else if(loss_of_balance) begin
                // Stop resets the original PID integral/history and cancels its
                // in-flight calculation. Preserve C/origin, discard this arm target.
                pid_stop<=1; mode<=RECOVER; handoff_stage<=0;
                pulse_left_ms<=0; pulse_command<=0; kick_ms<=0;
                position_target_valid<=0; home_target<=0; prepare_target<=0; target_value<=0;
                resume_turn_pending<=fresh_turn; resume_turn_negative<=pulse_negative;
            end else if(start_event && (mode==IDLE || mode==READY)) begin
                resume_turn_pending<=0;
                if(manual_mode) begin
                    control_center<=manual_center;
                    mode<=HANDOFF; handoff_stage<=0; pid_prepare<=1;
                    // Already upright: lock the current arm position once.
                    prepare_center<=manual_center; prepare_target<=position;
                    home_target<=position; target_value<=position; position_target_valid<=1;
                    pulse_left_ms<=0; pulse_command<=0; pulses<=0;
                end else begin
                    control_center<=reference_center;
                    mode<=KICK; kick_ms<=0; pulse_left_ms<=0; pulse_command<=0;
                    pulses<=1; home_target<=0; target_value<=0; prepare_target<=0;
                    position_target_valid<=0;
                end
            end else begin
                case(mode)
                    IDLE: if(reference_ready || manual_ready) mode<=READY;
                    READY: if(!reference_ready && !manual_ready) mode<=IDLE;
                    KICK,SWING: begin
                        if(in_center) begin
                            // Enter center immediately; no speed threshold or dwell.
                            mode<=HANDOFF; handoff_stage<=0; pid_prepare<=1;
                            // One capture edge, one target. Never continuously follow P.
                            prepare_center<=control_center; prepare_target<=position;
                            home_target<=position; target_value<=position; position_target_valid<=1;
                            pulse_left_ms<=0; pulse_command<=0;
                        end else if(fresh_turn) begin
                            // Each real apex redirects/restarts one finite pulse.
                            // No cooldown, periodic pumping, pulse budget or adaptation.
                            mode<=SWING; pulse_left_ms<=PULSE_MS;
                            pulse_command<=signed_duty(pulse_negative);
                            if(pulses!=255) pulses<=pulses+1'b1;
                        end else if(tick_ms) begin
                            if(mode==KICK) begin
                                if(KICK_MS<=1 || kick_ms>=KICK_MS-1) begin mode<=SWING; kick_ms<=0; end
                                else kick_ms<=kick_ms+1'b1;
                            end
                            if(pulse_left_ms!=0) pulse_left_ms<=pulse_left_ms-1'b1;
                        end
                    end
                    HANDOFF: begin
                        // Prepare must reach PID before start. Wait only for its
                        // first actual computed command, not an added capture test.
                        if(handoff_stage==0) begin pid_start<=1; handoff_stage<=1; end
                        else if(handoff_stage==1) handoff_stage<=2;
                        if(handoff_stage>=1 && pid_running && pid_angle_update) mode<=BALANCE;
                    end
                    BALANCE: begin end
                    RECOVER: begin
                        position_target_valid<=0;
                        // Stop the old PID first. A moving rod resumes SWING;
                        // near-down/low-speed only selects a fresh initial kick.
                        // They no longer block ALL recovery until near standstill.
                        if(!pid_running) begin
                            if(in_center) begin
                                mode<=SWING; resume_turn_pending<=0;
                                pulse_left_ms<=0; pulse_command<=0;
                            end else if(fresh_turn || resume_turn_pending) begin
                                mode<=SWING; resume_turn_pending<=0;
                                pulse_left_ms<=PULSE_MS;
                                pulse_command<=signed_duty(fresh_turn ? pulse_negative : resume_turn_negative);
                                if(pulses!=255) pulses<=pulses+1'b1;
                            end else if(tick_ms) begin
                                resume_turn_pending<=0;
                                pulse_left_ms<=0; pulse_command<=0;
                                if(near_down && slow_down) begin
                                    mode<=KICK; kick_ms<=0;
                                    if(pulses!=255) pulses<=pulses+1'b1;
                                end else mode<=SWING;
                            end
                        end
                    end
                    default: mode<=IDLE;
                endcase
            end
        end
    end
endmodule

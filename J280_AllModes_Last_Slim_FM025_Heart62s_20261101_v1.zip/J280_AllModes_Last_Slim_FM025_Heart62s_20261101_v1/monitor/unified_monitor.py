"""One receive-only window for J280 swing, balance, positioning and trajectories."""
from __future__ import annotations
import argparse
import csv
import json
import math
import os
from pathlib import Path
import queue
import time
import tkinter as tk
from tkinter import filedialog,ttk
from unified_protocol import (FIELDS,BALANCE_LABELS,DIP_LABELS,PROFILE_LABELS,POSITION_LABELS,
    TRAJECTORY_LABELS,FAULT_LABELS,UnifiedHistory,UnifiedRecorder,UnifiedStreamDecoder,
    decode_unified,label,sw4_meaning,unified_status)
from wave_monitor import Plot,SerialWorker
from feedforward_protocol import decode_feedforward,speed_description,speed_summary,diagnostic_summary,FAST_SPEED_TAGS
from amfm_semantics import (profile_label as mod_profile_label,angle_semantic as mod_angle_semantic,
    is_modulated_tag,upper_envelope_degrees,lower_envelope_degrees,modulation_summary,
    stop_meaning as mod_stop_meaning,heart_config)

ROOT=Path(__file__).resolve().parent
READ_ONLY_NOTICE='只接收数据，不发送启动、目标、标定或调参命令。SW1全局启停，SW5复位；关闭窗口不会停止电机。'

# [D_LPF修改] 依据板卡FL14显示状态，不凭轨迹CF或D增益推断是否已烧录滤波版。
def derivative_filter_status(f):
    return '角度D低通：已启用（FL14=1）' if f.flag(14) else '角度D低通：未启用（FL14=0）'


def deg(value):return '—（无有效基准）' if value is None else f'{value:+.2f}°'

def active_profile_label(f):
    return mod_profile_label(f.active_trajectory_profile,f.trajectory_config_tag,label(PROFILE_LABELS,f.active_trajectory_profile))

def selected_mode_label(f):
    if f.selected_dip_mode in (1,2,3) and is_modulated_tag(f.trajectory_config_tag):
        return f'{f.selected_dip_mode:02b} '+mod_profile_label(f.selected_dip_mode,f.trajectory_config_tag,label(PROFILE_LABELS,f.selected_dip_mode))
    return label(DIP_LABELS,f.selected_dip_mode)

SPAN_OPTIONS=('5','10','20','30','60','120','300','600','1800')

def window_seconds(value):
    try:span=float(value)
    except (TypeError,ValueError):return 30.
    return min(1800.,max(5.,span)) if math.isfinite(span) else 30.


# [FAST_AB_10S修改] 同一X8002协议可承载旧单程与新半幅语义，用CF登记区分。
TRAJECTORY_SEMANTICS_PATH=ROOT.parent/'config/trajectory_semantics.json'


def centered_half_amplitude_tags(path=None, key='centered_half_amplitude_tags'):
    """Read local semantic registrations; None means unavailable, never guessed."""
    try:
        data=json.loads(Path(TRAJECTORY_SEMANTICS_PATH if path is None else path).read_text(encoding='utf-8-sig'))
        entries=data.get(key,[]) if key != 'centered_half_amplitude_tags' else data[key]
        if not isinstance(entries,list):return None
        tags=set()
        for entry in entries:
            if not isinstance(entry,str) or len(entry)!=8 or any(c not in '0123456789abcdefABCDEF' for c in entry):return None
            tags.add(int(entry,16))
        return frozenset(tags)
    except (OSError,UnicodeError,ValueError,TypeError,KeyError):
        return None


def trajectory_angle_semantic(profile,config_tag,registered_tags):
    # [FAST_AB_10S修改] 正弦一直是半幅；A/B在登记可读时按CF判断，失败时明确未确认。
    modulated=mod_angle_semantic(profile,config_tag)
    if modulated is not None:return modulated
    if profile==3:return '有符号半幅（负号倒相）'
    if profile==0:return '无轨迹'
    if profile not in (1,2):return '角度语义未确认'
    if registered_tags is None:return '角度语义未确认（配置登记不可用）'
    if config_tag in registered_tags:
        full_tags=centered_half_amplitude_tags(key='full_stroke_start_tags')
        if full_tags is not None and config_tag in full_tags:
            return '有符号半幅（单程=2×TA，从当前端点起步）'
        return '有符号半幅（负号倒相）'
    return '有符号单程（旧配置）'


def trajectory_semantics(f):
    tags=centered_half_amplitude_tags()
    # [FAST_AB_10S修改] TE属于当前拨码；TA属于仍在运行/退出的实际曲线，不能互相代替。
    return (trajectory_angle_semantic(f.selected_dip_mode,f.trajectory_config_tag,tags),
            trajectory_angle_semantic(f.active_trajectory_profile,f.trajectory_config_tag,tags))


def trajectory_summary(f):
    if not f.has_runtime:
        return 'X8001兼容：未上报轨迹编辑TE、接受TA、步长TZ、运行TI及伸长TM；不从旧E/G推断。'
    edit_semantic,active_semantic=trajectory_semantics(f)
    step='未知步长' if f.trajectory_step_degrees is None else f'{f.trajectory_step_degrees:g}°'
    names=('AM最大包络半幅','FM固定半幅','心形最大偏移' if heart_config(f.trajectory_config_tag) else '普通正弦') if is_modulated_tag(f.trajectory_config_tag) else ('A','B','C')
    period_label=({1:'AM包络周期CL',2:'FM变速循环CL',3:'完整心形周期CL' if heart_config(f.trajectory_config_tag) else '实际周期CL'}.get(f.active_trajectory_profile,'实际周期CL') if is_modulated_tag(f.trajectory_config_tag) else '实际周期CL')
    return (f'下次轨迹TE={f.selected_trajectory_edit_deci/10:+.1f}°（{edit_semantic}，步长{step}）；'
            f'各模式编辑 {names[0]}={f.trapezoid_edit_deci/10:+.1f}° / {names[1]}={f.scurve_edit_deci/10:+.1f}° / {names[2]}={f.sine_edit_deci/10:+.1f}°。\n'
            f'已接受TA={f.accepted_trajectory_deci/10:+.1f}°（{active_semantic}，实际{active_profile_label(f)}），运行TI={f.trajectory_run_id}，'
            f'时间系数TM={f.trajectory_time_stretch}，{period_label}={f.trajectory_cycle_ms/1000:.3f}s；{label(TRAJECTORY_LABELS,f.trajectory_state)}。')


class UnifiedMonitor:
    def __init__(self,root,mode='live',create_worker=True):
        self.root=root;self.mode=mode;self.allow_worker=create_worker;self.worker=None;self.recorder=None
        self.events=queue.Queue();self.decoder=UnifiedStreamDecoder();self.history=UnifiedHistory()
        self.last_frame=self.last_received_at=None;self.legacy={};self.connection_segment=0;self.last_ff=None
        self.connected=self.wanted=self.closing=False;self.valid=0;self.previous_counts=[0]*5
        self.session_start=time.monotonic();self.paused_at=None;self.dirty=True;self.last_error='';self.last_status='尚未连接'
        self.root.title('J280 · 全功能统一监测 v8.7 心形 / AM / FM / 定位 · 只读 · X8002 / Z8601')
        sw,sh=root.winfo_screenwidth(),root.winfo_screenheight()
        root.geometry(f'{min(1280,sw-50)}x{min(880,sh-70)}');root.minsize(min(980,sw-50),min(620,sh-70))
        style=ttk.Style(root);style.configure('TLabel',font=('Microsoft YaHei UI',9));style.configure('TButton',font=('Microsoft YaHei UI',9))
        self.port_var=tk.StringVar(value='COM7');self.auto_var=tk.BooleanVar(value=True);self.span_var=tk.StringVar(value='120')
        self.status_var=tk.StringVar();self.stats_var=tk.StringVar();self.record_var=tk.StringVar(value='连接后自动保存独立X快照CSV。')
        self.sw4_var=tk.StringVar(value='等待板卡状态');self.note_var=tk.StringVar();self.metric_var=tk.StringVar();self.raw_var=tk.StringVar()
        self.overview_var=tk.StringVar();self.swing_var=tk.StringVar();self.position_var=tk.StringVar();self.planner_var=tk.StringVar()
        self.parameter_var=tk.StringVar();self.legacy_var=tk.StringVar();self.task_var=tk.StringVar()
        self.ff_var=tk.StringVar(value='前馈诊断：等待独立Z=8601；旧版固件没有此帧。')
        self.values={k:tk.StringVar(value='—') for k in ('balance','mode','position','command')}
        self.details={k:tk.StringVar() for k in self.values}
        body=ttk.Frame(root,padding=(10,8));body.pack(fill='both',expand=True)
        ttk.Label(body,text='J280 · 起摆、平衡、定位与轨迹统一监测',font=('Microsoft YaHei UI',16,'bold')).pack(anchor='w')
        ttk.Label(body,text=READ_ONLY_NOTICE,foreground='#975516').pack(anchor='w',pady=(2,4))
        bar=ttk.Frame(body);bar.pack(fill='x')
        ttk.Label(bar,text='串口').pack(side='left');self.port_box=ttk.Combobox(bar,textvariable=self.port_var,width=9);self.port_box.pack(side='left',padx=5)
        ttk.Button(bar,text='刷新',command=self.refresh_ports).pack(side='left')
        ttk.Label(bar,text='115200 · 8N1',foreground='#52667d').pack(side='left',padx=8)
        self.connect_button=ttk.Button(bar,text='连接监测',command=self.toggle_connection);self.connect_button.pack(side='left')
        self.auto_box=ttk.Checkbutton(bar,text='断线重连',variable=self.auto_var);self.auto_box.pack(side='left',padx=5)
        ttk.Label(bar,text='窗口').pack(side='left',padx=(8,0))
        ttk.Combobox(bar,textvariable=self.span_var,values=SPAN_OPTIONS,width=5,state='readonly').pack(side='left',padx=4)
        ttk.Label(bar,text='秒').pack(side='left')
        self.pause_button=ttk.Button(bar,text='暂停波形',command=self.toggle_pause);self.pause_button.pack(side='left',padx=7)
        self.replay_button=ttk.Button(bar,text='回放统一CSV',command=self.choose_replay);self.replay_button.pack(side='right')
        self.status_label=ttk.Label(body,textvariable=self.status_var);self.status_label.pack(anchor='w',pady=(3,0))
        ttk.Label(body,textvariable=self.stats_var,foreground='#64758a',font=('Microsoft YaHei UI',8)).pack(anchor='w')
        self.notebook=ttk.Notebook(body);self.notebook.pack(fill='both',expand=True,pady=(5,3))
        self.pages={}
        for key,title in [('overview','总览'),('swing','起摆与平衡'),('position','定位与轨迹'),('planner','规划加速度 / jerk'),('records','记录、参数与兼容')]:
            page=ttk.Frame(self.notebook,padding=8);self.notebook.add(page,text=title);self.pages[key]=page
        overview=self.pages['overview'];cards=ttk.Frame(overview);cards.pack(fill='x')
        for i,(key,title) in enumerate([('balance','摆杆流程'),('mode','选择 / 实际轨迹'),('position','实际 / 规划方位'),('command','内部电机命令')]):
            card=ttk.LabelFrame(cards,text=title,padding=(8,5));card.grid(row=0,column=i,sticky='nsew',padx=(0,5) if i<3 else 0)
            cards.columnconfigure(i,weight=1,uniform='cards')
            ttk.Label(card,textvariable=self.values[key],font=('Microsoft YaHei UI',15,'bold'),foreground='#1764a7',wraplength=270).pack(anchor='w')
            ttk.Label(card,textvariable=self.details[key],wraplength=270,font=('Microsoft YaHei UI',8)).pack(anchor='w')
        ttk.Label(overview,textvariable=self.overview_var,wraplength=1200,justify='left').pack(anchor='w',pady=9)
        ttk.Label(overview,textvariable=self.task_var,wraplength=1200,justify='left').pack(anchor='w')
        ttk.Label(overview,textvariable=self.sw4_var,wraplength=1200,foreground='#975516').pack(anchor='w',pady=7)
        ttk.Label(overview,textvariable=self.metric_var,wraplength=1200,foreground='#216a59',justify='left').pack(anchor='w')
        ttk.Label(overview,text='指标来自当前窗口最后一段有效X数据，属于自测统计，不是官方评分或“全程不倒”自动验收。\n失衡后重新起摆单独记录，不能算作原轨迹始终保持平衡。',wraplength=1200,foreground='#64758a').pack(anchor='w',pady=7)
        self.plots=[]
        swing=self.pages['swing'];ttk.Label(swing,textvariable=self.swing_var,wraplength=1200).pack(anchor='w',pady=(0,5))
        grid=ttk.Frame(swing);grid.pack(fill='both',expand=True)
        self._plot(grid,0,0,'摆杆ADC与直立／下垂参考','ADC计数，非角度',[('A','#176ec4',lambda f:f.angle_adc),('C直立','#d38a10',lambda f:f.center_adc),('DC下垂','#8390a0',lambda f:f.down_center_adc)])
        self._plot(grid,0,1,'摆杆相对直立偏差','A−C，ADC计数，非完整内环误差',[('A−C','#a44dbe',lambda f:f.angle_error_adc),('零线','#a0aab5',lambda f:0)])
        self._plot(grid,1,0,'摆杆角速度估计','PV÷256，ADC计数/ms；不是摆臂速度',[('摆杆PV','#16846c',lambda f:f.pole_velocity_adc_ms)])
        self._plot(grid,1,1,'控制器内部总命令','百分比；非实测PWM、电流或力矩',[('U','#a44dbe',lambda f:f.command_pct)])
        position=self.pages['position'];ttk.Label(position,textvariable=self.position_var,wraplength=1200,justify='left').pack(anchor='w',pady=(0,5))
        ttk.Label(position,textvariable=self.ff_var,wraplength=1200,justify='left',foreground='#52667d').pack(anchor='w',pady=(0,4))
        grid=ttk.Frame(position);grid.pack(fill='both',expand=True)
        self._plot(grid,0,0,'规划与实际水平摆臂方位','度；相对本段H，基准无效时留空',[('参考RF','#176ec4',lambda f:f.reference_degrees),('实际P','#16846c',lambda f:f.position_degrees),('端点/中心','#d38a10',lambda f:f.endpoint_degrees),('规划上包络','#df7d28',upper_envelope_degrees),('规划下包络','#df7d28',lower_envelope_degrees)],span=2)
        self._plot(grid,1,0,'规划与实际估算摆臂速度','度/s；等待板卡CF确认测速方法',[('规划V','#176ec4',lambda f:f.reference_speed_degrees),('估算W','#16846c',lambda f:f.actual_speed_degrees)],span=2)
        self.speed_plot=self.plots[-1]
        planner=self.pages['planner'];ttk.Label(planner,textvariable=self.planner_var,wraplength=1200,justify='left').pack(anchor='w',pady=(0,5))
        grid=ttk.Frame(planner);grid.pack(fill='both',expand=True)
        self._plot(grid,0,0,'规划加速度','度/s²；无有效规划值时不画',[('规划AC','#176ec4',lambda f:f.reference_acceleration_degrees)],span=2)
        self._plot(grid,1,0,'规划加加速度 jerk','度/s³；梯形拐点无有限jerk，不画0冒充实测',[('规划JK','#a44dbe',lambda f:f.reference_jerk_degrees)],span=2)
        records=self.pages['records'];actions=ttk.Frame(records);actions.pack(fill='x')
        ttk.Label(actions,text='本地备注').pack(side='left')
        ttk.Entry(actions,textvariable=self.note_var).pack(side='left',fill='x',expand=True,padx=6)
        ttk.Button(actions,text='保存备注 / 扰动标记',command=self.save_note).pack(side='left')
        ttk.Button(actions,text='打开记录文件夹',command=self.open_records).pack(side='left',padx=5)
        ttk.Label(records,text='备注按钮仅写本地事件CSV，绝不向板卡发送命令。旧A/M/O逐行独立展示，不与X拼成快照。',foreground='#975516',wraplength=1200).pack(anchor='w',pady=6)
        text=tk.Text(records,wrap='word',height=18,font=('Consolas',10));scroll=ttk.Scrollbar(records,orient='vertical',command=text.yview);text.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right',fill='y');text.pack(fill='both',expand=True);self.record_text=text
        ttk.Label(body,textvariable=self.record_var,foreground='#52667d',font=('Microsoft YaHei UI',8),wraplength=1200).pack(anchor='w')
        root.protocol('WM_DELETE_WINDOW',self.close)
        if mode=='live':self.refresh_ports()
        self.refresh_status();self.poll_after_id=root.after(50,self.poll_events);self.redraw_after_id=root.after(120,self.redraw)

    def _plot(self,parent,row,col,title,unit,series,span=1):
        for i in range(2):parent.columnconfigure(i,weight=1,uniform='plots');parent.rowconfigure(i,weight=1,uniform='plots')
        plot=Plot(parent,title,unit,series);plot.grid(row=row,column=col,columnspan=span,sticky='nsew',padx=(0,4) if span==1 and col==0 else 0,pady=(0,4) if row==0 else 0)
        plot.canvas.configure(height=165);plot.canvas.bind('<Configure>',lambda e:self.mark_dirty());self.plots.append(plot)
    def mark_dirty(self):self.dirty=True
    def elapsed(self,at=None):return max(0,(time.monotonic() if at is None else at)-self.session_start)
    def refresh_ports(self):
        try:
            from serial.tools import list_ports
            self.port_box['values']=[p.device for p in list_ports.comports()]
        except Exception as exc:self.last_status=f'串口列表读取失败：{exc}'
    def update_controls(self):
        self.connect_button.configure(text='断开监测' if self.wanted else '连接监测')
        self.port_box.configure(state='disabled' if self.wanted else 'normal');self.auto_box.configure(state='disabled' if self.wanted else 'normal')
        self.replay_button.configure(state='disabled' if self.wanted else 'normal')
    def finish_recording(self):
        current,self.recorder=self.recorder,None
        if current is not None:
            try:current.close();self.record_var.set('已保存：'+current.csv_path.name)
            except OSError as exc:self.record_var.set(f'关闭记录异常：{exc}')
    def event(self,kind,message,at=None):
        if self.recorder is not None:
            try:self.recorder.event(kind,message,self.elapsed(at))
            except OSError as exc:self.record_error(exc)
    def record_error(self,exc):self.finish_recording();self.record_var.set(f'记录异常，显示继续：{exc}')
    def toggle_connection(self):
        if self.wanted:
            self.wanted=self.connected=False
            if self.worker is not None:self.worker.disconnect()
            self.event('manual_disconnect','用户断开监测');self.finish_recording();self.last_status='已断开，保留历史数据';self.update_controls();self.refresh_status();return
        if not self.allow_worker:self.status_var.set('离线检查不能连接真实串口。');return
        port=self.port_var.get().strip()
        if not port:self.status_var.set('请选择串口。');return
        self.finish_recording();self.mode='live';self.history.clear();self.decoder=UnifiedStreamDecoder();self.legacy.clear();self.last_ff=None
        self.last_frame=self.last_received_at=None;self.valid=0;self.previous_counts=[0]*5;self.connection_segment=0
        self.session_start=time.monotonic();self.paused_at=None;self.last_error=''
        if self.worker is None:self.worker=SerialWorker(self.events);self.worker.start()
        try:self.recorder=UnifiedRecorder(ROOT/'records',port);self.record_var.set('自含X记录：'+self.recorder.csv_path.name)
        except OSError as exc:self.record_error(exc)
        self.connected=False;self.wanted=True;self.last_status=f'正在连接{port}'
        self.worker.connect(port,self.auto_var.get());self.update_controls();self.mark_dirty()

    def process_frame(self,f,elapsed,record=True):
        continuity=self.history.append(f,elapsed,self.connection_segment);self.last_frame=f;self.valid+=1
        self.speed_plot.unit=speed_description(f.trajectory_config_tag)
        self.values['balance'].set(label(BALANCE_LABELS,f.balance_mode))
        self.details['balance'].set(f'M={f.balance_mode:X}，F={f.fault:X}：{label(FAULT_LABELS,f.fault)}；标定{"是" if f.calibrated else "否"}')
        selected=selected_mode_label(f);active=active_profile_label(f)
        self.values['mode'].set(f'{f.selected_dip_mode:02b} / {active}')
        self.details['mode'].set('所选：'+selected+('；正在停止旧轨迹／等待接管' if f.switch_pending else '；参考归属：'+('轨迹' if f.reference_owner==1 else '位置')))
        self.values['position'].set(f'{deg(f.position_degrees)} / {deg(f.reference_degrees)}')
        self.details['position'].set(f'H={f.active_base_units}；PID实际目标Y={f.pid_target_units}；408工程单位/转')
        self.values['command'].set(f'{f.command_pct:+d}%')
        self.details['command'].set(f'限幅{f.duty_limit_pct}%；驱动逻辑使能{"是" if f.flag(4) else "否"}；非实测PWM')
        self.overview_var.set(f'自动起摆：{label(BALANCE_LABELS,f.balance_mode)}，补能脉冲{f.swing_pulse_count}次，峰值幅度{f.peak_amplitude_adc}ADC。\n'
            f'直立与抗扰：A−C={f.angle_error_adc:+d}ADC，摆杆速度={f.pole_velocity_adc_ms:+.3f}ADC/ms；当前M={f.balance_mode:X}，不能仅凭一帧判定抗扰合格。\n'
            f'位置控制：{label(POSITION_LABELS,f.position_task_state)}，任务ID={f.position_task_id}，中断={bool(f.position_interrupted)}。\n'
            f'轨迹运动：{active}，{label(TRAJECTORY_LABELS,f.trajectory_state)}，阶段={f.trajectory_phase}，完整周期={f.trajectory_cycle_count}。\n'
            f'运动中直立：持续观察偏差与M；失衡恢复或中断不能记为“全过程不倒”。')
        self.task_var.set(f'所选 {selected}；实际轨迹 {active}；运行={f.flag(5)}，停止请求={f.flag(6)}，轨迹中断={f.flag(7)}。')
        if f.has_runtime:
            edit_semantic,active_semantic=trajectory_semantics(f)
            self.task_var.set(self.task_var.get()+f' 下次TE={f.selected_trajectory_edit_deci/10:+.1f}°（{edit_semantic}）；接受TA={f.accepted_trajectory_deci/10:+.1f}°（{active_semantic}），运行ID={f.trajectory_run_id}。')
        self.sw4_var.set(mod_stop_meaning(f) or sw4_meaning(f))
        self.swing_var.set(f'A={f.angle_adc}，直立C={f.center_adc}，下垂DC={f.down_center_adc}ADC；脉冲PC={f.swing_pulse_count}，峰值PK={f.peak_amplitude_adc}ADC。\n'
            f'自动参考={f.flag(1)}，角度运动数据可信={f.flag(2)}，传感器OK={f.flag(13)}；编码器无效跳变历史={f.flag(12)}。')
        runtime=trajectory_summary(f)
        self.position_var.set(f'定位增量E={f.edit_deci/10:+.1f}°，当前确认G={f.confirmed_deci/10:+.1f}°；{label(POSITION_LABELS,f.position_task_state)}；规划时长={f.position_duration_ms/1000:.3f}s。\n'
            +runtime+('\n'+modulation_summary(f) if modulation_summary(f) else '')+'\n00每次确认锁实际位置；轨迹基准H运行中固定。'+speed_summary(f.trajectory_config_tag)+'SW2/SW3编辑下次角度，SW4停止后再启动才执行。')
        self.planner_var.set(f'当前实际轨迹：{active}。加速度有效={f.flag(9)}，jerk数值有效={f.flag(8)}。\n'
            '以下是轨迹规划量，非机械实测。v8.4圆角梯形和七段S均限制jerk、保持加速度连续；旧配置仍按上传的有效标志显示。')
        if is_modulated_tag(f.trajectory_config_tag) and f.active_trajectory_profile in (1,2,3):
            self.planner_var.set(f'当前实际轨迹：{active}。加速度有效={f.flag(9)}，jerk有效={f.flag(8)}。\n参考及解析导数由板卡规划；包络由CF/EL/TA派生，非实测。11为心形的配置使用内建平滑首尾；旧标签仍按原正弦显示。')
        self.parameter_var.set(f'固件快照参数：\nANGLE KP/KI/KD = {f.angle_kp_100}/{f.angle_ki_100}/{f.angle_kd_100}（原整数缩放参数）\n'
            f'LOCATION KP/KD = {f.location_kp_10}/{f.location_kd_10}\n'
            f'位置时长 PM/PD = {f.position_min_move_ms}/{f.position_ms_per_degree} ms\n'
            f'轨迹配置标签 CF=0x{f.trajectory_config_tag:08X}，DUTY_LIMIT={f.duty_limit_pct}%\n'
            f'板卡运行T={f.uptime_ms}ms，快照Q={f.snapshot_sequence}\n'
            '这些参数来自板卡X快照，不由监测软件猜测；未遥测P/I/D分项。')
        self.parameter_var.set(self.parameter_var.get()+f'\n协议版本 X={f.version:04X}\n'+derivative_filter_status(f)+'\n'+runtime)
        self.raw_var.set('原始X：'+f.raw)
        if record and self.recorder is not None:
            try:
                self.recorder.append(f,elapsed,self.connection_segment,continuity)
                if continuity.reason:self.recorder.event('segment',continuity.reason,elapsed)
            except OSError as exc:self.record_error(exc)
        self.mark_dirty();return continuity

    def process_packet(self,p,at):
        if p.kind=='X':self.last_received_at=at;self.process_frame(p.frame,self.elapsed(at))
        elif p.kind=='Z':self.process_diagnostic(p.frame,self.elapsed(at),at)
        else:self.legacy[p.kind]=(p.frame,at)
    def process_diagnostic(self,f,elapsed,at=None,record=True):
        self.last_ff=(f,time.monotonic() if at is None else at,self.connection_segment)
        if record and self.recorder is not None:
            try:self.recorder.append_diagnostic(f,elapsed,self.connection_segment)
            except OSError as exc:self.record_error(exc)
        self.refresh_diagnostic();self.mark_dirty()
    def refresh_diagnostic(self):
        if self.last_ff is None:
            self.ff_var.set('前馈诊断：未收到独立Z=8601；不能据此判断前馈已启用。')
            return
        d,at,segment=self.last_ff
        fresh=self.mode=='live' and self.connected and time.monotonic()-at<1.2 and segment==self.connection_segment
        paired=self.last_frame is not None and d.matches(self.last_frame) and segment==self.connection_segment
        age='实时' if fresh else '历史／离线'
        pair='与当前X同一发送快照' if paired else '独立快照，当前未与X配对'
        self.ff_var.set(f'Z8601 [{age}；{pair}；Q={d.snapshot_sequence}] '+diagnostic_summary(d))
    def poll_events(self):
        if self.closing:return
        for _ in range(250):
            try:e=self.events.get_nowait()
            except queue.Empty:break
            if e.kind=='connected' and self.wanted:
                self.connected=True;self.connection_segment+=1;self.last_error='';self.last_received_at=None
                d=self.decoder;self.previous_counts=[a+b for a,b in zip(self.previous_counts,(d.received_bytes,d.invalid_x,d.invalid_legacy,d.legacy_count,d.unsupported_o))]
                self.decoder=UnifiedStreamDecoder();self.last_status='串口打开，等待完整X=8002/8001';self.event('connected',str(e.value),e.at)
            elif e.kind=='error' and self.wanted:
                self.connected=False;self.last_error=e.value['message'];self.last_status='等待重连' if e.value['retry'] else '连接失败'
                self.event('serial_error',self.last_error,e.at)
                if not e.value['retry']:self.wanted=False;self.finish_recording();self.update_controls()
            elif e.kind=='disconnected':self.connected=False
            elif e.kind=='data' and self.wanted:
                for packet in self.decoder.feed(e.value):self.process_packet(packet,e.at)
        self.refresh_status();self.poll_after_id=self.root.after(50,self.poll_events)

    def refresh_status(self):
        now=time.monotonic();age=None if self.last_received_at is None else now-self.last_received_at
        text,fresh=unified_status(self.last_frame,age,self.connected,self.mode)
        if self.mode=='live' and not self.connected:text+=' '+self.last_status+(f'：{self.last_error}' if self.last_error else '')
        if self.paused_at is not None:text+=' 波形已暂停；接收和记录继续。'
        self.status_var.set(text);self.status_label.configure(foreground='#14734f' if fresh else '#a13b39')
        d=self.decoder;n=[a+b for a,b in zip(self.previous_counts,(d.received_bytes,d.invalid_x,d.invalid_legacy,d.legacy_count,d.unsupported_o))]
        self.stats_var.set(f'有效X {self.valid} · 字节{n[0]} · 坏X{n[1]} · 旧A/M/O{n[3]} · 坏旧帧{n[2]} · 不兼容旧O{n[4]} · 累计丢号{self.history.lost_snapshots} · 连接段{self.connection_segment} · Z诊断{d.diagnostic_count} / 坏Z{d.invalid_diagnostic}')
        self.refresh_diagnostic()
        legacy=[]
        for kind in ('A','M','O'):
            if kind not in self.legacy:legacy.append(f'{kind}：未收到');continue
            f,at=self.legacy[kind];state='新鲜' if self.mode=='live' and self.connected and now-at<1.2 else '历史/离线'
            if kind=='A':desc=f'A={f.angle} C={f.center} P={f.position} T={f.target} U={f.command:+d}% R={f.running} K={f.calibrated} F={f.fault}'
            elif kind=='M':desc=f'M={f.mode:X}，摆杆速度={f.velocity_adc_per_ms:+.3f} ADC/ms，脉冲={f.pulse_count}，参考={f.reference_ready}，motion={f.motion_valid}'
            else:desc=f'O5103 E={f.edit_deci/10:+.1f}° G={f.confirmed_deci/10:+.1f}° 实际={deg(f.position_degrees)} 规划={deg(f.reference_degrees)} S={f.task_state:X}'
            legacy.append(f'{kind} [{state}，距今{max(0,now-at):.2f}s] {desc}')
        self.legacy_var.set('独立兼容接收（不刷新X、不补齐统一字段）：\n'+'\n'.join(legacy))
        self._refresh_record_text()
    def _refresh_record_text(self):
        content=self.parameter_var.get()+'\n\n'+self.ff_var.get()+'\n\n'+self.legacy_var.get()+'\n\n'+self.raw_var.get()
        if getattr(self,'_record_content',None)==content:return
        self._record_content=content;self.record_text.configure(state='normal');self.record_text.delete('1.0','end');self.record_text.insert('1.0',content);self.record_text.configure(state='disabled')
    def redraw(self):
        if self.closing:return
        key=(self.dirty,self.span_var.get(),self.paused_at)
        if self.dirty or getattr(self,'_last_draw_key',None)!=key:
            right=self.paused_at if self.paused_at is not None else (self.history.samples[-1].t if self.history.samples else 0)
            span=window_seconds(self.span_var.get());points=self.history.window(right,span)
            for p in self.plots:p.draw(points,right,span,self.paused_at is not None)
            m=self.history.metrics(right,span)
            if m:
                rmse='—' if m['position_rmse_degrees'] is None else f"{m['position_rmse_degrees']:.3f}°"
                self.metric_var.set(f"窗口最后一连续段（{'历史/离线' if self.mode!='live' or not self.connected else '需结合通信新鲜度'}）：{m['samples']}点，位置跟踪RMSE={rmse}，摆杆最大|A−C|={m['pole_peak_adc']}ADC，内部|U|峰值={m['command_peak_pct']}%。")
            else:self.metric_var.set('窗口统计：等待完整X快照。')
            self.dirty=False;self._last_draw_key=(False,self.span_var.get(),self.paused_at)
        self.redraw_after_id=self.root.after(120,self.redraw)
    def toggle_pause(self):
        self.paused_at=(self.history.samples[-1].t if self.history.samples else 0) if self.paused_at is None else None
        self.pause_button.configure(text='继续波形' if self.paused_at is not None else '暂停波形');self.mark_dirty()
    def save_note(self):
        note=self.note_var.get().strip()
        if not note:self.record_var.set('请输入本地备注；按钮不会发送命令。');return
        if self.recorder is None:self.record_var.set('当前没有正在录制的CSV，备注未保存。');return
        self.event('user_note',note);self.record_var.set('本地备注已保存：'+note)
    def open_records(self):
        folder=ROOT/'records';folder.mkdir(exist_ok=True)
        try:os.startfile(str(folder))
        except OSError as exc:self.record_var.set(f'打开记录失败：{exc}')
    def choose_replay(self):
        if self.wanted:return
        p=filedialog.askopenfilename(title='回放统一X快照CSV',filetypes=[('Unified CSV','*_unified.csv'),('CSV','*.csv')],initialdir=str(ROOT/'records'))
        if p:
            try:self.load_replay(p)
            except (OSError,ValueError,KeyError) as exc:self.status_var.set(f'回放失败：{exc}')
    def load_replay(self,path):
        frames=[]
        with Path(path).open(encoding='utf-8-sig',newline='') as stream:
            for row in csv.DictReader(stream):
                t=float(row['elapsed_s'])
                if not math.isfinite(t) or t<0:raise ValueError('CSV时间无效')
                frames.append((decode_unified(row['raw_line']),t,int(row.get('connection_segment') or 0)))
        if not frames:raise ValueError('CSV没有有效X=8002/8001快照')
        self.finish_recording();self.mode='replay';self.history.clear();self.valid=0;self.paused_at=None;self.legacy.clear();self.last_ff=None
        self.last_received_at=None
        for f,t,segment in frames:self.connection_segment=segment;self.process_frame(f,t,record=False)
        diagnostic_path=Path(path).with_name(Path(path).name.replace('_unified.csv','_feedforward.csv'))
        if diagnostic_path!=Path(path) and diagnostic_path.exists():
            with diagnostic_path.open(encoding='utf-8-sig',newline='') as stream:
                for row in csv.DictReader(stream):
                    if int(row.get('connection_segment') or 0)!=self.connection_segment:continue
                    t=float(row['elapsed_s'])
                    if math.isfinite(t) and t<=frames[-1][1]+.2:
                        self.process_diagnostic(decode_feedforward(row['raw_line']),t,record=False)
        self.record_var.set('离线回放：'+Path(path).name+'；不修改原记录，不代表当前板卡。');self.refresh_status();self.mark_dirty()
    def close(self):
        if self.closing:return
        self.closing=True
        if self.worker is not None:self.worker.shutdown();self.worker.join(timeout=.5)
        self.finish_recording()
        for token in (getattr(self,'poll_after_id',None),getattr(self,'redraw_after_id',None)):
            if token is not None:
                try:self.root.after_cancel(token)
                except tk.TclError:pass
        self.root.update_idletasks();self.root.destroy()

def demo_line(index=0,**overrides):
    defaults={'T':index*100,'Q':index,'D':2,'O':1,'M':5,'K':1,'R':1,'A':2955+round(4*math.sin(index)),
              'C':2955,'P':100+round(20*math.sin(index/20)),'RF':100+round(20*math.sin(index/20+.03)),
              'Y':100,'H':100,'EP':134,'V':256,'W':240,'U':3,'B':100,'S':6,'J':2,'N':2,'CY':index//110,
              'EL':index*100,'PH':3,'AC':512,'JK':128,'FL':0x233f,'PV':32,'PC':5,'DC':859,'PK':100,
              'CL':11000,'CF':0x12345678,'AP':40,'AI':1,'AD':400,'LP':7,'LD':70,'PM':300,'PD':15,
              'TE':300,'TA':300,'TZ':2,'TI':1,'TM':1,'EA':300,'EB':300,'EC':100}
    defaults.update(overrides)
    return 'X=8002'+''.join(f' {key}={defaults.get(key,0)&((1<<(width*4))-1):0{width}X}' for key,width,_,_ in FIELDS)

def main():
    p=argparse.ArgumentParser();p.add_argument('--ui-check',action='store_true');p.add_argument('--demo',action='store_true');p.add_argument('--replay',type=Path)
    args=p.parse_args();mode='demo' if args.ui_check or args.demo else 'replay' if args.replay else 'live'
    root=tk.Tk();app=UnifiedMonitor(root,mode=mode,create_worker=mode=='live')
    if mode=='demo':
        for i in range(301):app.process_frame(decode_unified(demo_line(i)),i/10,record=False)
        app.connect_button.configure(state='disabled');app.replay_button.configure(state='disabled');app.refresh_status()
    elif args.replay:app.load_replay(args.replay)
    if args.ui_check:
        assert app.worker is None and app.recorder is None and len(app.history.samples)==301
        assert len(app.notebook.tabs())==5 and len(app.plots)==8
        for size in ('1280x680','1366x768'):
            root.geometry(size);root.update();app.mark_dirty();app.redraw()
            for page in app.pages.values():
                app.notebook.select(page);root.update();app.mark_dirty();app.redraw()
                assert page.winfo_width()>900 and page.winfo_height()>400
            for control in (app.connect_button,app.pause_button,app.replay_button,app.port_box,app.notebook):
                assert control.winfo_ismapped()
                x=control.winfo_rootx()-root.winfo_rootx();y=control.winfo_rooty()-root.winfo_rooty()
                assert 0<=x and x+control.winfo_width()<=root.winfo_width()
                assert 0<=y and y+control.winfo_height()<=root.winfo_height()
        assert all(plot.canvas.find_all() for plot in app.plots)
        print('PASS: five tabs, eight plots, 1280x680 and 1366x768 layout, atomic X data; no serial port opened')
        app.close();return 0
    root.mainloop();return 0

if __name__=='__main__':raise SystemExit(main())

"""Offline protocol/GUI/CSV checks; fake events only, no real serial ports."""
import csv
import json
import math
from pathlib import Path
import queue
import tempfile
import time
import tkinter as tk
import unittest
from unittest.mock import patch
from unified_protocol import *
from unified_monitor import UnifiedMonitor,demo_line
from wave_monitor import LinkEvent,SerialWorker

ROOT=Path(__file__).resolve().parent
A=b'A=0B8B C=0B8B P=00000064 T=00000064 U=03 R=1 K=1 F=0\r\n'
M=b'M=5 W=00000100 N=03 Q=1 Z=1\r\n'
O=(b'O=5103 D=0 S=1 E=00000000 G=00001C20 H=00000064 R=00000064 '
   b'P=00000064 V=00000000 W=00000000 K=1 A=1 I=0001 Z=0 M=5 U=00 '
   b'B=0B8B C=0B8B T=00000064 Q=00000001 L=0000000000001388\r\n')

def wire(**updates):
    # Independent literal contract; not built from the parser's FIELDS regex.
    line=('X=8001 T=000003E8 Q=0000000A D=0 O=0 M=5 F=0 K=1 R=1 '
          'A=0B8D C=0B8B P=0000006D Y=0000006D RF=0000006D H=00000064 EP=0000006D '
          'V=00000100 W=FFFFFF00 U=FD B=64 E=00001C20 G=00001C20 S=1 I=FFFF Z=0 '
          'L=0000000100000001 J=0 N=1 CY=00000000 EL=00000000 PH=0000 '
          'AC=00000200 JK=00000300 FL=240F PV=FFFFFF80 PC=03 DC=035B PK=0010 '
          'CL=00000000 CF=12345678 AP=00000028 AI=00000001 AD=00000037 LP=00000007 '
          'LD=00000028 PM=0000012C PD=0000000F')
    parts=line.split(' ');out=[]
    for part in parts:
        key,raw=part.split('=')
        if key in updates:
            width=len(raw);raw=f'{updates[key]&((1<<(width*4))-1):0{width}X}'
        out.append(key+'='+raw)
    return (' '.join(out)+'\r\n').encode('ascii')

class UnifiedProtocolTests(unittest.TestCase):
    def test_independent_rtl_uart_transmit_fixture(self):
        # Produced by UART TX bit-center sampling in the RTL testbench, not by
        # wire(), demo_line(), the host decoder, or a host-side encoder.
        payload=(ROOT/'fixtures/unified_uart_v8001.txt').read_bytes()
        self.assertEqual(len(payload),427);self.assertTrue(payload.endswith(b'\r\n'))
        f=decode_unified(payload)
        expected={
            'uptime_ms':0x10203040,'snapshot_sequence':5,'selected_dip_mode':0,
            'reference_owner':1,'balance_mode':5,'fault':0,'calibrated':1,'system_active':1,
            'angle_adc':2955,'center_adc':2955,'actual_position_units':1000,
            'pid_target_units':1816,'planner_reference_units':1010,'active_base_units':1000,
            'trajectory_endpoint_units':1816,'reference_velocity_q8':256,'actual_velocity_q8':512,
            'command_pct':25,'duty_limit_pct':100,'edit_deci':7200,'confirmed_deci':40000,
            'position_task_state':2,'position_task_id':6,'position_interrupted':0,
            'position_duration_ms':0x0123456789ABCDEF,'active_trajectory_profile':2,
            'trajectory_state':2,'trajectory_cycle_count':12,'trajectory_elapsed_ms':100000,
            'trajectory_phase':7,'reference_acceleration_q8':512,'reference_jerk_q8':768,
            'flags':0x3fff,'pole_velocity_q8':257,'swing_pulse_count':12,'down_center_adc':859,
            'peak_amplitude_adc':4095,'trajectory_cycle_ms':11000,
            'trajectory_config_tag':0x10203040,'angle_kp_100':40,'angle_ki_100':1,
            'angle_kd_100':55,'location_kp_10':4,'location_kd_10':40,
            'position_min_move_ms':300,'position_ms_per_degree':15,
        }
        self.assertEqual(dict(f.values),expected)
        d=UnifiedStreamDecoder();packets=[]
        for byte in payload:packets.extend(d.feed(bytes([byte])))
        self.assertEqual([p.kind for p in packets],['X'])
        self.assertEqual(dict(packets[0].frame.values),expected)
        self.assertAlmostEqual(f.position_degrees,0)
        self.assertAlmostEqual(f.endpoint_degrees,720)
        self.assertTrue(f.switch_pending)
    def test_contract_matches_fixed_spec_and_lengths(self):
        d=json.loads((ROOT.parent/'config/unified_protocol.json').read_text(encoding='utf-8'))
        self.assertEqual([(f['key'],f['hex_width'],f['name'],f['signed']) for f in d['fields']],FIELDS)
        self.assertEqual((d['line_without_crlf'],d['line_with_crlf']),(510,512))
        self.assertEqual(len(wire()),427);self.assertEqual(len(A+M+O+wire()),686)
    def test_signed_fields_and_all_raw_parameters(self):
        f=decode_unified(wire())
        self.assertEqual((f.command_pct,f.actual_velocity_q8,f.pole_velocity_q8),(-3,-256,-128))
        self.assertEqual((f.angle_kp_100,f.angle_ki_100,f.angle_kd_100,f.location_kp_10,f.location_kd_10),(40,1,55,7,40))
        self.assertEqual((f.position_min_move_ms,f.position_ms_per_degree,f.position_duration_ms),(300,15,4294967297))
        self.assertEqual((f.position_task_id,f.trajectory_config_tag),(65535,0x12345678))
        with self.assertRaises(TypeError):f.values['command_pct']=10
    def test_signed32_extrema_and_unsigned64_duration(self):
        f=decode_unified(wire(P=-2147483648,Y=2147483647,RF=-2147483648,H=0,V=-2147483648,W=2147483647,
                             E=-2147483648,G=2147483647,AC=-2147483648,JK=2147483647,L=0xffffffffffffffff))
        self.assertEqual(f.edit_deci,-2147483648);self.assertEqual(f.confirmed_deci,2147483647)
        self.assertEqual(f.position_duration_ms,0xffffffffffffffff);self.assertEqual(f.actual_position_units,-2147483648)
        self.assertEqual(f.reference_acceleration_q8,-2147483648)
    def test_multiturn_is_never_modulo360(self):
        f=decode_unified(wire(G=7200,P=916,RF=916,H=100))
        self.assertEqual(f.endpoint_degrees,720);self.assertEqual(f.position_degrees,720)
        f=decode_unified(wire(G=-36000,P=-3980,RF=-3980,H=100))
        self.assertEqual(f.endpoint_degrees,-3600);self.assertEqual(f.position_degrees,-3600)
    def test_relative_target_is_clamped_at_numeric_boundary(self):
        f=decode_unified(wire(H=2147483640,G=2147483647))
        self.assertEqual(f.endpoint_units,2147483647);self.assertAlmostEqual(f.endpoint_degrees,7*360/408)
    def test_trajectory_endpoint_uses_ep_and_reference_uses_rf_not_pid_y(self):
        f=decode_unified(wire(O=1,J=2,D=2,H=100,EP=134,P=110,RF=111,Y=112))
        self.assertEqual(f.endpoint_units,134);self.assertAlmostEqual(f.reference_degrees,11*360/408)
        self.assertNotEqual(f.reference_degrees,(f.pid_target_units-f.active_base_units)*360/408)
    def test_no_base_produces_missing_angles_not_zero(self):
        f=decode_unified(wire(FL=0))
        self.assertIsNone(f.reference_degrees);self.assertIsNone(f.position_degrees);self.assertIsNone(f.endpoint_degrees)
        self.assertIsNone(f.tracking_error_degrees)
    def test_acceleration_jerk_validity_masks_position_and_trapezoid(self):
        f=decode_unified(wire())
        self.assertIsNone(f.reference_acceleration_degrees);self.assertIsNone(f.reference_jerk_degrees)
        f=decode_unified(wire(O=1,J=1,D=1,FL=0x220f))
        self.assertIsNotNone(f.reference_acceleration_degrees);self.assertIsNone(f.reference_jerk_degrees)
        f=decode_unified(wire(O=1,J=2,D=2,FL=0x230f))
        self.assertAlmostEqual(f.reference_jerk_degrees,3*360/408)
    def test_speeds_are_different_physical_quantities(self):
        f=decode_unified(wire())
        self.assertAlmostEqual(f.actual_speed_degrees,-360/408)
        self.assertEqual(f.pole_velocity_adc_ms,-.5)
    def test_malformed_scale_and_wrong_version_rejected(self):
        for data in (wire(A=4096),wire(DC=4096),wire(PK=8192),wire(U=101),wire(B=101),wire(K=2),wire(R=2),wire(Z=2),wire().replace(b'X=8001',b'X=8002'),b'bad'):
            with self.subTest(data=data[:40]):
                with self.assertRaises(ValueError):decode_unified(data)
        with self.assertRaises(ValueError):decode_unified(b'\xff')
        with self.assertRaises(ValueError):decode_unified(None)
    def test_unknown_states_are_accepted_and_labeled(self):
        f=decode_unified(wire(M=15,S=15,N=15,F=15))
        self.assertIn('未知',label(BALANCE_LABELS,f.balance_mode));self.assertIn('未知',label(TRAJECTORY_LABELS,f.trajectory_state))
    def test_stream_any_byte_split_keeps_atomic_x_and_legacy(self):
        stream=b'noise'+A+M+O+wire()+wire(Q=11,P=999,RF=-222)
        for step in (1,2,7,31,64,1000):
            d=UnifiedStreamDecoder();packets=[]
            for i in range(0,len(stream),step):packets.extend(d.feed(stream[i:i+step]))
            self.assertEqual([p.kind for p in packets],['A','M','O','X','X'])
            self.assertEqual([p.frame.actual_position_units for p in packets if p.kind=='X'],[109,999])
            self.assertEqual(d.invalid_x,0);self.assertEqual(d.invalid_legacy,0)
    def test_internal_a_m_o_fields_never_resynchronize_valid_x(self):
        d=UnifiedStreamDecoder();out=d.feed(wire())
        self.assertEqual(len(out),1);self.assertEqual(out[0].kind,'X');self.assertEqual(d.legacy_count,0)
        self.assertEqual(out[0].frame.angle_adc,2957)
    def test_truncated_corrupt_x_recovery_does_not_forge_legacy(self):
        d=UnifiedStreamDecoder();out=d.feed(b'X=8001 T=oops\r\n'+wire())
        self.assertEqual([p.kind for p in out],['X']);self.assertEqual(d.invalid_x,1)
        d=UnifiedStreamDecoder();bad=wire().replace(b' FL=240F',b' FL=oops')
        out=d.feed(bad+wire(Q=20));self.assertEqual([p.kind for p in out],['X'])
        self.assertEqual(out[0].frame.snapshot_sequence,20);self.assertEqual(d.legacy_count,0)
    def test_missing_newline_recovery_and_bounded_noise(self):
        d=UnifiedStreamDecoder();out=d.feed(b'X=8001 T=0000 '+wire())
        self.assertEqual(len(out),1);self.assertEqual(out[0].frame.snapshot_sequence,10)
        d.feed(b'z'*100000);self.assertLessEqual(len(d.buffer),d.MAX_BUFFER)
        with self.assertRaises(TypeError):d.feed('text')
    def test_legacy_only_never_creates_x(self):
        d=UnifiedStreamDecoder();packets=d.feed(A+M+O)
        self.assertEqual([p.kind for p in packets],['A','M','O']);self.assertEqual(d.invalid_x,0)
    def test_sw4_context_respects_selected_vs_active_and_stopping(self):
        self.assertIn('本次旋转',sw4_meaning(decode_unified(wire(S=3))))
        self.assertIn('忽略',sw4_meaning(decode_unified(wire(S=2))))
        self.assertIn('启动所选',sw4_meaning(decode_unified(wire(O=1,D=2,J=0,N=1))))
        self.assertIn('请求平滑停止',sw4_meaning(decode_unified(wire(O=1,D=2,J=2,N=2,FL=0x242f))))
        self.assertIn('停止请求已接受',sw4_meaning(decode_unified(wire(O=1,D=2,J=1,N=4,FL=0x246f))))
        self.assertIn('等待轨迹停止',sw4_meaning(decode_unified(wire(O=1,D=0,J=1))))
        self.assertIn('停机标定',sw4_meaning(decode_unified(wire(M=1))))
    def test_unified_freshness_is_independent_of_legacy(self):
        f=decode_unified(wire())
        self.assertTrue(unified_status(f,.1,True)[1])
        for age,connected in ((2,True),(None,True),(.1,False)):
            self.assertFalse(unified_status(f,age,connected)[1])
        self.assertFalse(unified_status(f,.1,True,'replay')[1]);self.assertFalse(unified_status(None,None,True)[1])

class UnifiedHistoryTests(unittest.TestCase):
    def test_seq_gaps_reconnect_and_regression_segments(self):
        h=UnifiedHistory();h.append(decode_unified(wire()),1,1)
        c=h.append(decode_unified(wire(Q=13,T=1300)),1.3,1)
        self.assertEqual(c.seq_gap,2);self.assertEqual(h.lost_snapshots,2)
        c=h.append(decode_unified(wire(Q=0,T=0)),1.4,1);self.assertIn('回退',c.reason)
        c=h.append(decode_unified(wire(Q=20,T=2000)),2,2);self.assertEqual(c.seq_gap,0);self.assertIn('连接段',c.reason)
    def test_same_base_new_task_and_counter_wrap_not_encoder_reset(self):
        h=UnifiedHistory();h.append(decode_unified(wire(I=65535)),1,1)
        c=h.append(decode_unified(wire(I=0,Q=11,T=1100)),1.1,1)
        self.assertIn('任务ID变化',c.reason);self.assertIn('非编码器复位',c.reason)
    def test_owner_profile_and_running_boundaries_segment(self):
        h=UnifiedHistory();h.append(decode_unified(wire()),1,1)
        c=h.append(decode_unified(wire(O=1,J=1,Q=11,T=1100,FL=0x242f)),1.1,1)
        self.assertIn('实际轨迹变化',c.reason);self.assertIn('运行边界',c.reason)
        c=h.append(decode_unified(wire(O=1,J=1,Q=12,T=1200,FL=0x242f,EL=100)),1.2,1)
        self.assertEqual(c.reason,'')
    def test_base_change_and_loss_do_not_connect_curves(self):
        h=UnifiedHistory();h.append(decode_unified(wire()),1,1)
        c=h.append(decode_unified(wire(H=300,Q=11,T=1100)),1.1,1);self.assertIn('基准',c.reason)
        c=h.append(decode_unified(wire(FL=0,M=6,Q=12,T=1200)),1.2,1);self.assertIn('基准',c.reason)
        self.assertIsNone(h.samples[-1].frame.position_degrees)
    def test_metrics_only_latest_epoch_and_valid_base(self):
        h=UnifiedHistory();h.append(decode_unified(wire(P=110,RF=109)),1,1)
        h.append(decode_unified(wire(P=111,RF=109,Q=11,T=1100)),1.1,1)
        m=h.metrics(1.1,30);self.assertEqual(m['samples'],2)
        self.assertAlmostEqual(m['position_rmse_degrees'],math.sqrt(2.5)*360/408)
        h.append(decode_unified(wire(P=999,H=300,I=0,Q=12,T=1200)),1.2,1)
        self.assertEqual(h.metrics(1.2,30)['samples'],1)
        h.append(decode_unified(wire(FL=0,M=6,Q=13,T=1300)),1.3,1)
        self.assertIsNone(h.metrics(1.3,30)['position_rmse_degrees'])
    def test_csv_full_atomic_fields_derived_and_missing_values(self):
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            recorder=UnifiedRecorder(folder,'TEST');h=UnifiedHistory()
            for i,f in enumerate((decode_unified(wire(FL=0,M=3)),decode_unified(wire(Q=13,T=1300,O=1,J=2,D=2,FL=0x230f)))):
                recorder.append(f,1+i/10,1,h.append(f,1+i/10,1))
            recorder.event('user_note','扰动标记，仅本地',1.2);recorder.close();recorder.close()
            with recorder.csv_path.open(encoding='utf-8-sig',newline='') as stream:rows=list(csv.DictReader(stream))
            self.assertEqual(tuple(rows[0]),UNIFIED_COLUMNS);self.assertEqual(rows[0]['position_degrees'],'')
            self.assertEqual(rows[0]['reference_jerk_degrees'],'');self.assertEqual(rows[1]['seq_gap'],'2')
            self.assertEqual(rows[1]['raw_line'],f.raw);self.assertEqual(rows[1]['position_duration_ms'],'4294967297')
            self.assertEqual(rows[1]['trajectory_config_tag'],'305419896');self.assertIn('T',rows[1]['host_time'])
            self.assertTrue(recorder.csv_path.name.endswith('_unified.csv'))
            with self.assertRaises(OSError):recorder.event('x','x',1)
            with self.assertRaises(OSError):recorder.append(f,2,1,h.append(f,2,1))
            self.assertIn('扰动标记',recorder.event_path.read_text(encoding='utf-8-sig'))

class UnifiedGuiTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw();self.app=UnifiedMonitor(self.root,mode='replay',create_worker=False)
    def tearDown(self):self.app.close()
    def test_five_tabs_eight_plots_and_no_control_sender(self):
        a=self.app;self.assertEqual(len(a.notebook.tabs()),5);self.assertEqual(len(a.plots),8);self.assertIsNone(a.worker)
        a.toggle_connection();self.assertIn('不能连接真实串口',a.status_var.get());self.assertIsNone(a.worker)
    def test_all_six_requirement_domains_have_snapshot_status(self):
        a=self.app;a.process_frame(decode_unified(wire()),1,record=False)
        for word in ('自动起摆','直立与抗扰','位置控制','轨迹运动','运动中直立'):self.assertIn(word,a.overview_var.get())
        self.assertIn('720.0',a.position_var.get());self.assertIn('40/1/55',a.parameter_var.get())
        self.assertIn('300/15',a.parameter_var.get());self.assertIn('非实测',a.details['command'].get())
    def test_selected_mode_not_claimed_active_before_handoff(self):
        a=self.app;a.process_frame(decode_unified(wire(D=2,O=1,J=1,N=4,FL=0x246f)),1,record=False)
        self.assertIn('梯形',a.values['mode'].get());self.assertIn('七段S',a.details['mode'].get())
        self.assertIn('停止旧轨迹',a.details['mode'].get());self.assertIn('已接受',a.sw4_var.get())
    def test_loss_and_recovery_never_label_trajectory_as_success(self):
        a=self.app;a.process_frame(decode_unified(wire(M=6,O=1,J=2,N=5,FL=0x2487,Z=1)),1,record=False)
        self.assertIn('失衡恢复',a.values['balance'].get());self.assertIn('中断',a.overview_var.get())
        self.assertIn('旧轨迹',a.sw4_var.get());self.assertIn('无有效基准',a.values['position'].get())
        self.assertIsNone(a.last_frame.endpoint_degrees)
    def test_s3_next_task_not_falsely_arrived_and_unknown_state_safe(self):
        a=self.app;a.process_frame(decode_unified(wire(S=3)),1,record=False)
        self.assertIn('等待实际收敛',a.overview_var.get());self.assertIn('本次旋转',a.sw4_var.get())
        a.process_frame(decode_unified(wire(M=15,F=15,S=15,N=15,Q=11)),1.1,record=False)
        self.assertIn('未知',a.values['balance'].get());self.assertIn('未知',a.details['balance'].get())
    def test_legacy_updates_never_refresh_x(self):
        a=self.app;a.mode='live';a.wanted=a.connected=True
        a.events.put(LinkEvent('data',wire(),time.monotonic()));a.poll_events()
        self.assertEqual(a.valid,1);first=a.last_frame;a.last_received_at=time.monotonic()-3
        a.events.put(LinkEvent('data',A+M+O,time.monotonic()));a.poll_events()
        self.assertEqual(a.valid,1);self.assertIs(a.last_frame,first);self.assertIn('历史统一快照',a.status_var.get())
        self.assertEqual(set(a.legacy),{'A','M','O'});self.assertIn('新鲜',a.legacy_var.get())
    def test_legacy_only_is_compatible_but_never_fabricates_snapshot(self):
        a=self.app;a.mode='live';a.wanted=a.connected=True
        a.events.put(LinkEvent('data',A+M+O,time.monotonic()));a.poll_events()
        self.assertIsNone(a.last_frame);self.assertIsNone(a.last_received_at);self.assertEqual(a.valid,0)
        self.assertIn('等待完整X',a.status_var.get());self.assertIn('O5103',a.legacy_var.get())
    def test_errors_disconnect_and_stale_keep_historical_values(self):
        a=self.app;a.mode='live';a.wanted=a.connected=True
        a.events.put(LinkEvent('data',wire(),time.monotonic()));a.poll_events();old=a.values['position'].get()
        a.events.put(LinkEvent('error',{'message':'fake USB removal','retry':True},time.monotonic()));a.poll_events()
        self.assertFalse(a.connected);self.assertTrue(a.wanted);self.assertEqual(a.values['position'].get(),old)
        self.assertIn('历史统一快照',a.status_var.get())
    def test_planned_derivatives_and_speeds_labeled_honestly(self):
        a=self.app;a.process_frame(decode_unified(wire(O=1,J=1,D=1,FL=0x220f)),1,record=False)
        self.assertIn('非机械实测',a.planner_var.get());self.assertIsNone(a.last_frame.reference_jerk_degrees)
        self.assertIn('50ms差分',a.position_var.get());self.assertIn('非实测PWM',a.details['command'].get())
        a.redraw();self.assertTrue(all(p.canvas.find_all() for p in a.plots))
    def test_pause_does_not_stop_ingest_or_record(self):
        a=self.app;a.process_frame(decode_unified(wire()),1,record=False);a.toggle_pause()
        a.process_frame(decode_unified(wire(Q=11,T=1100)),1.1,record=False)
        self.assertEqual(a.valid,2);self.assertEqual(a.paused_at,1);a.toggle_pause();self.assertIsNone(a.paused_at)
    def test_multi_task_multi_mode_csv_replay_keeps_raw_values_and_segments(self):
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            rec=UnifiedRecorder(folder,'TEST');h=UnifiedHistory()
            packets=[wire(G=7200),wire(Q=11,T=1100,H=916,P=916,RF=916,I=0,G=-3600),
                     wire(Q=12,T=1200,O=1,D=3,J=3,N=2,FL=0x233f,CY=1,EL=20000)]
            for i,b in enumerate(packets):
                f=decode_unified(b);rec.append(f,1+i/10,1,h.append(f,1+i/10,1))
            rec.close();content=rec.csv_path.read_bytes();self.app.load_replay(rec.csv_path)
            self.assertEqual(self.app.valid,3);self.assertEqual(self.app.last_frame.active_trajectory_profile,3)
            self.assertEqual(len({p.epoch for p in self.app.history.samples}),3)
            self.assertEqual(content,rec.csv_path.read_bytes());self.assertIsNone(self.app.worker)
            self.assertIn('离线',self.app.status_var.get())
    def test_note_is_local_event_and_no_command(self):
        base=ROOT/'_offline_tests';base.mkdir(exist_ok=True)
        with tempfile.TemporaryDirectory(dir=base) as folder:
            a=self.app;a.recorder=UnifiedRecorder(folder,'TEST');path=a.recorder.event_path
            a.note_var.set('轻推，人工标记');a.save_note();self.assertIn('本地备注已保存',a.record_var.get())
            a.finish_recording();self.assertIn('轻推',path.read_text(encoding='utf-8-sig'));self.assertIsNone(a.worker)

if __name__=='__main__':unittest.main()

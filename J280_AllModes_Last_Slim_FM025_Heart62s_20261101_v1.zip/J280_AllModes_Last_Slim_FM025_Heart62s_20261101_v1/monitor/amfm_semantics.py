"""Tag-qualified AM/FM display math; no serial commands or hardware estimation."""
from pathlib import Path
import json
import math
from functools import lru_cache

SEMANTICS_PATH=Path(__file__).resolve().parents[1]/'config/modulated_semantics.json'

@lru_cache(maxsize=4)
def _read_registry(path,mtime,size):
    try:
        data=json.loads(Path(path).read_text(encoding='utf-8-sig'))
        tags=data['am_fm_tags']
        if not isinstance(tags,dict):return {}
        clean={}
        for tag,cfg in tags.items():
            if not isinstance(tag,str) or len(tag)!=8 or any(c not in '0123456789abcdefABCDEF' for c in tag):continue
            if not isinstance(cfg,dict):continue
            am,fm=cfg.get('am',{}),cfg.get('fm',{})
            try:
                numbers=[am['carrier_period_ms'],am['envelope_period_ms'],am['min_ratio'],am['ramp_ms'],
                         fm['min_frequency_hz'],fm['max_frequency_hz'],fm['modulation_period_ms'],fm['ramp_ms']]
                if not all(isinstance(v,(int,float)) and math.isfinite(v) for v in numbers):continue
                if not (am['carrier_period_ms']>0 and am['envelope_period_ms']>0 and 0<am['min_ratio']<=1 and am['ramp_ms']>0):continue
                if not (0<fm['min_frequency_hz']<=fm['max_frequency_hz'] and fm['modulation_period_ms']>0 and fm['ramp_ms']>0):continue
            except (KeyError,TypeError):continue
            clean[int(tag,16)]=cfg
        return clean
    except (OSError,UnicodeError,ValueError,TypeError,KeyError):return {}

def registry(path=None):
    p=Path(SEMANTICS_PATH if path is None else path)
    try:s=p.stat()
    except OSError:return {}
    return _read_registry(str(p),s.st_mtime_ns,s.st_size)

def config_for_tag(tag):return registry().get(tag)
def is_modulated_tag(tag):return config_for_tag(tag) is not None

def profile_label(profile,tag,legacy):
    if is_modulated_tag(tag):
        return {1:'AM幅度调制往返',2:'FM频率调制往返',3:'心形包络往返' if heart_config(tag) else legacy}.get(profile,legacy)
    return legacy

def angle_semantic(profile,tag):
    if not is_modulated_tag(tag):return None
    if profile==3 and heart_config(tag):return '最大绝对偏移（正值下尖朝负，负值镜像）'
    return {1:'AM最大包络半幅（最小=1/3，负号倒相）',
            2:'FM固定半幅（负号倒相）'}.get(profile)

def modulated_data(f):
    """Derived PLANNED steady-state quantities, synchronized by board EL.

    RF/P remain the actual received reference and encoder position. No value here
    is claimed to measure a physical envelope or instantaneous mechanical f.
    """
    cfg=config_for_tag(f.trajectory_config_tag)
    j=f.active_trajectory_profile
    if cfg is None or j not in (1,2) or not f.has_runtime:return None
    if not f.base_valid or f.reference_owner!=1 or not f.flag(5):return None
    p=cfg['am' if j==1 else 'fm']
    cycle=p['envelope_period_ms'] if j==1 else p['modulation_period_ms']
    # [LAST_FM修改] 频率30秒循环，完整位置相位120秒闭合；旧标签仍用原周期。
    position_cycle=cycle if j==1 else p.get('position_cycle_ms',cycle)
    if f.trajectory_time_stretch!=1 or f.trajectory_cycle_ms!=position_cycle:return None
    t=f.trajectory_elapsed_ms/1000
    amplitude=abs(f.accepted_trajectory_deci)/10
    steady=f.trajectory_phase==2
    if j==1:
        ratio=p['min_ratio'];w=2*math.pi/(cycle/1000)
        a=amplitude*((1+ratio)+(1-ratio)*math.cos(w*t))/2
        freq=1000/p['carrier_period_ms']
        minimum=amplitude*ratio
    else:
        lo,hi=p['min_frequency_hz'],p['max_frequency_hz']
        freq=(lo+hi)/2-(hi-lo)/2*math.cos(2*math.pi*t/(cycle/1000))
        a=amplitude;minimum=amplitude
    return {'profile':j,'maximum_half_degrees':amplitude,'minimum_half_degrees':minimum,
            'envelope_half_degrees':a,'frequency_hz':freq,'instant_period_s':1/freq,
            'modulation_period_s':cycle/1000,'position_cycle_s':position_cycle/1000,'steady':steady,
            'ramp_ms':p['ramp_ms'],'board_elapsed_s':t,
            'phase_stage':{1:'平滑接入',2:'稳态',3:'平滑退出'}.get(f.trajectory_phase,'阶段未确认')}

def upper_envelope_degrees(f):
    h=heart_data(f)
    if h is not None:return h['upper_degrees'] if h['steady'] else None
    d=modulated_data(f)
    return d['envelope_half_degrees'] if d and d['steady'] else None

def lower_envelope_degrees(f):
    h=heart_data(f)
    if h is not None:return h['lower_degrees'] if h['steady'] else None
    value=upper_envelope_degrees(f)
    return -value if value is not None else None

def modulation_summary(f):
    h=heart_data(f)
    if h is not None:return heart_summary(h)
    d=modulated_data(f)
    if d is None:return ''
    if d['profile']==1:
        return (f"AM：快往返{d['instant_period_s']:.3f}s；包络{d['modulation_period_s']:.3f}s；"
                f"最大/最小半幅{d['maximum_half_degrees']:.2f}°/{d['minimum_half_degrees']:.2f}°；"
                f"当前规划稳态包络±{d['envelope_half_degrees']:.2f}°；{d['phase_stage']}。")
    return (f"FM：固定半幅±{d['maximum_half_degrees']:.2f}°；变速循环{d['modulation_period_s']:.3f}s；"
            f"位置相位周期{d['position_cycle_s']:.3f}s；规划瞬时频率{d['frequency_hz']:.4f}Hz / 瞬时周期{d['instant_period_s']:.3f}s；"
            f"{d['phase_stage']}（频率由板卡EL相位推导，非机械实测）。")

def stop_meaning(f):
    h=heart_config(f.trajectory_config_tag)
    if h and f.active_trajectory_profile==3 and f.balance_mode==5 and f.base_valid and f.reference_owner==1 and f.flag(5) and not f.flag(6):
        return f"SW4：请求{h['exit_ramp_ms']/1000:g}秒平滑收拢回本段起点；SW2/SW3只编辑下次最大绝对偏移。"
    if not is_modulated_tag(f.trajectory_config_tag) or f.active_trajectory_profile not in (1,2):return None
    if f.balance_mode==5 and f.base_valid and f.reference_owner==1 and f.flag(5) and not f.flag(6):
        return 'SW4：按下请求AM/FM平滑减幅退出到本次中心；编辑角度只在下一次明确启动生效。'
    return None


# Mode11 is tag-qualified: old firmware's ordinary sine remains ordinary sine.
def heart_config(tag):
    cfg=config_for_tag(tag)
    h=cfg.get('heart') if cfg else None
    if not isinstance(h,dict):return None
    try:
        keys=('period_ms','carrier_cycles','carrier_period_ms','base_max_degrees',
              'upper_max_degrees','upper_epsilon','lower_epsilon','lower_power',
              'endpoint_gate_ms','exit_ramp_ms')
        if not all(isinstance(h[k],(int,float)) and not isinstance(h[k],bool) and math.isfinite(h[k]) and h[k]>0 for k in keys):return None
        if h['carrier_cycles']!=int(h['carrier_cycles']):return None
        if abs(h['period_ms']-h['carrier_cycles']*h['carrier_period_ms'])>1e-6:return None
        if h['endpoint_gate_ms']*2>=h['period_ms']:return None
        if not 0<h['upper_max_degrees']<=h['base_max_degrees']:return None
    except (KeyError,TypeError):return None
    return h

def _septic(x):
    x=max(0.,min(1.,x))
    return x**4*(35+x*(-84+x*(70-20*x)))

def _classic_up_peak():
    lo,hi=0.,1.
    for _ in range(60):
        c=(lo+hi)/2
        if 19-4*c-24*c*c-32*c**3>0:lo=c
        else:hi=c
    c=(lo+hi)/2
    return 19*c-2*c*c-8*c**3-8*c**4
_CLASSIC_UP_PEAK=_classic_up_peak()

def heart_bounds_at(elapsed_ms,accepted_deci,h,cycle_ms=None):
    """PLANNED bounds in degrees relative to board H; uses atomic EL, not host time.

    This gives the full intrinsic shape only. A requested stop has another
    private fade index that is not in X8002; callers hide bounds during PH3.
    """
    # [EQ62修改] CL决定循环；形状仍56秒，后6秒规划边界为零。
    period=h['period_ms'];cycle=period if cycle_ms is None else cycle_ms
    t=elapsed_ms%cycle
    if t==0 or t>=period:return 0.,0.
    s=2*t/period-1
    eps=h['upper_epsilon']
    rho=((s*s+eps*eps)**(1/3)-eps**(2/3))/((1+eps*eps)**(1/3)-eps**(2/3))
    c=math.sqrt(max(0.,1-rho))
    U=(19*c-2*c*c-8*c**3-8*c**4)*h['upper_max_degrees']/_CLASSIC_UP_PEAK
    eps=h['lower_epsilon']
    absolute=(math.sqrt(s*s+eps*eps)-eps)/(math.sqrt(1+eps*eps)-eps)
    L=-h['base_max_degrees']*max(0.,1-absolute)**h['lower_power']
    gate=_septic(t/h['endpoint_gate_ms'])*_septic((period-t)/h['endpoint_gate_ms'])
    scale=accepted_deci/(10*h['base_max_degrees'])
    a,b=gate*U*scale,gate*L*scale
    return max(a,b),min(a,b)

def heart_data(f):
    h=heart_config(f.trajectory_config_tag)
    if h is None or f.active_trajectory_profile!=3 or not f.has_runtime:return None
    if not f.base_valid or f.reference_owner!=1 or not f.flag(5):return None
    # [EQ62修改] 同一CF的历史56秒记录与当前62秒记录均按板端CL解释。
    allowed_cycles={h['period_ms'],h.get('cycle_ms',h['period_ms'])}
    if f.trajectory_time_stretch!=1 or f.trajectory_cycle_ms not in allowed_cycles:return None
    upper,lower=heart_bounds_at(f.trajectory_elapsed_ms,f.accepted_trajectory_deci,h,f.trajectory_cycle_ms)
    return {'profile':3,'maximum_absolute_degrees':abs(f.accepted_trajectory_deci)/10,
            'upper_degrees':upper,'lower_degrees':lower,'steady':f.trajectory_phase==2,
            'carrier_period_s':h['carrier_period_ms']/1000,'carrier_cycles':h['carrier_cycles'],
            'period_s':f.trajectory_cycle_ms/1000,'board_elapsed_s':f.trajectory_elapsed_ms/1000,
            'shape_period_s':h['period_ms']/1000,'hold_s':(f.trajectory_cycle_ms-h['period_ms'])/1000,
            'phase_stage':'心形执行' if f.trajectory_phase==2 else '停止过渡，完整包络暂隐',
            'mirror':f.accepted_trajectory_deci<0}

def heart_summary(h):
    bounds=(f"当前规划包络 {h['lower_degrees']:+.2f}°～{h['upper_degrees']:+.2f}°"
            if h['steady'] else '退出包络私有相位未遥测，暂不画完整心形边界')
    interval=(f"（{h['shape_period_s']:g}s绘制＋{h['hold_s']:g}s间隔保持）" if h.get('hold_s',0)>0 else '')
    return (f"心形：{h['period_s']:g}s一颗心{interval}／{h['carrier_cycles']:g}个载波周期，"

            f"基准往返约{h['carrier_period_s']:g}s；最大绝对偏移{h['maximum_absolute_degrees']:.2f}°"
            f"（{'负值镜像' if h['mirror'] else '心尖朝负'}）；{bounds}；{h['phase_stage']}。"
            "包络由CF/EL/TA推导，非实物测量。")

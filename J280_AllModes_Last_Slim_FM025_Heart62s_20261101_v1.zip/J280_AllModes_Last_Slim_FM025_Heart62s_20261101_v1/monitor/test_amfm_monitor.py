"""Offline tag-qualified AM/FM parser/display tests. Never opens COM."""
import copy,json,math,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
import amfm_semantics as am
import unified_monitor as monitor
from unified_protocol import decode_unified,UnifiedHistory,UnifiedRecorder,FIELDS
TAG=0xA1B2C3D4
CFG={'am':{'carrier_period_ms':3500,'envelope_period_ms':31500,'min_ratio':1/3,'ramp_ms':2000},
     'fm':{'min_frequency_hz':.1,'max_frequency_hz':.5,'modulation_period_ms':30000,'ramp_ms':2000},'default_deci':300}
def frame(j=1,**kw):
    data=dict(D=j,J=j,CF=TAG,EL=0,PH=2,CL=31500 if j==1 else 30000,TM=1,TA=300,TE=600,EA=300,EB=300,EC=900)
    data.update(kw)
    return decode_unified(monitor.demo_line(0,**data))
class RegistryCase(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.path=Path(self.temp.name)/'modulated_semantics.json'
        self.path.write_text(json.dumps({'am_fm_tags':{f'{TAG:08X}':CFG}}),encoding='utf-8')
        self.ctx=patch.object(am,'SEMANTICS_PATH',self.path);self.ctx.start()
        am._read_registry.cache_clear()
    def tearDown(self):
        self.ctx.stop();self.temp.cleanup();am._read_registry.cache_clear()
class AMFMProtocol(RegistryCase):
    def test_registered_labels_and_old_profile_labels(self):
        for j,name in [(1,'AM'),(2,'FM')]:
            self.assertIn(name,monitor.active_profile_label(frame(j)))
            self.assertIn(name,monitor.selected_mode_label(frame(j)))
        self.assertIn('梯形',monitor.active_profile_label(frame(CF=0x12345678)))
        self.assertIn('七段S',monitor.active_profile_label(frame(2,CF=0x12345678)))
        self.assertIn('正弦',monitor.active_profile_label(frame(3,CL=7000)))
    def test_selected_does_not_rename_running_profile(self):
        f=frame(1,D=2)
        self.assertIn('AM',monitor.active_profile_label(f))
        self.assertIn('FM',monitor.selected_mode_label(f))
        self.assertIn('最大包络',monitor.trajectory_semantics(f)[1])
        self.assertIn('固定半幅',monitor.trajectory_semantics(f)[0])
    def test_max_min_and_periodic_envelope(self):
        for ms,a in [(0,30),(15750,10),(31500,30),(47250,10),(63000,30)]:
            f=frame(EL=ms)
            self.assertAlmostEqual(am.upper_envelope_degrees(f),a,places=12)
            self.assertAlmostEqual(am.lower_envelope_degrees(f),-a,places=12)
            self.assertAlmostEqual(am.modulated_data(f)['instant_period_s'],3.5)
    def test_negative_amplitude_only_changes_phase_not_envelope(self):
        self.assertEqual(am.modulated_data(frame(TA=300)),am.modulated_data(frame(TA=-300)))
    def test_amplitude_scales_without_stretching_period(self):
        f=frame(TA=1234,EL=15750)
        d=am.modulated_data(f)
        self.assertAlmostEqual(d['maximum_half_degrees'],123.4)
        self.assertAlmostEqual(d['envelope_half_degrees'],123.4/3)
        self.assertEqual(d['modulation_period_s'],31.5)
        self.assertEqual(d['instant_period_s'],3.5)
    def test_fm_frequency_uses_phase_and_matches_two_to_ten_seconds(self):
        for ms,freq in [(0,.1),(7500,.3),(15000,.5),(22500,.3),(30000,.1),(45000,.5)]:
            d=am.modulated_data(frame(2,EL=ms))
            self.assertAlmostEqual(d['frequency_hz'],freq,places=12)
            self.assertAlmostEqual(d['instant_period_s'],1/freq,places=11)
            self.assertEqual(d['modulation_period_s'],30)
            self.assertEqual(d['envelope_half_degrees'],30)
    def test_fm_fixed_amplitude_independent_of_frequency(self):
        for ms in range(0,30001,300):
            d=am.modulated_data(frame(2,TA=-7200,EL=ms))
            self.assertEqual(d['envelope_half_degrees'],720)
            self.assertGreaterEqual(d['instant_period_s'],2-1e-10)
            self.assertLessEqual(d['instant_period_s'],10+1e-10)
    def test_transient_does_not_fabricate_steady_envelope(self):
        for stage in (0,1,3,4):
            f=frame(PH=stage)
            self.assertIsNone(am.upper_envelope_degrees(f))
            self.assertIsNone(am.lower_envelope_degrees(f))
        self.assertIn('平滑接入',am.modulation_summary(frame(PH=1)))
        self.assertIn('平滑退出',am.modulation_summary(frame(2,PH=3)))
    def test_stale_or_mismatched_reference_hides_derived_curve(self):
        for kw in [{'O':0},{'FL':0},{'TM':2},{'CL':7000},{'CF':123}]:
            self.assertIsNone(am.modulated_data(frame(**kw)))
            self.assertIsNone(am.upper_envelope_degrees(frame(**kw)))
        for j in (0,3):
            self.assertIsNone(am.modulated_data(frame(j,CL=7000)))
    def test_zero_and_small_requested_amplitudes(self):
        self.assertEqual(am.upper_envelope_degrees(frame(TA=0)),0)
        self.assertAlmostEqual(am.upper_envelope_degrees(frame(TA=1)),.1)
    def test_legacy_8001_never_infers_accepted_amplitude(self):
        fields=monitor.demo_line().split()
        short='X=8001 '+' '.join(fields[1:47])
        self.assertIsNone(am.modulated_data(decode_unified(short)))
    def test_registry_missing_is_not_guessed(self):
        self.path.unlink()
        self.assertFalse(am.is_modulated_tag(TAG))
        self.assertIsNone(am.modulated_data(frame()))
    def test_registry_bad_or_nonfinite_is_rejected(self):
        for text in ['{','{}','{"am_fm_tags":[]}',json.dumps({'am_fm_tags':{f'{TAG:08X}':{'am':{},'fm':{}}}})]:
            self.path.write_text(text);am._read_registry.cache_clear()
            self.assertFalse(am.is_modulated_tag(TAG))
        c=copy.deepcopy(CFG);c['am']['carrier_period_ms']=float('nan')
        self.path.write_text(json.dumps({'am_fm_tags':{f'{TAG:08X}':c}}));am._read_registry.cache_clear()
        self.assertFalse(am.is_modulated_tag(TAG))
    def test_registry_reloads_when_new_config_added(self):
        self.assertFalse(am.is_modulated_tag(1234))
        self.path.write_text(json.dumps({'am_fm_tags':{f'{TAG:08X}':CFG,'000004D2':CFG}}))
        self.assertTrue(am.is_modulated_tag(1234))
    def test_history_segments_on_config_change(self):
        h=UnifiedHistory();h.append(frame(),0,1)
        c=h.append(frame(CF=0x12345678,Q=1,T=100),.1,1)
        self.assertIn('CF变化',c.reason)
        self.assertNotEqual(h.samples[0].epoch,h.samples[1].epoch)
    def test_wire_fields_and_csv_raw_frames_are_unchanged(self):
        f=frame()
        self.assertEqual(len(f.raw),510)
        self.assertEqual(len(FIELDS),54)
        h=UnifiedHistory();c=h.append(f,0,1)
        record=UnifiedRecorder(self.temp.name,'FAKE')
        record.append(f,0,1,c);record.close()
        text=record.csv_path.read_text(encoding='utf-8-sig')
        self.assertIn(f.raw,text)
        self.assertEqual(decode_unified(f.raw).trajectory_config_tag,TAG)
    def test_summary_and_stop_message(self):
        self.assertIn('3.500s',am.modulation_summary(frame()))
        self.assertIn('31.500s',am.modulation_summary(frame()))
        self.assertIn('2.000s',am.modulation_summary(frame(2,EL=15000)))
        self.assertIn('非机械实测',am.modulation_summary(frame(2)))
        self.assertIn('平滑减幅',am.stop_meaning(frame()))
        self.assertIsNone(am.stop_meaning(frame(3,CL=7000)))
class AMFMGUI(RegistryCase):
    def setUp(self):
        super().setUp()
        self.root=tk.Tk();self.root.withdraw()
        self.app=monitor.UnifiedMonitor(self.root,mode='demo',create_worker=False)
    def tearDown(self):
        self.app.close();super().tearDown()
    def test_am_view_and_envelope_getters(self):
        f=frame(EL=15750);self.app.process_frame(f,15.75,False)
        text=self.app.position_var.get()
        self.assertIn('AM最大包络',text)
        self.assertIn('当前规划稳态包络±10.00°',text)
        self.assertIn('AM幅度调制',self.app.values['mode'].get())
        series=self.app.plots[4].series
        self.assertEqual(len(series),5)
        self.assertAlmostEqual(series[-2][2](f),10)
        self.assertAlmostEqual(series[-1][2](f),-10)
    def test_fm_view_and_fixed_limits(self):
        f=frame(2,EL=15000,TA=600)
        self.app.process_frame(f,15,False)
        text=self.app.position_var.get()
        self.assertIn('FM固定半幅',text)
        self.assertIn('0.5000Hz / 瞬时周期2.000s',text)
        self.assertIn('固定半幅±60.00°',text)
        self.assertEqual(am.upper_envelope_degrees(f),60)
    def test_position_and_sine_do_not_gain_amfm_overlays(self):
        for j in (0,3):
            f=frame(j,CL=7000);self.app.process_frame(f,j,False)
            self.assertIsNone(am.upper_envelope_degrees(f))
            self.assertNotIn('规划瞬时频率',self.app.position_var.get())
            self.assertNotIn('当前规划稳态包络',self.app.position_var.get())
        self.assertEqual(len(self.app.plots),8)
        self.assertEqual(len(self.app.notebook.tabs()),5)
    def test_old_csv_profile_keeps_original_label(self):
        f=frame(2,CF=0x12345678);self.app.process_frame(f,0,False)
        self.assertIn('七段S',self.app.values['mode'].get())
        self.assertNotIn('FM频率',self.app.values['mode'].get())
    def test_plots_render_envelopes_and_variable_frequency(self):
        for j in (1,2):
            for i in range(100):
                self.app.process_frame(frame(j,Q=i,T=i*100,EL=i*100),i*.1,False)
            self.root.geometry('1280x680');self.root.update()
            self.app.notebook.select(self.app.pages['position']);self.root.update()
            self.app.mark_dirty();self.app.redraw()
            self.assertTrue(self.app.plots[4].canvas.find_all())
            self.assertIsNone(self.app.worker)
            self.assertIsNone(self.app.recorder)
if __name__=='__main__':unittest.main()

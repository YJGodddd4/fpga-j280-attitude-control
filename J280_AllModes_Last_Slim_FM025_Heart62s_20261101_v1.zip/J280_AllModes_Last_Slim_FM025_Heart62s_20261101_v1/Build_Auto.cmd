@echo off
setlocal
cd /d "%~dp0"
"%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -X utf8 "scripts\build_checked.py"
set "BUILD_RC=%ERRORLEVEL%"
echo.
echo Build exit code: %BUILD_RC%
echo Only a timing-checked output is copied to bitstream.
pause
exit /b %BUILD_RC%

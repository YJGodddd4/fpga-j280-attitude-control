@echo off
cd /d "%~dp0monitor"
call Start_Unified_Monitor.cmd

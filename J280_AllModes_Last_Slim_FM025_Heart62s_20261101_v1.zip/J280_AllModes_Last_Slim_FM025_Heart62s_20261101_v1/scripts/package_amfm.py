"""Create source-matched AM/FM delivery; no serial or programmer access."""
from pathlib import Path
from html.parser import HTMLParser
import json,hashlib,zipfile,difflib,re,shutil
ROOT=Path(__file__).resolve().parents[1]
NAME=ROOT.name
OUT=ROOT.parent/(NAME+'_完整工程与监测.zip')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def path(s):return ROOT/Path(s.replace('\\','/'))
build=load(ROOT/'reports/allmodes_v8_5_amfm_build_summary.json')
assert build['exit_code']==0 and build['setup_violations']==build['hold_violations']==0
for n,h in build['source_sha256'].items():assert sha(path(n))==h,('stale native build',n)
fs=ROOT/'bitstream/J280_AllModes_v8_5_AMFM.fs'
assert sha(fs)==build['bitstream_sha256']
expected={'CLK_HZ':50000000,'MOTOR_CHANNEL':0,'MOTOR_REVERSE':0,'ENCODER_REVERSE':1,
'ENCODER_COUNTS_REV':1040,'DUTY_LIMIT':100,'ANGLE_KP_100':40,'ANGLE_KI_100':1,
'ANGLE_KD_100':492,'ANGLE_D_FILTER_SHIFT':1,'LOCATION_KP_10':7,'LOCATION_KD_10':93,
'POSITION_MIN_MOVE_MS':300,'POSITION_MS_PER_DEG':15,'AUTO_MAP_CONFIRMED':1,
'AUTO_UP_REF':2955,'AUTO_DOWN_REF':859,'SWING_DUTY_START':70,'SWING_KICK_MS':70,
'SWING_PULSE_MS':101,'CAPTURE_HALF_WIDTH':64,'SWING_POLARITY':1,
'BALANCE_EXIT_ADC':388,'RECOVERY_DOWN_ADC':500,'RECOVERY_SPEED_Q8':158}
top=(ROOT/'rtl/j280_pendulum_top.v').read_text(encoding='utf-8-sig')
for k,v in expected.items():assert re.search(r'\b'+k+r'\s*=\s*'+str(v)+r'\b',top),k
cfg=load(ROOT/'config/trajectory_profiles.json')
am=cfg['am'];fm=cfg['fm']
assert am['amplitude_degrees']==30 and am['carrier_period_ms']==3500 and am['envelope_period_ms']==31500
assert abs(am['min_ratio']-1/3)<1e-15 and am['ramp_ms']==2000
assert fm['amplitude_degrees']==30 and fm['modulation_period_ms']==30000
assert fm['min_frequency_hz']==.1 and fm['max_frequency_hz']==.5 and fm['ramp_ms']==2000
tv=load(ROOT/'config/trajectory_validation.json')
for n,h in tv['rom_sha256'].items():assert sha(path(n))==h,('ROM metadata differs',n)
meta=load(ROOT/'config/modulated_semantics.json')
assert tv['config_tag'] in meta['am_fm_tags']
tests={}
for name in ['generator','numeric_check','limits','editor','trajectory','monitor']:
 p=ROOT/('tests/amfm_'+name+'_result.json')
 result=load(p);assert result.get('success') is True,('validation failed',name)
 for n,h in result.get('source_sha256',{}).items():assert sha(path(n))==h,('stale evidence',name,n)
 tests[name]=result
origin=load(ROOT/'reference_input/archive_origin.json')
source=Path(origin['input_zip']);assert sha(source)==origin['input_zip_sha256']
z=zipfile.ZipFile(source);prefix=z.namelist()[0].split('/')[0]+'/'
oldcfg=json.loads(z.read(prefix+'config/trajectory_profiles.json').decode('utf-8-sig'))
assert cfg['sine']==oldcfg['sine'],'Ordinary11 configuration changed'
assert (ROOT/'rtl/trajectory_tables_sine.mem').read_bytes()==z.read(prefix+'rtl/trajectory_tables_sine.mem')
assert (ROOT/'rtl/trajectory_tables_envelope.mem').read_bytes().startswith(z.read(prefix+'rtl/trajectory_tables_envelope.mem'))
changed=[];patch=[]
allowed_rtl={'trajectory_task.v','trajectory_editor.v','trajectory_tables.v','trajectory_tables_ab.mem','trajectory_tables_envelope.mem'}
for p in sorted((ROOT/'rtl').iterdir()):
 if not p.is_file():continue
 n='rtl/'+p.name
 try:old=z.read(prefix+n)
 except KeyError:raise AssertionError('Unexpected new production RTL: '+n)
 if old!=p.read_bytes():
  assert p.name in allowed_rtl,('Unexpected controller/00/source modification',n)
  changed.append(n)
  if p.suffix=='.v':patch+=list(difflib.unified_diff(old.decode('utf-8-sig').splitlines(True),p.read_text(encoding='utf-8-sig').splitlines(True),fromfile='input/'+n,tofile='amfm/'+n))
for n in ['config/trajectory_profiles.json','scripts/generate_trajectory_tables.py','scripts/build_checked.py']:
 old=z.read(prefix+n).decode('utf-8-sig').splitlines(True);new=path(n).read_text(encoding='utf-8-sig').splitlines(True)
 patch+=list(difflib.unified_diff(old,new,fromfile='input/'+n,tofile='amfm/'+n))
for p in sorted((ROOT/'monitor').glob('*.py')):
 n='monitor/'+p.name
 old=z.read(prefix+n).decode('utf-8-sig').splitlines(True) if prefix+n in z.namelist() else []
 new=p.read_text(encoding='utf-8-sig').splitlines(True)
 if old!=new:patch+=list(difflib.unified_diff(old,new,fromfile='input/'+n if old else '/dev/null',tofile='amfm/'+n))
(ROOT/'changes_v8_4_to_AMFM.patch').write_text(''.join(patch),encoding='utf-8')
class Text(HTMLParser):
 def __init__(self):super().__init__();self.parts=[]
 def handle_data(self,s):
  if s.strip():self.parts.append(s.strip())
resources={}
for name,src in [('synthesis_resources','impl/gwsynthesis/J280_Pendulum_syn_resource.html'),('place_route_resources','impl/pnr/J280_Pendulum.rpt.html')]:
 p=path(src);assert p.exists(),src
 shutil.copyfile(p,ROOT/'reports'/(name+'.html'))
 parser=Text();parser.feed(p.read_text(encoding='utf-8',errors='replace'))
 (ROOT/'reports'/(name+'.txt')).write_text('\n'.join(parser.parts),encoding='utf-8')
 resources[name]='reports/'+name+'.txt'
png=ROOT/'plots/AM_FM_位置曲线模拟.png';assert png.exists() and png.stat().st_size>10000
sim=load(ROOT/'plots/simulation_parameters.json')
assert sim['am']['carrier_period_ms']==3500 and sim['am']['envelope_period_ms']==31500
assert sim['fm']['modulation_period_ms']==30000 and sim['fm']['instantaneous_period_range_seconds']==[2,10]
summary={'variant':NAME,'input_zip_sha256':origin['input_zip_sha256'],
 'native_build':'PASS','setup_violations':0,'hold_violations':0,'frequency_summary':build['frequency_summary'],
 'bitstream':fs.relative_to(ROOT).as_posix(),'bitstream_sha256':sha(fs),
 'trajectory_validation':tv,'parameter_values':expected,'changed_production_rtl':changed,'resource_reports':resources,
 'test_reports':{n:'tests/amfm_'+n+'_result.json' for n in tests},
 'unchanged_position_and_control_sources':True,'original11_rom_and_configuration_identical':True,
 'mode_assignment':{'00':'original relative position','01':'ordinary AM','10':'sinusoidal FM','11':'original ordinary sine'},
 'am_period_ms':{'carrier':3500,'envelope':31500},'fm_modulation_ms':30000,'fm_instantaneous_period_range_seconds':[2,10],
 'control_period_ms':{'angle':5,'location':50},'trajectory_sample_ms':10,
 'uart_packet_format_changed':False,'plot_sha256':sha(png),
 'hardware_tested':False,'plant_model_tested':False,
 'history':'reference_input contains original archive snapshots and historical evidence; only current amfm reports apply.'}
(ROOT/'reports/amfm_validation_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
def include(p):
 r=p.relative_to(ROOT);parts=r.parts
 if any(x in {'__pycache__','records','_offline_tests','_sim_temp','.git','.mplconfig'} or x.startswith('.trajectory-generation-') for x in parts):return False
 if p.name.endswith(('.gprj.user','startup_error.log')):return False
 if p.suffix=='.fs':return r.as_posix()=='bitstream/J280_AllModes_v8_5_AMFM.fs'
 if parts[0]=='impl':return r.as_posix()=='impl/J280_Pendulum_process_config.json'
 if parts[0]=='tests' and p.name.endswith(('_result.json','_test.log')) and not p.name.startswith('amfm_'):return False
 if r.as_posix()=='scripts/package_checked.py':return False
 if parts[0]=='reports' and p.name.startswith('first_'):return False
 return p.name!='file_manifest_sha256.json'
files=sorted(p for p in ROOT.rglob('*') if p.is_file() and include(p))
manifest={p.relative_to(ROOT).as_posix():sha(p) for p in files}
mp=ROOT/'file_manifest_sha256.json';mp.write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8');files.append(mp)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as archive:
 for p in files:archive.write(p,NAME+'/'+p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(OUT) as archive:
 assert archive.testzip() is None
 for n,h in manifest.items():assert hashlib.sha256(archive.read(NAME+'/'+n)).hexdigest()==h,n
result={'zip':str(OUT),'zip_sha256':sha(OUT),'zip_bytes':OUT.stat().st_size,'files':len(files),
 'bitstream':str(fs),'bitstream_sha256':sha(fs),'hardware_tested':False,'plot':str(png)}
(ROOT.parent/(NAME+'_交付校验.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))

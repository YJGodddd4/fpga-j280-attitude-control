"""Generate requested analytic position figures; not a mechanical plant simulation."""
from pathlib import Path
import sys,os,json,math
ROOT=Path(__file__).resolve().parents[1]
DEPS=ROOT.parent/'amfm_plot_deps'
if DEPS.is_dir():sys.path.insert(0,str(DEPS))
OUT=ROOT/'plots';OUT.mkdir(exist_ok=True)
os.environ['MPLCONFIGDIR']=str(OUT/'.mplconfig')
import matplotlib
matplotlib.use('Agg')
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
font=FontProperties(fname='C:/Windows/Fonts/msyh.ttc')
plt.rcParams.update({'font.family':font.get_name(),'font.sans-serif':[font.get_name()],
'axes.unicode_minus':False,'font.size':12,'axes.spines.top':False,
'axes.spines.right':False,'figure.facecolor':'white','axes.facecolor':'white'})
H=30.0;Tc=3.5;Tm=31.5;Tf=30.0
t=np.linspace(0,63,6301)
env=H*(2+np.cos(2*np.pi*t/Tm))/3
q=env*np.sin(2*np.pi*t/Tc)
u=np.linspace(0,60,6001)
freq=.3-.2*np.cos(2*np.pi*u/Tf)
phase=2*np.pi*.3*u-6*np.sin(2*np.pi*u/Tf)
fm=H*np.sin(phase)
assert abs(env.min()-10)<1e-8 and abs(env.max()-30)<1e-8
assert abs(freq.min()-.1)<1e-8 and abs(freq.max()-.5)<1e-8
assert abs(phase[3000]-18*np.pi)<1e-8
fig,ax=plt.subplots(2,1,figsize=(17,9.2))
fig.subplots_adjust(left=.075,right=.98,top=.89,bottom=.14,hspace=.55)
fig.suptitle('AM / FM 摆臂位置参考曲线',fontsize=22,y=.98)
blue='#0875b9';orange='#d46716';gray='#66717c'
for a in ax:
 a.grid(True,color='#dbe1e8',linewidth=.7)
 a.axhline(0,color='#a4adb8',linewidth=.8)
 a.set_ylim(-36,36);a.set_yticks([-30,-20,-10,0,10,20,30])
 a.set_ylabel('相对锁定中心的方位角（°）')
 a.set_xlabel('时间（s）')
 a.tick_params(colors='#3e4752')
 for sp in a.spines.values():sp.set_color('#a4adb8')
ax[0].set_title('01 AM：快往返3.5s｜包络31.5s（9次快往返）｜最大/最小包络半幅30°/10°',
loc='left',fontsize=14,pad=17)
ax[0].plot(t,q,color=blue,linewidth=1.7,label='位置参考')
ax[0].plot(t,env,color=orange,linestyle='--',linewidth=1.4,label='上下正弦包络')
ax[0].plot(t,-env,color=orange,linestyle='--',linewidth=1.4)
ax[0].set_xlim(0,63);ax[0].set_xticks([0,10,20,31.5,40,50,63])
ax[0].annotate('最小包络半幅10°',xy=(15.75,10),xytext=(18,26),
 arrowprops={'arrowstyle':'-','color':gray},fontsize=11,color=gray)
ax[0].annotate('最大包络半幅30°',xy=(31.5,30),xytext=(36,33),
 arrowprops={'arrowstyle':'-','color':gray},fontsize=11,color=gray)
ax[0].annotate('',xy=(0,-33),xytext=(31.5,-33),
 arrowprops={'arrowstyle':'<->','color':gray})
ax[0].text(15.75,-31,'31.5s：一个完整包络周期',ha='center',fontsize=10,color=gray)
ax[0].legend(loc='upper right',bbox_to_anchor=(1,-.16),ncol=2,frameon=False,fontsize=10,borderaxespad=0)
ax[1].set_title('10 FM：固定半幅30°｜瞬时周期2–10s｜慢→快→慢的变速循环30s',
loc='left',fontsize=14,pad=17)
ax[1].plot(u,fm,color=blue,linewidth=1.7,label='位置参考')
ax[1].axhline(H,color=orange,linestyle='--',linewidth=1.4,label='固定半幅±30°')
ax[1].axhline(-H,color=orange,linestyle='--',linewidth=1.4)
ax[1].set_xlim(0,60);ax[1].set_xticks(range(0,61,5))
for x,txt in [(0,'慢：10s'),(15,'快：2s'),(30,'慢：10s'),(45,'快：2s'),(60,'慢：10s')]:
 ax[1].text(x,33,txt,ha='left' if x==0 else 'right' if x==60 else 'center',fontsize=10,color=gray)
ax[1].legend(loc='upper right',bbox_to_anchor=(1,-.16),ncol=2,frameon=False,fontsize=10,borderaxespad=0)
fig.text(.5,.025,'数学稳态参考；半幅30°为可调展示值。图中不包含启停过渡及倒立摆闭环动力学。',ha='center',color=gray,fontsize=11)
path=OUT/'AM_FM_位置曲线模拟.png'
fig.savefig(path,dpi=190)
plt.close(fig)
meta={'am':{'maximum_half_amplitude_degrees':H,'minimum_half_amplitude_degrees':H/3,
'carrier_period_ms':3500,'envelope_period_ms':31500,'carrier_cycles_per_envelope':9,
'position_formula':'H*(2+cos(2*pi*t/31.5))/3*sin(2*pi*t/3.5)'},
'fm':{'half_amplitude_degrees':H,'modulation_period_ms':30000,
'minimum_frequency_hz':.1,'maximum_frequency_hz':.5,
'instantaneous_period_range_seconds':[2,10],
'position_formula':'H*sin(2*pi*0.3*t-6*sin(2*pi*t/30))'},
'plant_model_included':False,'hardware_tested':False,'startup_stop_transitions_included':False}
(OUT/'simulation_parameters.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print(path)

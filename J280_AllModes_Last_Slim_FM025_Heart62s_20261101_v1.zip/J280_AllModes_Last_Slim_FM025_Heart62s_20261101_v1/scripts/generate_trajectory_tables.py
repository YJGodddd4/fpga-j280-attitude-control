"""Generate unchanged AM/FM ROMs plus the annotated14-cycle heart position reference."""
from pathlib import Path
import json,math,zlib,hashlib
ROOT=Path(__file__).resolve().parents[1]
def nearest(x):return int(math.floor(x+.5)) if x>=0 else -int(math.floor(-x+.5))
def u32(x):return nearest(x)&0xffffffff
def envelope(t,T):
    x=max(0.,min(1.,t/T))
    return(10*x**3-15*x**4+6*x**5,(30*x*x-60*x**3+30*x**4)/T,
           (60*x-180*x*x+120*x**3)/T**2,(60-360*x+360*x*x)/T**3)
def pack_reference(row,scale):
    q,v,a,j,phase=row
    return ((phase&255)<<128)|(u32(q*scale*65536)<<96)|(u32(v*scale*256)<<64)|(u32(a*scale*256)<<32)|u32(j*scale*256)
def am_at(t,p):
    H=p['amplitude_degrees'];m=p['min_ratio'];wc=2*math.pi/(p['carrier_period_ms']/1000.)
    wm=2*math.pi/(p['envelope_period_ms']/1000.)
    mid=H*(1+m)/2;depth=H*(1-m)/2
    A=mid+depth*math.cos(wm*t)
    dA=-depth*wm*math.sin(wm*t);ddA=-depth*wm**2*math.cos(wm*t)
    dddA=depth*wm**3*math.sin(wm*t);sn=math.sin(wc*t);cs=math.cos(wc*t)
    return(A*sn,dA*sn+A*wc*cs,(ddA-A*wc**2)*sn+2*dA*wc*cs,
           (dddA-3*dA*wc**2)*sn+(3*ddA*wc-A*wc**3)*cs,2)
def fm_at(t,p):
    H=p['amplitude_degrees'];low=p['min_frequency_hz'];high=p['max_frequency_hz']
    mid=(low+high)/2;dev=(high-low)/2;wm=2*math.pi/(p['modulation_period_ms']/1000.)
    ph=2*math.pi*mid*t-(2*math.pi*dev/wm)*math.sin(wm*t)
    w=2*math.pi*(mid-dev*math.cos(wm*t))
    dw=2*math.pi*dev*wm*math.sin(wm*t);ddw=2*math.pi*dev*wm**2*math.cos(wm*t)
    sn=math.sin(ph);cs=math.cos(ph)
    return(H*sn,H*w*cs,H*(dw*cs-w*w*sn),H*((ddw-w**3)*cs-3*w*dw*sn),2)
# Analytic third-order scalar jets. Offline generation uses only Python stdlib.
# Entries are physical-time derivatives, not finite differences of integer counts.
class Jet:
    def __init__(self,v,d1=0.,d2=0.,d3=0.): self.d=tuple(float(x) for x in (v,d1,d2,d3))
    def __add__(self,o):
        o=o if isinstance(o,Jet) else Jet(o)
        return Jet(*(a+b for a,b in zip(self.d,o.d)))
    __radd__=__add__
    def __neg__(self):return Jet(*(-x for x in self.d))
    def __sub__(self,o):return self+(-o if isinstance(o,Jet) else -Jet(o))
    def __rsub__(self,o):return Jet(o)+(-self)
    def __mul__(self,o):
        o=o if isinstance(o,Jet) else Jet(o);a,b=self.d,o.d
        return Jet(a[0]*b[0],a[1]*b[0]+a[0]*b[1],
                   a[2]*b[0]+2*a[1]*b[1]+a[0]*b[2],
                   a[3]*b[0]+3*a[2]*b[1]+3*a[1]*b[2]+a[0]*b[3])
    __rmul__=__mul__
    def __truediv__(self,o):return self*(o**-1 if isinstance(o,Jet) else 1/o)
    def __pow__(self,p):
        a,b,c,d=self.d;f0=a**p
        f1=p*a**(p-1) if p!=0 else 0.
        f2=p*(p-1)*a**(p-2) if p not in (0,1) else 0.
        f3=p*(p-1)*(p-2)*a**(p-3) if p not in (0,1,2) else 0.
        return Jet(f0,f1*b,f2*b*b+f1*c,f3*b**3+3*f2*b*c+f1*d)
    def cos(self):
        a,b,c,d=self.d;sn=math.sin(a);cs=math.cos(a)
        return Jet(cs,-sn*b,-cs*b*b-sn*c,sn*b**3-3*cs*b*c-sn*d)

def smoothstep7(x):
    if x.d[0]<=0:return Jet(0.)
    if x.d[0]>=1:return Jet(1.)
    return x**4*(35+x*(-84+x*(70-20*x)))

def heart_upper_peak():
    left,right=0.,1.
    for _ in range(64):
        c=(left+right)/2
        if 19-4*c-24*c*c-32*c*c*c>0:left=c
        else:right=c
    c=(left+right)/2
    return 19*c-2*c*c-8*c**3-8*c**4
HEART_UPPER_PEAK=heart_upper_peak()

def heart_at(t,p):
    T=p['period_ms']/1000.;H=p['amplitude_degrees']
    if t<=0 or t>=T:return(0.,0.,0.,0.,2)
    tj=Jet(t,1.);s=2*tj/T-1;eps=p['upper_epsilon']
    rho=((s*s+eps*eps)**(1/3)-eps**(2/3))/((1+eps*eps)**(1/3)-eps**(2/3))
    c=(1-rho)**.5
    U=(19*c-2*c**2-8*c**3-8*c**4)*(p['upper_max_degrees']/HEART_UPPER_PEAK)
    eps=p['lower_epsilon']
    abs_s=((s*s+eps*eps)**.5-eps)/((1+eps*eps)**.5-eps)
    L=-H*(1-abs_s)**p['lower_power']
    gate_s=p['endpoint_gate_ms']/1000.
    gate=smoothstep7(tj/gate_s)*smoothstep7((T-tj)/gate_s)
    U=gate*U;L=gate*L
    ref=(U+L)*.5-(U-L)*.5*((2*math.pi*p['carrier_cycles'])*(tj/T-.5)).cos()
    return(*ref.d,2)

def heart_exit_envelope(t,T):
    return smoothstep7(Jet(t/T,1/T)).d

def numeric_limit(rows,erows,scale,base_deci):
    # Interpolation is convex between integer ROM entries, so these integer
    # maxima also cover every fractional phase and both entry/exit signs.
    mx=[max(abs(nearest(r[k]*scale*(65536 if k==0 else 256))) for r in rows) for k in range(4)]
    ew=[max(abs(nearest(r[k]*65536)) for r in erows) for k in range(4)]
    ew[0]=max(ew[0],65536)
    q,v,a,j=mx;w0,w1,w2,w3=ew
    numerators=[q*w0,(v*w0<<8)+q*w1,(a*w0<<8)+(v*w1<<9)+q*w2,
                (j*w0<<8)+3*(a*w1<<8)+3*(v*w2<<8)+q*w3]
    # Output derivatives are signed32 Q8. Retain 2% integer headroom for
    # arithmetic rounding. This is a representation limit, not a motor limit.
    derivative_limit=min((((2147483647<<24)-(1<<23))*base_deci)//max(1,n) for n in numerators[1:])
    limit=min(2147483647,derivative_limit*98//100)
    assert limit>=7200
    assert max(numerators)<(1<<63)
    return limit,{'rom_integer_max_abs':mx,'envelope_integer_max_abs':ew,
                  'product_numerator_bounds':numerators,'max_request_deci':limit,
                  'kind':'signed32 derivative representation only; no mechanical speed assertion'}
def main():
    cfg=json.loads((ROOT/'config/trajectory_profiles.json').read_text(encoding='utf-8'))
    if cfg.get('mode_assignment',{}).get('01')!='ordinary_AM' or cfg['mode_assignment'].get('10')!='sinusoidal_FM':
        raise ValueError('AM/FM mode assignment required')
    dt_ms=cfg['sample_ms'];dt=dt_ms/1000.;scale=cfg['engineering_units_per_turn']/360.
    if not isinstance(dt_ms,int) or dt_ms<=0 or cfg['engineering_units_per_turn']<=0:raise ValueError('Invalid sampling/units')
    # Keep the historical config key/ROM names for project compatibility.
    pa=cfg['am'];pf=cfg['fm'];pc=cfg['sine']
    for p,keys in [(pa,('carrier_period_ms','envelope_period_ms','ramp_ms')),(pf,('modulation_period_ms','ramp_ms')),(pc,('period_ms','ramp_ms'))]:
        if p['amplitude_degrees']<=0:raise ValueError('Positive base amplitude required')
        for k in keys:
            if not isinstance(p[k],int) or p[k]<=0 or p[k]%dt_ms:raise ValueError('Periods/ramps must align to sample_ms')
        if abs(p['amplitude_degrees']*10-nearest(p['amplitude_degrees']*10))>1e-8:raise ValueError('Base amplitude must align to0.1 degree')
    if not 0<pa['min_ratio']<1:raise ValueError('AM min_ratio must be between0and1')
    if pa['envelope_period_ms']%pa['carrier_period_ms']:raise ValueError('AM full pattern must have integer carrier cycles')
    if not 0<pf['min_frequency_hz']<=pf['max_frequency_hz']:raise ValueError('Positive FM frequency range required')
    # [LAST_FM修改] 调频周期30秒不变；相位须经过4个调频周期才闭合。
    from fractions import Fraction
    fm_cycles=(Fraction(str(pf['min_frequency_hz']))+Fraction(str(pf['max_frequency_hz'])))/2*Fraction(pf['modulation_period_ms'],1000)
    fm_repeat=fm_cycles.denominator
    fm_cycle_ms=pf['modulation_period_ms']*fm_repeat
    na=pa['envelope_period_ms']//dt_ms;nf=fm_cycle_ms//dt_ms
    # [EQ62修改] 56秒原曲线保持不变，另有6秒中心保持；总周期62秒。
    hold_ms=pc.get('between_heart_hold_ms',0)
    if not isinstance(hold_ms,int) or hold_ms<0 or hold_ms%dt_ms:raise ValueError('Hold must align to sample_ms')
    nc=pc['period_ms']//dt_ms;cycle_c=pc['period_ms']+hold_ms
    cycle_ticks=cycle_c//dt_ms
    ne=pc['ramp_ms']//dt_ms;nem=pa['ramp_ms']//dt_ms
    if pa['ramp_ms']!=pf['ramp_ms']:raise ValueError('AM/FM share an entry/exit envelope table')
    if max(na,nf,nc,cycle_ticks,ne,nem)>65534:raise ValueError('ROM sample count exceeds16-bit representation')
    arows=[am_at(i*dt,pa) for i in range(na)]
    frows=[fm_at(i*dt,pf) for i in range(nf)]
    # Heart carries its own C3 endpoint gate and has no additional entry fade.
    if not isinstance(pc['carrier_cycles'],int) or pc['carrier_cycles']<=0:raise ValueError('Heart requires a positive integer carrier count')
    if pc['period_ms'] != pc['carrier_period_ms']*pc['carrier_cycles']:raise ValueError('Heart carrier ratio does not close')
    if not 0<pc['upper_max_degrees']<=pc['amplitude_degrees']:raise ValueError('Invalid heart upper/absolute-amplitude ratio')
    if not 0<pc['lower_power']<1 or min(pc['upper_epsilon'],pc['lower_epsilon'])<=0:raise ValueError('Invalid heart smoothing')
    if not isinstance(pc['endpoint_gate_ms'],int) or not 0<pc['endpoint_gate_ms']<pc['period_ms']/2:raise ValueError('Invalid heart endpoint gate')
    amplitude=pc['amplitude_degrees']
    crows=[heart_at(i*dt,pc) for i in range(nc)]
    erows=[heart_exit_envelope(i*dt,pc['ramp_ms']/1000.) for i in range(ne+1)]
    mrows=[envelope(i*dt,pa['ramp_ms']/1000.) for i in range(nem+1)]
    for rows in (arows,frows,crows):
        for row in rows:
            for value,factor in zip(row[:4],(scale*65536,scale*256,scale*256,scale*256)):
                if not math.isfinite(value) or not -2147483648<=nearest(value*factor)<=2147483647:raise ValueError('Reference exceeds signed32 representation')
    for row in erows+mrows:
        if any(not math.isfinite(x) or not -2147483648<=nearest(x*65536)<=2147483647 for x in row):raise ValueError('Envelope exceeds signed32 Q16')
    cbounds={name:max(abs(r[k]) for r in crows) for k,name in enumerate(('position','velocity','acceleration','jerk'))}
    ba,bf,bc=(nearest(p['amplitude_degrees']*10) for p in (pa,pf,pc))
    maxa,proofa=numeric_limit(arows,mrows,scale,ba);maxf,prooff=numeric_limit(frows,mrows,scale,bf)
    maxc,proofc=numeric_limit(crows,erows,scale,bc)
    ab=arows+frows
    paths=[]
    for name,rows in [('ab',ab),('sine',crows)]:
        p=ROOT/f'rtl/trajectory_tables_{name}.mem';p.write_text(''.join(f'{pack_reference(row,scale):036X}\n' for row in rows),encoding='ascii');paths.append(p)
    ep=ROOT/'rtl/trajectory_tables_envelope.mem'
    cp=''.join(''.join(f'{u32(x*65536):08X}' for x in row)+'\n' for row in erows)
    mp=''.join(''.join(f'{u32(x*65536):08X}' for x in row)+'\n' for row in mrows)
    ep.write_text(cp+mp,encoding='ascii');paths.append(ep)
    # AM/FM table generation is unchanged. Their compatibility is verified
    # against the complete prior ab.mem in the release checks.
    # [EQ62修改] 保留原CF；CL明确上报实际62秒周期，旧56秒记录仍兼容。
    tag_cfg=json.loads(json.dumps(cfg));tag_cfg['sine'].pop('between_heart_hold_ms',None)
    tag=zlib.crc32(json.dumps(tag_cfg,sort_keys=True,separators=(',',':')).encode())&0xffffffff

    sempath=ROOT/'config/modulated_semantics.json'
    sem=json.loads(sempath.read_text(encoding='utf-8')) if sempath.exists() else {}
    tags=sem.setdefault('am_fm_tags',{})
    tags[f'{tag:08X}']={'am':{k:pa[k] for k in ('carrier_period_ms','envelope_period_ms','min_ratio','ramp_ms')},
                      'fm':{k:pf[k] for k in ('min_frequency_hz','max_frequency_hz','modulation_period_ms','ramp_ms')},
                      'default_deci':ba,'speed_estimator':{'id':'raw1040_window50_update10_alpha_half','window_ms':50,'update_ms':10,'iir_shift':1,'units':'engineering_units_per_second_q8'}}
    tags[f'{tag:08X}']['fm']['position_cycle_ms']=fm_cycle_ms
    tags[f'{tag:08X}']['fm']['modulation_repeats']=fm_repeat
    tags[f'{tag:08X}']['heart']={
        'period_ms':pc['period_ms'],'between_heart_hold_ms':hold_ms,'cycle_ms':cycle_c,'carrier_cycles':pc['carrier_cycles'],'carrier_period_ms':pc['carrier_period_ms'],
        'base_max_degrees':pc['amplitude_degrees'],'upper_max_degrees':pc['upper_max_degrees'],
        'upper_epsilon':pc['upper_epsilon'],'lower_epsilon':pc['lower_epsilon'],'lower_power':pc['lower_power'],
        'endpoint_gate_ms':pc['endpoint_gate_ms'],'exit_ramp_ms':pc['ramp_ms'],
        'amplitude_semantics':'signed maximum absolute displacement; positive draws the heart tip downward',
        'entry_ramp_ms':0,'time_stretch':1}
    sem['am_fm_tags']={k:tags[k] for k in sorted(tags)}
    sempath.write_text(json.dumps(sem,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    h=f'''// Generated by scripts/generate_trajectory_tables.py; synchronous periodic ROMs.
module trajectory_tables(
 input wire clk,input wire [1:0] profile,input wire [15:0] sample_index,envelope_index,
 output reg signed [31:0] q16,v8,a8,j8,w0,w1,w2,w3,
 output reg [7:0] sample_phase,
 output wire [15:0] leg_ticks,dwell_ticks,sine_ticks,envelope_ticks,
 output wire [31:0] profile_cycle_ms,sample_ms,config_tag,base_deci,max_request_deci,units_per_turn,
 output wire signed [31:0] stroke_units,stroke_q16
);
 localparam integer A_COUNT={na},F_COUNT={nf},C_COUNT={nc},EC_COUNT={ne+1},EM_COUNT={nem+1};
 reg [143:0] ab_rom[0:A_COUNT+F_COUNT-1];
 reg [143:0] sine_rom[0:C_COUNT-1];
 reg [127:0] env_rom[0:EC_COUNT+EM_COUNT-1];
 reg [143:0] ab_value,sine_value;reg [127:0] env_value;
 initial begin
  $readmemh("rtl/trajectory_tables_ab.mem",ab_rom);
  $readmemh("rtl/trajectory_tables_sine.mem",sine_rom);
  $readmemh("rtl/trajectory_tables_envelope.mem",env_rom);
 end
 wire [16:0] ab_address=profile==2 ? sample_index+A_COUNT : sample_index;
 wire [16:0] env_address=profile==3 ? envelope_index : envelope_index+EC_COUNT;
 always @(posedge clk)begin
  ab_value<=ab_rom[ab_address<A_COUNT+F_COUNT ? ab_address : 0];
  sine_value<=sine_rom[sample_index<C_COUNT ? sample_index : 0];
  env_value<=env_rom[env_address<EC_COUNT+EM_COUNT ? env_address : 0];
 end
 always @*begin
  if(profile==3)begin {{sample_phase,q16,v8,a8,j8}}=sine_value[135:0];end
  else begin {{sample_phase,q16,v8,a8,j8}}=ab_value[135:0];end
  {{w0,w1,w2,w3}}=env_value;
 end
 // "sine_ticks" is the retained API name for the selected periodic table.
 assign leg_ticks=16'd0;assign dwell_ticks=16'd0;
 assign sine_ticks=profile==3 ? 16'd{cycle_ticks} : (profile==2 ? 16'd{nf} : 16'd{na});
 assign envelope_ticks=profile==3 ? 16'd{ne} : 16'd{nem};
 assign sample_ms=32'd{dt_ms};assign config_tag=32'h{tag:08X};
 assign profile_cycle_ms=profile==3 ? 32'd{cycle_c} : (profile==2 ? 32'd{fm_cycle_ms} : 32'd{pa['envelope_period_ms']});
 assign stroke_units=profile==3 ? 32'sd{nearest(amplitude*2*scale)} : (profile==2 ? 32'sd{nearest(pf['amplitude_degrees']*2*scale)} : 32'sd{nearest(pa['amplitude_degrees']*2*scale)});
 assign stroke_q16=profile==3 ? 32'sd{nearest(amplitude*2*scale*65536)} : (profile==2 ? 32'sd{nearest(pf['amplitude_degrees']*2*scale*65536)} : 32'sd{nearest(pa['amplitude_degrees']*2*scale*65536)});
 assign base_deci=profile==3 ? 32'd{bc} : (profile==2 ? 32'd{bf} : 32'd{ba});
 assign max_request_deci=profile==3 ? 32'd{maxc} : (profile==2 ? 32'd{maxf} : 32'd{maxa});
 assign units_per_turn=32'd{int(cfg['engineering_units_per_turn'])};
endmodule
'''
    (ROOT/'rtl/trajectory_tables.v').write_text(h,encoding='utf-8');paths.append(ROOT/'rtl/trajectory_tables.v')
    # [EQ62修改] 仅无损压缩存储字段；读出恢复原32位，点数/读延迟不变。
    from rom_lossless import compress_tables
    packing=compress_tables(ROOT)
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    report={'config_tag':f'{tag:08X}','sample_ms':dt_ms,
        'am_carrier_period_ms':pa['carrier_period_ms'],'am_envelope_period_ms':pa['envelope_period_ms'],
        'fm_phase_closed':True,'fm_cycles_per_modulation':float(fm_cycles),'fm_modulation_repeats':fm_repeat,'fm_position_cycle_ms':fm_cycle_ms,
        'fm_modulation_period_ms':pf['modulation_period_ms'],'fm_frequency_range_hz':[pf['min_frequency_hz'],pf['max_frequency_hz']],
        'am_fm_ramp_ms':pa['ramp_ms'],'heart_shape_ms':pc['period_ms'],'heart_hold_ms':hold_ms,'heart_cycle_ms':cycle_c,'heart_exit_ramp_ms':pc['ramp_ms'],
        'heart_base_peak_samples_degrees':cbounds,
        'mode11_replaces_sine_with_heart':True,
        'raw_rom_bits':(len(ab)+len(crows))*144+(len(erows)+len(mrows))*128,'lossless_packing':packing,
        'rom_points':{'ab':len(ab),'sine':len(crows),'envelope':len(erows)+len(mrows)},
        'runtime_angle_semantics':'signed maximum AM envelope / fixed FM amplitude / maximum absolute heart displacement',
        'runtime_base_deci':{'am':ba,'fm':bf,'sine':bc},
        'runtime_time_scaling':{'am':'fixed TM1','fm':'fixed TM1','heart':'fixed TM1'},
        'am_numeric_representation_proof':proofa,'fm_numeric_representation_proof':prooff,'heart_numeric_representation_proof':proofc,
        'trajectory_math_only':True,'hardware_tested':False,
        'rom_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in paths},
        'modulated_semantics_file':'config/modulated_semantics.json','modulated_semantics_sha256':sha(sempath)}
    (ROOT/'config/trajectory_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()

"""Validate final v8.6 build/test provenance, then package source and firmware.

No programmer, serial port, source mutation, or external network is used.
Run after both Gowin builds and all final RTL/monitor checks have completed.
package_summary.json is an external archive receipt (not an archive member),
so the ZIP SHA256 does not create a self-referential hash.
"""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT.parent/'J280_AllModes_v8_6_前馈与监测完整包.zip'
MANIFEST=ROOT/'file_manifest_sha256.json'
RECEIPT=ROOT/'package_summary.json'
VERIFICATION=ROOT/'reports/final_verification_summary.json'
BUILD_NAMES={
 'feedforward':'allmodes_v8_6_feedforward_build_summary.json',
 'zeroff':'allmodes_v8_6_zeroff_build_summary.json',
}
TEST_NAMES=(
 'ff_arithmetic_result.json','ff_control_result.json','fastspeed_result.json',
 'ffmonitor_uart_result.json','ffmonitor_host_result.json',
 'ffmonitor_regression_result.json','ff_normalizer_result.json','ff_top_result.json',
)
HASH_KEYS=('sourceSha256','input_sha256','hashes','source_sha256')
MUTATION_HELPERS={
 'ffmonitor_edit.py','ffmonitor_host_edit.py','ffmonitor_uart_make.py',
 'ffmonitor_finalize.py','amfm_make_pair.py',
}
SHA_RE=re.compile(r'[0-9a-fA-F]{64}\Z')

def require(condition,message):
    if not condition:raise ValueError(message)

def digest(path):
    with Path(path).open('rb') as stream:
        h=hashlib.sha256()
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def checked_file(path):
    path=Path(path)
    require(path.is_file(),f'Missing required file: {path}')
    resolved=path.resolve()
    require(resolved.is_relative_to(ROOT.resolve()),f'File escapes project root: {path}')
    require(not path.is_symlink(),f'Symbolic-link files are not packaged: {path}')
    return path

def load_json(path):
    checked_file(path)
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    require(isinstance(data,dict),f'Expected JSON object: {path}')
    return data

def relative(path):
    return Path(path).relative_to(ROOT).as_posix()

def normalize_hashes(data):
    require(isinstance(data,dict) and data,'Build has no source hash map')
    result={}
    for raw,value in data.items():
        require(isinstance(raw,str) and isinstance(value,str) and SHA_RE.fullmatch(value),
                f'Invalid source hash entry: {raw!r}')
        key=raw.replace('\\','/')
        p=PurePosixPath(key)
        require(not p.is_absolute() and '..' not in p.parts and ':' not in key,
                f'Unsafe source key: {raw}')
        require(key not in result,f'Duplicate normalized source key: {key}')
        result[key]=value.lower()
    return result

def expected_build_inputs():
    result=[ROOT/'J280_Pendulum.gprj',ROOT/'scripts/generate_trajectory_tables.py',
            ROOT/'impl/J280_Pendulum_process_config.json']
    result.extend(p for p in (ROOT/'rtl').iterdir() if p.suffix.lower() in {'.v','.vh','.mem'})
    result.extend(p for p in (ROOT/'constraints').iterdir() if p.is_file())
    result.extend((ROOT/'config').glob('*.json'))
    return {relative(checked_file(p)):digest(p) for p in sorted(result)}

def validate_timing(label,data):
    require(data.get('exit_code')==0,f'{label}: compiler did not exit successfully')
    require(data.get('setup_violations')==0 and data.get('hold_violations')==0,
            f'{label}: setup/hold violations are not both zero')
    summary=data.get('frequency_summary')
    require(isinstance(summary,list),f'{label}: missing clock-frequency summary')
    values=[float(m.group(1)) for item in summary if isinstance(item,str)
            and (m:=re.fullmatch(r'([\d.]+)\(MHz\)',item))]
    require(len(values)>=2 and len(values)%2==0,f'{label}: incomplete frequency pairs')
    require(all(0<values[i]<=values[i+1] for i in range(0,len(values),2)),
            f'{label}: actual Fmax is below its constraint')
    return {'setup_violations':0,'hold_violations':0,'frequency_summary':summary}

def production_file_for_hash(key):
    if not isinstance(key,str):return None
    raw=key.replace('\\','/')
    p=Path(raw)
    if p.is_absolute():
        try:raw=p.resolve().relative_to(ROOT.resolve()).as_posix()
        except ValueError:return None
    if raw.startswith(('rtl/','monitor/')):
        target=ROOT/raw
        return target if target.is_file() else None
    if '/' not in raw:
        candidates=[p for folder in ('rtl','monitor') for p in (ROOT/folder).rglob(raw)
                    if p.is_file() and p.name==raw and '__pycache__' not in p.parts]
        require(len(candidates)<=1,f'Ambiguous production basename in a test hash map: {raw}')
        return candidates[0] if candidates else None
    return None

def validate_tests():
    checks={}
    for name in TEST_NAMES:
        path=ROOT/'tests'/name
        data=load_json(path)
        require(data.get('success') is True,f'Test not successful: {name}')
        count=0
        for kind in HASH_KEYS:
            mapping=data.get(kind)
            if not isinstance(mapping,dict):continue
            for key,expected in mapping.items():
                target=production_file_for_hash(key)
                if target is None:continue
                checked_file(target)
                require(isinstance(expected,str) and SHA_RE.fullmatch(expected),
                        f'{name}: invalid production hash for {key}')
                require(digest(target)==expected.lower(),
                        f'{name}: stale production source hash: {relative(target)}')
                count+=1
        if name!='ffmonitor_host_result.json':
            require(count>0,f'{name}: no matching current production hashes found')
        checks[name]={'success':True,'production_hash_entries_verified':count,
                      'report_sha256':digest(path)}
    return checks

def validate_builds(current):
    checks={};reports={}
    for label,name in BUILD_NAMES.items():
        reports[label]=load_json(ROOT/'reports'/name)
        checks[label]=validate_timing(label,reports[label])
    main=normalize_hashes(reports['feedforward'].get('source_sha256'))
    zero=normalize_hashes(reports['zeroff'].get('source_sha256'))
    require(main==current,'Main build source provenance does not match all current build inputs')
    require(set(zero)==set(current),'ZeroFF build source-key set differs from current build inputs')
    top='rtl/j280_pendulum_top.v'
    original=(ROOT/top).read_bytes()
    pattern=rb'(parameter\s+integer\s+LOCATION_AFF_Q16\s*=\s*)16384\b'
    converted,count=re.subn(pattern,rb'\g<1>0',original)
    require(count==1,'Main top must have exactly one LOCATION_AFF_Q16=16384 declaration')
    expected_zero=dict(current);expected_zero[top]=hashlib.sha256(converted).hexdigest()
    require(zero==expected_zero,
            'ZeroFF build must differ only by LOCATION_AFF_Q16=16384 -> 0 in top')
    firmware={}
    candidates=list((ROOT/'bitstream').glob('*.fs'))
    for label,data in reports.items():
        expected=data.get('bitstream_sha256')
        require(isinstance(expected,str) and SHA_RE.fullmatch(expected),f'{label}: invalid firmware hash')
        found=[checked_file(p) for p in candidates if digest(p)==expected.lower()]
        require(found,f'{label}: no firmware copied into bitstream/ matches its build digest')
        # Prefer an explicitly named zero/base image if duplicate copies exist.
        if label=='zeroff':
            found.sort(key=lambda p:(not any(k in p.stem.lower() for k in ('zero','ff0','baseline')),p.name))
        else:
            found.sort(key=lambda p:(any(k in p.stem.lower() for k in ('zero','ff0','baseline')),p.name))
        firmware[label]=found[0]
        checks[label].update({'source_sha256':main if label=='feedforward' else zero,
            'bitstream':relative(found[0]),'bitstream_sha256':expected.lower(),
            'build_summary_sha256':digest(ROOT/'reports'/BUILD_NAMES[label]),
            'hardware_tested':data.get('hardware_tested',False)})
    require(firmware['feedforward']!=firmware['zeroff'],'Main and ZeroFF need distinct copied firmware files')
    return checks,firmware

def include(path,firmware):
    rel=relative(path);parts=PurePosixPath(rel).parts;name=path.name;low=name.lower()
    if any(part in {'__pycache__','records','_offline_tests','_sim_temp','.git'} for part in parts):return False
    if path.suffix.lower() in {'.csv','.pyc','.pyo','.vvp','.wasm'}:return False
    if name in MUTATION_HELPERS:return False
    if low.endswith(('_edit.py','_make.py','_finalize.py')):return False
    if len(parts)==1:
        return name in {'J280_Pendulum.gprj','Build_Auto.cmd','baseline_info.json'} or path.suffix.lower() in {'.md','.cmd'}
    first=parts[0]
    if first=='impl':return rel=='impl/J280_Pendulum_process_config.json'
    if first=='bitstream':return path in firmware.values()
    if first in {'rtl','constraints','settings','config'}:return True
    if first=='monitor':
        if path.suffix.lower() in {'.log','.json'} and parts[1]!='fixtures':return False
        return True
    if first=='scripts':
        return name in {'build.tcl','build_checked.py','generate_trajectory_tables.py','package_v86.py',
                        'plot_amfm_reference.py','plot_trajectory_comparison.py'}
    if first=='tests':
        if len(parts)!=2:return False
        if name.endswith('_result.json'):
            return name.startswith(('ff','fastspeed','trajectory_generation'))
        if path.suffix.lower()=='.json':
            return name.startswith(('ff','fastspeed','trajectory_generation'))
        if path.suffix.lower() in {'.sv','.v','.mjs','.py'}:return True
        if path.suffix.lower()=='.txt':return name in {'ffmonitor_x_fixture.txt','ffmonitor_z_fixture.txt','unified_uart_fixture.txt'}
        return False
    if first=='reports':
        if rel=='reports/final_verification_summary.json':return True
        if name=='trajectory_generation.log':return True
        return any(name==stem+ending for stem in ('allmodes_v8_6_feedforward','allmodes_v8_6_zeroff')
                   for ending in ('_build_summary.json','_timing.txt','_gowin_build.log'))
    return False

def safe_archive_name(name):
    p=PurePosixPath(name)
    require('\\' not in name and ':' not in name and not p.is_absolute()
            and '..' not in p.parts and '.' not in p.parts,f'Unsafe ZIP path: {name}')
    require(len(p.parts)>1 and p.parts[0]==ROOT.name,f'Unexpected ZIP root: {name}')

def write_json(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def run(check_only=False):
    current=expected_build_inputs()
    builds,firmware=validate_builds(current)
    tests=validate_tests()
    verification={'success':True,'created_local':datetime.now().astimezone().isoformat(),
        'builds':builds,'tests':tests,'source_hashes_match_current':True,
        'zeroff_only_changes_coefficient':True,'hardware_tested':False,
        'scope':'Native Gowin setup/hold/Fmax and source/firmware provenance; real RTL simulation and offline monitor checks. No mechanical or hardware validation.'}
    if check_only:
        print(json.dumps({'success':True,'check_only':True,'builds':list(builds),'tests':list(tests)},ensure_ascii=False,indent=2))
        return
    write_json(VERIFICATION,verification)
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and include(p,firmware))
    require(files,'No package payload files selected')
    for path in files:checked_file(path)
    require(all(path in files for path in firmware.values()),'Firmware omitted from package payload')
    hashes={relative(p):digest(p) for p in files}
    manifest={'format':1,'algorithm':'sha256','archive_root':ROOT.name,'files':hashes,
              'self_excluded':'file_manifest_sha256.json',
              'external_receipt':'package_summary.json (not in ZIP to avoid self-referential archive hash)'}
    write_json(MANIFEST,manifest)
    manifest_sha=digest(MANIFEST)
    archive_files=files+[MANIFEST]
    names={ROOT.name+'/'+relative(p):p for p in archive_files}
    require(len(names)==len(archive_files),'Duplicate archive path')
    temporary=ARCHIVE.with_name(ARCHIVE.name+'.partial')
    try:
        with zipfile.ZipFile(temporary,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
            for name,path in sorted(names.items()):
                safe_archive_name(name);archive.write(path,name)
        with zipfile.ZipFile(temporary,'r') as archive:
            members=archive.namelist()
            require(len(set(members))==len(members),'Duplicate ZIP members')
            require(set(members)==set(names),'ZIP membership differs from selected payload')
            for name in members:safe_archive_name(name)
            require(archive.testzip() is None,'ZIP CRC integrity failure')
            manifest_name=ROOT.name+'/file_manifest_sha256.json'
            packed_manifest=archive.read(manifest_name)
            require(hashlib.sha256(packed_manifest).hexdigest()==manifest_sha,'Manifest changed while packaging')
            require(json.loads(packed_manifest)==manifest,'Packed manifest differs from verified manifest')
            for rel,expected in hashes.items():
                require(hashlib.sha256(archive.read(ROOT.name+'/'+rel)).hexdigest()==expected,
                        f'ZIP member hash mismatch: {rel}')
        # Catch files edited by a concurrent build or editor during packaging.
        for path in files:
            require(digest(path)==hashes[relative(path)],f'Payload changed while packaging: {relative(path)}')
        require(digest(MANIFEST)==manifest_sha,'Manifest changed during archive verification')
        os.replace(temporary,ARCHIVE)
    except BaseException:
        if temporary.exists():temporary.unlink()
        raise
    receipt={'success':True,'created_local':datetime.now().astimezone().isoformat(),
        'archive_path':str(ARCHIVE),'archive_sha256':digest(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,
        'archive_root':ROOT.name,'archive_file_count':len(names),'manifest_sha256':manifest_sha,
        'verified_members':len(names),'zip_paths_safe':True,'zip_crc_verified':True,
        'zip_hashes_verified':True,'payload_unchanged_during_package':True,
        'source_and_firmware_provenance_verified':True,'hardware_tested':False,
        'builds':{k:{f:v[f] for f in ('setup_violations','hold_violations','frequency_summary','bitstream','bitstream_sha256')} for k,v in builds.items()},
        'test_reports':list(tests),'verification_summary':'reports/final_verification_summary.json',
        'receipt_is_external_to_zip':True}
    write_json(RECEIPT,receipt)
    print(json.dumps(receipt,ensure_ascii=False,indent=2))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-only',action='store_true',help='Validate gates without writing any files or ZIP')
    args=parser.parse_args()
    try:run(args.check_only)
    except (OSError,ValueError,KeyError,zipfile.BadZipFile) as exc:
        print('PACKAGE BLOCKED: '+str(exc),file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':raise SystemExit(main())

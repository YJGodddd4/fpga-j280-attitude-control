"""Exact signed-field packing; no resampling, rounding, timing, or value changes."""
from pathlib import Path
import re,json,hashlib

def compress_tables(root):
    root=Path(root); layouts={}; reports={}; decoded={}
    for name in ['ab','sine','envelope']:
        path=root/f'rtl/trajectory_tables_{name}.mem'
        words=[int(x,16) for x in path.read_text().split()]
        logical_rows=len(words);fm_half=0
        if name=='ab':
            header=(root/'rtl/trajectory_tables.v').read_text()
            a_count=int(re.search(r'A_COUNT=(\d+)',header)[1])
            f_count=int(re.search(r'F_COUNT=(\d+)',header)[1])
            if f_count==12000:
                # [LAST_FM修改] 后60秒恰为前60秒逐字段取反，无损省去一半FM存储。
                fm_half=f_count//2
                for first,second in zip(words[a_count:a_count+fm_half],words[a_count+fm_half:]):
                    assert first>>128==second>>128
                    for shift in [96,64,32,0]:
                        assert (((first>>shift)&0xffffffff)+((second>>shift)&0xffffffff))&0xffffffff==0
                words=words[:a_count+fm_half]

        fields=['w0','w1','w2','w3'] if name=='envelope' else ['phase','q16','v8','a8','j8']
        shifts=[96,64,32,0] if name=='envelope' else [128,96,64,32,0]
        values=[];widths=[];phase_bias=0
        for key,shift in zip(fields,shifts):
            raw=[(w>>shift)&(255 if key=='phase' else 0xffffffff) for w in words]
            v=raw if key=='phase' else [x if x<2**31 else x-2**32 for x in raw]
            # [LAST_FM修改] 全表阶段恒为2，存0并在读出加2；保持全部接口位。
            if key=='phase' and set(v)=={2}:phase_bias=2;v=[0]*len(v)
            bits=(max(v).bit_length() or 1) if key=='phase' else next(b for b in range(1,33) if min(v)>=-(1<<(b-1)) and max(v)<(1<<(b-1)))
            values.append(v);widths.append(bits)
        packed=[]
        for row in zip(*values):
            word=0
            for v,bits in zip(row,widths):word=(word<<bits)|(v&((1<<bits)-1))
            packed.append(word)
        for i,word in enumerate(packed):
            left=sum(widths)
            for key,bits,v in zip(fields,widths,values):
                left-=bits;x=(word>>left)&((1<<bits)-1)
                if key!='phase' and x>=(1<<(bits-1)):x-=1<<bits
                assert x==v[i],(name,i,key)
        total=sum(widths);digits=(total+3)//4
        path.write_text(''.join(f'{w:0{digits}X}\n' for w in packed),encoding='ascii')
        layouts[name]=(fields,widths,total)
        reports[name]={'rows':len(words),'packed_bits':total,'fields':dict(zip(fields,widths)),
            'phase_bias':phase_bias,'logical_rows':logical_rows,'fm_half_ticks':fm_half,'all_fields_roundtrip_exact':True,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

    p=root/'rtl/trajectory_tables.v';s=p.read_text()
    ab=layouts['ab'][2];c=layouts['sine'][2];env=layouts['envelope'][2]
    s=s.replace('reg [143:0] ab_rom',f'reg [{ab-1}:0] ab_rom')
    s=s.replace('reg [143:0] sine_rom',f'reg [{c-1}:0] sine_rom')
    s=s.replace('reg [127:0] env_rom',f'reg [{env-1}:0] env_rom')
    s=s.replace('reg [143:0] ab_value,sine_value;reg [127:0] env_value;',f'reg [{ab-1}:0] ab_value;reg [{c-1}:0] sine_value;reg [{env-1}:0] env_value;')
    def assignments(name):
        fields,widths,total=layouts[name];left=total;lines=[]
        for key,bits in zip(fields,widths):
            left-=bits;part=f'{name if name!="envelope" else "env"}_value[{left+bits-1}:{left}]'
            if key=='phase':lines.append(f"    sample_phase=8'd{reports[name]['phase_bias']}+{part};")
            else:lines.append(f'    {key}=$signed({part});')
        return '\n'.join(lines)
    old='''  if(profile==3)begin {sample_phase,q16,v8,a8,j8}=sine_value[135:0];end
  else begin {sample_phase,q16,v8,a8,j8}=ab_value[135:0];end
  {w0,w1,w2,w3}=env_value;'''
    assert old in s
    new='''  // [EQ62修改] 同步读延迟不变，窄存储在运算前符号扩展回原32位。
  if(profile==3)begin
'''+assignments('sine')+'\n  end else begin\n'+assignments('ab')+'\n  end\n'+assignments('envelope')
    s=s.replace(old,new)
    s=s.replace('// "sine_ticks" is the retained API name for the selected periodic table.',
        '// [EQ62修改] 心形数据仍为5600点；其后600点回读零起点，保留6秒中心保持。\n // "sine_ticks" is the retained API name for the selected periodic table.')
    if reports['ab']['fm_half_ticks']:
        half=reports['ab']['fm_half_ticks']
        s=s.replace('\n reg [',f'\n localparam integer F_STORE_COUNT={half}; // [LAST_FM修改] 半波反相无损复用\n reg [',1)
        s=s.replace('ab_rom[0:A_COUNT+F_COUNT-1]','ab_rom[0:A_COUNT+F_STORE_COUNT-1]')
        s=s.replace(' always @(posedge clk)begin',""" wire ab_negative_read=(ab_address>=A_COUNT+F_STORE_COUNT && ab_address<A_COUNT+F_COUNT);
 wire [16:0] ab_storage_address=ab_negative_read ? ab_address-F_STORE_COUNT : ab_address;
 reg ab_negative;
 always @(posedge clk)begin
  ab_negative<=ab_negative_read;""",1)
        s=s.replace('ab_address<A_COUNT+F_COUNT ? ab_address : 0','ab_address<A_COUNT+F_COUNT ? ab_storage_address : 0')
        needle='\n  end\n'
        pos=s.index(needle,s.index('  end else begin'))
        s=s[:pos]+"""
    if(ab_negative)begin q16=-q16;v8=-v8;a8=-a8;j8=-j8;end // [LAST_FM修改]
"""+s[pos:]
    p.write_text(s,encoding='utf-8')

    return reports

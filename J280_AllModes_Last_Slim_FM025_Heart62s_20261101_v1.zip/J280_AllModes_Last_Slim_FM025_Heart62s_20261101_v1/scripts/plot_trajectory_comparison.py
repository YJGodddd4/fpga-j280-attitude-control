"""Plot shipped planned references against the uploaded v8.3 analytic baseline.

No serial, hardware, measured speed, or display filtering is used. New A/B
curves are decoded from the shipped Q16/Q8 ROMs. Old A/B equations use frozen
v8.3 parameters independently. Position is shown before final integer-R
rounding, relative to the reference held at SW4 start. English figure labels
keep the output portable across machines without Chinese fonts.
"""
from pathlib import Path
import json, math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
REPORTS=ROOT/'reports'


def signed32(x):
    x=x&0xffffffff
    return x-0x100000000 if x&0x80000000 else x


def integrate_constant_stages(t,stages,jerk_control):
    """Independent integration of baseline acceleration/jerk intervals."""
    q=v=a=0.0
    for control,duration in stages:
        span=min(max(t,0),duration)
        if jerk_control:
            q+=v*span+a*span**2/2+control*span**3/6
            v+=a*span+control*span**2/2
            a+=control*span
        else:
            q+=v*span+control*span**2/2
            v+=control*span
            a=control
        t-=duration
        if t<0:
            return q,v
    return 180.,0.


def old_ab(t,seven_s=False):
    # Uploaded v8.3: full leg4.5s, dwell0.5s, independent center->+90
    # first slot5s, then +90 <-> -90 at10s per round trip.
    stages=([(120.,.5),(0.,.5),(-120.,.5),(0.,1.5),(-120.,.5),(0.,.5),(120.,.5)]
            if seven_s else [(40.,1.5),(0.,1.5),(-40.,1.5)])
    if t<4.5:
        q,v=integrate_constant_stages(t,stages,seven_s)
        return q/2,v/2
    if t<5:
        return 90.,0.
    t=(t-5)%10
    if t<4.5:
        q,v=integrate_constant_stages(t,stages,seven_s)
        return 90-q,-v
    if t<5:
        return -90.,0.
    if t<9.5:
        q,v=integrate_constant_stages(t-5,stages,seven_s)
        return q-90,v
    return 90.,0.


def main():
    cfg=json.loads((ROOT/'config/trajectory_profiles.json').read_text(encoding='utf-8'))
    vr=json.loads((ROOT/'config/trajectory_validation.json').read_text(encoding='utf-8'))
    scale=360/cfg['engineering_units_per_turn']
    dt=cfg['sample_ms']/1000
    raw=[int(s,16) for s in (ROOT/'rtl/trajectory_tables_ab.mem').read_text().splitlines()]
    n=vr['trapezoid_leg_ms']//cfg['sample_ms']+1
    blocks=[raw[:n],raw[n:]]
    data=[]
    for block in blocks:
        data.append(np.array([(signed32(x>>96)*scale/65536,signed32(x>>64)*scale/256,
                               signed32(x>>32)*scale/256,signed32(x)*scale/256) for x in block]))
    def new_ab(t,index):
        name=['trapezoid','s_curve'][index]
        leg=vr[name+'_leg_ms']/1000
        dwell=cfg[name]['dwell_ms']/1000
        cycle=2*(leg+dwell)
        t=t%cycle
        reverse=t>=leg+dwell
        local=t-(leg+dwell) if reverse else t
        q=np.interp(min(local,leg),np.arange(len(data[index]))*dt,data[index][:,0])
        v=np.interp(min(local,leg),np.arange(len(data[index]))*dt,data[index][:,1])
        if local>=leg: v=0
        return (180-q,-v) if reverse else (q,v)
    def sine(t,period,ramp):
        u=min(t/ramp,1)
        w=10*u**3-15*u**4+6*u**5
        wd=(30*u**2-60*u**3+30*u**4)/ramp if t<ramp else 0
        omega=2*math.pi/period
        q0=90*math.sin(omega*t)
        return q0*w,90*omega*math.cos(omega*t)*w+q0*wd
    time=np.linspace(0,26,13001)
    old=[np.array([old_ab(t,k==1) for t in time]) for k in range(2)]
    new=[np.array([new_ab(t,k) for t in time]) for k in range(2)]
    old.append(np.array([sine(t,10.,6.) for t in time]))
    new.append(np.array([sine(t,cfg['sine']['period_ms']/1000,cfg['sine']['ramp_ms']/1000) for t in time]))
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':11,
                         'axes.titlesize':12,'axes.spines.top':False,'axes.spines.right':False,
                         'figure.facecolor':'white','savefig.facecolor':'white'})
    fig,axs=plt.subplots(3,2,figsize=(14,12),sharex=True,layout='constrained')
    colors=['#65758B','#CF5C22']
    names=['A | Rounded trapezoid','B | Seven-segment S','C | Sine scan']
    for k,name in enumerate(names):
        for col,(field,ylabel) in enumerate([(1,'Planned velocity (deg/s)'),(0,'Displacement from held start (deg)')]):
            ax=axs[k,col]
            ax.plot(time,old[k][:,field],color=colors[0],lw=1.6,ls='--',label='Uploaded v8.3 | 10 s cycle')
            ax.plot(time,new[k][:,field],color=colors[1],lw=1.8,label='New v8.4 | 7 s cycle')
            ax.axhline(0,color='#9AA5B1',lw=.6)
            ax.grid(True,color='#E2E7ED',lw=.7)
            ax.set_title(name+(' | Velocity' if col==0 else ' | Position'),loc='left',fontweight='bold')
            ax.set_ylabel(ylabel)
            ax.set_xlim(0,26)
            ax.set_xticks(np.arange(0,27,2))
            ax.axvline(7,color=colors[1],lw=.65,alpha=.5)
            ax.axvline(14,color=colors[1],lw=.65,alpha=.5)
            if k<2:
                ax.axvspan(0,5,color=colors[0],alpha=.07)
            else:
                ax.axvspan(0,6,color=colors[0],alpha=.07)
        axs[k,0].set_ylim(-105,125)
        axs[k,1].set_ylim((-115,205) if k<2 else (-110,110))
    axs[0,0].legend(loc='lower right',frameon=True,fontsize=9)
    axs[0,1].legend(loc='lower right',frameon=True,fontsize=9)
    axs[0,1].annotate('First full 180 deg stroke\nends at 3.15 s',xy=(3.15,180),xytext=(8,167),
                      arrowprops={'arrowstyle':'->','color':colors[1]},color=colors[1],fontsize=10)
    axs[0,1].annotate('Old first 90 deg half stroke',xy=(4.5,90),xytext=(7,40),
                      arrowprops={'arrowstyle':'->','color':colors[0]},color=colors[0],fontsize=9)
    axs[1,0].text(.02,.97,'A: 70 ms jerk corners | B: 350 ms jerk ramps\nBoth: continuous velocity and acceleration',
                   transform=axs[1,0].transAxes,va='top',fontsize=9,
                   bbox={'facecolor':'white','edgecolor':'#DEE4EB','alpha':.94,'pad':5})
    axs[2,1].text(.02,.96,'Sine keeps the 6 s entry envelope.\nCycle shrinks from 10 s to 7 s.',
                   transform=axs[2,1].transAxes,va='top',fontsize=9,
                   bbox={'facecolor':'white','edgecolor':'#DEE4EB','alpha':.94,'pad':5})
    for ax in axs[-1,:]: ax.set_xlabel('Time since reference start (s)')
    fig.suptitle('J280 | Planned trajectory comparison\n30% shorter round trip; A/B start with the full stroke',
                 fontsize=19,fontweight='bold')
    fig.supxlabel('TA = +90 deg (A/B full stroke = 180 deg). Planned references before final integer-R rounding.\n'
                  'Faster motion raises peak speed: A/B 60 -> 85.71 deg/s; sine steady peak 56.55 -> 80.78 deg/s.\n'
                  'These curves are not measured motor speed or a claim of mechanical tracking accuracy.',fontsize=10)
    REPORTS.mkdir(exist_ok=True)
    out=REPORTS/'trajectory_velocity_comparison.png'
    fig.savefig(out,dpi=180)
    plt.close(fig)
    metrics={
        'config_tag':vr['config_tag'],
        'scope':'Planned continuous baseline versus shipped new ROM, before integer-R position rounding; no plant or hardware measurements',
        'baseline_cycle_seconds':10,'new_cycle_seconds':7,
        'old_ab_initial_half_leg_seconds':4.5,'old_ab_initial_slot_including_dwell_seconds':5,
        'new_ab_first_full_leg_seconds':3.15,'new_ab_slot_including_dwell_seconds':3.5,
        'ab_peak_velocity_degrees_s':{'old':60.,'new':cfg['trapezoid']['velocity_degrees_s']},
        'sine_steady_peak_velocity_degrees_s':{'old':90*2*math.pi/10,'new':90*2*math.pi/7},
        'ab_smoothness':'Underlying analytic plan: position C2 and velocity C1; acceleration continuous and Lipschitz; jerk finite piecewise constant with boundary steps, not C1 acceleration. Emitted fixed-point samples and final integer position retain quantization.',
        'trapezoid_peak_acceleration_degrees_s2':{'old':40.,'new':cfg['trapezoid']['acceleration_degrees_s2']},
        's_curve_peak_acceleration_degrees_s2':{'old':60.,'new':cfg['s_curve']['acceleration_degrees_s2']},
        'trapezoid_peak_jerk_degrees_s3':{'old':'unbounded at ideal acceleration switches','new':cfg['trapezoid']['jerk_degrees_s3']},
        's_curve_peak_jerk_degrees_s3':{'old':120.,'new':cfg['s_curve']['jerk_degrees_s3']},
        'figure':out.relative_to(ROOT).as_posix(),
    }
    (REPORTS/'trajectory_smoothing_comparison.json').write_text(json.dumps(metrics,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(metrics,indent=2))

if __name__=='__main__':main()

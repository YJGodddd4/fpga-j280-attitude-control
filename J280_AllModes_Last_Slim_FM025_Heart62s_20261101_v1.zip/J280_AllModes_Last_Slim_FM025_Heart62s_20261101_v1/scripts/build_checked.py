from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,shutil,subprocess,sys,os

ROOT=Path(__file__).resolve().parents[1]
if len(sys.argv)!=1: raise SystemExit('Build this position-control project without arguments.')
PROJECT=ROOT
# [FAST_AB_10S修改] 新变体使用独立报告名，不覆盖v8.1基线报告。
VARIANT='allmodes_last_equivalent62s'
# [FAST_AB_10S修改] 按环境变量、本机安装、原路径、PATH顺序寻找Gowin；不运行下载器。
def find_gowin():
    candidates=[os.environ.get('J280_GOWIN_EXE'),
        r'D:\Gowin\Gowin_V1.9.12.03_x64\IDE\bin\gw_sh.exe',
        r'D:\GOWIN_gaoyun\Gowin\Gowin_V1.9.12.03_x64\IDE\bin\gw_sh.exe',
        r'D:\FPGA-gowin\Gowin\Gowin_V1.9.12.03_x64\IDE\bin\gw_sh.exe',
        shutil.which('gw_sh.exe')]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            return Path(candidate).resolve()
    attempted='; '.join(str(candidate) for candidate in candidates if candidate)
    raise SystemExit('找不到Gowin编译工具gw_sh.exe。请将J280_GOWIN_EXE设置为现有可执行文件的完整路径。已检查: '+attempted)
TOOL=find_gowin()
reports=ROOT/'reports';reports.mkdir(exist_ok=True)
with (reports/'trajectory_generation.log').open('wb') as generation_log:
    subprocess.run([sys.executable,'-X','utf8',str(ROOT/'scripts/generate_trajectory_tables.py')],
        cwd=ROOT,stdout=generation_log,stderr=subprocess.STDOUT,check=True,
        creationflags=subprocess.CREATE_NO_WINDOW)

# The GUI also needs this persisted setting; Tcl session options alone are not
# saved when the user reopens the project. Retain the config when packaging.
gui_config=PROJECT/'impl/J280_Pendulum_process_config.json'
gui_template=ROOT/'settings/J280_Pendulum_process_config.json'
gui_config.parent.mkdir(exist_ok=True)
if not gui_config.exists() and gui_template.exists():
    shutil.copyfile(gui_template,gui_config)
if gui_config.exists():
    raw=gui_config.read_bytes()
    raw=re.sub(rb'("SSPI"\s*:\s*)false',rb'\1true',raw)
    raw=re.sub(rb'("TopModule"\s*:\s*)"[^"]*"',rb'\1"j280_pendulum_top"',raw)
    gui_config.write_bytes(raw)
def hashes():
    pp=[PROJECT/'J280_Pendulum.gprj',*(p for p in (PROJECT/'rtl').glob('*') if p.suffix in {'.v','.vh','.mem'}),
        *(PROJECT/'constraints').glob('*'),*(PROJECT/'config').glob('*.json'),*(PROJECT/'scripts').glob('*.py'),PROJECT/'scripts/build.tcl',gui_template]
    if gui_config.exists():pp.append(gui_config)
    return {str(p.relative_to(PROJECT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(pp) if p.is_file()}
# Include all added synthesizable helpers before hashing/opening the project.
project=PROJECT/'J280_Pendulum.gprj'
project_text=project.read_text(encoding='utf-8')
added=[]
for source in sorted((PROJECT/'rtl').glob('*.v')):
    rel='rtl/'+source.name
    if f'path="{rel}"' not in project_text:
        added.append(f'    <File path="{rel}" type="file.verilog" enable="1"/>\n')
if added:
    project_text=project_text.replace('  </FileList>',''.join(added)+'  </FileList>')
    project.write_text(project_text,encoding='utf-8')
before=hashes()
print('Building '+VARIANT+'; no programmer or hardware commands are run.',flush=True)
with (reports/(VARIANT+'_gowin_build.log')).open('wb') as log:
    process=subprocess.run([str(TOOL),'scripts/build.tcl'],cwd=PROJECT,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
if process.returncode:
    print((reports/(VARIANT+'_gowin_build.log')).read_text(encoding='utf-8',errors='replace')[-14000:])
    raise SystemExit(process.returncode)
assert before==hashes(),'Source changed during build'
class Text(HTMLParser):
    def __init__(self):super().__init__();self.parts=[]
    def handle_data(self,s):
        if s.strip():self.parts.append(s.strip())
pnr=PROJECT/'impl/pnr'
parser=Text();parser.feed((pnr/'J280_Pendulum_tr_content.html').read_text(encoding='utf-8',errors='replace'))
parts=parser.parts
setup=int(parts[parts.index('Numbers of Setup Violated Endpoints')+1])
hold=int(parts[parts.index('Numbers of Hold Violated Endpoints')+1])
frequency_parts=parts[parts.index('Max Frequency Summary:'):parts.index('Total Negative Slack Summary:')]
values=[float(m.group(1)) for s in frequency_parts if (m:=re.fullmatch(r'([\d.]+)\(MHz\)',s))]
assert len(values)>=4,frequency_parts
assert setup==0 and hold==0,(setup,hold)
assert all(values[i+1]>=values[i] for i in range(0,len(values)-1,2)),frequency_parts
out=ROOT/'bitstream';out.mkdir(exist_ok=True)
# [FAST_AB_10S修改] 仅在原有时序与源码哈希检查通过后复制本变体固件。
name='J280_AllModes_Last_Equivalent62s.fs'
dest=out/name;shutil.copyfile(pnr/'J280_Pendulum.fs',dest)
summary={'variant':VARIANT,'exit_code':process.returncode,'setup_violations':setup,'hold_violations':hold,'frequency_summary':frequency_parts,'source_sha256':before,'bitstream_path':str(dest),'bitstream_sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'hardware_tested':False}
(reports/(VARIANT+'_build_summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
(reports/(VARIANT+'_timing.txt')).write_text('\n'.join(parts),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k!='source_sha256'},ensure_ascii=True,indent=2),flush=True)

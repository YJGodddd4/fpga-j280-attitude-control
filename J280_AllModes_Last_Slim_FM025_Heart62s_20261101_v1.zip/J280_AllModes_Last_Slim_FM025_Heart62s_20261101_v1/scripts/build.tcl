# 从任意工作目录执行：gw_sh.exe scripts/build.tcl
set project_root [file normalize [file join [file dirname [info script]] ..]]
open_project [file join $project_root J280_Pendulum.gprj]
set_option -top_module j280_pendulum_top
set_option -verilog_std v2001
set_option -cst_warn_to_error 1
set_option -use_sspi_as_gpio 1
run all

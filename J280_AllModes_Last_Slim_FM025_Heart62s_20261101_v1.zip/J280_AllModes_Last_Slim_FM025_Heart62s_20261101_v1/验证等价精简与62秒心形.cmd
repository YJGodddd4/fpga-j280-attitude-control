@echo off
setlocal
cd /d "%~dp0"
"%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -X utf8 tests\eq_rom_math.py
if errorlevel 1 exit /b 1
"%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" tests\equivalence_run.mjs
if errorlevel 1 exit /b 1
"%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" tests\ff_top.mjs
if errorlevel 1 exit /b 1
"%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" -E -X utf8 monitor\verify_unified_monitor.py
pause
